/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
// #ifdef_Target32Bit_
package com.sun.javacard.crypto;

import javacard.security.CryptoException;
import javacard.security.KeyAgreement;
import javacard.security.PrivateKey;

import com.sun.javacard.impl.NativeMethods;
import javacard.security.ECPrivateKey;

/** This class implements EC Diffie-Helmann key exchange agreement */
public class ECDHKeyAgreement extends KeyAgreement {

    private ECPrivateKey privKey;
    private byte algorithm;

    private byte[] temp_s_buffer;
    private byte[] temp_result_buffer;
    private com.sun.javacard.crypto.SHAMessageDigest md;

    /**
     * Creates an instance of the class
     * 
     * @param algorithm
     *            Only ALG_EC_SVDP_DH and ALG_EC_SVDP_DHC are currently
     *            supported
     * @param externalAccess
     *            Not supported and must be false
     */
    public ECDHKeyAgreement(byte algorithm, boolean externalAccess) {
        if ((algorithm == ALG_EC_SVDP_DH || algorithm == ALG_EC_SVDP_DHC || algorithm == ALG_EC_PACE_GM || algorithm == ALG_EC_SVDP_DH_PLAIN_XY) && !externalAccess) {
            this.algorithm = algorithm;
        } else {
            CryptoException.throwIt(CryptoException.NO_SUCH_ALGORITHM);
        }
    }

    /**
     * Gets the KeyAgreement algorithm.
     * 
     * @return the algorithm code defined above.
     * 
     * it can be ALG_EC_SVDP_DH or ALG_EC_SVDP_DHC
     */
    public byte getAlgorithm() {
        return algorithm;
    }

    /**
     * Initializes the object with the given private key.
     * 
     * @param privKey
     *            the private key
     * @exception CryptoException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>CryptoException.ILLEGAL_VALUE</code> if the
     *                input key type is inconsistent with the
     *                <code>KeyAgreement</code> algorithm, e.g. if the
     *                <code>KeyAgreement</code> algorithm is
     *                <code>ALG_EC_SVDP_DH</code> and the key type is
     *                <code>TYPE_RSA_PRIVATE</code>.</li>
     *                <li><code>CryptoException.UNINITIALIZED_KEY</code> if
     *                <code>privKey</code> is uninitialized, or if the
     *                <code>KeyAgreement</code> algorithm is set to
     *                <CODE>ALG_EC_SVDP_DHC</CODE> and the cofactor, K, has
     *                not been successfully initialized since the time the
     *                initialized state of the key was set to false.</li>
     *                </ul>
     * 
     */
    public void init(PrivateKey privKey) throws CryptoException {
        // check the type
        if (!(privKey instanceof ECSharedDomainPrivateKeyImpl)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        ECPrivateKey tmp = (ECPrivateKey) privKey; // cast

        // validate
        if (!tmp.isInitialized()) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }

        if (SecurityNativeMethods.validateDomainParameters(((ECMemoryPoolKey)tmp).getDomainMemoryPoolReference(), ((ECMemoryPoolKey)tmp).getOwnMemoryPoolReference(), null)) {
            // validate the K if necessary
            if (this.algorithm == ALG_EC_SVDP_DHC) {
                short k = tmp.getK(); // this throws UNINITIALIZED_KEY if K is
                // not set
                if (k <= 0) {
                    CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
                }
            }

            this.privKey = tmp; // store the key
        } else {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
    }

    /**
     * Generates the secret data as per the requested algorithm using the
     * PrivateKey specified during initialization and the public key data
     * provided.
     * 
     * Note that in the case of the algorithms <CODE>ALG_EC_SVDP_DH</CODE> and
     * <CODE>ALG_EC_SVDP_DHC</CODE> the public key data provided should be the
     * public elliptic curve point of the second party in the protocol,
     * specified as per ANSI X9.62. A specific implementation need not support
     * the compressed form, but must support the uncompressed form of the point.
     * 
     * @param publicKey
     *            buffer holding the public data of the second party
     * @param publicOffset
     *            offset into the publicKey buffer at which the data begins
     * @param publicLength
     *            byte length of the public data
     * @param secret
     *            buffer to hold the secret output
     * @param secretOffset
     *            offset into the secret array at which to start writing the
     *            secret
     * @return byte length of the secret
     * @exception CryptoException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>CryptoException.ILLEGAL_VALUE</code> if the
     *                publicKey data format is incorrect or inconsistent with
     *                the key length.
     *                </ul>
     * 
     */
    public short generateSecret(byte[] publicKey, short publicOffset, short publicLength, byte[] secret,
            short secretOffset) throws CryptoException {

        NativeMethods.checkArrayArgs(publicKey, publicOffset, publicLength);

        // the public key is an encoded point
        // check its format

        if (privKey == null) // forgot to call init
        {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }

        // the public key is an encoded point
        // check its format
        if (!privKey.isInitialized()) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }
        
        switch(algorithm){
            case ALG_EC_SVDP_DH:
            case ALG_EC_SVDP_DHC:
                NativeMethods.checkArrayArgs(secret, secretOffset, (short) 20);
                break;
                
            case ALG_EC_PACE_GM:
            case ALG_EC_SVDP_DH_PLAIN_XY:
                NativeMethods.checkArrayArgs(secret, secretOffset, (short) (privKey.getSize()/8 * 2 + 1));
                break;
                
            default:
                break;
        }

        if (this.algorithm == ALG_EC_SVDP_DHC) {
            privKey.getK(); // this throws UNINITIALIZED_KEY if K is not set
        }

        if (publicKey == null) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        if (publicLength % 2 == 0) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        if ((short) (publicOffset + publicLength) > (short) (publicKey.length)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        if (publicOffset < 0) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        if (publicLength < 3) { // the public key is at least: (tag, X, Y) = 3
            // bytes
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        if (publicKey[publicOffset] != 0x04) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        if (temp_s_buffer == null) {
            temp_s_buffer = new byte[24]; // max S size = 192/8
        }
        short s_size = privKey.getS(temp_s_buffer, (short) 0);

        if (temp_result_buffer == null) {
            temp_result_buffer = new byte[24]; // max X +Y size = 192/8 * 2 + 1
        }

        short res_len = -1;
        
        switch(algorithm){
            case ALG_EC_SVDP_DH:
                res_len = SecurityNativeMethods.ECSVDP_DH(temp_result_buffer, (short) 0, // destination
                    ((ECMemoryPoolKey)privKey).getDomainMemoryPoolReference(), // domain parameters
                    temp_s_buffer, s_size, // private key
                    publicKey, publicOffset, publicLength, // other's public
                    // key
                    (short)0, (short)0);
                break;
            case ALG_EC_SVDP_DHC:
                res_len = SecurityNativeMethods.ECSVDP_DHC(temp_result_buffer, (short) 0, // destination
                    ((ECMemoryPoolKey)privKey).getDomainMemoryPoolReference(), // domain parameters
                    temp_s_buffer, s_size, // private key
                    publicKey, publicOffset, publicLength); // other's public
                break;
            case ALG_EC_PACE_GM:
                res_len = SecurityNativeMethods.ECSVDP_DH(secret, secretOffset, // destination
                    ((ECMemoryPoolKey)privKey).getDomainMemoryPoolReference(), // domain parameters
                    temp_s_buffer, s_size, // private key
                    publicKey, publicOffset, publicLength, // other's public
                    // key
                    (short)1, (short)1);
                break;
            case ALG_EC_SVDP_DH_PLAIN_XY:
                res_len = SecurityNativeMethods.ECSVDP_DH(secret, secretOffset, // destination
                    ((ECMemoryPoolKey)privKey).getDomainMemoryPoolReference(), // domain parameters
                    temp_s_buffer, s_size, // private key
                    publicKey, publicOffset, publicLength, // other's public
                    // key
                    (short)0, (short)1);
                break;
                
            default:
                break;
        }

//        if (this.algorithm == ALG_EC_SVDP_DH) {
//            res_len = SecurityNativeMethods.ECSVDP_DH(temp_result_buffer, (short) 0, // destination
//                    ((ECMemoryPoolKey)privKey).getDomainMemoryPoolReference(), // domain parameters
//                    temp_s_buffer, s_size, // private key
//                    publicKey, publicOffset, publicLength // other's public
//                    // key
//                    );
//        } else {
//            res_len = SecurityNativeMethods.ECSVDP_DHC(temp_result_buffer, (short) 0, // destination
//                    ((ECMemoryPoolKey)privKey).getDomainMemoryPoolReference(), // domain parameters
//                    temp_s_buffer, s_size, // private key
//                    publicKey, publicOffset, publicLength); // other's public
//            // key
//        }

        if (res_len > 0 && (algorithm == ALG_EC_SVDP_DH || algorithm == ALG_EC_SVDP_DHC)) { // if completed normally
            // compute the SHA-1 of the result
            if (md == null) {
                md = new com.sun.javacard.crypto.SHAMessageDigest(javacard.security.MessageDigest.ALG_SHA);
            }

            short len = md.doFinal(temp_result_buffer, (short) 0, res_len, secret, secretOffset);

            return len;
        } else if(res_len > 0){
            return res_len;
        } else {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
            return 0; // unreachable
        }
    }
}
// #endif_Target32Bit_
