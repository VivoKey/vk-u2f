/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

import javacard.framework.JCSystem;
import javacard.framework.Util;
import javacard.security.CryptoException;
import javacard.security.SignatureMessageRecovery;

import com.sun.javacard.impl.NativeMethods;

/**
 * Note: Throughout this code, the padding field (t) is assumed to be 1
 */
public class RSASHAISO9796MRSignature extends com.sun.javacard.crypto.SignatureInternal implements SignatureMessageRecovery {
    private javacard.security.InitializedMessageDigest messageDigest;
    // The msgRepBuff is used as the representative buff during signing and
    // during verification the first 20 bytes are used for remembering the
    // digest
    // in the signature and the next 20 bytes used for accumulated hash.

    private boolean initFlag; // set during init() and must be checked at all
    // methods that expect initialization
    private byte beginVerify[];// marks when beginVerify is called. Used only
    // for
    // verification. This must be reset to 0 at card
    // reset in sync with the messagedigest and
    // msgRepBuff
    private RSAPrivateKeyImpl privKey;// only used for singning
    private RSAPublicKeyImpl pubKey;// only used for verification
    private byte mode;
    private short m1Copied;// The amount of incoming data copied into
    // msgRepBuff.
    // used for sing
    private short msgLen; // length of message passed in. Used for sign &
    // verify
    private byte[] msgRepBuff;// contains the message representative to
    // sign. Length is the modulus length. Only used
    // for sign.

    private static final short RSA_LEN_512_IN_BYTES = (short) 64;
    private static final short MAX_M1_LENGTH = RSA_LEN_512_IN_BYTES - (short) 21;
    private static final short MSGREP_DIGEST_OFFSET = RSA_LEN_512_IN_BYTES - (short) 21;// The
    // Offset into the msgRep buffer that digest must be copied to. The extra -1
    // is to convert length to offset since offset starts from 0.
    private static final short DIGEST_LENGTH = (short) 20;
    private static final short ACCUM_DIGEST_OFFSET = (short) 20;
    private static final short MSGREP_TRAILER_OFFSET = RSA_LEN_512_IN_BYTES - 1;
    private static final byte HEADER_PAD_FULL_MSG_REC = 0x40;// full msg
    // recovery
    private static final byte HEADER_PAD_PART_MSG_REC = 0x60;// partial msg
    // recovery
    private static final byte MAX_MSG_LEN = RSA_LEN_512_IN_BYTES;// setting

    // maximum
    // msgLen.

    /**
     * for methods of the SignatureInternal class that don't make sense, throw exception
     */
    public void init(javacard.security.Key theKey, byte theMode, byte[] bArray, short bOff, short bLen)
            throws CryptoException {
        CryptoException.throwIt(CryptoException.ILLEGAL_USE);
    }

    public short sign(byte[] inBuff, short inOff, short inLen, byte[] sigBuff, short sigOff) throws CryptoException {
        NativeMethods.sensitiveResultSetTagValUnassigned();
        CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        NativeMethods.sensitiveResultSet((short) 0);
        return (short) 0;
    }

    public boolean verify(byte[] inBuff, short inOff, short inLen, byte[] sigBuff, short sigOff, short sigLen)
            throws CryptoException {
        NativeMethods.sensitiveResultSetTagValUnassigned();
        CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        NativeMethods.sensitiveResultSetBooleanFalse();
        return false;
    }

    /**
     * allocates space for messageDigest buffer and instantiates messageDigest
     * object
     */
    public RSASHAISO9796MRSignature(byte algorithm, byte messageDigestAlgorithm, byte cipherAlgorithm, byte paddingAlgorithm) {
        super(algorithm, messageDigestAlgorithm, cipherAlgorithm, paddingAlgorithm);
        messageDigest = javacard.security.MessageDigest.getInitializedMessageDigestInstance(javacard.security.MessageDigest.ALG_SHA, false);
        initFlag = false;
        beginVerify = JCSystem.makeTransientByteArray((short) 1, JCSystem.CLEAR_ON_DESELECT);
        msgRepBuff = JCSystem.makeTransientByteArray(RSA_LEN_512_IN_BYTES, JCSystem.CLEAR_ON_DESELECT);
    }

    /**
     * Initializes the key and mode and sets the init flag. Also initializes all
     * the buffers. If key object modified after init() behavior is unspecified.
     * At the end of this method: 1. mode is set, 2. key references are set 3.
     * initFlag set to true 4. msgRepBuff is cleared 5. messageDigest object is
     * reset 6. For sign, m1Copied set to 0 and msgLen=0.
     * 
     * @param theKey
     *            the private key (incase of sign) or public key (for verify)
     * @param theMode
     *            either sign or verify
     */
    public void init(javacard.security.Key theKey, byte theMode) throws CryptoException {
        // verify key correspond to mode
        if ((theMode == MODE_SIGN) && (theKey instanceof com.sun.javacard.crypto.RSAPrivateKeyImpl)) {
            mode = MODE_SIGN;
            privKey = (com.sun.javacard.crypto.RSAPrivateKeyImpl) theKey;
        } else if ((theMode == MODE_VERIFY) && (theKey instanceof com.sun.javacard.crypto.RSAPublicKeyImpl)) {
            mode = MODE_VERIFY;
            pubKey = (com.sun.javacard.crypto.RSAPublicKeyImpl) theKey;
        } else {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
        if (!(mode == MODE_SIGN ? privKey.isInitialized() : pubKey.isInitialized())) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }

        messageDigest.reset();
        if (theMode == MODE_SIGN) {
            m1Copied = 0;
            msgLen = 0;
        }
        initFlag = true;
    }

    public void setInitialDigest(byte[] initialDigestBuf, short initialDigestOffset,
            short initialDigestLength, byte[] digestedMsgLenBuf, short digestedMsgLenOffset, short digestedMsgLenLength)
            throws CryptoException{
        CryptoException.throwIt(CryptoException.ILLEGAL_USE);;
    }

    public short getLength() {
        if (!initFlag) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }
        if (!(mode == MODE_SIGN ? privKey.isInitialized() : pubKey.isInitialized())) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }

        return RSA_LEN_512_IN_BYTES;
    }

    /**
     * capture (capacity-168) bits of data Two cases. 1. inLen <= remaining
     * space - copy inLen amount into msgRep 2. inLen > remaining space - copy
     * remaining amount
     */
    private void copyM1(byte[] inBuff, short inOff, short inLen) {
        short remainingSpace = (short) (MAX_M1_LENGTH - m1Copied);
        if (remainingSpace > 0) {
            if (inLen <= remainingSpace) {
                Util.arrayCopy(inBuff, inOff, msgRepBuff, m1Copied, inLen);
                m1Copied += inLen;
            } else {
                Util.arrayCopy(inBuff, inOff, msgRepBuff, m1Copied, remainingSpace);
                m1Copied += remainingSpace;
            }
        }
    }

    /**
     * calculate the intermediate hashes and also capture |M| amount of data in
     * the msgRepBuff buffer since we don't know the length of M1 But it must be <=
     * modulus length
     */
    public void update(byte[] inBuff, short inOff, short inLen) throws CryptoException {
        if (inLen == 0) {
            return;
        }
        if (!initFlag) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }
        if (mode == MODE_VERIFY && beginVerify[0] != (byte) 1) {
            CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        }

        if (!(mode == MODE_SIGN ? privKey.isInitialized() : pubKey.isInitialized())) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }
        /*
         * Input array bounds checking is not done as MessageDigest.update
         * does the same thing.
         */
        messageDigest.update(inBuff, inOff, inLen);
        /*
        * Note: We cap the msgLen variable at a MAX_MSG_LEN which is the modulus
        * length. In all the calculations involving msgLen this caping still works
        * because those calculations just care if msgLen is too big to fit inside
        * signature or not. We do this because if msgLen overflows, then calculations
        * could get messed up.
        */
        if (msgLen + inLen > MAX_MSG_LEN) {
            msgLen = MAX_MSG_LEN;
        } else {
            msgLen += inLen;
        }
        if (mode == MODE_SIGN) {
            copyM1(inBuff, inOff, inLen);
        }
    }

    /**
     * The method returns to the caller an indication to the number of left-most
     * bytes used for the recoverable part of message.
     * 
     * @param inBuff
     *            the last part of data accumulated for signing.
     * @param inOffset
     *            the offset to start reading data from
     * @param inLength
     *            length of data in inBuff starting from inOffset.
     * @param sigBuff
     *            the out-parameter that would containt the signature data after
     *            method returns.
     * @param sigBuffOffset
     *            offset in sigBuff where signature data would begin.
     * @param msgBytes
     *            out-parameter for number of left-most bytes used in M1.
     *            msgBytes[msgBytesOffset] represents the short value for the
     *            number of left-most bytes used in M1.
     * @return number of bytes output in sigBuff.
     */
    public short sign(byte[] inbuff, short inOffset, short inLength, byte[] sigBuff, short sigBuffOffset,
            short[] msgBytes, short msgBytesOffset) throws CryptoException {
        NativeMethods.sensitiveResultSetTagValUnassigned();
        // check initialized
        if (!initFlag) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }
        if (mode != MODE_SIGN) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }
        if (!privKey.isInitialized()) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }
        /**
         * Checking array bounds to throw the right kind of exception Input
         * array bounds checking is not done as MessageDigest.doFinal does the
         * same thing.
         */
        if (msgLen + inLength > MAX_MSG_LEN) {
            msgLen = MAX_MSG_LEN;
        } else {
            msgLen += inLength;
        }
        if (inLength != 0) {
            copyM1(inbuff, inOffset, inLength);
        }

        NativeMethods.checkArrayArgs(sigBuff, sigBuffOffset, RSA_LEN_512_IN_BYTES);
        /**
         * copy final digest into msgRepBuff. The doFinal does arrays checks on
         * inBuff, msgRepBuff
         */
        messageDigest.doFinal(inbuff, inOffset, inLength, msgRepBuff, MSGREP_DIGEST_OFFSET);
        /**
         * Set last byte to 0xBC since we know the hash algorithm. This is not
         * Configurable
         */
        msgRepBuff[MSGREP_TRAILER_OFFSET] = (byte) 0xBC;

        /**
         * calculate c*=m1Len = min(c-delta,|M|) where delta = (c-|M|) mod 8
         */
        short m1Len = 0;
        /* Message Allocation code below. All calculations in bits */
        /* calculate capacity of signature in bytes as:
        * c = modulusLengthBits - HashLengthBits - 8t -4
        * In this implementation, HashLength is 160 bytes, t=1 so,
        * c = modulusLength - 172 bits
        */

        /* Note: In the below calculations, <<3 and >>3 works because the number
        * multiplied or divided is not large enough to become negative
        */
        short capacity = (short) ((privKey.modulusLength << 3) - (short) 172);
        // Observation 1: delta represents the free space in the signature which
        // is not covered by an octet (so it is less than 8)
        // as long as |M| (length in bits) is a multiple of 8 (which it always
        // is
        // since we only deal with full bytes), |M| can be kep at a maximum
        // value
        // even if msgLen keeps increasing because (c - |M|) mod 8 will be the
        // same as long as |M| is greater than c and multiple of 8

        // Observation 2: delta is always 4 for us since capacity is always
        // 4 bits into a byte and |M| is always byte de-limited (multiple of 8).
        short delta = (short) 4;
        if ((capacity - delta) <= (msgLen << 3)) {
            m1Len = (short) (capacity - delta);
        } else {
            m1Len = (short) (msgLen << 3);
        }
        /**
         * convert m1Len from bits to bytes. Note, gauranteed that m1Len in bits
         * mod 8 = 0.
         */
        m1Len >>= 3;

        /**
         * There already should be data copied into msgRepBuff at index 0.
         * Figure out where the actual index starts and copy data to appropriate
         * location padLen is bumber of 0 bits padded before M1 starts.
         */
        short padLen = (short) ((RSA_LEN_512_IN_BYTES << 3) - 160 - (m1Len << 3) - 8 - 4);

        /**
         * M1 should be copied from (padLen+4)/8 byte index. Copy the M1 data
         * starting from index 0 in msgRepBuff to start from index calculated
         * with length |M1|.
         */
        Util.arrayCopyNonAtomic(msgRepBuff, (short) 0, msgRepBuff, (short) ((padLen + 4) >> 3), m1Len);

        /**
         * set header fields for partial msg rec or full msg rec
         */
        if (m1Len == msgLen) {
            msgRepBuff[(short) 0] = HEADER_PAD_FULL_MSG_REC;
        } else {
            msgRepBuff[(short) 0] = HEADER_PAD_PART_MSG_REC;
        }

        /**
         * pad the msgRepBuff so that padLen/8 number of bytes starting from 2nd
         * byte are 0. If padLen%8 !=0 => last byte needs to be xOrd with 0x01
         */
        Util.arrayFillNonAtomic(msgRepBuff, (short) 1, (short) ((padLen - 4) >> 3), (byte) 0x00);
        msgRepBuff[(short) (padLen >> 3)] |= (byte) 0x01;

        /**
         * process the msgRepBuff nibble at a time: leftmost nibble remains
         * unchanged if leftmostnibble has rightmost bit set to 0 then
         */
        if ((msgRepBuff[(short) 0] & 0x10) == 0) {
            // analyze the 2nd nibble
            boolean lastFound = false;
            if ((msgRepBuff[(short) 0] & 0x0F) == 0) {
                msgRepBuff[(short) 0] |= 0x0B;
            } else {
                // last padding 1 found.
                msgRepBuff[(short) 0] ^= 0x0B;
                lastFound = true;
            }
            short i = 1;
            while (!lastFound) {
                // get 1st nibble of msgRepBuff[i]
                if ((msgRepBuff[i] & 0xF0) == 0) {
                    msgRepBuff[i] |= 0xB0;
                } else {
                    msgRepBuff[i] ^= 0xB0;
                    lastFound = true;
                }

                if (!lastFound) {
                    // get 2nd nibble of msgRep[i]
                    if ((msgRepBuff[i] & 0x0F) == 0) {
                        msgRepBuff[i] |= 0x0B;
                    } else {
                        msgRepBuff[i] ^= 0x0B;
                        lastFound = true;
                    }
                }
                i++;
            }
        }
        /**
         * Note: no changes made to bitstring if leftmost nibble has rightmost
         * bit set to 1. Note that the message representative is k-1 bits and we
         * should ignore the first bit.
         */
        short resultLength = RSAISO9796MR.RSA_SIGN(privKey.modulus, privKey.modulusLength, privKey.exponent,
                privKey.exponentLength, msgRepBuff, RSA_LEN_512_IN_BYTES, sigBuff, sigBuffOffset);

        /* copy m1Length into msgBytes*/
        msgBytes[msgBytesOffset] = m1Len;

        /* must also reset state to what it was after init()*/
        messageDigest.reset();
        // clear the buffer
        Util.arrayFillNonAtomic(msgRepBuff, (short) 0, (short) msgRepBuff.length, (byte) 0);
        m1Copied = 0;
        msgLen = 0;
        
        NativeMethods.sensitiveResultSet(resultLength);
        return resultLength;
    }

    /**
     * Takes in the signature data and writes out the recoverable part of the
     * message to the buffer. Note: This method is mandatory and must be called
     * after init() and before either the update() or the verify(). It would
     * only make sense to call this method if mode in init() was verify. The
     * caller of this method must allocate enough space in the sigAndRecDataBuff
     * buffer that the method can write the recoverable part of message starting
     * at buffOffset.
     * 
     * @param sigAndRecDataBuff
     *            on entry, this array contains the signature data and on exit
     *            it contains the recoverable part of the message.
     * @param buffLength
     *            The length of signature data
     * @param bufOffset
     *            the offset into buffer
     * @return length of recoverable message data written to sigAndRecDataBuff
     */
    public short beginVerify(byte[] sigAndRecDataBuff, short buffOffset, short buffLength) throws CryptoException {
        if (!initFlag) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }
        if (mode != MODE_VERIFY) {
            CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        }
        if (!pubKey.isInitialized()) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }
        if (buffLength != RSA_LEN_512_IN_BYTES) {
            CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        }

        NativeMethods.checkArrayArgs(sigAndRecDataBuff, buffOffset, buffLength);
        // decrypt the signature and recover hash & recoverable message.
        short msgRepLength = RSAISO9796MR.RSA_SIG_DECRYPT_REC(pubKey.modulus, pubKey.modulusLength, pubKey.exponent,
                pubKey.exponentLength, sigAndRecDataBuff, buffOffset, buffLength, sigAndRecDataBuff, buffOffset);

        // By now the whole msgRep is in sigAndRecDataBuff at index buffOffset
        // First verify that the msgRep is properly formed as described in spec
        // if last octet not 0xBC, throw Exception. For us, the hash algorithm
        // is always SHA-1
        if (sigAndRecDataBuff[(short) (buffOffset + msgRepLength - 1)] != (byte) 0xBC) {
            CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        }
        // check the error condition that the first bit of message
        // representative
        // is 0. Since during representative generation, the first bit was
        // removed we should actually check if the 2nd bit is non zero for the
        // error condidtion. A good representative should have it's 2nd bit 1.
        if ((sigAndRecDataBuff[buffOffset] & 0x40) == 0) {
            CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        }

        // Check error condition where partial message recovery and yet more
        // than
        // 8 bits of 0 padding. i,e, more than or equal to two 0xB nibbles.
        if ((sigAndRecDataBuff[(short) (0 + buffOffset)] & 0x20) != 0 && // partial
                // msg
                // rec
                // with
                // 1
                // bit
                // 0
                // padding
                (sigAndRecDataBuff[(short) (0 + buffOffset)] & 0x0F) == 0x0B && // 2nd
                // nibble
                // all
                // 0s
                ((sigAndRecDataBuff[(short) (1 + buffOffset)] & 0xF0) == 0xA0 || // 3rd
                // nibble
                // all
                // 0s
                (sigAndRecDataBuff[(short) (1 + buffOffset)] & 0xF0) == 0xB0)) { // 3rd
            // nibble
            // has
            // 3
            // 0's
            CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        }

        // Go through the array and look for the nibble (ignoring the very
        // first)
        // that is not a '0xB' That is the final padding nibble. After that
        // starts
        // the actual data. Given that our interface would only allow byte-level
        // data, we can assume that the last padding nibble would be at the end
        // of the last padding byte.
        // We need to check that the above assumption is true or else throw
        // an exception
        short lastPadByteIndex;
        for (lastPadByteIndex = buffOffset; lastPadByteIndex < msgRepLength; lastPadByteIndex++) {
            if (lastPadByteIndex != buffOffset && // not the first nibble
                    (sigAndRecDataBuff[lastPadByteIndex] & (byte) 0xF0) != (byte) 0xB0) {
                // for all bytes after the first, the first nibble of the byte
                // is
                // not correctly padded. This implies recoverable data is not
                // byte alligned. Throw an exception
                CryptoException.throwIt(CryptoException.ILLEGAL_USE);
            }

            if ((sigAndRecDataBuff[lastPadByteIndex] & (byte) 0x0F) != (byte) 0x0B) {
                // found the last padding byte.
                // 2nd nibbles of all padding bytes including the first byte
                // must
                // be either 0xB (padding) or 0xA(last padding byte). We are
                // here
                // implies last padding byte. Check to see if it is 0xA or else
                // exception
                if ((sigAndRecDataBuff[lastPadByteIndex] & (byte) 0x0F) != (byte) 0x0A) {
                    CryptoException.throwIt(CryptoException.ILLEGAL_USE);
                }
                break;
            }
        }
        if (lastPadByteIndex == msgRepLength) {
            // last padding byte not found. Badly formed message representatice
            CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        }
        // recover the hash
        Util.arrayCopy(sigAndRecDataBuff, (short) (buffOffset + MSGREP_DIGEST_OFFSET), msgRepBuff, (short) 0,
                DIGEST_LENGTH);
        // recover recoverable message as the rest of data on the left
        short m1Length = (short) (buffOffset + MSGREP_DIGEST_OFFSET - (lastPadByteIndex + 1));
        if (m1Length < 0) {
            // padding too long and extending into the digest part of
            // representative
            CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        }
        Util.arrayCopy(sigAndRecDataBuff, (short) (lastPadByteIndex + 1), sigAndRecDataBuff, buffOffset, m1Length);
        // digest M1 into accumulated hash part of msgRepBuff
        messageDigest.update(sigAndRecDataBuff, buffOffset, m1Length);
        beginVerify[0] = 1;
        return m1Length;
    }

    /**
     * The verify method no longer takes the signature object as it did in the
 SignatureInternal class since it was given in the init() method. It would just
     * finalize the hash, compare with the one it remembers since init() and
     * return true or false.
     * 
     * @param inBuff
     *            the final piece of data for verifying signature.
     * @param inOffset
     *            the offset in inBuff where data begins
     * @param inLength
     *            the length of data.
     * @return true if calculated hash is same as signature hash, otherwise
     *         false.
     */
    public boolean verify(byte[] inBuff, short inOffset, short inLength) throws CryptoException {
        NativeMethods.sensitiveResultSetTagValUnassigned();
        
        if (!initFlag || mode != MODE_VERIFY) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }
        if (beginVerify[0] != 1) {
            CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        }
        /**
         * the following code sets the inBuff offset to 0 if inLength is 0. this
         * is done because messagedigest will throw exception if inOffset is out
         * of bounds even if length is 0
         */
        if (inLength > 0) {
            messageDigest.doFinal(inBuff, inOffset, inLength, msgRepBuff, ACCUM_DIGEST_OFFSET);
        } else {
            messageDigest.doFinal(inBuff, (short) 0, inLength, msgRepBuff, ACCUM_DIGEST_OFFSET);
        }
        boolean result = (Util.arrayCompare(msgRepBuff, (short) 0, msgRepBuff, ACCUM_DIGEST_OFFSET, DIGEST_LENGTH) == 0);
        // clear the msgRepBuff
        messageDigest.reset();
        beginVerify[0] = (byte) 0;
        Util.arrayFillNonAtomic(msgRepBuff, (short) 0, (short) msgRepBuff.length, (byte) 0);
        
        if (result)
            NativeMethods.sensitiveResultSetBooleanTrue();
        else
            NativeMethods.sensitiveResultSetBooleanFalse();
        
        return result;
    }

    public short signPreComputedHash(byte[] hashBuf, short hashOff, short hashLength, byte[] sigBuff, short sigOffset){
        NativeMethods.sensitiveResultSetTagValUnassigned();
        CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        NativeMethods.sensitiveResultSet((short) 0);
        return (short)0;
    }

    public boolean verifyPreComputedHash(byte[] hashBuff, short hashOffset, short hashLength, byte[] sigBuff, short sigOffset,
            short sigLength) throws CryptoException {
        
        NativeMethods.sensitiveResultSetTagValUnassigned();
        CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        NativeMethods.sensitiveResultSetBooleanFalse();
        return false;
    }
    
}
