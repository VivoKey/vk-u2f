/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */
package com.sun.javacard.crypto;

import com.sun.javacard.impl.NativeMethods;
import javacard.framework.JCSystem;
import javacard.framework.Util;
import javacard.security.CryptoException;
import javacard.security.ECKey;
import javacard.security.KeyBuilder;

/**
 *
 * 
 */
public class ECSharedDomainPrivateKeyImpl extends ECMemoryPoolKey implements javacard.security.ECPrivateKey{
    
    private static final byte MEMORY_POOL_SIZE = (byte) 7;

    private static final byte PRIVATE_KEY = (byte) 7;

    private boolean[] sInitialized;

    private byte[] privateKey;
    
    private ECKeyImpl sharedDomain = null;
    
    private byte[] memoryPool;
    
    private boolean shared;
    
    private byte keyType;

    public ECSharedDomainPrivateKeyImpl(byte type, javacard.security.Key sharedDomainParams) {
        short size = ((ECKeyImpl)sharedDomainParams).getSize();
        switch(type){
            case KeyBuilder.TYPE_EC_FP_PRIVATE:
                memoryPool = new byte[MEMORY_POOL_SIZE];
                privateKey = new byte[(byte) (size / 8 + ECKeyImpl.ALIGNMENT_SPACE + ECKeyImpl.BIGINT_STRUCT_SIZE)];
                sInitialized = new boolean[1];
                break;
                
            case KeyBuilder.TYPE_EC_FP_PRIVATE_TRANSIENT_DESELECT:
                memoryPool = JCSystem.makeTransientByteArray(MEMORY_POOL_SIZE, JCSystem.MEMORY_TYPE_TRANSIENT_DESELECT);
                privateKey = JCSystem.makeTransientByteArray((byte) (size / 8 + ECKeyImpl.ALIGNMENT_SPACE + ECKeyImpl.BIGINT_STRUCT_SIZE), JCSystem.MEMORY_TYPE_TRANSIENT_DESELECT);
                sInitialized = JCSystem.makeTransientBooleanArray((byte)1, JCSystem.MEMORY_TYPE_TRANSIENT_DESELECT);
                break;
                
            case KeyBuilder.TYPE_EC_FP_PRIVATE_TRANSIENT_RESET:
                memoryPool = JCSystem.makeTransientByteArray(MEMORY_POOL_SIZE, JCSystem.MEMORY_TYPE_TRANSIENT_RESET);
                privateKey = JCSystem.makeTransientByteArray((byte) (size / 8 + ECKeyImpl.ALIGNMENT_SPACE + ECKeyImpl.BIGINT_STRUCT_SIZE), JCSystem.MEMORY_TYPE_TRANSIENT_RESET);
                sInitialized = JCSystem.makeTransientBooleanArray((byte)1, JCSystem.MEMORY_TYPE_TRANSIENT_RESET);
                break;
                
            default:
                break;
        }      
        sharedDomain = (ECKeyImpl)sharedDomainParams;
        shared = true;
        keyType = type;
    }
    
    public ECSharedDomainPrivateKeyImpl(byte type, short size) {
        sharedDomain = new ECKeyImpl(type, size);
        switch(type){
            case KeyBuilder.TYPE_EC_FP_PRIVATE:
                memoryPool = new byte[MEMORY_POOL_SIZE];
                privateKey = new byte[(byte) (size / 8 + ECKeyImpl.ALIGNMENT_SPACE + ECKeyImpl.BIGINT_STRUCT_SIZE)];
                sInitialized = new boolean[1];
                break;
                
            case KeyBuilder.TYPE_EC_FP_PRIVATE_TRANSIENT_DESELECT:
                memoryPool = JCSystem.makeTransientByteArray(MEMORY_POOL_SIZE, JCSystem.MEMORY_TYPE_TRANSIENT_DESELECT);
                privateKey = JCSystem.makeTransientByteArray((byte) (size / 8 + ECKeyImpl.ALIGNMENT_SPACE + ECKeyImpl.BIGINT_STRUCT_SIZE), JCSystem.MEMORY_TYPE_TRANSIENT_DESELECT);
                sInitialized = JCSystem.makeTransientBooleanArray((byte)1, JCSystem.MEMORY_TYPE_TRANSIENT_DESELECT);
                break;
                
            case KeyBuilder.TYPE_EC_FP_PRIVATE_TRANSIENT_RESET:
                memoryPool = JCSystem.makeTransientByteArray(MEMORY_POOL_SIZE, JCSystem.MEMORY_TYPE_TRANSIENT_RESET);
                privateKey = JCSystem.makeTransientByteArray((byte) (size / 8 + ECKeyImpl.ALIGNMENT_SPACE + ECKeyImpl.BIGINT_STRUCT_SIZE), JCSystem.MEMORY_TYPE_TRANSIENT_RESET);
                sInitialized = JCSystem.makeTransientBooleanArray((byte)1, JCSystem.MEMORY_TYPE_TRANSIENT_RESET);
                break;
                
            default:
                break;
        }
        shared = false;
        keyType = type;
    }

    public void setS(byte buffer[], short offset, short length) {

        if (length > (short) (sharedDomain.getSize() / 8)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        NativeMethods.checkArrayArgs(buffer, offset, length);
        SecurityNativeMethods.setECDomainParameter(isPersistent(), buffer, offset, length, PRIVATE_KEY, memoryPool, privateKey);
        sInitialized[0] = true;
    }

    public short getS(byte buffer[], short offset) {

        if (sInitialized[0] == false) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }

        NativeMethods.checkArrayArgs(buffer, offset, (short) (sharedDomain.getSize() / 8));
        return SecurityNativeMethods.getECDomainParameter(PRIVATE_KEY, memoryPool, buffer, offset);
    }

    public boolean isInitialized() {
        if ((sharedDomain.isInitialized()) && (sInitialized[0])) {
            return true;
        } else {
            return false;
        }
    }

    public void clearKey() {
        if(!shared){
            sharedDomain.clearKey();
        }
        Util.arrayFillNonAtomic(privateKey, (short) 0, (short) privateKey.length, (byte) 0);
        sInitialized[0] = false;
    }

    public short getSize() {
        return sharedDomain.getSize();
    }

    public byte getType() {
        return keyType;
    }

    public void setFieldFP(byte[] buffer, short offset, short length) throws CryptoException {
        sharedDomain.setFieldFP(buffer, offset, length);
    }

    public void setFieldF2M(short e) throws CryptoException {
        sharedDomain.setFieldF2M(e);
    }

    public void setFieldF2M(short e1, short e2, short e3) throws CryptoException {
        sharedDomain.setFieldF2M(e1, e2, e3);
    }

    public void setA(byte[] buffer, short offset, short length) throws CryptoException {
        sharedDomain.setA(buffer, offset, length);
    }

    public void setB(byte[] buffer, short offset, short length) throws CryptoException {
        sharedDomain.setB(buffer, offset, length);
    }

    public void setG(byte[] buffer, short offset, short length) throws CryptoException {
        sharedDomain.setG(buffer, offset, length);
    }

    public void setR(byte[] buffer, short offset, short length) throws CryptoException {
        sharedDomain.setR(buffer, offset, length);
    }

    public void setK(short K) {
        sharedDomain.setK(K);
    }

    public short getField(byte[] buffer, short offset) throws CryptoException {
        return sharedDomain.getField(buffer, offset);
    }

    public short getA(byte[] buffer, short offset) throws CryptoException {
        return sharedDomain.getA(buffer, offset);
    }

    public short getB(byte[] buffer, short offset) throws CryptoException {
        return sharedDomain.getB(buffer, offset);
    }

    public short getG(byte[] buffer, short offset) throws CryptoException {
        return sharedDomain.getG(buffer, offset);
    }

    public short getR(byte[] buffer, short offset) throws CryptoException {
        return sharedDomain.getR(buffer, offset);
    }

    public short getK() throws CryptoException {
        return sharedDomain.getK();
    }
    
    private short isPersistent(){
        switch(keyType){
            case KeyBuilder.TYPE_EC_FP_PRIVATE:
                return PERSISTENT;
            default:
                return NON_PERSISTENT;
        }
    }
    
    public void copyDomainParametersFrom(ECKey ecKey) throws CryptoException {
        sharedDomain.copyDomainParametersFrom(ecKey);
    }

    byte[] getOwnMemoryPoolReference() {
        return memoryPool;
    }

    byte[] getDomainMemoryPoolReference() {
        return sharedDomain.getDomainMemoryPoolReference();
    }

    boolean isDomainInitialized() {
        return sharedDomain.isDomainInitialized();
    }
    
}
