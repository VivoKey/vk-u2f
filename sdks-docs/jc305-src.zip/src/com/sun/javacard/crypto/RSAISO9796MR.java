/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

/*
 * @(#)RSAISO9796MR.java	1.2 05/05/05
 */
/**
 * This class encapsulates methods used for Signature with message recovery.
 */
import javacard.security.CryptoException;

final class RSAISO9796MR {
    /**
     * This method takes in the data and encrypts with the key information
     * given.
     * 
     * @param n
     *            the key modulus
     * @param nLength
     *            modulus length in bytes
     * @param e
     *            exponent
     * @param eLength
     *            the exponent length in bytes
     * @param H
     *            the digest
     * @param hLength
     *            the length of data in H
     * @param S
     *            The signature buffer
     * @param Soffset
     *            the offset into S where signature writing should begin
     * @return length of signature in bytes
     */
    public static short RSA_SIGN(byte[] n, short nLength, byte[] e, short eLength, byte[] H, short hLength, byte[] S,
            short SoffSet) throws CryptoException {

        return SecurityNativeMethods.RSA_SIGN(n, nLength, e, eLength, H, hLength, S, SoffSet);
    }

    /**
     * message decrypts the buffer sigBuff, writes the message representative
     * into buffer msgRep
     * 
     * @param n
     *            the key modulus
     * @param nLength
     *            modulus length in bytes
     * @param e
     *            exponent
     * @param eLength
     *            the exponent length in bytes
     * @param sigBuff
     *            the signature data buffer
     * @param sigBuffOffset
     *            the offset into the sigBuff array where data begins
     * @param sigBuffLength
     *            the length of data in sigBuff array
     * @param msgRep
     *            out-parameter to capture the decrypted data
     * @param msgRepOffset
     *            The offset into the msgRep array where data will be written
     * @return the number of bytes of data written to msgRep
     * 
     */
    public static short RSA_SIG_DECRYPT_REC(byte[] n, short nLength, byte[] e, short eLength, byte[] sigBuff,
            short sigBuffOffset, short sigBuffLength, byte[] msgRep, short msgRepOffset) throws CryptoException {
        // first allocate space for msgRep decryption. size same as signature
        return SecurityNativeMethods.RSA_SIG_DECRYPT_REC(n, nLength, e, eLength, sigBuff, sigBuffOffset, sigBuffLength,
                msgRep, msgRepOffset);
    }
}
