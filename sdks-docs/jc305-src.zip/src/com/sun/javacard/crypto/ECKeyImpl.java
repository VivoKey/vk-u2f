/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
// #ifdef_Target32Bit_
package com.sun.javacard.crypto;

import javacard.framework.Util;
import javacard.security.CryptoException;
import javacard.security.ECKey;

import com.sun.javacard.impl.NativeMethods;

public class ECKeyImpl extends ECMemoryPoolKey implements ECKey, javacard.security.Key {

    /*
     * This is an implementation of the javacard.security.ECKey interface.
     * See the interface for a description of each of the public methods.
     */

    /*
     * Constant to indicate type of domain parameter.
     * See ECImpl.h for complete list of implemntation specific constants.
     */

    private static final byte A_PARM = (byte) 1;
    private static final byte B_PARM = (byte) 2;
    private static final byte FIELD_PARM = (byte) 3;
    private static final byte GX_PARM = (byte) 4;
    private static final byte GY_PARM = (byte) 5;
    private static final byte R_PARM = (byte) 6;

    /**
     * The below constants represent the size of the byte array needed to store
     * the C structure that holds the domain parameters and the alignment value
     * used to align the storage for individual values of the domain parameters.
     * The size of the byte array needed to hold the domain parameter structure
     * will vary based on the size of a pointer. For Solaris and Windows,
     * pointers will be 4 bytes or 32 bits. The structure contains 9 pointers
     * and a 16 bit value. Additionally, 3 more bytes will be needed in case the
     * address of the structure needs to be aligned. The 9 pointers, 2 byte
     * value and the alignment space make up MEMORY_POOL_SIZE. The size of the
     * byte arrays used to store the individual domain parameter values is based
     * on the EC Key size divided by 8 plus the below alignment constant plus
     * space for the BigInteger Structure information related to the value. If
     * E2P space is at a premium, these values could be stored as byte arrays
     * and later converted to a Big Integer value. The reason it is not done
     * here is that it would require more RAM to later create these big Integer
     * structures and in general, RAM is usually a more scarce resource. So this
     * implementation has been optimized to use less RAM at the cost of E2P
     * space. Even though this storage is used in C, it is allocated here, so
     * that if the key object is ever Garbage Collected, the internal C
     * strucures for the key will automatically be collected as well.
     */
    protected static final byte MEMORY_POOL_SIZE = (byte) 29;
    protected static final byte ALIGNMENT_SPACE = (byte) 5;
    /*
     * the BIGINT_STRUCT_SIZE is based on a pointer that is 4 bytes long
     * and three 1 byte fields.
     */
    protected static final byte BIGINT_STRUCT_SIZE = (byte) 7;

    /* Flags to indicate initialization state */
    private boolean fieldFPInitialized = false;
    private boolean aInitialized = false;
    private boolean bInitialized = false;
    private boolean gInitialized = false;
    private boolean rInitialized = false;
    private boolean kInitialized = false;

    private byte keyType;
    private short keyLength;

    private byte[] memoryPool;
    private byte[] fieldFP;
    private byte[] A;
    private byte[] B;
    private byte[] R;
    private byte[] GX;
    private byte[] GY;
    
    private byte[] tempCopyBuffer;
    
    public ECKeyImpl(byte type, short bitLength){
        initializeDomainStorage(type, bitLength);
    }

    public void setFieldFP(byte[] buffer, short offset, short length) throws CryptoException {
        if ((length != (short) (keyLength / 8)) || ((buffer[offset] & (byte) 0x80) == 0)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
        setECParameter(buffer, offset, length, FIELD_PARM, fieldFP);
        fieldFPInitialized = true;
    }

    public void setFieldF2M(short e) throws CryptoException {
        CryptoException.throwIt(CryptoException.NO_SUCH_ALGORITHM);
    }

    public void setFieldF2M(short e1, short e2, short e3) throws CryptoException {
        CryptoException.throwIt(CryptoException.NO_SUCH_ALGORITHM);
    }

    public void setA(byte[] buffer, short offset, short length) throws CryptoException {
        setECParameter(buffer, offset, length, A_PARM, A);
        aInitialized = true;
        return;
    }

    public void setB(byte[] buffer, short offset, short length) throws CryptoException {
        setECParameter(buffer, offset, length, B_PARM, B);
        bInitialized = true;
        return;
    }

    public void setG(byte[] buffer, short offset, short length) throws CryptoException {
        NativeMethods.checkArrayArgs(buffer, offset, length);

        if (buffer[offset] != 0x04) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        short lengthX = (short) ((length - 1) / (short) 2);

        short tempOffset = (short) (offset + 1);
        // Set values
        setECParameter(buffer, tempOffset, lengthX, GX_PARM, GX);
        tempOffset += lengthX;
        setECParameter(buffer, tempOffset, lengthX, GY_PARM, GY);
        gInitialized = true;
        return;
    }

    public void setR(byte[] buffer, short offset, short length) throws CryptoException {
        setECParameter(buffer, offset, length, R_PARM, R);
        rInitialized = true;
        return;
    }

    public void setK(short K) throws CryptoException {

        SecurityNativeMethods.setK(K, memoryPool);
        kInitialized = true;
        return;
    }

    public short getField(byte[] buffer, short offset) throws CryptoException {

        if (fieldFPInitialized != true) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }

        return getECParameter(buffer, offset, FIELD_PARM);
    }

    public short getA(byte[] buffer, short offset) throws CryptoException {

        if (aInitialized != true) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }

        return getECParameter(buffer, offset, A_PARM);
    }

    public short getB(byte[] buffer, short offset) throws CryptoException {

        if (bInitialized != true) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }

        return getECParameter(buffer, offset, B_PARM);
    }

    public short getG(byte[] buffer, short offset) throws CryptoException {

        if (gInitialized != true) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }

        buffer[offset] = 0x04;
        // get x and y coordinates of G
        short xLength = getECParameter(buffer, (short) (offset + 1), GX_PARM);
        short yLength = getECParameter(buffer, (short) (offset + xLength + 1), GY_PARM);
        short xySize = xLength > yLength ? xLength : yLength;
        short totalSize = (short) (2 * xySize + 1);

        /*
         * A very large percentage of the time, X and Y will be the same size,
         * but for those few times this is not true, we need to pad appropriately.
         * To allow this to happen without use of another buffer (transient RAM
         * memory), X and Y are retrieved into buffer again with appropriate 0
         * padding. Repeat, this should happen very infrequently.
         */
        if (xLength != yLength) {
            NativeMethods.arrayFillNonAtomicForSensitiveArrays(buffer, (short) (offset + 1), totalSize, (byte) 0);
            getECParameter(buffer, (short) (offset + xySize - xLength + 1), GX_PARM);
            getECParameter(buffer, (short) (offset + totalSize - yLength), GY_PARM);
        }

        return totalSize;
    }

    public short getR(byte[] buffer, short offset) throws CryptoException {

        if (rInitialized != true) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }

        return getECParameter(buffer, offset, R_PARM);
    }

    public short getK() throws CryptoException {

        if (kInitialized != true) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }

        return SecurityNativeMethods.getK(memoryPool);
    }

    /*
     * getSize, getType and isInitialized and clearKey are protected methods
     * here that support functionality in the public methods in ECPrivateKey
     * and ECPublicKey. The functionality is here, since the values are kept
     * here.
     */
    public short getSize() {
        return keyLength;
    }

    public byte getType() {
        return keyType;
    }

    public boolean isInitialized() {
        if ((fieldFPInitialized) && (aInitialized) && (bInitialized) && (gInitialized) && (rInitialized)) {
            return true;
        } else {
            return false;
        }
    }

    public void clearKey() {
        Util.arrayFillNonAtomic(fieldFP, (short) 0, (short) fieldFP.length, (byte) 0);
        fieldFPInitialized = false;
        Util.arrayFillNonAtomic(A, (short) 0, (short) A.length, (byte) 0);
        aInitialized = false;
        Util.arrayFillNonAtomic(B, (short) 0, (short) B.length, (byte) 0);
        bInitialized = false;
        Util.arrayFillNonAtomic(GX, (short) 0, (short) GX.length, (byte) 0);
        Util.arrayFillNonAtomic(GY, (short) 0, (short) GY.length, (byte) 0);
        gInitialized = false;
        Util.arrayFillNonAtomic(R, (short) 0, (short) R.length, (byte) 0);
        rInitialized = false;
        setK((short) 0);
        kInitialized = false;
    }

    /**
     * Method called by ECPrivateKey and ECPublicKey constructor to initialize
     * storage for domain parameters and to set the keyType and Length.
     * 
     * @param type
     *            The type of key
     * @param bitLength
     *            The bit Length of the key.
     */
    private void initializeDomainStorage(byte type, short bitLength) {
        memoryPool = new byte[MEMORY_POOL_SIZE];
        // R needs 1 more byte, since it can be one byte longer than the key
        // length
        fieldFP = new byte[(byte) (bitLength / 8 + ALIGNMENT_SPACE + BIGINT_STRUCT_SIZE)];
        A = new byte[(byte) (bitLength / 8 + ALIGNMENT_SPACE + BIGINT_STRUCT_SIZE)];
        B = new byte[(byte) (bitLength / 8 + ALIGNMENT_SPACE + BIGINT_STRUCT_SIZE)];
        R = new byte[(byte) (bitLength / 8 + ALIGNMENT_SPACE + BIGINT_STRUCT_SIZE + 1)];
        GX = new byte[(byte) (bitLength / 8 + ALIGNMENT_SPACE + BIGINT_STRUCT_SIZE)];
        GY = new byte[(byte) (bitLength / 8 + ALIGNMENT_SPACE + BIGINT_STRUCT_SIZE)];
        keyType = type;
        keyLength = bitLength;
        tempCopyBuffer = new byte[(byte) (bitLength / 4 + 1)];
    }

    /**
     * Private utility method used to do the work for all of the "set" methods
     * above.
     * 
     * @param buffer
     *            the value to set.
     * @param offset
     *            the offset where the value starts.
     * @param length
     *            the length of the value.
     * @param parameterType
     *            The type of parameter.
     * @param memoryPool2
     *            The storage for the value in the internal domain parameter
     *            structure.
     */
    private void setECParameter(byte[] buffer, short offset, short length, byte parameterType, byte[] memoryPool2)
            throws CryptoException {

        NativeMethods.checkArrayArgs(buffer, offset, length);

        if (length == 0) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        if (parameterType == R_PARM && (length > ((short) (keyLength / 8) + 1))) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        } else if (parameterType != R_PARM && length > (short) (keyLength / 8)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        if (!SecurityNativeMethods.setECDomainParameter(PERSISTENT, buffer, offset, length, parameterType, memoryPool, memoryPool2)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
    }

    /**
     * Private utility method used to do the work for all of the "get" methods
     * above.
     * 
     * @param buffer
     *            The buffer where the requested value is returned.
     * @param offset
     *            The offset were the value is to be placed in the buffer.
     * @param parameterType
     *            The type of parameter that is to be returned.
     * @return the length of the returned value.
     */
    private short getECParameter(byte[] buffer, short offset, byte parameterType) throws CryptoException {
        return SecurityNativeMethods.getECDomainParameter(parameterType, memoryPool, buffer, offset);
    }
    
    public void copyDomainParametersFrom(ECKey ecKey) throws CryptoException{
        if(ecKey == null || !(ecKey instanceof javacard.security.Key)){
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
        if(!(ecKey instanceof ECMemoryPoolKey)){
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
        if(((javacard.security.Key)ecKey).getSize() != getSize()){
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
        if(!((ECMemoryPoolKey)ecKey).isDomainInitialized()){
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }
        if(!SecurityNativeMethods.validateDomainParameters(((ECMemoryPoolKey)ecKey).getDomainMemoryPoolReference(), null, null)){
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
        short len = ecKey.getField(tempCopyBuffer, (short)0);
        setFieldFP(tempCopyBuffer, (short)0, len);
        len = ecKey.getA(tempCopyBuffer, (short)0);
        setA(tempCopyBuffer, (short)0, len);
        len = ecKey.getB(tempCopyBuffer, (short)0);
        setB(tempCopyBuffer, (short)0, len);
        len = ecKey.getR(tempCopyBuffer, (short)0);
        setR(tempCopyBuffer, (short)0, len);
        len = ecKey.getG(tempCopyBuffer, (short)0);
        setG(tempCopyBuffer, (short)0, len);
        try{
            setK(ecKey.getK());
        }catch(CryptoException e){
            
        }
    }

    byte[] getOwnMemoryPoolReference() {
        return null;
    }

    byte[] getDomainMemoryPoolReference() {
        return memoryPool;
    }

    boolean isDomainInitialized() {
        return isInitialized();
    }
}
// #endif_Target32Bit_
