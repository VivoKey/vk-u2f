/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

public abstract class RandomDataInternal extends javacard.security.RandomData {
    //private byte algorithm;

    public RandomDataInternal(byte algorithm) {
        //this.algorithm = algorithm;
    }

}
