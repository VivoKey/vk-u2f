/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

import javacard.security.CryptoException;

/**
 * This class implements RSA PKCS#1 v1.5. It was coded according to PKCS#1 v2.0,
 * to facilitate future compliance with 2.0.
 * 
 */

final class PKCS1 {

    /**
     * Carries out the 4 steps of the RSA PKCS#1 Encryption Process which are:
     * 1. Encryption Block formatting 2. Byte array to integer conversion 3. RSA
     * computation 4. Integer to byte array conversion
     * 
     * @param n
     *            the modulus for the RSA computation.
     * @param modLength
     *            the length of the modulus.
     * @param e
     *            the exponent for the RSA computation.
     * @param expLength
     *            the length of the exponent.
     * @param M
     *            the message to encrypt.
     * @param MLength
     *            the length of the message.
     * @param C
     *            The result.
     * @param offSet
     *            Offset into the result.
     * @param BT
     *            The type
     */
    static public short RSAES_V15_ENCRYPT(byte[] n, short modLength, byte[] e, short expLength, byte[] M,
            short MLength, byte[] C, short offSet, byte BT) throws CryptoException {

        /*
         *  The message length must not be longer than
         *  modLength-11 bytes according to the PKCS#1 standard
         */
        if (MLength > modLength - 11) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        if ((BT != 0x02) && (BT != 0x01)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        return SecurityNativeMethods.RSAES_V15_ENCRYPT(n, modLength, e, expLength, M, MLength, C, offSet, BT);
    }

    /**
     * Implements the RSA Decryption process. Basically there are 4 steps: 1.
     * Byte array to integer conversion 2. RSA computation 3. Integer to byte
     * array conversion 4. Encryption block parsing
     */
    public static short RSADS_V15_DECRYPT(byte[] n, short nLength, byte[] d, short dLength, byte[] c, byte[] M,
            short offSet) throws CryptoException {

        // If the length of the encrypted data is not nLength then there is an
        // error
        if (c.length != nLength) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
        short result = SecurityNativeMethods.RSADS_V15_DECRYPT(n, nLength, d, dLength, c, M, offSet);

        if (result < 0) {
            CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        }
        return result;
    }

    /**
     * This module implements DER Encoding of SHA MessageDigest Implements the 4
     * steps of the RSA PKCS#1 Signature process which are: 1. Message digesting
     * 2. Data encoding 3. RSA Encryption 4. Byte array to bit string conversion
     */
    public static short RSASA_V15_SIGN(byte[] n, short nLength, byte[] e, short eLength, byte[] H, byte[] S,
            short SoffSet) throws CryptoException {

        if (H.length != 20) {
            CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        }

        return SecurityNativeMethods.RSASA_V15_SIGN(n, nLength, e, eLength, H, S, SoffSet);
    }

    /**
     * Implements the 4 steps of the RSA PKCS#1 verify process which are: 1. Bit
     * string to Byte array conversion 2. RSA Decryption 3. Data decoding 4.
     * Message digesting and comparison
     */
    public static boolean RSASA_V15_VERIFY(byte[] n, short nLength, byte[] e, short eLength, byte[] H, byte[] S,
            short SoffSet, short SLen) throws CryptoException {

        if (SLen != nLength) {
            return false;
        }

        return SecurityNativeMethods.RSASA_V15_VERIFY(n, nLength, e, eLength, H, S, SoffSet, SLen);
    }
}
