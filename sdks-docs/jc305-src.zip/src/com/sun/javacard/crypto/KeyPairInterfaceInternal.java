/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

import javacard.security.CryptoException;
import javacard.security.PrivateKey;
import javacard.security.PublicKey;

public interface KeyPairInterfaceInternal {

    public PublicKey getPublic();

    public PrivateKey getPrivate();

    public void genKeyPair() throws CryptoException;

}
