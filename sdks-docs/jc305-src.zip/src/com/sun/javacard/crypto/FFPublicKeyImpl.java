/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */
package com.sun.javacard.crypto;

import com.sun.javacard.impl.NativeMethods;
import javacard.framework.JCSystem;
import javacard.framework.Util;
import javacard.security.CryptoException;
import javacard.security.DHPublicKey;
import javacard.security.KeyBuilder;

/**
 *
 * 
 */
public class FFPublicKeyImpl extends FFKeyImpl implements DHPublicKey{

    private static final byte PUBLIC_KEY = (byte) 5;
    
    private boolean[] yInitialized;

    private byte[] Y;
    
    public FFPublicKeyImpl(byte type, short bitLength) {
        super.initializeDomainStorage(type, bitLength);
        switch(type){
            case KeyBuilder.TYPE_DH_PUBLIC:
                Y = new byte[(short) (super.getSize() / 8 + super.ALIGNMENT_SPACE + super.BIGINT_STRUCT_SIZE)];
                yInitialized = new boolean[(short)1];
                break;
                
            case KeyBuilder.TYPE_DH_PUBLIC_TRANSIENT_RESET:
                Y = JCSystem.makeTransientByteArray((short) (super.getSize() / 8 + super.ALIGNMENT_SPACE + super.BIGINT_STRUCT_SIZE), JCSystem.MEMORY_TYPE_TRANSIENT_RESET);
                yInitialized = JCSystem.makeTransientBooleanArray((short)1, JCSystem.MEMORY_TYPE_TRANSIENT_RESET);
                break;
                
            default:
                break;
        }
    }

    public void setY(byte[] buffer, short offset, short length) throws CryptoException {
        NativeMethods.checkArrayArgs(buffer, offset, length);
        if(length == 0){
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
        if (length > (short) (super.getSize() / 8)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
        SecurityNativeMethods.setFFDomainParameter(isPersistent(), buffer, offset, length, PUBLIC_KEY, super.memoryPool, Y);
        yInitialized[(short)0] = true;
    }

    public short getY(byte[] buffer, short offset) {
        if (yInitialized[(short)0] == false) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }

        return SecurityNativeMethods.getFFDomainParameter(PUBLIC_KEY, super.memoryPool, buffer, offset);
    }

    public boolean isInitialized() {
        return ((super.isInitialized()) && (yInitialized[(short)0]));
    }

    public void clearKey() {
        super.clearKey();
        Util.arrayFillNonAtomic(Y, (short) 0, (short) Y.length, (byte) 0);
        yInitialized[(short)0] = false;
    }

    public byte getType() {
        return super.getType();
    }

    public short getSize() {
        return super.getSize();
    }
    
}
