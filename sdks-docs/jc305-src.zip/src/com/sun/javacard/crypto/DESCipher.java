/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

import javacard.framework.JCSystem;
import javacard.framework.Util;
import javacard.security.CryptoException;
import javacard.security.KeyBuilder;

import com.sun.javacard.impl.NativeMethods;

/**
 * Base class providing common functionality for DES ciphers. Please note, only
 * single key and 2 key triple DES are supported. Padding is implemented using a
 * variation on the Factory Method Pattern. A reference to an interface is
 * maintained here in the base class, and each concrete subclass instantiates
 * the appropriate Padder object. The factory method happens to be the
 * constructor of the concrete subclass
 */
public abstract class DESCipher extends CipherInternal {
    /*This class is the base class for all DES ciphers. Although strictly speaking
     *it could be instantiated, it would be incorrect to do so since no padding
     *scheme is implemented, therefore this class is declared abstract to avoid
     *such mistakes.
     */

    /**
     * Indicates that the cipher has not been initialized for encryption or
     * decryption yet
     */
    private final static byte MODE_UNINITIALIZED = -1;

    /**
     * DES ciphers encrypt/decrypt in block size of 8 bytes
     */
    protected final static short BLOCK_SIZE = 8;

    /**
     * ENCRYPT or DECRYPT
     */
    protected byte[] mode;
    protected byte modeNonTransient;

    /**
     * The Key
     */
    private Object[] dk;
    private Object dkNonTransient;

    /**
     * Work space
     */
    private byte[] holdCount;

    private byte[] intermediateOutput;
    private byte[] data;
    private byte[] holdData;

    /**
     * The object used to implement the padding scheme of concrete cipher
     * objects The padder is implemented as a separate object to enable sharing
     * of padding schemes
     */
    protected Padder padder;

    /**
     * A circular queue used to store data blocks entered using 'update'. This
     * queue is necessary because DES operates on 8 byte blocks, but there is no
     * requirement on the user to pass in data in multiples of 8 bytes. The
     * queue is used as an 8 byte buffer which stores the trailing bytes of each
     * input block between successive updates. This way we ensure that each
     * cipher block is indeed 8 bytes
     */
    protected CircularQueue circular = null;

    public DESCipher(byte algorithm, byte cipherAlgorithm, byte paddingAlgorithm) {
        super(algorithm, cipherAlgorithm, paddingAlgorithm);
        /*The maximum length in bytes for keyData can be 24 bytes in the case
         *of triple DES with 3 keys, but we are only going to implement 2 key triple DES,
         *so we will only use 16 bytes.
         */
        circular = new CircularQueue((short) (2 * BLOCK_SIZE));
        intermediateOutput = JCSystem.makeTransientByteArray((BLOCK_SIZE), JCSystem.CLEAR_ON_DESELECT);
        data = JCSystem.makeTransientByteArray((BLOCK_SIZE), JCSystem.CLEAR_ON_DESELECT);
        holdData = JCSystem.makeTransientByteArray((BLOCK_SIZE), JCSystem.CLEAR_ON_DESELECT);
        holdCount = JCSystem.makeTransientByteArray((short) (1), JCSystem.CLEAR_ON_DESELECT);
        dk = JCSystem.makeTransientObjectArray((short) (1), JCSystem.CLEAR_ON_RESET);
        mode = JCSystem.makeTransientByteArray((short) (1), JCSystem.CLEAR_ON_RESET);
        mode[0] = MODE_UNINITIALIZED;
        modeNonTransient = MODE_UNINITIALIZED;
    }

    public short getEncryptedLength( short plainLength){
        // the only algorithms we implement have 8 byte padding or NOPAD
        if (this.getAlgorithm()==CipherInternal.ALG_DES_CBC_NOPAD ||
                this.getAlgorithm()==CipherInternal.ALG_DES_ECB_NOPAD){
            return plainLength;
        } else {
            return (short)(((plainLength+8)/8)*8);
        }
    }

    /**
     * The init defined in the API spec.
     */
    public void init(javacard.security.Key theKey, byte theMode) throws CryptoException {

        short keyLength;

        if (!(theKey instanceof DESKeyImpl)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        dk[0] = theKey;

        if (!((DESKeyImpl) dk[0]).isInitialized()) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }

        keyLength = theKey.getSize();
        if (keyLength != KeyBuilder.LENGTH_DES && keyLength != KeyBuilder.LENGTH_DES3_2KEY) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        if ((theMode != MODE_DECRYPT) && (theMode != MODE_ENCRYPT)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        if (theKey.getType() == KeyBuilder.TYPE_DES) {
            modeNonTransient = theMode;
            dkNonTransient = theKey;
        } else {
            mode[0] = theMode;
        }
        // clear the queue in case it has residual elements from previous use
        circular.clearQueue();
    }

    /**
     * The init defined in the API spec.
     */
    public void init(javacard.security.Key theKey, byte theMode, byte bArray[], short bOff, short bLen)
            throws CryptoException {
        init(theKey, theMode);
    }

    /**
     * Resets the CipherInternal to post init state (but zeros out IV)
     */
    protected abstract void resetIV();

    /**
     * The doFinal method defined in the API spec
     */
    public short doFinal(byte inBuff[], short inOffset, short inLength, byte outBuff[], short outOffset)
            throws CryptoException {

        NativeMethods.sensitiveResultSetTagValUnassigned();
        
        if (modeNonTransient != MODE_UNINITIALIZED) {
            mode[0] = modeNonTransient;
            dk[0] = dkNonTransient;
        }

        /* Cannot check output buffer parameters in the general parameter checking
         * method, since it is different for update and final.
         */
        if (mode[0] == MODE_ENCRYPT) {
            NativeMethods.checkArrayArgs(outBuff, outOffset,
                    (short) (inLength + holdCount[0] + (((inLength + holdCount[0]) % BLOCK_SIZE) == 0 ? BLOCK_SIZE
                            : (BLOCK_SIZE - ((inLength + holdCount[0]) % BLOCK_SIZE)))));
        } else {
            if ((inLength + holdCount[0]) < BLOCK_SIZE) {
                CryptoException.throwIt(CryptoException.ILLEGAL_USE);
            }

            /* We only check for a best case scenario here. The final array copy
             * will check for the last 0 to 8 bytes, and throw an exception if the output
             * buffer is not long enough to hold the last bytes less padding.
             */
            NativeMethods.checkArrayArgs(outBuff, outOffset, (short) (inLength + holdCount[0] - BLOCK_SIZE));

        }

        short counter = updateIntern(inBuff, inOffset, inLength, outBuff, outOffset);

        short paddingLength = 0;
        /* Once we do the final update we have to deal with padding. There will be
         * between 0 and 8 trailing bytes in holdData. If the number of bytes is an even 8,
         * we call cipherQueue and then handle padding. If the number of bytes is less than
         * 8, we do not cipher prior to handling padding.
         */

        for (short i = 0; i < holdCount[0]; i++) {
            circular.queuePut(holdData[i]);
        }

        if (mode[0] == MODE_ENCRYPT) {
            if (holdCount[0] == BLOCK_SIZE) {
                cipherQueue(circular, outBuff, (short) (outOffset + counter));
                counter += BLOCK_SIZE;
            }
            holdCount[0] = 0;
            /* Once we get to here, we need to deal with padding.
             * Except for the case of the NOPAD cipher, there will be between 0 and 7
             * trailing bytes in the queue. We pad the queue and call cipherQueue.
             * We must make sure to add 'counter' to outOffset to account for data that
             * has been ciphered already.
             */
            paddingLength = padder.pad(circular);
            if (paddingLength != 0) {
                cipherQueue(circular, outBuff, (short) (outOffset + counter));
                counter += BLOCK_SIZE;
            }// if(paddingLength != 0)
        } else {
            holdCount[0] = 0;
            /* To keep from returning padding bytes if update recieves all input,
             * we keep up to 8 bytes in the queue until now. We must now decrypt the last
             * 8 bytes and strip any padding.
             */
            cipherQueue(circular, data, (short) (0));
            paddingLength = padder.unPad(data);
            if ((short) (BLOCK_SIZE - paddingLength) > 0) {
                NativeMethods.arrayCopyNonAtomicForSensitiveArrays(data, (short) 0, outBuff, (short) (outOffset + counter),
                        (short) (BLOCK_SIZE - paddingLength));
            }
            // update counter i.e. subtract the number of padding bytes since we
            // don't consider
            // these to have been decrypted
            counter += (BLOCK_SIZE - paddingLength);

        }

        /*if after this final update the queue is not empty it means that the
         *total number of data bytes (including padding if relevant) is not a 
         *multiple of BLOCK_SIZE (8) and we must throw an exception
         */
        if (circular.getCount() != 0) {
            CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        }
        circular.clearQueue();
        resetIV();
        
        NativeMethods.sensitiveResultSet(counter);
        
        return counter;
    }

    /**
     * The update method defined in the API spec
     */
    /*The update procedure is as follows:
     *while(there are still input bytes)
     *{
     *  transfer input to one block hold buffer to prevent passing padding back on decrypt
     *  return if not more than one full block to work with
     *	if(we have more than 8 bytes to work with)
     *   	remove 8 bytes from the queue and cipher them
     *}
     */
    public short update(byte inBuff[], short inOffset, short inLength, byte outBuff[], short outOffset)
            throws CryptoException {
        
        NativeMethods.sensitiveResultSetTagValUnassigned();
        
        short currentOffset = inOffset;
        short counter = 0;
        short inPutCheck = (inLength == (short)8 ? (short)9 : inLength);

        checkCipherParameters(inBuff, inOffset, inLength);
        /* Cannot check output buffer parameters in the general parameter checking
         * method, since it is different for update and final.
         */
        NativeMethods.checkArrayArgs(outBuff, outOffset, (short) ((inLength == 0 ? BLOCK_SIZE : inLength)
                + holdCount[0] - (((inLength + holdCount[0]) % BLOCK_SIZE) == 0 ? BLOCK_SIZE
                : ((inLength + holdCount[0]) % BLOCK_SIZE))));
        if (inLength == 0) {
            NativeMethods.sensitiveResultSet(counter);
            return counter;
        }
        while (currentOffset < ((inOffset + inLength))) {
            // Fill buffer to prevent passing back padding on Decrypt
            for (; holdCount[0] < 8; currentOffset++) {
                holdData[holdCount[0]++] = inBuff[currentOffset];
                inPutCheck -= 1;
                if (inPutCheck == 0) {
                    NativeMethods.sensitiveResultSet(counter);
                    return counter;
                }
            }
            // Fill queue now that we are sure we have more than one Block of
            // data
            for (short i = 0; i < BLOCK_SIZE; i++) {
                circular.queuePut(holdData[i]);
            }
            holdCount[0] = 0;
            cipherQueue(circular, outBuff, outOffset);
            // increment the counter in the input/output buffers
            counter += BLOCK_SIZE;
            outOffset += BLOCK_SIZE;

        }// while(currentOffset < (inOffset + inLength));

        NativeMethods.sensitiveResultSet(counter);
        
        return counter;
    }
    
    private short updateIntern(byte inBuff[], short inOffset, short inLength, byte outBuff[], short outOffset)
            throws CryptoException {
        
        NativeMethods.sensitiveResultSetTagValUnassigned();
        
        short currentOffset = inOffset;
        short counter = 0;
        short inPutCheck = inLength;

        checkCipherParameters(inBuff, inOffset, inLength);
        /* Cannot check output buffer parameters in the general parameter checking
         * method, since it is different for update and final.
         */
        NativeMethods.checkArrayArgs(outBuff, outOffset, (short) ((inLength == 0 ? BLOCK_SIZE : inLength)
                + holdCount[0] - (((inLength + holdCount[0]) % BLOCK_SIZE) == 0 ? BLOCK_SIZE
                : ((inLength + holdCount[0]) % BLOCK_SIZE))));
        if (inLength == 0) {
            NativeMethods.sensitiveResultSet(counter);
            return counter;
        }
        while (currentOffset < ((inOffset + inLength))) {
            // Fill buffer to prevent passing back padding on Decrypt
            for (; holdCount[0] < 8; currentOffset++) {
                holdData[holdCount[0]++] = inBuff[currentOffset];
                inPutCheck -= 1;
                if (inPutCheck == 0) {
                    NativeMethods.sensitiveResultSet(counter);
                    return counter;
                }
            }
            // Fill queue now that we are sure we have more than one Block of
            // data
            for (short i = 0; i < BLOCK_SIZE; i++) {
                circular.queuePut(holdData[i]);
            }
            holdCount[0] = 0;
            cipherQueue(circular, outBuff, outOffset);
            // increment the counter in the input/output buffers
            counter += BLOCK_SIZE;
            outOffset += BLOCK_SIZE;

        }// while(currentOffset < (inOffset + inLength));

        NativeMethods.sensitiveResultSet(counter);
        
        return counter;
    }

    protected void checkCipherParameters(byte[] inBuff, short inOff, short inLength) {

        if (modeNonTransient != MODE_UNINITIALIZED) {
            mode[0] = modeNonTransient;
            dk[0] = dkNonTransient;
        }
        if (mode[0] == MODE_UNINITIALIZED) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }
        if (dk[0] == null) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }
        if (!((DESKeyImpl) dk[0]).isInitialized()) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }

        NativeMethods.checkArrayArgs(inBuff, inOff, inLength);
    }

    /**
     * Performs the cipher operation on the contents of the circular queue
     */
    protected void cipherQueue(CircularQueue queue, byte[] outBuff, short outOffset) {

        for (short i = 0; i < BLOCK_SIZE; i++) {
            data[i] = queue.queueGet();
        }

        switch (((DESKeyImpl) dk[0]).getSize()) {
            case KeyBuilder.LENGTH_DES:
                if (mode[0] == MODE_ENCRYPT) {
                    // encrypt the data
                    SecurityNativeMethods.ecbEnc(data, intermediateOutput, ((DESKeyImpl) dk[0]).data, (byte) 0);
                    // copy the output into outBuff
                    NativeMethods.arrayCopyNonAtomicForSensitiveArrays(intermediateOutput, (short) 0, outBuff, outOffset, BLOCK_SIZE);
                } else {
                    // decrypt the data
                    SecurityNativeMethods.ecbDec(data, intermediateOutput, ((DESKeyImpl) dk[0]).data, (byte) 0);
                    // copy the output into outBuff
                    NativeMethods.arrayCopyNonAtomicForSensitiveArrays(intermediateOutput, (short) 0, outBuff, outOffset, BLOCK_SIZE);
                }
                break;
            case KeyBuilder.LENGTH_DES3_2KEY:
                if (mode[0] == MODE_ENCRYPT) {
                    // In the case of DES3_2KEY encryption we encrypt with the
                    // first key
                    // decrypt with the second key and then encrypt again with
                    // the first key

                    // encrypt the data using the first key
                    SecurityNativeMethods.ecbEnc(data, intermediateOutput, ((DESKeyImpl) dk[0]).data, (byte) 0);
                    // copy the intermediate output back into data
                    Util.arrayCopyNonAtomic(intermediateOutput, (short) 0, data, (short) 0, BLOCK_SIZE);

                    // decrypt the data using the second key
                    SecurityNativeMethods.ecbDec(data, intermediateOutput, ((DESKeyImpl) dk[0]).data, (byte) 8);
                    // copy the intermediate output back into data
                    Util.arrayCopyNonAtomic(intermediateOutput, (short) 0, data, (short) 0, BLOCK_SIZE);

                    // encrypt the data again using the first key
                    SecurityNativeMethods.ecbEnc(data, intermediateOutput, ((DESKeyImpl) dk[0]).data, (byte) 0);
                    // copy the intermediate output outBuff
                    NativeMethods.arrayCopyNonAtomicForSensitiveArrays(intermediateOutput, (short) 0, outBuff, outOffset, BLOCK_SIZE);

                } else {
                    // In the case of DES3_2KEY decryption we decrypt with the
                    // first key
                    // encrypt with the second key and then decrypt again with
                    // the first key
                    // decrypt the data using the first key
                    SecurityNativeMethods.ecbDec(data, intermediateOutput, ((DESKeyImpl) dk[0]).data, (byte) 0);
                    // copy the intermediate output back into data
                    Util.arrayCopyNonAtomic(intermediateOutput, (short) 0, data, (short) 0, BLOCK_SIZE);

                    // encrypt the data using the second key
                    SecurityNativeMethods.ecbEnc(data, intermediateOutput, ((DESKeyImpl) dk[0]).data, (byte) 8);
                    // copy the intermediate output back into data
                    Util.arrayCopyNonAtomic(intermediateOutput, (short) 0, data, (short) 0, BLOCK_SIZE);

                    // decrypt the data again using the first key
                    SecurityNativeMethods.ecbDec(data, intermediateOutput, ((DESKeyImpl) dk[0]).data, (byte) 0);
                    // copy the intermediate output outBuff
                    NativeMethods.arrayCopyNonAtomicForSensitiveArrays(intermediateOutput, (short) 0, outBuff, outOffset, BLOCK_SIZE);
                }
                break;

            default:
                CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
                break;

        }// switch
    }// end method
}// enc class
