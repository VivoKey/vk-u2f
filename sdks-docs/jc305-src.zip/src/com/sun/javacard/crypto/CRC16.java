/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
// #ifdef_Target32Bit_
package com.sun.javacard.crypto;

import javacard.framework.JCSystem;
import javacard.framework.Util;
import javacard.security.Checksum;
import javacard.security.CryptoException;

import com.sun.javacard.impl.NativeMethods;

public class CRC16 extends javacard.security.Checksum {

    private byte[] checksum16; // holds checksum result
    private static final short CRC16_POLYNOMIAL = (short) 0x1021;
    private static final short CRC16_OUTBUF_LEN = (short) 2;
    private static final short CRC16_FINAL_XOR = (short) 0xFFFF;

    /**
     * Default Constructor
     */
    public CRC16() {
        checksum16 = JCSystem.makeTransientByteArray(CRC16_OUTBUF_LEN, JCSystem.CLEAR_ON_DESELECT);
    }

    public byte getAlgorithm() {
        return Checksum.ALG_ISO3309_CRC16;
    }

    public void init(byte[] bArray, short bOff, short bLen) throws CryptoException {

        /* Spec expects that init be provided with 2 bytes length of initial crc
         * Hence hardcoded check for 16 bits.
         */

        NativeMethods.checkArrayArgs(bArray, bOff, CRC16_OUTBUF_LEN);
        if (bLen != CRC16_OUTBUF_LEN) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        Util.arrayCopyNonAtomic(bArray, bOff, checksum16, (short) 0, bLen);
    }

    public short doFinal(byte[] inBuff, short inOffset, short inLength, byte[] outBuff, short outOffset) {

        NativeMethods.sensitiveResultSetTagValUnassigned();
        // check only for len=16 for checksum16
        NativeMethods.checkArrayArgs(outBuff, outOffset, CRC16_OUTBUF_LEN);
        // just call update for computing checksum
        update(inBuff, inOffset, inLength);

        // XORing of checksum is done only for the final checksum value
        short temp = Util.getShort(checksum16, (short) 0);
        temp ^= CRC16_FINAL_XOR;
        Util.setShort(checksum16, (short) 0, temp);

        // copy the checksum value to output buffer - transacted
        Util.arrayCopy(checksum16, (short) 0, outBuff, outOffset, CRC16_OUTBUF_LEN);
        // reset
        Util.arrayFillNonAtomic(checksum16, (short) 0, (short) checksum16.length, (byte) 0);

        NativeMethods.sensitiveResultSet(CRC16_OUTBUF_LEN);
        return CRC16_OUTBUF_LEN;
    }

    public void update(byte[] inBuff, short inOffset, short inLength) {
        NativeMethods.checkArrayArgs(inBuff, inOffset, inLength);
        // now we are ready to compute checksum
        computeChecksum(inBuff, inOffset, inLength);
    }

    /**
     * Calculate CRC for the data in inBuff and store result in checksum16
     * array.
     */
    void computeChecksum(byte[] inBuf, short inOff, short inLen) {
        short fcs = Util.getShort(checksum16, (short) 0); /* Stored CRC value */
        for (short i = inOff; i < (short) (inOff + inLen); i++) {
            short d = (short) (inBuf[i] << 8);
            for (short k = 0; k < 8; k++) {
                if ((short) ((fcs ^ d) & 0x8000) != 0) {
                    fcs = (short) ((short) (fcs << 1) ^ CRC16_POLYNOMIAL);
                } else {
                    fcs = (short) (fcs << 1);
                }
                d <<= 1;
            }
        }
        Util.setShort(checksum16, (short) 0, fcs);
    }
}
// #endif_Target32Bit_
