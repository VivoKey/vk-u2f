/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

import javacard.security.CryptoException;
import javacardx.crypto.KeyEncryption;
import javacard.framework.Util;

/**
 * When KeyBuilder.buildKey is called with keyEncryption = true, it must provide
 * a version of the specified key that implements the KeyEncryption interface.
 * This class is the version of RSAPrivateKeyImpl that implements KeyEncryption
 */
public class RSAPrivateKeyEncryption extends RSAPrivateKeyImpl implements KeyEncryption {

    final static short MAX_ENCRYPTED_KEY = 72;
    /**
     * The Cipher object that will be used to decrypt key parameters in 'set'
     * methods
     */
    javacardx.crypto.Cipher keyDecryptionCipher = null;
    private byte[] mod;
    private byte[] exp;

    public RSAPrivateKeyEncryption(byte type, short bitLength) {
        super(type, bitLength);
        // These are made for keys 512 bits or less, increase size to support
        // larger keys
        this.mod = new byte[MAX_ENCRYPTED_KEY];
        this.exp = new byte[MAX_ENCRYPTED_KEY];
    }

    public void setModulus(byte[] buffer, short offset, short length) {
        if ((length == 0) || (length > MAX_ENCRYPTED_KEY)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
        Util.arrayCopy(buffer, offset, mod, (short) 0, length);
        short decryptedLength = length;
        short outOffset = 0;
        // If the keyDecryptionCipher is not null, first decrypt the data at the
        // appropriate offset and length in the buffer
        if (keyDecryptionCipher != null) {
            decryptedLength = keyDecryptionCipher.doFinal(buffer, offset, length, mod, outOffset);
        }
        // now do the actual set operation
        super.setModulus(mod, outOffset, decryptedLength);
    }

    public void setExponent(byte buffer[], short offset, short length) {
        if ((length == 0) || (length > MAX_ENCRYPTED_KEY)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
        Util.arrayCopy(buffer, offset, exp, (short) 0, length);
        short decryptedLength = length;
        short outOffset = 0;
        /*
         * If the keyDecryptionCipher is not null, first decrypt the data 
         * at the appropriate offset and length in the buffer
         */
        if (keyDecryptionCipher != null) {
            decryptedLength = keyDecryptionCipher.doFinal(buffer, offset, length, exp, outOffset);
        }
        // now do the actual set operation
        super.setExponent(exp, outOffset, decryptedLength);
    }

    public javacardx.crypto.Cipher getKeyCipher() {
        return keyDecryptionCipher;
    }

    public void setKeyCipher(javacardx.crypto.Cipher keyCipher) {
        keyDecryptionCipher = keyCipher;
    }

}
