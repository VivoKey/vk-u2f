/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
// #ifdef_Target32Bit_
package com.sun.javacard.crypto;

import javacard.framework.JCSystem;
import javacard.framework.Util;
import javacard.security.AESKey;
import javacard.security.CryptoException;
import javacard.security.KeyBuilder;

import com.sun.javacard.impl.NativeMethods;

public abstract class AESCipher extends CipherInternal {
    /**
     * Indicates that the cipher has not been initialized for encryption or
     * decryption yet
     */
    private final static byte MODE_UNINITIALIZED = -1;

    /**
     * AES ciphers encrypt/decrypt in block size of 16 bytes
     */
    protected final static short AES_128_BLOCK_SIZE = 16;

    /* akey is accessed by AES128CBCCipher */
    protected AESKeyImpl akey;

    /**
     * ENCRYPT or DECRYPT Mode mode object is create in Persistent memory and
     * stored in such a way that it does not participate in transaction (spec
     * requirement). This is necessary as one could create a AESKey of type
 persistent then create a CipherInternal/Signature object and then a tear happens.
 After tear, if they call Signature.Sign or CipherInternal.doFinal, then this must
 work with the default IV.
     */
    protected byte[] mode; // byte value
    protected byte[] keyLength; // short value
    private byte[] holdCount; // byte value
    protected byte[] intermediateOutput;
    protected byte[] data;
    private byte[] holdData;

    private boolean[] update_status;

    /**
     * A queue is used to store data blocks entered using 'update'. This queue
     * is necessary because AES operates on 16,24,32 byte blocks depending on
     * the alg selected, but there is no requirement on the user to pass in data
     * in multiples of 16,24, or 32 bytes. Here, the queue is used as an 16 byte
     * buffer which stores the trailing bytes of each input block between
     * successive updates. This way we ensure that each cipher block is indeed
     * 16 bytes
     */

    protected CircularQueue myqueue = null;

    public AESCipher(byte algorithm, byte cipherAlgorithm, byte paddingAlgorithm) {
        super(algorithm, cipherAlgorithm, paddingAlgorithm);
        myqueue = new CircularQueue(AES_128_BLOCK_SIZE);
        intermediateOutput = JCSystem.makeTransientByteArray(AES_128_BLOCK_SIZE, JCSystem.CLEAR_ON_DESELECT);
        data = JCSystem.makeTransientByteArray(AES_128_BLOCK_SIZE, JCSystem.CLEAR_ON_DESELECT);
        holdData = JCSystem.makeTransientByteArray(AES_128_BLOCK_SIZE, JCSystem.CLEAR_ON_DESELECT);

        update_status = JCSystem.makeTransientBooleanArray((short) 1, JCSystem.CLEAR_ON_DESELECT);

        mode = new byte[1];

        keyLength = JCSystem.makeTransientByteArray((short) 2, JCSystem.CLEAR_ON_DESELECT);

        holdCount = JCSystem.makeTransientByteArray((short) 1, JCSystem.CLEAR_ON_DESELECT);

        Util.setShort(keyLength, (short) 0, (short) 0);
        Util.arrayFillNonAtomic(mode, (short) 0, (short) 1, MODE_UNINITIALIZED);
        holdCount[0] = 0;
    }

    public short getEncryptedLength( short plainLength){
        return (short)(((plainLength+16)/16)*16);
    }

    /**
     * The init defined in the API spec.
     */
    public void init(javacard.security.Key theKey, byte theMode) throws CryptoException {

        Util.arrayFillNonAtomic(mode, (short) 0, (short) 1, MODE_UNINITIALIZED);
        
        if (!theKey.isInitialized()) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }
        
        if (!(theKey instanceof AESKey)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        if ((theMode != MODE_DECRYPT) && (theMode != MODE_ENCRYPT)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        akey = (AESKeyImpl) theKey;

        Util.setShort(keyLength, (short) 0, akey.getSize());
        // keyLength is theKey.getSize
        /* As we are only doing 128 bit AES keys, the below code is not required.
         * If the code supports other key sizes, the below and additional code
         * may be required.
         */
        /*
        if (theKey.getSize() != KeyBuilder.LENGTH_AES_128) {
            Util.setShort(keyLength, (short)0, (short)0);
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }	
        */

        Util.arrayFillNonAtomic(mode, (short) 0, (short) 1, theMode);
        // clear the queue in case it has residual elements from previous use
        myqueue.clearQueue();
    }

    /**
     * The init defined in the API spec.
     */
    public void init(javacard.security.Key theKey, byte theMode, byte bArray[], short bOff, short bLen)
            throws CryptoException {

        init(theKey, theMode);
    }

    /**
     * Resets the CipherInternal to post init state (but zeros out IV)
     */
    protected abstract void resetIV();

    void resetMe() {
        holdCount[0] = 0;
        myqueue.clearQueue();
        Util.arrayFillNonAtomic(intermediateOutput, (short) 0, AES_128_BLOCK_SIZE, (byte) 0x00);
        Util.arrayFillNonAtomic(holdData, (short) 0, AES_128_BLOCK_SIZE, (byte) 0x00);
    }

    /**
     * The doFinal method defined in the API spec
     */
    public short doFinal(byte inBuff[], short inOffset, short inLength, byte outBuff[], short outOffset)
            throws CryptoException {
        /* Cannot check output buffer parameters in the general parameter 
         * checking method, since it is different for update and final.
         */
        NativeMethods.sensitiveResultSetTagValUnassigned();
        short counter = AES_128_BLOCK_SIZE;

        if (inLength == 0) {
            if (!(update_status[0])) {
                CryptoException.throwIt(CryptoException.ILLEGAL_USE);
            } else {
                counter = 0;
            }
        }
        /* check if doFinal is called w/o calling update & len is block aligned.
         * Or update was called with non-block aligned data and then
         * doFinal is called after that with non-block aligned data (total)
         */
        else if (((inLength + holdCount[0]) % AES_128_BLOCK_SIZE) != 0) {
            counter = 0;
            CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        } else {
            if (mode[0] == MODE_ENCRYPT) {

                NativeMethods.checkArrayArgs(outBuff, outOffset, AES_128_BLOCK_SIZE);
            } else { // (mode[0] == MODE_DECRYPT)

                /* Note that you cannot call doFinal with size from current &
                 * previous less than BLOCK_SIZE for decrypt
                 * I cannot return intermediate output because it may be 
                 * incorrect.
                 */

                NativeMethods
                        .checkArrayArgs(outBuff, outOffset, (short) (inLength + holdCount[0] - AES_128_BLOCK_SIZE));
            }

            counter = update(inBuff, inOffset, inLength, outBuff, outOffset);
        }
        /* the below code is the same when inLength == 0, but, update is 
         * called before with block size.  Then we return the intermediate o/p.
         */
        if (myqueue.getCount() != 0) {
            CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        }
        resetMe();
        resetIV();
        
        NativeMethods.sensitiveResultSet(counter);
        return counter;
    }

    /**
     * The update method defined in the API spec
     */

    public short update(byte inBuff[], short inOffset, short inLength, byte outBuff[], short outOffset)
            throws CryptoException {
        
        NativeMethods.sensitiveResultSetTagValUnassigned();
        short currentOffset = inOffset;
        short counter = 0;
        short inPutCheck = inLength;

        checkCipherParameters(inBuff, inOffset, inLength);
        /* Cannot check output buffer parameters in the general parameter 
         * checking method, since it is different for update and final.
         */

        /* simulate a null pointer exception if outBuff is null */
        short test = (short) outBuff.length;

        if (inLength == 0) { // nothing to update
            NativeMethods.sensitiveResultSet(counter);
            return counter;
        }

        // items can still be added to holding buffer
        if ((inLength + holdCount[0]) < AES_128_BLOCK_SIZE) {
            for (; (currentOffset < (inOffset + inLength)); currentOffset++, holdCount[0]++) {
                holdData[holdCount[0]] = inBuff[currentOffset];

            }
        } else if ((short) (inLength + holdCount[0]) == AES_128_BLOCK_SIZE) {
            for (; (currentOffset < (inOffset + inLength)); currentOffset++, holdCount[0]++) {
                holdData[holdCount[0]] = inBuff[currentOffset];
            }
            prepareAndCipher(outBuff, outOffset);
            counter += AES_128_BLOCK_SIZE;
        } else {
            /* items more than AES_BLK size, hence cipher and store 
             * more in holding buffer
             */
            short outoff2 = outOffset;
            for (; currentOffset < (short) (inOffset + inLength); currentOffset++, holdCount[0]++) {

                holdData[holdCount[0]] = inBuff[currentOffset];
                if ((short) (holdCount[0] + 1) == AES_128_BLOCK_SIZE) {
                    prepareAndCipher(outBuff, outoff2);
                    counter += AES_128_BLOCK_SIZE;
                    holdCount[0] = (short) -1;
                    outoff2 += AES_128_BLOCK_SIZE;
                }
            }
        }
        update_status[0] = true;

        NativeMethods.sensitiveResultSet(counter);
        return counter;
    }

    void prepareAndCipher(byte[] outBuff, short outOffset) {
        for (short i = 0; i < AES_128_BLOCK_SIZE; i++) {
            myqueue.queuePut(holdData[i]);
        }
        holdCount[0] = 0;
        cipherQueue(myqueue, outBuff, outOffset);

    }

    protected void checkCipherParameters(byte[] inBuff, short inOff, short inLength) {

        if (mode[0] == MODE_UNINITIALIZED) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }

        if (!akey.isInitialized()) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }

        NativeMethods.checkArrayArgs(inBuff, inOff, inLength);
    }

    /**
     * Performs the cipher operation on the contents of the myqueue queue
     */
    protected void cipherQueue(CircularQueue queue, byte[] outBuff, short outOffset) {

        //short c = queue.getCount();

        /* We need to do this as a deselect or tear event will clear the 
         * the keyLength variable.  If akey is of type persistant, then
         * the key will be initialized, but, cipher.doFinal will fail w/o 
         * this after deselect.
         */
        Util.setShort(keyLength, (short) 0, akey.getSize());

        switch (Util.getShort(keyLength, (short) 0)) {
            case KeyBuilder.LENGTH_AES_128:
                if (mode[0] == MODE_ENCRYPT) {
                    // encrypt the data
                    SecurityNativeMethods.aesCBCEncrypt(data, intermediateOutput, akey.data, (byte) 0);

                } else {// if (mode[0] == MODE_DECRYPT) {
                    // decrypt the data
                    SecurityNativeMethods.aesCBCDecrypt(data, intermediateOutput, akey.data, (byte) 0);
                }
                break;
            default:
                CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
                break;
        }
    }
}
// #endif_Target32Bit_
