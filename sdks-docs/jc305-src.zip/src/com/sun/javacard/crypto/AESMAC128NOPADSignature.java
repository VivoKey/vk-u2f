/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
// #ifdef_Target32Bit_
package com.sun.javacard.crypto;

import javacard.framework.JCSystem;
import javacard.framework.Util;
import javacard.security.AESKey;
import javacard.security.CryptoException;
import javacard.security.KeyBuilder;
import javacardx.crypto.Cipher;

import com.sun.javacard.impl.NativeMethods;

public class AESMAC128NOPADSignature extends SignatureInternal {

    protected final static short AES_128_BLOCK_SIZE = 16;

    /**
     * The cipher object used to create and verify the SignatureInternal
     */
    protected Cipher cipher;

    /**
     * The current operating mode (MODE_SIGN or MODE_VERIFY) mode object is
     * create in Persistent memory and stored in such a way that it does not
     * participate in transaction (spec requirement). This is necessary as one
 could create a AESKey of type persistent then create a Cipher/SignatureInternal
 object and then a tear happens. After tear, if they call SignatureInternal.Sign
 or Cipher.doFinal, then this must work with the default IV.
     */
    protected byte[] mode;

    /**
     * Indicates proper initialization of this signature object
     */
    protected boolean[] initFlag;

    boolean keyPersistant = false;

    /**
     * This temporary buffer is used to hold the output from cipher.update().
     * Since this is AES of 128 bit, no more than BLOCKSIZE (16) bytes should be
     * needed.
     */
    private byte[] temp = null;

    private byte[] temp_in_store = null;
    private byte[] temp_in_count; // byte value

    public AESMAC128NOPADSignature(byte algorithm, byte messageDigestAlgorithm, byte cipherAlgorithm, byte paddingAlgorithm) {
        super(algorithm, messageDigestAlgorithm, cipherAlgorithm, paddingAlgorithm);
        temp = JCSystem.makeTransientByteArray(AES_128_BLOCK_SIZE, JCSystem.CLEAR_ON_DESELECT);

        temp_in_store = JCSystem.makeTransientByteArray(AES_128_BLOCK_SIZE, JCSystem.CLEAR_ON_DESELECT);

        cipher = Cipher.getInstance(Cipher.ALG_AES_BLOCK_128_CBC_NOPAD, false);

        initFlag = JCSystem.makeTransientBooleanArray((short) 1, JCSystem.CLEAR_ON_DESELECT);
        mode = new byte[1];

        temp_in_count = JCSystem.makeTransientByteArray((short) 1, JCSystem.CLEAR_ON_DESELECT);
        temp_in_count[0] = 0;

    }

    public void init(javacard.security.Key theKey, byte theMode) throws CryptoException {
        init(theKey, theMode, AES128CBCCipher.defaultIV, (short) 0, (short) AES128CBCCipher.defaultIV.length);
    }

    /**
     * Initializes the SignatureInternal object
     * 
     * @param theKey
     *            the key object to use for signing
     * @param theMode
     *            one of MODE_SIGN or MODE_VERIFY
     * @param bArray
     *            byte array containing the Initialization Vector for the
     *            cipher.
     * @param bOff
     *            offset within bArray where the Initialization Vector data
     *            begins.
     * @param bLen
     *            byte length of Initialization Vector. Should be 16
     * 
     */
    public void init(javacard.security.Key theKey, byte theMode, byte[] bArray, short bOff, short bLen)
            throws CryptoException {
        /* store a reference to the key. We must check it's initialization 
         * state later
         */
        // Verify that the key is initialized
        if (!theKey.isInitialized()) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }

        /* Ensure that the Initialization Vector length specified is of the 
         * correct length
         */
        if (bLen != AES_128_BLOCK_SIZE) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        /* Verify that the mode value is valid and set the mode for the 
         * cipher accordingly
         */
        switch (theMode) {
            /* The cipher object does an ENCRYPTION operation whether we are 
             * signing data or verifying a signature.
             * In a verification we sign the data and compare it to a passed in 
             * signature
             */
            case MODE_SIGN:
            case MODE_VERIFY:
                Util.arrayFillNonAtomic(mode, (short) 0, (short) 1, theMode);
                break;

            default:
                CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        // Verify that the key is a AES key
        if (!(theKey instanceof AESKey)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        /* if we got this far then the input is valid and we can proceed
         * Initialize the cipher. It should be instantiated in the constructor of 
         * derived classes
         */
        cipher.init(theKey, Cipher.MODE_ENCRYPT, bArray, bOff, bLen);
        /* if the cipher.init didn't throw an exception then the initialization
         * succeeded
         */
        initFlag[0] = true;
        /* If the key is persistant we need to keep track of it so that we can 
         * use the SignatureInternal object after tear or reset.
         */
        if (theKey.getType() == KeyBuilder.TYPE_AES) {
            keyPersistant = true;
        } else {
            keyPersistant = false;
        }
    }

    public void setInitialDigest(byte[] initialDigestBuf, short initialDigestOffset,
            short initialDigestLength, byte[] digestedMsgLenBuf, short digestedMsgLenOffset, short digestedMsgLenLength)
            throws CryptoException{
        CryptoException.throwIt(CryptoException.ILLEGAL_USE);
    }

    public short getLength() throws CryptoException {
        /*
         * cipher.update is used here, to verify that the cipher key has 
         * been initializedit will throw CryptoException.UNINITIALIZED_KEY, 
         * if the key is not initialized
         */
        cipher.update(temp, (short) 0, (short) 0, temp, (short) 0);

        if (!initFlag[0]) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }
        return AES_128_BLOCK_SIZE;
    }

    public void update(byte[] inBuff, short inOff, short inLen) throws CryptoException {
        // Ensure the SignatureInternal object is initialized for signing
        if (!initFlag[0]) {
            if (!(keyPersistant)) {
                CryptoException.throwIt(CryptoException.INVALID_INIT);
            }
        }

        /** Checking array bounds to throw the right kind of exception */
        NativeMethods.checkArrayArgs(inBuff, inOff, inLen);

        if (inLen == 0) { // nothing to update - just return
            return;
        }

        /*
         * We don't need to store the output resulting from the update calls
         * since in the AES algorithm only the LAST 16 bytes encrypted contain
         * the signature, so we can allow the cipher object to output its 
         * encrypted output into a temporary buffer that we don't need to store
         * The spec says that we should throw a CryptoException(UNINITIALIZED_KEY)
         * if the key is not initialized, but the cipher.update does that already
         */
        doUpdate(inBuff, inOff, inLen, temp, (short) 0);
    }

    public short sign(byte[] inBuff, short inOff, short inLen, byte[] sigBuff, short sigOff) throws CryptoException {
        /*  To get the last 16 bytes of encrypted output all we need to do is  
         *  doFinal on the cipher 
         *  Ensure the SignatureInternal object is initialized for signing
         */
        NativeMethods.sensitiveResultSetTagValUnassigned();
        if (mode[0] != MODE_SIGN) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }

        if (!initFlag[0]) {
            if (!(keyPersistant)) {
                CryptoException.throwIt(CryptoException.INVALID_INIT);
            }
        }

        /** Checking array bounds to throw the right kind of exception */
        NativeMethods.checkArrayArgs(inBuff, inOff, inLen);
        NativeMethods.checkArrayArgs(sigBuff, sigOff, AES_128_BLOCK_SIZE);

        short result = doSign(inBuff, inOff, inLen, sigBuff, sigOff);
        
        NativeMethods.sensitiveResultSet(result);
        return result;
    }

    public boolean verify(byte[] inBuff, short inOff, short inLen, byte[] sigBuff, short sigOff, short sigLen)
            throws CryptoException {

        NativeMethods.sensitiveResultSetTagValUnassigned();
        // Ensure the SignatureInternal object is initialized for verification
        if (mode[0] != MODE_VERIFY) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }

        if (!initFlag[0]) {
            if (!(keyPersistant)) {
                CryptoException.throwIt(CryptoException.INVALID_INIT);
            }
        }

        if (sigLen != AESCipher.AES_128_BLOCK_SIZE) {
            NativeMethods.sensitiveResultSetBooleanFalse();
            return false;
        }

        /** Checking array bounds to throw the right kind of exception */
        NativeMethods.checkArrayArgs(inBuff, inOff, inLen);
        NativeMethods.checkArrayArgs(sigBuff, sigOff, sigLen);

        /*   
         * First call sign on this last bit of input and store the 
         * resulting signature in a temporary buffer.
         * The buffer (temp) need only be long enough to support 
         * the input length + possible padding bytes
         */

        // sign the data
        doSign(inBuff, inOff, inLen, temp, (short) 0);

        // now compare the last sigLen bytes of temp
        if (Util.arrayCompare(temp, (short) 0, sigBuff, sigOff, sigLen) != 0) {
            NativeMethods.sensitiveResultSetBooleanFalse();
            return false;
        }
        
        NativeMethods.sensitiveResultSetBooleanTrue();
        return true;
    }

    protected short doSign(byte[] inBuff, short inOff, short inLen, byte[] sigBuff, short sigOff)
            throws CryptoException {

        if (((short) (inLen + temp_in_count[0]) % AES_128_BLOCK_SIZE) != 0) {
            CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        }

        /* if I call doFinal with the entire date, I will have to keep track
         * if I had called update earlier.  With this method, it is very simple.
         * Finally when I call doFinal with len = 0, I should get the correct
         * result or an exception.  Keeping a +ve attitude, that exceptions for
         * not block aligned are thrown rarely.
         */
        doUpdate(inBuff, inOff, inLen, temp, (short) 0);
        cipher.doFinal(inBuff, inOff, (short) 0, temp, (short) 0);
        temp_in_count[0] = (byte) 0;
        /*    
         * We have finalBytes output to the temp buffer. We need to copy the
        * last AES_128_BLOCK_SIZE bytes of this into sigBuff
        */
        NativeMethods.arrayCopyNonAtomicForSensitiveArrays(temp, (short) 0, sigBuff, sigOff, AES_128_BLOCK_SIZE);

        return AES_128_BLOCK_SIZE;
    }

    /**
     * wrapper method to call cipher.update
     * 
     */

    protected short doUpdate(byte[] inBuff, short inOff, short inLen, byte[] sigBuff, short sigOff)
            throws CryptoException {
        short result = 0;
        // Call cipher.update in Block sizes
        short track = temp_in_count[0];
        short j = (short) (inLen + track);
        short ino = inOff;

        // Case 1 - (track + inLen) or j < AES_128_BLOCK_SIZE
        if (j < AES_128_BLOCK_SIZE) {
            // just copy and return 0
            for (; track < j; track++, ino++) {
                temp_in_store[track] = inBuff[ino];
            }
            temp_in_count[0] = (byte) track;
            return (short) 0;
        }
        // case 2 - (track + inLen) or j == AES_128_BLOCK_SIZE
        else if (j == AES_128_BLOCK_SIZE) {
            // cipher the block and return result
            for (; track < j; track++, ino++) {
                temp_in_store[track] = inBuff[ino];
            }
            result = cipher.update(temp_in_store, (short) 0, AES_128_BLOCK_SIZE, sigBuff, sigOff);
            temp_in_count[0] = (byte) 0;
            return result;
        }
        // case 3 - (track + inLen) or j > AES_128_BLOCK_SIZE
        else {
            // copy the input into temp_in_store and then cipher.update if block
            // aligned
            while (ino < (short) (inOff + inLen)) {
                for (; (track < AES_128_BLOCK_SIZE) && ((short) (inOff + inLen) > ino); track++, ino++) {
                    temp_in_store[track] = inBuff[ino];
                }
                temp_in_count[0] = (byte) track;
                if (track == AES_128_BLOCK_SIZE) {
                    result = cipher.update(temp_in_store, (short) 0, AES_128_BLOCK_SIZE, sigBuff, sigOff);
                    temp_in_count[0] = (byte) 0;
                    track = (short) 0;
                }
            }
            return result;
        }
    }

    public short signPreComputedHash(byte[] hashBuf, short hashOff, short hashLength, byte[] sigBuff, short sigOffset){
        NativeMethods.sensitiveResultSetTagValUnassigned();
        CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        
        NativeMethods.sensitiveResultSet((short) 0);
        return (short)0;
    }
    
    public boolean verifyPreComputedHash(byte[] hashBuff, short hashOffset, short hashLength, byte[] sigBuff, short sigOffset,
            short sigLength) throws CryptoException{
        NativeMethods.sensitiveResultSetTagValUnassigned();
        CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        
        NativeMethods.sensitiveResultSetBooleanFalse();
        return false;
    }

}
// #endif_Target32Bit_
