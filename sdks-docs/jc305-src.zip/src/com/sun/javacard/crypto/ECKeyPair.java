/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
// #ifdef_Target32Bit_
package com.sun.javacard.crypto;

import javacard.framework.Util;
import javacard.security.CryptoException;
import javacard.security.ECPrivateKey;
import javacard.security.ECPublicKey;
import javacard.security.KeyBuilder;
import javacard.security.KeyPair;
import javacard.security.PrivateKey;
import javacard.security.PublicKey;

/**
 * This class is a container for an EC key pair (a public key and a private
 * key).
 * <p>
 * In addition, this class features a key generation method.
 * 
 * @see PublicKey
 * @see PrivateKey
 */
public final class ECKeyPair implements KeyPairInterfaceInternal {

    private ECPrivateKey privateKey;
    private ECPublicKey publicKey;
    private byte[] B1, B2; // used as tmp buffers

    /**
     * Returns a reference to the public key component of this
     * <code>KeyPair</code> object.
     * 
     * @return a reference to the public key.
     */
    public PublicKey getPublic() {
        return publicKey;
    }

    /**
     * Returns a reference to the private key component of this
     * <code>KeyPair</code> object.
     * 
     * @return a reference to the private key.
     */
    public PrivateKey getPrivate() {
        return privateKey;
    }

    /**
     * Constructs a new <code>ECKeyPair</code> object containing the specified
     * public key and private key.
     * 
     * @param publicKey
     *            the public key.
     * @param privateKey
     *            the private key.
     * @exception CryptoException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>CryptoException.ILLEGAL_VALUE</code> if the
     *                input parameter key objects are inconsistent with each
     *                other - i.e mismatched algorithm, size etc.
     *                <li><code>CryptoException.NO_SUCH_ALGORITHM</code> if
     *                the algorithm associated with the specified type, size of
     *                key is not supported.
     *                </ul>
     */
    public ECKeyPair(PublicKey public_key, PrivateKey private_key) throws CryptoException {

        if (public_key.getType() != KeyBuilder.TYPE_EC_FP_PUBLIC
                || private_key.getType() != KeyBuilder.TYPE_EC_FP_PRIVATE) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        if (public_key.getSize() != private_key.getSize()) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        this.publicKey = (ECPublicKey) public_key;
        this.privateKey = (ECPrivateKey) private_key;
        // buffers; size = 2*24+1; used by initDomainParameters()
        // and by compareDomainParameters()
        B1 = new byte[49];
        B2 = new byte[49];

    }

    /**
     * Constructs a <code>KeyPair</code> instance for the specified algorithm
     * and keylength; the encapsulated keys are uninitialized. To initialize the
     * <code>KeyPair</code> instance use the <code>genKeyPair()</code>
     * method.
     * <p>
     * The encapsulated key objects are of the specified <code>keyLength</code>
     * size and implement the appropriate <code>Key</code> interface
     * associated with the specified algorithm
     * <p>
     * Notes:
     * <ul>
     * <li><em>The key objects encapsulated in the generated </em><code>KeyPair</code><em> object
     * need not support the </em><code>KeyEncryption</code><em> interface.</em>
     * </ul>
     * 
     * @param algorithm
     *            the type of algorithm whose key pair needs to be generated.
     *            Valid codes listed in <code>ALG_..</code> constants above.
     * @param keyLength
     *            the key size in bits. The valid key bit lengths for ALG_EC_FP
     *            are: 112, 128, 160 and 192 bits. See the
     *            <code>KeyBuilder</code> class.
     * @exception CryptoException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>CryptoException.NO_SUCH_ALGORITHM</code> if
     *                the requested algorithm associated with the specified
     *                type, size of key is not supported.
     *                </ul>
     * @see KeyBuilder
     * @see Signature
     * @see javacardx.crypto.Cipher
     * @see javacardx.crypto.KeyEncryption
     */
    public ECKeyPair(byte algorithm, short keyLength) throws CryptoException {

        if (algorithm == KeyPair.ALG_EC_FP) {

            switch (keyLength) {
                case KeyBuilder.LENGTH_EC_FP_112:
                case KeyBuilder.LENGTH_EC_FP_128:
                case KeyBuilder.LENGTH_EC_FP_160:
                case KeyBuilder.LENGTH_EC_FP_192:
                    break;
                default:
                    CryptoException.throwIt(CryptoException.NO_SUCH_ALGORITHM);
            }

            privateKey = new com.sun.javacard.crypto.ECSharedDomainPrivateKeyImpl(KeyBuilder.TYPE_EC_FP_PRIVATE, keyLength);

            publicKey = new com.sun.javacard.crypto.ECSharedDomainPublicKeyImpl(KeyBuilder.TYPE_EC_FP_PUBLIC, keyLength);
            B1 = new byte[49];
            B2 = new byte[49];

        } else {
            CryptoException.throwIt(CryptoException.NO_SUCH_ALGORITHM);
        }
    }

    /**
     * (Re)Initializes the key objects encapsulated in this <code>KeyPair</code>
     * instance with new key values. The initialized public and private key
     * objects encapsulated in this instance will then be suitable for use with
     * the <code>Signature</code>, <code>Cipher</code> and
     * <code>KeyAgreement</code> objects. An internal secure random number
     * generator is used during new key pair generation.
     * 
     * @exception CryptoException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>CryptoException.ILLEGAL_VALUE</code> if the
     *                Field, A, B, G and R parameter set in EC keys are invalid
     *                or mismatch.
     *                </ul>
     */
    public final void genKeyPair() throws CryptoException {

        try { // checking if domain params are set
            publicKey.getA(B1, (short) 0);
            publicKey.getB(B1, (short) 0);
            publicKey.getG(B1, (short) 0);
            publicKey.getR(B1, (short) 0);
            publicKey.getField(B1, (short) 0);
            privateKey.getA(B1, (short) 0);
            privateKey.getB(B1, (short) 0);
            privateKey.getG(B1, (short) 0);
            privateKey.getR(B1, (short) 0);
            privateKey.getField(B1, (short) 0);
        } catch (CryptoException e) {
            initDomainParameters();
        }

        compareDomainParameters(); // throws CryptoException.ILLEGAL_VALUE
        // if domain parameters do not match

        if (!SecurityNativeMethods.validateDomainParameters(((ECMemoryPoolKey)privateKey).getDomainMemoryPoolReference(), ((ECMemoryPoolKey)privateKey).getOwnMemoryPoolReference(), ((ECMemoryPoolKey)publicKey).getOwnMemoryPoolReference())) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        SecurityNativeMethods.genECKeyPair(((ECMemoryPoolKey)privateKey).getDomainMemoryPoolReference(), B1, (short) 0, (short) (privateKey.getSize() / 8),
                B2, (short) 0, (short) (publicKey.getSize() / 8));

        privateKey.setS(B1, (short) 0, (short) (privateKey.getSize() / 8));
        publicKey.setW(B2, (short) 0, (short) ((publicKey.getSize() / 8) * 2 + 1));

    }

    /**
     * This throws CryptoException.ILLEGAL_VALUE if dom params are diff
     */
    private void compareDomainParameters() throws CryptoException {

        short s1, s2;

        // check A

        s1 = publicKey.getA(B1, (short) 0);
        s2 = privateKey.getA(B2, (short) 0);

        if (s1 != s2 || Util.arrayCompare(B1, (short) 0, B2, (short) 0, s1) != 0) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        // check B

        s1 = publicKey.getB(B1, (short) 0);
        s2 = privateKey.getB(B2, (short) 0);

        if (s1 != s2 || Util.arrayCompare(B1, (short) 0, B2, (short) 0, s1) != 0) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        // check G

        s1 = publicKey.getG(B1, (short) 0);
        s2 = privateKey.getG(B2, (short) 0);

        if (s1 != s2 || Util.arrayCompare(B1, (short) 0, B2, (short) 0, s1) != 0) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        // check R

        s1 = publicKey.getR(B1, (short) 0);
        s2 = privateKey.getR(B2, (short) 0);

        if (s1 != s2 || Util.arrayCompare(B1, (short) 0, B2, (short) 0, s1) != 0) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        // check Field

        s1 = publicKey.getField(B1, (short) 0);
        s2 = privateKey.getField(B2, (short) 0);

        if (s1 != s2 || Util.arrayCompare(B1, (short) 0, B2, (short) 0, s1) != 0) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

    }

    /**
     * Sets some default domain parameters based on the key length
     */
    private void initDomainParameters() {

        // constants used to comm with native method getDefaultDomainParameter
        final short A = 1;
        final short B = 2;
        final short G = 3;
        final short R = 4;
        final short F = 5;

        short len = 0;

        // using buffer B1 for intermediate results

        switch (publicKey.getSize()) // key sizes are guaranteed to be
        // identical and valid
        {

            case KeyBuilder.LENGTH_EC_FP_112:

                len = SecurityNativeMethods.getDefaultDomainParameter(B1, A, KeyBuilder.LENGTH_EC_FP_112);
                privateKey.setA(B1, (short) 0, len);
                publicKey.setA(B1, (short) 0, len);

                len = SecurityNativeMethods.getDefaultDomainParameter(B1, B, KeyBuilder.LENGTH_EC_FP_112);
                privateKey.setB(B1, (short) 0, len);
                publicKey.setB(B1, (short) 0, len);

                len = SecurityNativeMethods.getDefaultDomainParameter(B1, G, KeyBuilder.LENGTH_EC_FP_112);
                privateKey.setG(B1, (short) 0, len);
                publicKey.setG(B1, (short) 0, len);

                len = SecurityNativeMethods.getDefaultDomainParameter(B1, R, KeyBuilder.LENGTH_EC_FP_112);
                privateKey.setR(B1, (short) 0, len);
                publicKey.setR(B1, (short) 0, len);

                len = SecurityNativeMethods.getDefaultDomainParameter(B1, F, KeyBuilder.LENGTH_EC_FP_112);
                privateKey.setFieldFP(B1, (short) 0, len);
                publicKey.setFieldFP(B1, (short) 0, len);

                break;

            case KeyBuilder.LENGTH_EC_FP_128:

                len = SecurityNativeMethods.getDefaultDomainParameter(B1, A, KeyBuilder.LENGTH_EC_FP_128);
                privateKey.setA(B1, (short) 0, len);
                publicKey.setA(B1, (short) 0, len);

                len = SecurityNativeMethods.getDefaultDomainParameter(B1, B, KeyBuilder.LENGTH_EC_FP_128);
                privateKey.setB(B1, (short) 0, len);
                publicKey.setB(B1, (short) 0, len);

                len = SecurityNativeMethods.getDefaultDomainParameter(B1, G, KeyBuilder.LENGTH_EC_FP_128);
                privateKey.setG(B1, (short) 0, len);
                publicKey.setG(B1, (short) 0, len);

                len = SecurityNativeMethods.getDefaultDomainParameter(B1, R, KeyBuilder.LENGTH_EC_FP_128);
                privateKey.setR(B1, (short) 0, len);
                publicKey.setR(B1, (short) 0, len);

                len = SecurityNativeMethods.getDefaultDomainParameter(B1, F, KeyBuilder.LENGTH_EC_FP_128);
                privateKey.setFieldFP(B1, (short) 0, len);
                publicKey.setFieldFP(B1, (short) 0, len);

                break;

            case KeyBuilder.LENGTH_EC_FP_160:

                len = SecurityNativeMethods.getDefaultDomainParameter(B1, A, KeyBuilder.LENGTH_EC_FP_160);
                privateKey.setA(B1, (short) 0, len);
                publicKey.setA(B1, (short) 0, len);

                len = SecurityNativeMethods.getDefaultDomainParameter(B1, B, KeyBuilder.LENGTH_EC_FP_160);
                privateKey.setB(B1, (short) 0, len);
                publicKey.setB(B1, (short) 0, len);

                len = SecurityNativeMethods.getDefaultDomainParameter(B1, G, KeyBuilder.LENGTH_EC_FP_160);
                privateKey.setG(B1, (short) 0, len);
                publicKey.setG(B1, (short) 0, len);

                len = SecurityNativeMethods.getDefaultDomainParameter(B1, R, KeyBuilder.LENGTH_EC_FP_160);
                privateKey.setR(B1, (short) 0, len);
                publicKey.setR(B1, (short) 0, len);

                len = SecurityNativeMethods.getDefaultDomainParameter(B1, F, KeyBuilder.LENGTH_EC_FP_160);
                privateKey.setFieldFP(B1, (short) 0, len);
                publicKey.setFieldFP(B1, (short) 0, len);

                break;

            case KeyBuilder.LENGTH_EC_FP_192:

                len = SecurityNativeMethods.getDefaultDomainParameter(B1, A, KeyBuilder.LENGTH_EC_FP_192);
                privateKey.setA(B1, (short) 0, len);
                publicKey.setA(B1, (short) 0, len);

                len = SecurityNativeMethods.getDefaultDomainParameter(B1, B, KeyBuilder.LENGTH_EC_FP_192);
                privateKey.setB(B1, (short) 0, len);
                publicKey.setB(B1, (short) 0, len);

                len = SecurityNativeMethods.getDefaultDomainParameter(B1, G, KeyBuilder.LENGTH_EC_FP_192);
                privateKey.setG(B1, (short) 0, len);
                publicKey.setG(B1, (short) 0, len);

                len = SecurityNativeMethods.getDefaultDomainParameter(B1, R, KeyBuilder.LENGTH_EC_FP_192);
                privateKey.setR(B1, (short) 0, len);
                publicKey.setR(B1, (short) 0, len);

                len = SecurityNativeMethods.getDefaultDomainParameter(B1, F, KeyBuilder.LENGTH_EC_FP_192);
                privateKey.setFieldFP(B1, (short) 0, len);
                publicKey.setFieldFP(B1, (short) 0, len);

                break;
                
            default:
                break;
        }
    }
}
// #endif_Target32Bit_
