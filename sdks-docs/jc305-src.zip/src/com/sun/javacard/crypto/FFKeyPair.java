/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */
package com.sun.javacard.crypto;

import javacard.framework.Util;
import javacard.security.CryptoException;
import javacard.security.KeyBuilder;
import javacard.security.KeyPair;
import javacard.security.PrivateKey;
import javacard.security.PublicKey;

/**
 *
 * 
 */
public final class FFKeyPair implements KeyPairInterfaceInternal {

    private FFPrivateKeyImpl privateKey;
    private FFPublicKeyImpl publicKey;
    private byte[] B1, B2; // used as tmp buffers

    /**
     * Returns a reference to the public key component of this
     * <code>KeyPair</code> object.
     * 
     * @return a reference to the public key.
     */
    public PublicKey getPublic() {
        return publicKey;
    }

    /**
     * Returns a reference to the private key component of this
     * <code>KeyPair</code> object.
     * 
     * @return a reference to the private key.
     */
    public PrivateKey getPrivate() {
        return privateKey;
    }

    /**
     * Constructs a new <code>ECKeyPair</code> object containing the specified
     * public key and private key.
     * 
     * @param publicKey
     *            the public key.
     * @param privateKey
     *            the private key.
     * @exception CryptoException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>CryptoException.ILLEGAL_VALUE</code> if the
     *                input parameter key objects are inconsistent with each
     *                other - i.e mismatched algorithm, size etc.
     *                <li><code>CryptoException.NO_SUCH_ALGORITHM</code> if
     *                the algorithm associated with the specified type, size of
     *                key is not supported.
     *                </ul>
     */
    public FFKeyPair(PublicKey public_key, PrivateKey private_key) throws CryptoException {

        if (!(public_key instanceof FFPublicKeyImpl) 
                || !(private_key instanceof FFPrivateKeyImpl)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        if (public_key.getSize() != private_key.getSize()) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        this.publicKey = (FFPublicKeyImpl) public_key;
        this.privateKey = (FFPrivateKeyImpl) private_key;
        // buffers; size = 2*24+1; used by initDomainParameters()
        // and by compareDomainParameters()
        B1 = new byte[256];
        B2 = new byte[256];

    }

    /**
     * Constructs a <code>KeyPair</code> instance for the specified algorithm
     * and keylength; the encapsulated keys are uninitialized. To initialize the
     * <code>KeyPair</code> instance use the <code>genKeyPair()</code>
     * method.
     * <p>
     * The encapsulated key objects are of the specified <code>keyLength</code>
     * size and implement the appropriate <code>Key</code> interface
     * associated with the specified algorithm
     * <p>
     * Notes:
     * <ul>
     * <li><em>The key objects encapsulated in the generated </em><code>KeyPair</code><em> object
     * need not support the </em><code>KeyEncryption</code><em> interface.</em>
     * </ul>
     * 
     * @param algorithm
     *            the type of algorithm whose key pair needs to be generated.
     *            Valid codes listed in <code>ALG_..</code> constants above.
     * @param keyLength
     *            the key size in bits. The valid key bit lengths for ALG_EC_FP
     *            are: 112, 128, 160 and 192 bits. See the
     *            <code>KeyBuilder</code> class.
     * @exception CryptoException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>CryptoException.NO_SUCH_ALGORITHM</code> if
     *                the requested algorithm associated with the specified
     *                type, size of key is not supported.
     *                </ul>
     * @see KeyBuilder
     * @see Signature
     * @see javacardx.crypto.Cipher
     * @see javacardx.crypto.KeyEncryption
     */
    public FFKeyPair(byte algorithm, short keyLength) throws CryptoException {

        if (algorithm == KeyPair.ALG_DH) {

            switch (keyLength) {
                case KeyBuilder.LENGTH_DH_1024:
                case KeyBuilder.LENGTH_DH_2048:
                    break;
                default:
                    CryptoException.throwIt(CryptoException.NO_SUCH_ALGORITHM);
            }

            privateKey = new com.sun.javacard.crypto.FFPrivateKeyImpl(KeyBuilder.TYPE_DH_PRIVATE, keyLength);

            publicKey = new com.sun.javacard.crypto.FFPublicKeyImpl(KeyBuilder.TYPE_DH_PUBLIC, keyLength);
            B1 = new byte[256];
            B2 = new byte[256];

        } else {
            CryptoException.throwIt(CryptoException.NO_SUCH_ALGORITHM);
        }
    }

    /**
     * (Re)Initializes the key objects encapsulated in this <code>KeyPair</code>
     * instance with new key values. The initialized public and private key
     * objects encapsulated in this instance will then be suitable for use with
     * the <code>Signature</code>, <code>Cipher</code> and
     * <code>KeyAgreement</code> objects. An internal secure random number
     * generator is used during new key pair generation.
     * 
     * @exception CryptoException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>CryptoException.ILLEGAL_VALUE</code> if the
     *                Field, A, B, G and R parameter set in EC keys are invalid
     *                or mismatch.
     *                </ul>
     */
    public final void genKeyPair() throws CryptoException {

        try { // checking if domain params are set
            publicKey.getP(B1, (short) 0);
            publicKey.getQ(B1, (short) 0);
            publicKey.getG(B1, (short) 0);
            privateKey.getP(B1, (short) 0);
            privateKey.getQ(B1, (short) 0);
            privateKey.getG(B1, (short) 0);
        } catch (CryptoException e) {
            initDomainParameters();
        }

        compareDomainParameters(); // throws CryptoException.ILLEGAL_VALUE
        // if domain parameters do not match

        if (!SecurityNativeMethods.validateFFDomainParameters(privateKey.memoryPool)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        SecurityNativeMethods.genFFKeyPair(privateKey.memoryPool, B1, (short) 0, (short) (privateKey.getActualQSize() / 8),
                B2, (short) 0, (short) (publicKey.getSize() / 8));

        privateKey.setX(B1, (short) 0, (short) (privateKey.getActualQSize() / 8));
        publicKey.setY(B2, (short) 0, (short) (publicKey.getSize() / 8));

    }

    /**
     * This throws CryptoException.ILLEGAL_VALUE if dom params are diff
     */
    private void compareDomainParameters() throws CryptoException {

        short s1, s2;

        // check A

        s1 = publicKey.getP(B1, (short) 0);
        s2 = privateKey.getP(B2, (short) 0);

        if (s1 != s2 || Util.arrayCompare(B1, (short) 0, B2, (short) 0, s1) != 0) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        // check B

        s1 = publicKey.getQ(B1, (short) 0);
        s2 = privateKey.getQ(B2, (short) 0);

        if (s1 != s2 || Util.arrayCompare(B1, (short) 0, B2, (short) 0, s1) != 0) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        // check G

        s1 = publicKey.getG(B1, (short) 0);
        s2 = privateKey.getG(B2, (short) 0);

        if (s1 != s2 || Util.arrayCompare(B1, (short) 0, B2, (short) 0, s1) != 0) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
    }

    /**
     * Sets some default domain parameters based on the key length
     */
    private void initDomainParameters() {

        // constants used to comm with native method getDefaultDomainParameter
        final short P = 6;
        final short Q = 7;
        final short G = 8;

        short len = 0;

        // using buffer B1 for intermediate results

        switch (publicKey.getSize()) // key sizes are guaranteed to be
        // identical and valid
        {

            case KeyBuilder.LENGTH_DH_1024:

                len = SecurityNativeMethods.getDefaultDomainParameter(B1, P, KeyBuilder.LENGTH_DH_1024);
                privateKey.setP(B1, (short) 0, len);
                publicKey.setP(B1, (short) 0, len);

                len = SecurityNativeMethods.getDefaultDomainParameter(B1, Q, KeyBuilder.LENGTH_DH_1024);
                privateKey.setQ(B1, (short) 0, len);
                publicKey.setQ(B1, (short) 0, len);

                len = SecurityNativeMethods.getDefaultDomainParameter(B1, G, KeyBuilder.LENGTH_DH_1024);
                privateKey.setG(B1, (short) 0, len);
                publicKey.setG(B1, (short) 0, len);

                break;

            case KeyBuilder.LENGTH_DH_2048:

                len = SecurityNativeMethods.getDefaultDomainParameter(B1, P, KeyBuilder.LENGTH_DH_2048);
                privateKey.setP(B1, (short) 0, len);
                publicKey.setP(B1, (short) 0, len);

                len = SecurityNativeMethods.getDefaultDomainParameter(B1, Q, KeyBuilder.LENGTH_DH_2048);
                privateKey.setQ(B1, (short) 0, len);
                publicKey.setQ(B1, (short) 0, len);

                len = SecurityNativeMethods.getDefaultDomainParameter(B1, G, KeyBuilder.LENGTH_DH_2048);
                privateKey.setG(B1, (short) 0, len);
                publicKey.setG(B1, (short) 0, len);

                break;
                
            default:
                break;
        }
    }
    
}
