/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */
package com.sun.javacard.crypto;

/**
 *
 * 
 */
abstract class ECMemoryPoolKey {

    static final short PERSISTENT = (short)1;
    static final short NON_PERSISTENT = (short)0;
    
    abstract byte[] getOwnMemoryPoolReference();
    
    abstract byte[] getDomainMemoryPoolReference();
    
    abstract boolean isDomainInitialized();
    
}
