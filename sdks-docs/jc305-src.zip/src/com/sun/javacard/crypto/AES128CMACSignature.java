/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */
package com.sun.javacard.crypto;

import com.sun.javacard.impl.NativeMethods;
import javacard.security.Key;
import javacard.framework.JCSystem;
import javacard.framework.Util;
import javacard.security.AESKey;
import javacard.security.CryptoException;
import javacard.security.KeyBuilder;
import javacardx.crypto.Cipher;



/**
 *
 * 
 */
public class AES128CMACSignature extends SignatureInternal {
    
    
    protected final static short AES_128_BLOCK_SIZE = 16;
    private static final short MEMORY_POOL_SIZE_INIT = 54;
    private static final short MEMORY_POOL_SIZE_RES = 90;
    
    private static final byte IS_LAST_BLOCK = 1;
    private static final byte IS_INTERMEDIATE_BLOCK = 0;
    
    private static final byte SIG_UPDATE_STATE = 2;
    private static final byte SIG_FINAL_STATE = 3;    

    /**
     * The cipher object used to create and verify the Signature
     */
    //protected Cipher cipher;

    /**
     * The current operating mode (MODE_SIGN or MODE_VERIFY) mode object is
     * create in Persistent memory and stored in such a way that it does not
     * participate in transaction (spec requirement). This is necessary as one
 could create a AESKey of type persistent then create a Cipher/SignatureInternal
 object and then a tear happens. After tear, if they call SignatureInternal.Sign
 or Cipher.doFinal, then this must work with the default IV.
     */
    protected byte[] mode;

    /**
     * Indicates proper initialization of this signature object
     */
    protected boolean[] initFlag;

    boolean keyPersistant = false;

    private byte[] temp = null;

    private byte[] temp_in_store = null;
    private byte[] temp_in_count; // byte value
    private short totalLen; /* total length of signed/verified bytes */
    
    private byte[] mempoolInit;
    private byte[] mempoolRes;
    /*
    protected byte[] defaultIV = { 
                (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, 
                (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00 };   
    */
    

    protected AESKeyImpl akey;
    
    public AES128CMACSignature(byte algorithm, byte messageDigestAlgorithm, byte cipherAlgorithm, byte paddingAlgorithm) {
        super(algorithm, messageDigestAlgorithm, cipherAlgorithm, paddingAlgorithm);
        temp = JCSystem.makeTransientByteArray(AES_128_BLOCK_SIZE, JCSystem.CLEAR_ON_DESELECT);

        temp_in_store = JCSystem.makeTransientByteArray(AES_128_BLOCK_SIZE, JCSystem.CLEAR_ON_DESELECT);

        initFlag = JCSystem.makeTransientBooleanArray((short) 1, JCSystem.CLEAR_ON_DESELECT);
        mode = new byte[1];

        temp_in_count = JCSystem.makeTransientByteArray((short) 1, JCSystem.CLEAR_ON_DESELECT);
        temp_in_count[0] = 0;
        mempoolInit = new byte[MEMORY_POOL_SIZE_INIT];
        
        
        mempoolRes = JCSystem.makeTransientByteArray((short) MEMORY_POOL_SIZE_RES, JCSystem.CLEAR_ON_DESELECT);  
        
    }    

    @Override
    public void init(Key theKey, byte theMode) throws CryptoException {
         /* store a reference to the key. We must check it's initialization 
         * state later
         */
        
        totalLen = 0;
        /* RI implementation expects only a NULL IV */
        //Util.arrayCopyNonAtomic(defaultIV, (short) 0, bArray, (short) 0, (short) defaultIV.length);
        
        
        //NativeMethods.checkArrayArgs(bArray, bOff, bLen);
        // Verify that the key is initialized
        if (!theKey.isInitialized()) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }
        SecurityNativeMethods.DebugShort((short)0xAA, (short)1);
        /* Ensure that the Initialization Vector length specified is of the 
         * correct length
         */
        /*
        if (bLen != AES_128_BLOCK_SIZE) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
        */
        
        SecurityNativeMethods.DebugShort((short)0xAA, (short)2);

        /* Verify that the mode value is valid and set the mode for the 
         * cipher accordingly
         */
        switch (theMode) {
            /* The cipher object does an ENCRYPTION operation whether we are 
             * signing data or verifying a signature.
             * In a verification we sign the data and compare it to a passed in 
             * signature
             */
            case MODE_SIGN:
            case MODE_VERIFY:
                Util.arrayFillNonAtomic(mode, (short) 0, (short) 1, theMode);
                break;

            default:
                CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
        SecurityNativeMethods.DebugShort((short)0xAA, (short)3);
        // Verify that the key is a AES key
        if (!(theKey instanceof AESKey)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
        akey = (AESKeyImpl) theKey;

        /* if we got this far then the input is valid and we can proceed
         * Initialize the cipher. It should be instantiated in the constructor of 
         * derived classes
         */
        SecurityNativeMethods.AESCMACinit(akey.data, mempoolInit, mempoolRes);
        /* if the cipher.init didn't throw an exception then the initialization
         * succeeded
         */
        initFlag[0] = true;
        SecurityNativeMethods.DebugShort((short)0xAA, (short)4);
        /* If the key is persistant we need to keep track of it so that we can 
         * use the SignatureInternal object after tear or reset.
         */
        if (theKey.getType() == KeyBuilder.TYPE_AES) {
            keyPersistant = true;
        } else {
            keyPersistant = false;
        }
    }

    @Override
    public void init(Key theKey, byte theMode, byte[] bArray, short bOff, short bLen) throws CryptoException {
        CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
    }

    @Override
    public void setInitialDigest(byte[] initialDigestBuf, short initialDigestOffset, short initialDigestLength, byte[] digestedMsgLenBuf, short digestedMsgLenOffset, short digestedMsgLenLength) throws CryptoException {
        CryptoException.throwIt(CryptoException.ILLEGAL_USE);
    }
    

    @Override
    public short getLength() throws CryptoException {
        /*
         * cipher.update is used here, to verify that the cipher key has 
         * been initializedit will throw CryptoException.UNINITIALIZED_KEY, 
         * if the key is not initialized
         */
        //cipher.update(temp, (short) 0, (short) 0, temp, (short) 0);

        if (!initFlag[0]) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }
        return AES_128_BLOCK_SIZE;
    }

    @Override
    public void update(byte[] inBuff, short inOffset, short inLength) throws CryptoException {
        // Ensure the SignatureInternal object is initialized for signing
        if (!initFlag[0]) {
            if (!(keyPersistant)) {
                CryptoException.throwIt(CryptoException.INVALID_INIT);
            }
        }
        
        // Verify that the key is initialized
        if (!akey.isInitialized()) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }

        /** Checking array bounds to throw the right kind of exception */
        NativeMethods.checkArrayArgs(inBuff, inOffset, inLength);

        if (inLength == 0) { // nothing to update - just return
            return;
        }
        


        /*
         * We don't need to store the output resulting from the update calls
         * since in the AES algorithm only the LAST 16 bytes encrypted contain
         * the signature, so we can allow the cipher object to output its 
         * encrypted output into a temporary buffer that we don't need to store
         * The spec says that we should throw a CryptoException(UNINITIALIZED_KEY)
         * if the key is not initialized, but the cipher.update does that already
         */
        doUpdate(inBuff, inOffset, inLength, temp, (short) 0, (short)SIG_UPDATE_STATE);
    }

    @Override
    public short sign(byte[] inBuff, short inOff, short inLen, byte[] sigBuff, short sigOffset) throws CryptoException {
        /*  To get the last 16 bytes of encrypted output all we need to do is  
         *  doFinal on the cipher 
         *  Ensure the SignatureInternal object is initialized for signing
         */
        NativeMethods.sensitiveResultSetTagValUnassigned();
        if (mode[0] != MODE_SIGN) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }

        
        SecurityNativeMethods.DebugShort((short)0x55, (short)0);
        if (!initFlag[0]) {
            if (!(keyPersistant)) {
                CryptoException.throwIt(CryptoException.INVALID_INIT);
            }
        }
        SecurityNativeMethods.DebugShort((short)0x55, (short)1);
        /** Checking array bounds to throw the right kind of exception */
        NativeMethods.checkArrayArgs(inBuff, inOff, inLen);
        NativeMethods.checkArrayArgs(sigBuff, sigOffset, AES_128_BLOCK_SIZE);

        short result = doSign(inBuff, inOff, inLen, sigBuff, sigOffset, (short)SIG_FINAL_STATE);
        
        
        
        
        NativeMethods.sensitiveResultSet(result);
        return result;
    }
    
    protected short doSign(byte[] inBuff, short inOff, short inLen, byte[] sigBuff, short sigOff, short bIsLastBlock)
            throws CryptoException {

        //if (((short) (inLen + temp_in_count[0]) % AES_128_BLOCK_SIZE) != 0) {
        //    CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        //}

        /* if I call doFinal with the entire date, I will have to keep track
         * if I had called update earlier.  With this method, it is very simple.
         * Finally when I call doFinal with len = 0, I should get the correct
         * result or an exception.  Keeping a +ve attitude, that exceptions for
         * not block aligned are thrown rarely.
         */
        short finalBytes = doUpdate(inBuff, inOff, inLen, temp, (short) 0, bIsLastBlock);
        //finalBytes = cipher.doFinal(inBuff, inOff, (short) 0, temp, (short) 0);
        
        temp_in_count[0] = (byte) 0;
        /*    
         * We have finalBytes output to the temp buffer. We need to copy the
        * last AES_128_BLOCK_SIZE bytes of this into sigBuff
        */
        NativeMethods.arrayCopyNonAtomicForSensitiveArrays(temp, (short) 0, sigBuff, sigOff, AES_128_BLOCK_SIZE);

        return finalBytes;
    }    



    @Override
    public boolean verify(byte[] inBuff, short inOff, short inLen, byte[] sigBuff, short sigOffset, short sigLength) throws CryptoException {
        NativeMethods.sensitiveResultSetTagValUnassigned();
        // Ensure the SignatureInternal object is initialized for verification
        if (mode[0] != MODE_VERIFY) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }

        if (!initFlag[0]) {
            if (!(keyPersistant)) {
                CryptoException.throwIt(CryptoException.INVALID_INIT);
            }
        }

        if (sigLength != AESCipher.AES_128_BLOCK_SIZE) {
            NativeMethods.sensitiveResultSetBooleanFalse();
            return false;
        }

        /** Checking array bounds to throw the right kind of exception */
        NativeMethods.checkArrayArgs(inBuff, inOff, inLen);
        NativeMethods.checkArrayArgs(sigBuff, sigOffset, sigLength);

        /*   
         * First call sign on this last bit of input and store the 
         * resulting signature in a temporary buffer.
         * The buffer (temp) need only be long enough to support 
         * the input length + possible padding bytes
         */

        // sign the data
        short finalBytes = doSign(inBuff, inOff, inLen, temp, (short) 0, (short)SIG_FINAL_STATE);

        // now compare the last sigLen bytes of temp
        if (Util.arrayCompare(temp, (short) 0, sigBuff, sigOffset, sigLength) != 0) {
            NativeMethods.sensitiveResultSetBooleanFalse();
            return false;
        }
        
        NativeMethods.sensitiveResultSetBooleanTrue();
        return true;
    }
    
   /**
     * wrapper method to call cipher.update
     * 
     */

    protected short doUpdate(byte[] inBuff, short inOff, short inLen, byte[] sigBuff, short sigOff, short finalState)
            throws CryptoException {
        short result = 0;
        short track = temp_in_count[0];
        short j = (short) (inLen + track);
        short ino = inOff;
        short blocks;
        short bLastBlock = IS_INTERMEDIATE_BLOCK;
        blocks = (short)0;/* number of AES blocks to be processed */

        totalLen += inLen;
        result = AES_128_BLOCK_SIZE;
        
        // Verify that the key is initialized
        if (!akey.isInitialized()) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }        
        
        SecurityNativeMethods.DebugShort((short)0, (short)(finalState));
        
        /* if input buffer length is 0 */
        if (j == 0)
        {
            SecurityNativeMethods.DebugShort((short)13, (short)(totalLen));
            if (totalLen == 0)
            {
                SecurityNativeMethods.AESCMACsign(temp_in_store, sigBuff, (short)0, (short)IS_LAST_BLOCK, (short)0, mempoolInit, mempoolRes);
                //result = 0;
            } else
            {
                SecurityNativeMethods.AESCMACsign(temp_in_store, sigBuff, (short)AES_128_BLOCK_SIZE, (short)IS_LAST_BLOCK, (short)1, mempoolInit, mempoolRes);
                //result = AES_128_BLOCK_SIZE;
            }
            temp_in_count[0] = 0;
            SecurityNativeMethods.DebugShort((short)19, (short)(result));
            return (short) result;
        }
        
        SecurityNativeMethods.DebugShort((short)1, (short)(inLen));
        SecurityNativeMethods.DebugShort((short)2, (short)(track));
        
        /* if sign is called with 0 bytes in length but the previous 16 bytes were provided using update */
        if ((inLen == 0) && (finalState == SIG_FINAL_STATE))
        {
            bLastBlock = IS_LAST_BLOCK;
            SecurityNativeMethods.DebugShort((short)13, blocks);
            SecurityNativeMethods.DebugShort((short)14, track);
            if (track != 0)                 
            {
                SecurityNativeMethods.AESCMACsign(temp_in_store, sigBuff, (short)track, (short)bLastBlock, (short)0, mempoolInit, mempoolRes);
                //result = totalLen;
            } else
            {
                SecurityNativeMethods.AESCMACsign(temp_in_store, sigBuff, (short)AES_128_BLOCK_SIZE, (short)bLastBlock, (short)0, mempoolInit, mempoolRes);
                //result = AES_128_BLOCK_SIZE;
            }
            temp_in_count[0] = 0;
            result = AES_128_BLOCK_SIZE;
            //result = totalLen;
            SecurityNativeMethods.DebugShort((short)18, (short)(result));
            return (short) result;                    
        }
        
        blocks = (short) ((inLen) / AES_128_BLOCK_SIZE);            
        if (((inLen) % AES_128_BLOCK_SIZE) > 0) blocks++;        
        
        /* bytes are loaded with update and sign is called with 0 in length */
        if ((inLen==0) && (track>0) && (track<AES_128_BLOCK_SIZE))
        {
         blocks++;   
        }


        // Case 1 - (track + inLen) or j < AES_128_BLOCK_SIZE
        if ((j < AES_128_BLOCK_SIZE) && (track == 0)) {
            // just copy and return 0
            for (; track < j; track++, ino++) {
                temp_in_store[track] = inBuff[ino];       
            }
            temp_in_count[0] = (byte) track;
            SecurityNativeMethods.DebugShort((short)10, track);
            
            if (finalState == SIG_FINAL_STATE)
            {            
                bLastBlock = IS_LAST_BLOCK;
                SecurityNativeMethods.DebugShort((short)12, blocks);
                SecurityNativeMethods.AESCMACsign(temp_in_store, sigBuff, (short)track, (short)bLastBlock, (short)0, mempoolInit, mempoolRes);
                temp_in_count[0] = (byte) 0;
                //result = track;
                result = AES_128_BLOCK_SIZE;
                
                track = (short) 0; 
            }
            SecurityNativeMethods.DebugShort((short)17, (short)(result));
            return (short) result;
        }
        // case 2 - (track + inLen) or j == AES_128_BLOCK_SIZE
        else if (j == AES_128_BLOCK_SIZE) {
            // cipher the block and return result
            for (; track < j; track++, ino++) {
                temp_in_store[track] = inBuff[ino];
            }

            SecurityNativeMethods.DebugShort((short)3, blocks);
            
            if (finalState == SIG_FINAL_STATE)
             {
               if (blocks == 1)
               {
                   bLastBlock = IS_LAST_BLOCK;
               }
             }            
            
            SecurityNativeMethods.AESCMACsign(temp_in_store, sigBuff, (short)track, (short)bLastBlock, (short)0, mempoolInit, mempoolRes);

            temp_in_count[0] = (byte) 0;
            result = AES_128_BLOCK_SIZE;
            track = (short) 0;  
            SecurityNativeMethods.DebugShort((short)16, (short)(result));
            return result;
        }
        // case 3 - (track + inLen) or j > AES_128_BLOCK_SIZE
        else {
            // copy the input into temp_in_store and then cipher.update if block
            // aligned

            SecurityNativeMethods.DebugShort((short)11, (short)(blocks));            
            
            if (finalState == SIG_FINAL_STATE)
            {
                if (((inLen)>0) && (blocks == 1))                
                {
                    bLastBlock = IS_LAST_BLOCK;                
                } else
                {                
                    bLastBlock = IS_INTERMEDIATE_BLOCK;
                }
            }               
     
            while (ino < (short) (inOff + inLen)) {
                for (; (track < AES_128_BLOCK_SIZE) && ((short) (inOff + inLen) > ino); ino++) {
                    temp_in_store[track] = inBuff[ino];
                    track++;
                    
                    //SecurityNativeMethods.DebugShort((short)4, blocks);
                    //SecurityNativeMethods.DebugShort((short)5, track);                    
                    
                    if ((track == AES_128_BLOCK_SIZE) /*|| (blocks == 1 && (track>0))*/)
                    {
                          //result = cipher.update(temp_in_store, (short) 0, AES_128_BLOCK_SIZE, sigBuff, sigOff);
              
                          if (finalState == SIG_FINAL_STATE) 
                          {
                            if (blocks == 1)
                            {
                                bLastBlock = IS_LAST_BLOCK;
                            }
                          }
                        

                          SecurityNativeMethods.AESCMACsign(temp_in_store, sigBuff, (short)track, (short)bLastBlock, (short)0, mempoolInit, mempoolRes);
                          //if (finalState == SIG_FINAL_STATE)
                          //{
                          blocks--;
                          //}
                          //temp_in_count[0] = (byte) 0;
                          track = (short) 0;
                          
                          result = AES_128_BLOCK_SIZE;
                    } 
                    
                }
                temp_in_count[0] = (byte) track;                  
            }

            
            SecurityNativeMethods.DebugShort((short)6, blocks);
            SecurityNativeMethods.DebugShort((short)7, track);            
            
            /* process also the last partial block of data if available */
            if ((temp_in_count[0]>0) && (temp_in_count[0]<AES_128_BLOCK_SIZE) && (blocks == 1) && (finalState == SIG_FINAL_STATE))
            {
                bLastBlock = IS_LAST_BLOCK;
                SecurityNativeMethods.DebugShort((short)8, blocks);
                SecurityNativeMethods.DebugShort((short)9, track);
                SecurityNativeMethods.AESCMACsign(temp_in_store, sigBuff, (short)track, (short)bLastBlock, (short)0, mempoolInit, mempoolRes);
                blocks--;
                //result = temp_in_count[0];
                temp_in_count[0] = (byte) 0;
                track = (short) 0; 
            }
            result = AES_128_BLOCK_SIZE;
            SecurityNativeMethods.DebugShort((short)15, (short)(result));
            return result;
        }
    }    

    @Override
    public boolean verifyPreComputedHash(byte[] hashBuff, short hashOffset, short hashLength, byte[] sigBuff, short sigOffset, short sigLength) throws CryptoException {
        NativeMethods.sensitiveResultSetTagValUnassigned();
        CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        
        NativeMethods.sensitiveResultSet((short) 0);
        return false;
    }
    
    @Override
    public short signPreComputedHash(byte[] hashBuff, short hashOffset, short hashLength, byte[] sigBuff, short sigOffset) throws CryptoException {
        NativeMethods.sensitiveResultSetTagValUnassigned();
        CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        
        NativeMethods.sensitiveResultSetBooleanFalse();
        return (short)0;
    }    
    
}
