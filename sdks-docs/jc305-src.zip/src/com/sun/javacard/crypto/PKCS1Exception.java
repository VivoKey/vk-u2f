/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

public class PKCS1Exception extends javacard.security.CryptoException {

    public PKCS1Exception(short reason) {
        super(reason);
    }
}
