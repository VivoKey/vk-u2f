/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
// #ifdef_Target32Bit_
package com.sun.javacard.crypto;

import javacard.framework.JCSystem;
import javacard.security.CryptoException;

import com.sun.javacard.impl.NativeMethods;
import javacard.framework.Util;
import javacard.security.ECPrivateKey;
import javacard.security.ECPublicKey;

// Implements SignatureInternal for the ECDSA algorithm.
public class ECDSASignature extends SignatureInternal {
    private javacard.security.InitializedMessageDigest messageDigest;
    private static final short SHA_DIGEST_LENGTH = 20;
    private static final short ENCODING_LENGTH_ADJUSTMENT = 8;
    private byte[] DigestBuff;
    private boolean initFlag;
    private ECPrivateKey privKey;
    private ECPublicKey pubKey;
    private byte mode;
    private short ECSignatureLength;
    private byte[] genSeed = { 0x67, 0x45, 0x23, 0x01, 0x1f, 0x5d, 0x3b, 0x79 };

    public ECDSASignature(byte algorithm, byte messageDigestAlgorithm, byte cipherAlgorithm, byte paddingAlgorithm) {
        super(algorithm, messageDigestAlgorithm, cipherAlgorithm, paddingAlgorithm);
        DigestBuff = JCSystem.makeTransientByteArray(SHA_DIGEST_LENGTH, JCSystem.CLEAR_ON_DESELECT);
        messageDigest = javacard.security.MessageDigest.getInitializedMessageDigestInstance(javacard.security.MessageDigest.ALG_SHA, false);
    }

    public void init(javacard.security.Key theKey, byte theMode) throws CryptoException {

        if (!theKey.isInitialized()) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }

        if ((theMode == MODE_SIGN) && (theKey instanceof ECSharedDomainPrivateKeyImpl)) {
            mode = MODE_SIGN;
            privKey = (ECPrivateKey) theKey;
            if (!SecurityNativeMethods.validateDomainParameters(((ECMemoryPoolKey)privKey).getDomainMemoryPoolReference(), ((ECMemoryPoolKey)privKey).getOwnMemoryPoolReference(), null)) {
                CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
            }
            ECSignatureLength = (short) ((privKey.getSize() / 8) * 2 + ENCODING_LENGTH_ADJUSTMENT);
        } else if ((theMode == MODE_VERIFY) && (theKey instanceof ECSharedDomainPublicKeyImpl)) {
            mode = MODE_VERIFY;
            pubKey = (ECPublicKey) theKey;
            if (!SecurityNativeMethods.validateDomainParameters(((ECMemoryPoolKey)pubKey).getDomainMemoryPoolReference(), null, ((ECMemoryPoolKey)pubKey).getOwnMemoryPoolReference())) {
                CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
            }
            ECSignatureLength = (short) ((pubKey.getSize() / 8) * 2 + ENCODING_LENGTH_ADJUSTMENT);
        } else {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
        initFlag = true;
    }

    /*
     * Since this form of init not supported for ECDSA, it just
     * throws an exception.
     */
    public void init(javacard.security.Key theKey, byte theMode, byte[] bArray, short bOff, short bLen)
            throws CryptoException {
        CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
    }

   public void setInitialDigest(byte[] initialDigestBuf, short initialDigestOffset,
            short initialDigestLength, byte[] digestedMsgLenBuf, short digestedMsgLenOffset, short digestedMsgLenLength)
            throws CryptoException{
       messageDigest.setInitialDigest( initialDigestBuf, initialDigestOffset,
                initialDigestLength, digestedMsgLenBuf, digestedMsgLenOffset,
                digestedMsgLenLength);
   }

    public short getLength() {

        if (!initFlag) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }
        if (!(mode == MODE_SIGN ? privKey.isInitialized() : pubKey.isInitialized())) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }

        return ECSignatureLength;
    }

    public void update(byte[] inBuff, short inOff, short inLen) throws CryptoException {

        if (inLen == 0) {
            return;
        }

        if (!initFlag) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }

        if (!(mode == MODE_SIGN ? privKey.isInitialized() : pubKey.isInitialized())) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }

        /*
         * Input array bounds checking is not done as MessageDigest.update
         * does the same thing.
         */
        messageDigest.update(inBuff, inOff, inLen);
    }

    public short sign(byte[] inBuff, short inOff, short inLen, byte[] sigBuff, short sigOff) throws CryptoException {
        short resultLength = 0;
        
        NativeMethods.sensitiveResultSetTagValUnassigned();
        
        if ((!initFlag) || (mode != MODE_SIGN)) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }

        if (!privKey.isInitialized()) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }

        /**
         * Checking array bounds to throw the right kind of exception Input
         * array bounds checking is not done as MessageDigest.doFinal does the
         * same thing.
         */

        NativeMethods.checkArrayArgs(sigBuff, sigOff, ECSignatureLength);
        messageDigest.doFinal(inBuff, inOff, inLen, DigestBuff, (short) 0);

        // "This algorithm truncates the SHA-1 digest to the length of the EC key
        // for EC key lengths less than 160 bits in accordance with section 4.1
        // "Elliptic Curve Digit SignatureInternal Algorithm" of the
        // "SEC 1: Elliptic Curve Cryptography" specification"
        // Truncate the message digest to the key size if it is too long
        short keyByteLen = (short)(privKey.getSize()/8);
        short hashLen = (short)messageDigest.getLength();
        if ( hashLen> keyByteLen){
            short excessBytes = (short)(hashLen - keyByteLen);
            Util.arrayCopy(DigestBuff, (short)0, DigestBuff, (short)excessBytes, (short)keyByteLen);
            Util.arrayFillNonAtomic(DigestBuff, (short)0, (short)excessBytes, (byte)0);
        }

        // Do signing of message Digest.
        resultLength = SecurityNativeMethods.ECDSASign(DigestBuff, (short) 0, genSeed, (short) 8, (short) 0,
                ((ECMemoryPoolKey)privKey).getDomainMemoryPoolReference(), sigBuff, sigOff,((ECMemoryPoolKey)privKey).getOwnMemoryPoolReference());
        
        NativeMethods.sensitiveResultSet(resultLength);
        return resultLength;
    }

    public short signPreComputedHash(byte[] hashBuf, short hashOff, short hashLength, byte[] sigBuff, short sigOffset){
        short resultLength = 0;

        NativeMethods.sensitiveResultSetTagValUnassigned();
        
        if ((!initFlag) || (mode != MODE_SIGN)) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }

        if (!privKey.isInitialized()) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }

        NativeMethods.checkArrayArgs(hashBuf, hashOff, hashLength);

        if (hashLength != messageDigest.getLength()){
            CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        }

        NativeMethods.checkArrayArgs(sigBuff, sigOffset, ECSignatureLength);

        Util.arrayCopy(hashBuf, hashOff, DigestBuff, (short) 0, hashLength);

        // "This algorithm truncates the SHA-1 digest to the length of the EC key
        // for EC key lengths less than 160 bits in accordance with section 4.1
        // "Elliptic Curve Digit SignatureInternal Algorithm" of the
        // "SEC 1: Elliptic Curve Cryptography" specification"
        // Truncate the message digest to the key size if it is too long
        short keyByteLen = (short)(privKey.getSize()/8);
        short hashLen = (short)messageDigest.getLength();
        if ( hashLen> keyByteLen){
            short excessBytes = (short)(hashLen - keyByteLen);
            Util.arrayCopy(DigestBuff, (short)0, DigestBuff, (short)excessBytes, (short)keyByteLen);
            Util.arrayFillNonAtomic(DigestBuff, (short)0, (short)excessBytes, (byte)0);
        }

        // Do signing of message Digest.
        resultLength = SecurityNativeMethods.ECDSASign(DigestBuff, (short) 0, genSeed, (short) 8, (short) 0,
                ((ECMemoryPoolKey)privKey).getDomainMemoryPoolReference(), sigBuff, sigOffset,((ECMemoryPoolKey)privKey).getOwnMemoryPoolReference());
        
        NativeMethods.sensitiveResultSet(resultLength);
        return resultLength;
    }
    
    public boolean verifyPreComputedHash(byte[] hashBuff, short hashOffset, short hashLength, byte[] sigBuff, short sigOffset,
            short sigLength) throws CryptoException{
        NativeMethods.sensitiveResultSetTagValUnassigned();
        
        if ((!initFlag) || (mode != MODE_VERIFY)) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }

        boolean verified = false;
        if (!pubKey.isInitialized()) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }
        /**
         * Checking array bounds to throw the right kind of exception Input
         * array bounds checking is not done as MessageDigest.doFinal does the
         * same thing.
         */
        NativeMethods.checkArrayArgs(sigBuff, sigOffset, sigLength);

        if (sigBuff[(short) (sigOffset + 1)] != sigLength - 2) {
            NativeMethods.sensitiveResultSetBooleanFalse();
            return false;
        }

        if (hashLength != messageDigest.getLength()){
            CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        }
        
        Util.arrayCopy(hashBuff, hashOffset, DigestBuff, (short) 0, hashLength);

        // "This algorithm truncates the SHA-1 digest to the length of the EC key
        // for EC key lengths less than 160 bits in accordance with section 4.1
        // "Elliptic Curve Digit SignatureInternal Algorithm" of the
        // "SEC 1: Elliptic Curve Cryptography" specification"
        // Truncate the message digest to the key size if it is too long
        short keyByteLen = (short)(pubKey.getSize()/8);
        short hashLen = (short)messageDigest.getLength();
        if ( hashLen> keyByteLen){
            short excessBytes = (short)(hashLen - keyByteLen);
            Util.arrayCopy(DigestBuff, (short)0, DigestBuff, (short)excessBytes, (short)keyByteLen);
            Util.arrayFillNonAtomic(DigestBuff, (short)0, (short)excessBytes, (byte)0);
        }

        // verify the SignatureInternal
        verified = SecurityNativeMethods.ECDSAVerify(sigBuff, sigOffset, DigestBuff, (short) 0, ((ECMemoryPoolKey)pubKey).getDomainMemoryPoolReference(), ((ECMemoryPoolKey)pubKey).getOwnMemoryPoolReference());
        
        if (verified)
            NativeMethods.sensitiveResultSetBooleanTrue();
        else
            NativeMethods.sensitiveResultSetBooleanFalse();
        return verified;
    }
    

    public boolean verify(byte[] inBuff, short inOff, short inLen, byte[] sigBuff, short sigOff, short sigLen)
            throws CryptoException {

        NativeMethods.sensitiveResultSetTagValUnassigned();
        
        if ((!initFlag) || (mode != MODE_VERIFY)) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }

        boolean verified = false;
        if (!pubKey.isInitialized()) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }
        /**
         * Checking array bounds to throw the right kind of exception Input
         * array bounds checking is not done as MessageDigest.doFinal does the
         * same thing.
         */
        NativeMethods.checkArrayArgs(sigBuff, sigOff, sigLen);

        if (sigBuff[(short) (sigOff + 1)] != sigLen - 2) {
            NativeMethods.sensitiveResultSetBooleanFalse();
            return false;
        }

        messageDigest.doFinal(inBuff, inOff, inLen, DigestBuff, (short) 0);

        // "This algorithm truncates the SHA-1 digest to the length of the EC key
        // for EC key lengths less than 160 bits in accordance with section 4.1
        // "Elliptic Curve Digit SignatureInternal Algorithm" of the
        // "SEC 1: Elliptic Curve Cryptography" specification"
        // Truncate the message digest to the key size if it is too long
        short keyByteLen = (short)(pubKey.getSize()/8);
        short hashLen = (short)messageDigest.getLength();
        if ( hashLen> keyByteLen){
            short excessBytes = (short)(hashLen - keyByteLen);
            Util.arrayCopy(DigestBuff, (short)0, DigestBuff, (short)excessBytes, (short)keyByteLen);
            Util.arrayFillNonAtomic(DigestBuff, (short)0, (short)excessBytes, (byte)0);
        }

        // verify the SignatureInternal
        verified = SecurityNativeMethods.ECDSAVerify(sigBuff, sigOff, DigestBuff, (short) 0, ((ECMemoryPoolKey)pubKey).getDomainMemoryPoolReference(), ((ECMemoryPoolKey)pubKey).getOwnMemoryPoolReference());
        
        if (verified)
            NativeMethods.sensitiveResultSetBooleanTrue();
        else
            NativeMethods.sensitiveResultSetBooleanFalse();
        return verified;
    }
}
// #endif_Target32Bit_
