/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

import javacard.security.CryptoException;
import javacardx.crypto.Cipher;

/**
 * Implements the ALG_DES_MAC8_ISO9797_M2 Signature algorithm: Pads the input
 * using the ISO9797 M2 padding scheme and then encrypts the plain text using a
 * DES CBC cipher. The last 8 bytes of the resulting cipher text are the
 * signature
 */
public class DESMAC8ISO9797M2Signature extends DESMAC8Signature {
    public DESMAC8ISO9797M2Signature(byte algorithm, byte messageDigestAlgorithm, byte cipherAlgorithm, byte paddingAlgorithm) {
        // instantiate the cipher object declared in the base class
        super(algorithm, messageDigestAlgorithm, cipherAlgorithm, paddingAlgorithm);
        // instantiate the cipher object declared in the base class.
        cipher = Cipher.getInstance(Cipher.ALG_DES_CBC_ISO9797_M2, false);
    }

}
