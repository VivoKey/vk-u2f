/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */
package com.sun.javacard.crypto;

import com.sun.javacard.impl.NativeMethods;
import javacard.framework.JCSystem;
import javacard.framework.Util;
import javacard.security.CryptoException;
import javacard.security.DHPrivateKey;
import javacard.security.KeyBuilder;

/**
 *
 * 
 */
public class FFPrivateKeyImpl extends FFKeyImpl implements DHPrivateKey{
    
    private static final byte PRIVATE_KEY = (byte) 4;
    
    private boolean[] xInitialized;

    private byte[] X;
    
    public FFPrivateKeyImpl(byte type, short bitLength) {
        super.initializeDomainStorage(type, bitLength);
        switch(type){
            case KeyBuilder.TYPE_DH_PRIVATE:
                X = new byte[(short) (super.getMaxQSize() / 8 + super.ALIGNMENT_SPACE + super.BIGINT_STRUCT_SIZE)];
                xInitialized = new boolean[(short)1];
                break;
                
            case KeyBuilder.TYPE_DH_PRIVATE_TRANSIENT_RESET:
                X = JCSystem.makeTransientByteArray((short) (super.getMaxQSize() / 8 + super.ALIGNMENT_SPACE + super.BIGINT_STRUCT_SIZE), JCSystem.MEMORY_TYPE_TRANSIENT_RESET);
                xInitialized = JCSystem.makeTransientBooleanArray((short)1, JCSystem.MEMORY_TYPE_TRANSIENT_RESET);
                break;
                
            default:
                break;
        }
    }

    public void setX(byte[] buffer, short offset, short length) throws CryptoException {
        NativeMethods.checkArrayArgs(buffer, offset, length);
        if(length == 0){
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
        if (length > (short) (super.getMaxQSize() / 8)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
        SecurityNativeMethods.setFFDomainParameter(isPersistent(), buffer, offset, length, PRIVATE_KEY, super.memoryPool, X);
        xInitialized[(short)0] = true;
    }

    public short getX(byte[] buffer, short offset) {
        if (xInitialized[(short)0] == false) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }
        
        return SecurityNativeMethods.getFFDomainParameter(PRIVATE_KEY, super.memoryPool, buffer, offset);
    }

    public boolean isInitialized() {
        return ((super.isInitialized()) && (xInitialized[(short)0]));
    }

    public void clearKey() {
        super.clearKey();
        Util.arrayFillNonAtomic(X, (short) 0, (short) X.length, (byte) 0);
        xInitialized[(short)0] = false;
    }

    public byte getType() {
        return super.getType();
    }

    public short getSize() {
        return super.getSize();
    }
    
}
