/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

import javacard.security.CryptoException;

/**
 * Implements the ISO 9797 Method 2 padding scheme An '80' byte is appended to
 * the end of the message, and then the smallest number of '00' bytes is
 * appended such that the resulting length of the message is a multiple of 8
 * bytes
 */
public class ISO9797M2Padder implements Padder {
    /**
     * The block size used in DES ciphers
     */
    public short BLOCK_SIZE = (short) 8;

    /**
     * The value of the byte that marks the beginning of the padding bytes
     */
    byte paddingMarker = (byte) 0x80;

    /**
     * Implements the ISO 9797 Method 2 padding scheme
     * 
     * @param circular
     *            the queue containing the last bytes of data that must be
     *            padded
     * @return the number of padding bytes added
     */
    public short pad(CircularQueue circular) {
        short count = circular.getCount();
        short paddingLength = (short) (BLOCK_SIZE - count);
        short paddingCount = paddingLength;
        // Insert the '80' byte into the queue and decrement paddingCount
        circular.queuePut(paddingMarker);
        paddingCount--;

        for (short i = 0; i < paddingCount; i++) {
            circular.queuePut((byte) 0x00);
        }
        return paddingLength;
    }

    /**
     * Returns the number of padding bytes
     * 
     * @param outBuff
     *            the buffer containing the decrypted, padded results
     * @return the number of padding bytes in outBuff
     */
    public short unPad(byte[] outBuff) {
        /*
         * Once we do the final decryption the last bytes will include the
         * padding bytes that were added prior to encryption.
         * We must remember to decrease counter in DESCipher by the number of padding 
         * bytes we found here and place only the decrypted results in the users outBuff,
         * leaving the padding bytes behind.
         */

        // Seek the '80' byte marker from the end of inBuff
        short markerIndex = (short) (outBuff.length - 1);
        while (outBuff[markerIndex] != paddingMarker) {
            /*
             * If the value at markerIndex is not 0x00 then our input was
             * not padded with this scheme so we won't do any unpadding.
             */

            if (outBuff[markerIndex] != (byte) 0x00) {
                CryptoException.throwIt(CryptoException.ILLEGAL_USE);
            }

            markerIndex--;
        }// while(inBuff[markerIndex] != markerValue)

        return (short) (outBuff.length - markerIndex);

    }// unPad
}// end class
