/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

import javacard.security.CryptoException;

public class SecurityNativeMethods {

    /**
     * data is 512 bits or 64-byte message.
     */

    public static native void computeSHABlock(byte[] data, byte[] digest);

    // #ifdef_Target32Bit_
    public static native void computeSHA256Block(byte[] data, byte[] digest);

    // #endif_Target32Bit_

    /**
     * Random.java
     */

    public static native void generateRandomData(byte[] buf, short offset, short len, byte[] seed, short seed_offset,
            short seed_len);

    /**
     * Elliptic Curve specific native methods
     */
    // #ifdef_Target32Bit_
    /**
     * This is the native method that computes a ECDSA signature for a given
     * plain text.
     * 
     * @param text -
     *            the plain text to be signed
     * @param textOffset -
     *            The offset into the byte array where the text starts. param
     *            seed - the seed for the random number generator.
     * @param seedLength -
     *            the length of the seed for the random generator.
     * @param seedOffset -
     *            the offset where the seed value starts.
     * @param memoryPoolIdentifier -
     *            This is a byte array used internally by the C code to store
     *            the Elliptic curve paramters and keys. This is obtained from a
     *            memory manager designed for use with crypto native code.
     * @param signature -
     *            the returned signature.
     * @param signatureOffset -
     *            the offset into the byte array where the signature is to be
     *            placed.
     * @return the length of the signature
     */

    public static native short ECDSASign(byte[] text, short textOffset, byte[] seed, short seedLength,
            short seedOffset, byte[] memoryPoolIdentifier, byte[] signature, short signatureOffset, byte[] privateMemoryPoolIdenitifier);

    /**
     * The native method that verifies a ECDSA Signature against a given text.
     * 
     * @param signature -
     *            the signature used to verify against a given text.
     * @param signatureOffset -
     *            the offset into the byte array where the signature is to be
     *            placed.
     * @param text -
     *            the text being verified by the signature
     * @param textOffset -
     *            The offset into the byte array where the text starts.
     * @param memoryPoolIdentifier -
     *            see above description
     * @return returns true if the signature can be verified, otherwise, false.
     */

    public static native boolean ECDSAVerify(byte[] signature, short signatureOffset, byte[] text, short textOffset,
            byte[] memoryPoolIdentifier, byte[] publicMemoryPoolIdenitifier);

    /**
     * This is the method used to set all elliptic curve domain parameters and
     * the private/public keys. These are all byte array parameters. The only
     * domain parameter not included would be K, which is short value and is set
     * by setK().
     * 
     * @param domainParameter -
     *            the value of the parameter to be set.
     * @param parameterOffset -
     *            the offset in thE byte array where the value of the parameter
     *            will start.
     * @param parameterLength -
     *            the length in bytes of the parameter.
     * @param parameterType -
     *            The type of paramter/key being set: 1 - A 2 - B 3 - Field 4 -
     *            GX 5 - GY 6 - R 7 - privateKey 8 - publicKeyX 9 - publicKeyY
     * @param memoryPoolIdentifier1 -
     *            Identifies the memory pool that holds the domain parameter
     *            structure.
     * @param memoryPoolIdentifier2 -
     *            The memory pool identifier that points to the memory that will
     *            be used to store the parameter value.
     * @return true if value set, false if illegal value found.
     */

    public static native boolean setECDomainParameter(short persist, byte[] domainParameter, short parameterOffset,
            short parameterLength, byte parameterType, byte[] memoryPoolIdentifier1, byte[] memoryPoolIdentifier2);
    
    public static native boolean setFFDomainParameter(short persist, byte[] domainParameter, short parameterOffset,
            short parameterLength, byte parameterType, byte[] memoryPoolIdentifier1, byte[] memoryPoolIdentifier2);

    /**
     * This is the method used to get all elliptic curve domain parameters and
     * the private/public keys. These are all byte array parameters. The only
     * domain parameter not included would be K, which is retrieved by getK().
     * 
     * @param parameterType -
     *            The type of paramter/key being retrieved. See above for
     *            values.
     * @param memoryPoolIdentifier -
     *            Identifies the memory pool that holds the domain parameter
     *            structure.
     * @param domainParameter -
     *            returns the value of the requested domain parameter here.
     * @param parameterOffset:
     *            the offset in the given array where the value of the parameter
     *            is to be placed.
     * @return the length of the parameter
     */

    public static native short getECDomainParameter(byte parameterType, byte[] memoryPoolIdentifier,
            byte[] DomainParameter, short parameterOffset);
    
    public static native short getFFDomainParameter(byte parameterType, byte[] memoryPoolIdentifier,
            byte[] DomainParameter, short parameterOffset);

    /**
     * This function will validate all domain paramters prior to performing a
     * sign/verify operation.
     * 
     * @param memoryPoolIdentifier -
     *            Identifies the memory pool that holds the domain parameters
     *            that are to be verified.
     * @return - returns true if all parameters are valid, otherwise false.
     */

    public static native boolean validateDomainParameters(byte[] memoryPoolIdentifier, byte[] privateMemoryPoolIdentifier, byte[] publicMemoryPoolIdentifier);
    
    public static native boolean validateFFDomainParameters(byte[] memoryPoolIdentifier);

    /**
     * will get the value of K previously set by setK.
     * 
     * @param memoryPoolIdentifier -
     *            The identifier for the memory where the domain parameters are
     *            to be found.
     * @return - returns the value of K.
     */

    public static native short getK(byte[] memoryPoolIdentifier);

    /**
     * will set the value of K in the domain parameter structure.
     * 
     * @param cofactor -
     *            the cofactor, or K.
     * @param memoryPoolIdentifier -
     *            The identifier for the memory where the domain parameters are
     *            to be stored.
     */

    public static native void setK(short cofactor, byte[] memoryPoolIdentifier);

    /**
     * Generate a keypair based on a given set of domain parameters.
     * 
     * @param memoryPoolIdentifier:
     *            memory pool where domain parameters are stored
     * @param privateKey:
     *            the PrivateKey
     * @param privateKeyOffset:
     *            The offset into the byte array where the privateKey value
     *            starts.
     * @param privateKeyLength:
     *            The length of the privateKey.
     * @param publicKey:
     *            the PublicKey
     * @param publicKeyOffset:
     *            The offset into the byte array where the publicKey value
     *            starts.
     * @param publicKeyLength:
     *            The length of the publicKey.
     */

    public static native void genECKeyPair(byte[] memoryPoolIdentifier, byte[] privateKey, short privateKeyOffset,
            short privateKeyLength, byte[] publicKey, short publicKeyOffset, short publicKeyLength);
    
    public static native void genFFKeyPair(byte[] memoryPoolIdentifier, byte[] privateKey, short privateKeyOffset,
            short privateKeyLength, byte[] publicKey, short publicKeyOffset, short publicKeyLength);

    // #endif_Target32Bit_

    /* end Elliptic Curve specific native methods */

    /**
     * com.sun.javacard.crypto.platform.DES.java
     */

    public static native void ecbEnc(byte[] X, byte[] Y, byte[] key, byte keyOffset);

    public static native void ecbDec(byte[] X, byte[] Y, byte[] key, byte keyOffset);

    // PKCS1 methods

    /**
     * Carries out the 4 steps of the RSA PKCS#1 Encryption Process which are:
     * 1. Encryption Block formatting 2. Byte array to integer conversion 3. RSA
     * computation 4. Integer to byte array conversion
     * 
     * @param n
     *            the modulus for the RSA computation.
     * @param modLength
     *            the length of the modulus.
     * @param e
     *            the exponent for the RSA computation.
     * @param expLength
     *            the length of the exponent.
     * @param M
     *            the message to encrypt.
     * @param MLength
     *            the length of the message.
     * @param C
     *            The result.
     */
    static public native short RSAES_V15_ENCRYPT(byte[] n, short modLength, byte[] e, short expLength, byte[] M,
            short MLength, byte[] C, short offSet, byte BT);

    /**
     * Implements the RSA Decryption process. Basically there are 4 steps: 1.
     * Byte array to integer conversion 2. RSA computation 3. Integer to byte
     * array conversion 4. Encryption block parsing
     */
    public static native short RSADS_V15_DECRYPT(byte[] n, short nLength, byte[] d, short dLength, byte[] c, byte[] M,
            short offSet) throws CryptoException;

    /**
     * This module implements DER Encoding of SHA MessageDigest Implements the 4
     * steps of the RSA PKCS#1 Signature process which are: 1. Message digesting
     * 2. Data encoding 3. RSA Encryption 4. Byte array to bit string conversion
     */
    public static native short RSASA_V15_SIGN(byte[] n, short nLength, byte[] e, short eLength, byte[] H, byte[] S,
            short SoffSet) throws CryptoException;

    /**
     * Implements the 4 steps of the RSA PKCS#1 verify process which are: 1. Bit
     * string to Byte array conversion 2. RSA Decryption 3. Data decoding 4.
     * Message digesting and comparison
     */
    public static native boolean RSASA_V15_VERIFY(byte[] n, short nLength, byte[] e, short eLength, byte[] H, byte[] S,
            short SoffSet, short SLen) throws CryptoException;

    /**
     * method signs H without padding it. Caller is responsible for padding.
     * Encrypted buffer written to S at offset SOffset. returns the number of
     * bytes written to S. Note: The out-parameter S should have enough space to
     * write signature amount of data.
     * 
     * @param n
     *            the modulus
     * @param nLength
     *            the modulus length
     * @param e
     *            the exponent
     * @param eLength
     *            the exponent length
     * @param H
     *            the message representative to encrypt
     * @param hLength
     *            the length of message representative.
     * @param S
     *            the output buffer for signature data
     * @param Soffset
     *            the offset in S to start writing to
     * @return the number of bytes written to S
     */
    public static native short RSA_SIGN(byte[] n, short nLength, byte[] e, short eLength, byte[] H, short hLength,
            byte[] S, short SoffSet) throws CryptoException;

    /**
     * method goes directly to the RSA decryption primitive. Does not throw away
     * the padding. the signature data is in sigBuff and the decrypted message
     * is written to msgRep at msgRepOffset. returns the number of bytes written
     * to msgRep.
     * 
     * @param n
     *            the modulus
     * @param nLength
     *            the modulus length
     * @param e
     *            the exponent
     * @param eLength
     *            the exponent length
     * @param sigBuff
     *            buffer that contains the signature data
     * @param sigBuffOffset
     *            the offset into sigBuff where signature data begins
     * @param sigBuffLength
     *            length of signature data in sigBuff
     * @param msgRep
     *            the out-parameter that will contain the decrypted message
     *            representative
     * @param msgRepOffset
     *            the offset into msgRep where the decrypted representative
     *            would begin.
     * @return the number of bytes written to msgRep.
     */
    public static native short RSA_SIG_DECRYPT_REC(byte[] n, short nLength, byte[] e, short eLength, byte[] sigBuff,
            short sigBuffOffset, short sigBuffLength, byte[] msgRep, short msgRepOffset) throws CryptoException;

    // RSAKeyGen methods

    /**
     * <B><U>RSA Encryption:</B></U>
     * <P>
     * 
     * <B><I><U>Public Key:</B></I></U><BR>
     * <code>n</code> product of two primes <code>p</code> and
     * <code>q</code> which are kept secret<BR>
     * <code>e</code> relatively prime to <code>(p-1)</code> and
     * <code>(q-1)</code>
     * <P>
     * 
     * <B><I><U>Private Key:</B></I></U><BR>
     * <code>d</code> <code>e<sup>-1</sup>mod((p-1)(q-1))</code>
     * <P>
     * 
     * Note: See "Applied Cryptography" by Bruce Schneier pages 466-469 for more
     * info.
     */

    public static native short generateRSAKeyData(byte[] pub_mod, short pub_mod_len, byte[] pub_exp, short pub_exp_len,
            byte[] priv_exp, byte[] seed);

    // #ifdef_Target32Bit_
    /**
     * Performs AES Encryption operation as per FIPS
     * 
     * @param plain_in
     *            a 16byte array containing plain input data
     * @param cipher_out
     *            a 16byte array containg the result of the encrypt operation
     * @param key
     *            a 16 byte array containg key data
     * @param keyOffset -
     *            offset to read the key data from the key buffer.
     */

    public static native void aesCBCEncrypt(byte[] plain_in, byte[] cipher_out, byte[] key, byte keyOffset);

    /**
     * Performs AES Decryption operation as per FIPS
     * 
     * @param cipher_in
     *            a 16byte array containing ciphered input data
     * @param plain_out
     *            a 16byte array containg the result of the decrypt operation
     * @param key
     *            a 16 byte array containg key data
     * @param keyOffset -
     *            offset to read the key data from the key buffer.
     */

    public static native void aesCBCDecrypt(byte[] cipher_in, byte[] plain_out, byte[] key, byte keyOffset);

    // #endif_Target32Bit_

    // ECDH methods

    // #ifdef_Target32Bit_
    /**
     * Generates the secret data
     * 
     * The public key data provided should be the public elliptic curve point of
     * the second party in the protocol, specified as per ANSI X9.62.
     * 
     * @param result
     *            Buffer for the result
     * @param resultOffset
     *            offset into the buffer
     * @param domainParameters
     *            memory pool with domain parameters
     * @param privKey
     *            private key
     * @param privKeyLength
     *            private key length
     * @param pubKey
     *            public key (in the uncompressed form)
     * @param pubOffset
     *            offset to the public key
     * @param pubLen
     *            length of the public key
     * @return length of the secret in bytes
     */
    public static native short ECSVDP_DH(byte[] result, short resultOffset, byte[] domainParameters, byte[] privKey,
            short privKeyLength, byte[] pubKey, short pubOffset, short pubLen, short isPaceGM, short raw);
    
    public static native short FFSVDP_DH(byte[] result, short resultOffset, byte[] domainParameters, byte[] privKey,
            short privKeyLength, byte[] pubKey, short pubOffset, short pubLen);

    public static native short ECSVDP_DHC(byte[] result, short resultOffset, byte[] domainParameters, byte[] privKey,
            short privKeyLength, byte[] pubKey, short pubOffset, short pubLen);

    /**
     * Retrieves default EC domain parameters into a byte array
     * 
     * @param destination
     *            Buffer for the data, must be long enough
     * @param what
     *            can be: A=1, B=2, G=3, R=4, F=5
     * @param keyLengh
     *            can be 112, 128, 160, 192
     * @return length of the result in bytes
     * 
     */

    public static native short getDefaultDomainParameter(byte[] destination, short what, short keyLength);
    // #endif_Target32Bit_
    
    /**
     * Retrieves AES GCM TAG into a byte array
     * 
     * @param tagbuf
     *            Buffer for the data, must be long enough
     * @param tagOff
     *            Offset within the provided buffer
     * @param tagLen
     *            can be 3, 6, 8, 10, 12, 14, 16
     * @return length of the result in bytes
     * 
     */
    public static native short AESGCMretrieveTag(byte[] tagBuf, short tagOff, short tagLen, byte[] mempool);
    /**
     * Verifies a provided AES GCM Tag
     * 
     * @param receivedTagBuf
     *            Buffer for the data, must be long enough
     * @param receivedTagOff
     *            Offset within the provided buffer
     * @param receivedTagLen
     *            can be 3, 6, 8, 10, 12, 14, 16
     * @param requiredTagLen
     *            can be 3, 6, 8, 10, 12, 14, 16
     * @return True is the Tag is valid, False if the Tag is not valid
     * 
     */    
    public static native boolean AESGCMverifyTag(byte[] receivedTagBuf, short receivedTagOff, short receivedTagLen, short requiredTagLen, byte[] mempool);
     /**
     * Encrypt AES GCM input buffer
     * 
     * @param plain_in
     *            Buffer for the input data
     * @param cipher_out
     *            Buffer for the output data
     * @param keyOffset
     *            Key offset
     * @return None
     * 
     */
    public static native void AESGCMencrypt(byte[] plain_in, byte[] cipher_out, byte keyOffset, byte[] mempool);
     /**
     * Decrypt AES GCM input buffer
     * 
     * @param plain_in
     *            Buffer for the input data
     * @param cipher_out
     *            Buffer for the output data
     * @param keyOffset
     *            Key offset
     * @return None
     * 
     */    
    public static native void AESGCMdecrypt(byte[] plain_in, byte[] cipher_out, byte keyOffset, byte[] mempool);
     /**
     * AES GCM Init 
     * 
     * @param data
     *            Buffer containing the AES key
     * @param nonceBuf
     *            Buffer containing the Nonce
     * @param nonceLen
     *            Nonce length
     * @param adataLen
     *            Additional Data input length
     * @param messageLen
     *            Input message length  
     * @param tagSize
     *            Tag size
     * @param warmInit
     *            Init Type - COLD = total init
     *                        WARM = partial init
     * @return None
     * 
     */ 
    public static native void AESGCMinit(byte[] data, byte[] nonceBuf, short nonceLen, short adataLen, short messageLen, short tagSize, short warmInit, byte[] mempool);
     /**
     * AES GCM
     * Set the AAD input buffer
     * 
     * @param aadBuf
     *            Buffer for the input data
     * @param aadOff
     *            Offset within the provided buffer
     * @param aadLen
     *            AAD length
     * @return None
     * 
     */
    public static native void AESGCMupdateAAD(byte[] aadBuf, short aadOff, short aadLen, byte[] mempool);
    
    
    /**
     * Retrieves AES CCM TAG into a byte array
     * 
     * @param tagbuf
     *            Buffer for the data, must be long enough
     * @param tagOff
     *            Offset within the provided buffer
     * @param tagLen
     *            can be 3, 6, 8, 10, 12, 14, 16
     * @return length of the result in bytes
     * 
     */
    public static native short AESCCMretrieveTag(byte[] tagBuf, short tagOff, short tagLen, byte[] mempool);
    /**
     * Verifies a provided AES CCM Tag
     * 
     * @param receivedTagBuf
     *            Buffer for the data, must be long enough
     * @param receivedTagOff
     *            Offset within the provided buffer
     * @param receivedTagLen
     *            can be 3, 6, 8, 10, 12, 14, 16
     * @param requiredTagLen
     *            can be 3, 6, 8, 10, 12, 14, 16
     * @return True is the Tag is valid, False if the Tag is not valid
     * 
     */    
    public static native boolean AESCCMverifyTag(byte[] receivedTagBuf, short receivedTagOff, short receivedTagLen, short requiredTagLen, byte[] mempool);
     /**
     * Encrypt AES CCM input buffer
     * 
     * @param plain_in
     *            Buffer for the input data
     * @param cipher_out
     *            Buffer for the output data
     * @param keyOffset
     *            Key offset
     * @return None
     * 
     */
    public static native void AESCCMencrypt(byte[] plain_in, byte[] cipher_out, byte keyOffset, byte[] mempool);
     /**
     * Decrypt AES CCM input buffer
     * 
     * @param plain_in
     *            Buffer for the input data
     * @param cipher_out
     *            Buffer for the output data
     * @param keyOffset
     *            Key offset
     * @return None
     * 
     */    
    public static native void AESCCMdecrypt(byte[] plain_in, byte[] cipher_out, byte keyOffset, byte[] mempool);
     /**
     * AES CCM Init 
     * 
     * @param data
     *            Buffer containing the AES key
     * @param nonceBuf
     *            Buffer containing the Nonce
     * @param nonceLen
     *            Nonce length
     * @param adataLen
     *            Additional Data input length
     * @param messageLen
     *            Input message length  
     * @param tagSize
     *            Tag size
     * @return None
     * 
     */ 
    public static native void AESCCMinit(byte[] data, byte[] nonceBuf, short nonceLen, short nonceOff, short adataLen, short messageLen, short tagSize, byte[] mempool);
     /**
     * Set the AAD input buffer
     * 
     * @param aadBuf
     *            Buffer for the input data
     * @param aadOff
     *            Offset within the provided buffer
     * @param aadLen
     *            AAD length
     * @param mempool
     * 
     */
    public static native void AESCCMupdateAAD(byte[] aadBuf, short aadOff, short aadLen, byte[] mempool);    
    public static native void DebugShort(short id, short value); 
    
    
    /* AES CMAC native functions */
    public static native void AESCMACinit(byte[] data, byte[] mempoolInit, byte[] mempoolRes);   
    public static native void AESCMACsign(byte[] inBuf, byte[] outBuf, short buffLen, short isLastBlock, short isEmptyBlock, byte[] mempoolInit, byte[] mempoolRes);  

}
