/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

import javacard.security.CryptoException;
import javacard.framework.Util;
import javacard.security.RSAPublicKey;

public class RSAPublicKeyImpl extends KeyInternal implements RSAPublicKey {
    byte[] modulus, exponent;
    /*
     * We keep the modulus and exponent lengths so that when we copy them 
     * in the 'get' methods, we copy only the number of bytes of the true 
     * key length is, and return the true key length.
     * Also, it is assumed for this implementation that the key length  
     * will not exceed 512 bits.  The key buffers would need to be longer 
     * to support longer keys.
     */
    short modulusLength;
    short exponentLength;

    private boolean ModulusInitialized = false;
    private boolean ExponentInitialized = false;
    protected static final short RSA_LEN_512 = (short) 64;

    public RSAPublicKeyImpl(byte type, short bitLength) {
        super(type, bitLength);
        modulus = new byte[RSA_LEN_512];
        exponent = new byte[RSA_LEN_512];
    }

    public void setModulus(byte buffer[], short offset, short length) {
        if ((length == 0) || (length > RSA_LEN_512)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        Util.arrayCopy(buffer, offset, modulus, (short) 0, length);
        modulusLength = length;
        ModulusInitialized = true;
    }

    public void setExponent(byte buffer[], short offset, short length) {
        if ((length == 0) || (length > RSA_LEN_512)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        Util.arrayCopy(buffer, offset, exponent, (short) 0, length);
        exponentLength = length;
        ExponentInitialized = true;
    }

    public short getModulus(byte buffer[], short offset) {
        if (ModulusInitialized == false) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }
        Util.arrayCopy(modulus, (short) 0, buffer, offset, modulusLength);
        return modulusLength;
    }

    public short getExponent(byte buffer[], short offset) {
        if (ExponentInitialized == false) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }
        Util.arrayCopy(exponent, (short) 0, buffer, offset, exponentLength);
        return exponentLength;
    }

    public boolean isInitialized() {
        return ((ModulusInitialized != false) && (ExponentInitialized != false));
    }

    public void clearKey() {
        Util.arrayFillNonAtomic(exponent, (short) 0, (short) exponent.length, (byte) 0);
        Util.arrayFillNonAtomic(modulus, (short) 0, (short) modulus.length, (byte) 0);
        ModulusInitialized = false;
        ExponentInitialized = false;
    }

    public short getModulusLength() {
        if (ModulusInitialized == false) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }
        return modulusLength;
    }

}
