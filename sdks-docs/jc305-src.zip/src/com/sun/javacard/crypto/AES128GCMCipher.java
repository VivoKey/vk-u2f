/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */
package com.sun.javacard.crypto;

import com.sun.javacard.impl.NativeMethods;
import javacard.framework.JCSystem;
import javacard.framework.Util;
import javacard.security.AESKey;
import javacard.security.CryptoException;
import javacard.security.Key;
import javacard.security.KeyBuilder;
import javacardx.crypto.AEADCipher;

/**
 * AES GCM Implementation
 * 
 */
public class AES128GCMCipher extends AEADCipher{
    
    /**
    * Indicates that the cipher has not been initialized for encryption or
    * decryption yet
    */
    private final static byte MODE_UNINITIALIZED = -1;

    /**
     * AES ciphers encrypt/decrypt in block size of 16 bytes
     */
    protected final static short AES_128_BLOCK_SIZE = 16;
    
    /*
    Maximum Nonce Length according to AES GCM
    Note : algo implements only the 12 byte IV
    */
    private final static byte MAX_NONCE_LEN = 12;
    
    /*
    Minimum Nonce Length according to AES GCM
    Note : algo implements only the 12 byte IV
    */
    private final static byte MIN_NONCE_LEN = 12;
    
    
    /*
    Flag the execution of doFinal (for retreiveTag)
    */
    private final static byte MODE_ENCRYPT_DONE = 3;    
    
    /*
    
    */
    private final static byte MODE_DECRYPT_DONE = 4; 
    /*
    Flags the execution of updateAAD (for calling update or doFinal without calling updateAAD)
    */
    private final static byte MODE_AAD_DONE = 5;   
    
    
    private static final short MEMORY_POOL_SIZE = 128;
    
    private static final byte CIPHER_UPDATE_STATE = 0;
    private static final byte CIPHER_FINAL_STATE = 1;
    
    private static final byte WARM_INIT = 1;
    private static final byte COLD_INIT = 0;
    
    
    
    
    protected byte[] dNonce = { (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
                 (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
                 (byte) 0x00 };  
    private final byte[] mempool;


        /* akey is accessed by AES128CBCCipher */
    protected AESKeyImpl akey;

    /**
     * ENCRYPT or DECRYPT Mode mode object is create in Persistent memory and
     * stored in such a way that it does not participate in transaction (spec
     * requirement). This is necessary as one could create a AESKey of type
     * persistent then create a Cipher/Signature object and then a tear happens.
     * After tear, if they call Signature.Sign or Cipher.doFinal, then this must
     * work with the default IV.
     */
    protected byte[] mode; // byte value
    protected byte[] keyLength; // short value
    protected byte finalState = CIPHER_UPDATE_STATE;
    
    protected byte[] defaultNonce;//Nonce
    protected byte[] intermediateOutput;
    private byte[] holdCount; // byte value
    private byte[] holdData;    
    private boolean[] update_status;
    protected byte[] data;
    
    protected byte[] AADLength;/* Additional Data Length */
    protected byte[] NonceLength;/* NonceLength */
    protected byte[] MessageLength;/* Message Length */
    protected byte[] TagLength;/* Tag Length*/
 
    /**
     * A queue is used to store data blocks entered using 'update'. This queue
     * is necessary because AES operates on 16,24,32 byte blocks depending on
     * the alg selected, but there is no requirement on the user to pass in data
     * in multiples of 16,24, or 32 bytes. Here, the queue is used as an 16 byte
     * buffer which stores the trailing bytes of each input block between
     * successive updates. This way we ensure that each cipher block is indeed
     * 16 bytes
     */

    protected CircularQueue myqueue = null;
    
    public AES128GCMCipher() {
        myqueue = new CircularQueue(AES_128_BLOCK_SIZE);
        keyLength = JCSystem.makeTransientByteArray((short) 2, JCSystem.CLEAR_ON_DESELECT);
        data = JCSystem.makeTransientByteArray(AES_128_BLOCK_SIZE, JCSystem.CLEAR_ON_DESELECT);
        mode = new byte[2];
        
        intermediateOutput = JCSystem.makeTransientByteArray(AES_128_BLOCK_SIZE, JCSystem.CLEAR_ON_DESELECT);
        defaultNonce = JCSystem.makeTransientByteArray(AES_128_BLOCK_SIZE, JCSystem.CLEAR_ON_DESELECT);
        holdCount = JCSystem.makeTransientByteArray((short) 1, JCSystem.CLEAR_ON_DESELECT);
        holdData = JCSystem.makeTransientByteArray(AES_128_BLOCK_SIZE, JCSystem.CLEAR_ON_DESELECT);
        update_status = JCSystem.makeTransientBooleanArray((short) 1, JCSystem.CLEAR_ON_DESELECT);
              
        holdCount[0] = 0;
        mode[0] = MODE_UNINITIALIZED;
        mode[1] = MODE_UNINITIALIZED;
        
        AADLength = JCSystem.makeTransientByteArray((short) 2, JCSystem.CLEAR_ON_DESELECT);
        NonceLength = JCSystem.makeTransientByteArray((short) 2, JCSystem.CLEAR_ON_DESELECT);
        MessageLength = JCSystem.makeTransientByteArray((short) 2, JCSystem.CLEAR_ON_DESELECT);
        TagLength = JCSystem.makeTransientByteArray((short) 2, JCSystem.CLEAR_ON_DESELECT);  
        mempool = JCSystem.makeTransientByteArray((short) MEMORY_POOL_SIZE, JCSystem.CLEAR_ON_DESELECT);  
    }
    
    @Override
    public void init(Key theKey, byte theMode) throws CryptoException, NullPointerException {       
        init(theKey, theMode, dNonce, (short)0, (short)12);
    }

    @Override
    public void init(Key theKey, byte theMode, byte[] bArray, short bOff, short bLen) throws CryptoException, NullPointerException {
        Util.setShort(AADLength, (short) 0, (short)0);
        Util.setShort(NonceLength, (short) 0, (short)0);
        Util.setShort(MessageLength, (short) 0, (short)0);
        Util.setShort(TagLength, (short) 0, (short)0);
        holdCount[0] = 0;

        
        Util.arrayFillNonAtomic(mode, (short) 0, (short) 1, MODE_UNINITIALIZED);
        Util.arrayFillNonAtomic(mode, (short) 1, (short) 1, MODE_UNINITIALIZED);
        
        if (theKey == null) {
            throw new NullPointerException(); 
        }   
        
        if (!(theKey instanceof AESKey)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }   
        
        if ((bLen<0))
        {
            throw new ArrayIndexOutOfBoundsException(); 
        }         
        
        if ((bLen + bOff) > bArray.length)
        {
            throw new ArrayIndexOutOfBoundsException(); 
        }     
        
        /*
        Validate Nonce length 
        Valid lengths is 12
        */
        if ((bLen < MIN_NONCE_LEN) || (bLen > MAX_NONCE_LEN))
        {
            CryptoException.throwIt((short)(CryptoException.ILLEGAL_VALUE));
        }       
        /*
        if (!(theKey instanceof AESKey)) {
            CryptoException.throwIt((short)(CryptoException.ILLEGAL_VALUE));
        }*/

        if ((theMode != MODE_DECRYPT) && (theMode != MODE_ENCRYPT)) {
            CryptoException.throwIt((short)(CryptoException.ILLEGAL_VALUE));
        }
        Util.arrayFillNonAtomic(mode, (short) 0, (short) 1, theMode);

        akey = (AESKeyImpl) theKey;

        if (!akey.isInitialized()) {
            CryptoException.throwIt((short)(CryptoException.UNINITIALIZED_KEY));
        }

        Util.setShort(keyLength, (short) 0, akey.getSize());
        // keyLength is theKey.getSize
        /* As we are only doing 128 bit AES keys, the below code is not required.
         * If the code supports other key sizes, the below and additional code
         * may be required.
         */
        
     
        
        if (theKey.getSize() != KeyBuilder.LENGTH_AES_128) {
            Util.setShort(keyLength, (short)0, (short)0);
            CryptoException.throwIt((short)(CryptoException.ILLEGAL_VALUE));
        }	
        

        Util.arrayCopy(dNonce, (short)0, defaultNonce, (short)0, AES_128_BLOCK_SIZE);
        Util.arrayCopy(bArray, bOff, defaultNonce, (short) 0, bLen);
              
        Util.setShort(NonceLength, (short) 0, (short)bLen);

   
        Util.arrayFillNonAtomic(mode, (short) 0, (short) 1, theMode);/* ENCRYPT or DECRYPT */
        
        SecurityNativeMethods.AESGCMinit(akey.data, defaultNonce, 
                                        Util.getShort(NonceLength, (short)0), 
                                        Util.getShort(AADLength, (short)0),
                                        Util.getShort(MessageLength, (short)0),
                                        Util.getShort(TagLength, (short)0), 
                                        COLD_INIT,
                                        mempool);
        
        // clear the queue in case it has residual elements from previous use
        myqueue.clearQueue();
        finalState = CIPHER_UPDATE_STATE;     
        
    }

    @Override
    public void init(Key theKey, byte theMode, byte[] nonceBuf, short nonceOff, short nonceLen, short adataLen, short messageLen, short tagSize) throws CryptoException, NullPointerException {
     
        CryptoException.throwIt((short)(CryptoException.INVALID_INIT)); 
    }

    @Override
    public void updateAAD(byte[] aadBuf, short aadOff, short aadLen) throws CryptoException, NullPointerException {
  
        /* Perform sanity check of the input parameters */

        if ((aadOff<0) || (aadLen<0))
        {
            throw new ArrayIndexOutOfBoundsException(); 
        }
        
        if ((aadLen - aadOff) > aadBuf.length)
        {
            throw new ArrayIndexOutOfBoundsException(); 
        }
      
        if ((aadOff + aadLen) < 0)
        { 
            throw new ArrayIndexOutOfBoundsException(); 
        }   
        
        if (aadOff > aadBuf.length)
        {
            throw new ArrayIndexOutOfBoundsException(); 
        }     
        
        
        if ((aadLen + aadOff) > aadBuf.length)
        {
            throw new ArrayIndexOutOfBoundsException(); 
        }        
             
        /* expected before aadlen check */
        if (mode[0] == MODE_UNINITIALIZED)
        {
            CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        }            
        
        SecurityNativeMethods.AESGCMupdateAAD(aadBuf, aadOff, aadLen, mempool);
        
        /* reset the internal AAD length after using it so that we know we performed update AAD*/
        Util.arrayFillNonAtomic(mode, (short) 1, (short) 1, MODE_AAD_DONE);
    }

    @Override
    public short update(byte[] inBuff, short inOffset, short inLength, byte[] outBuff, short outOffset) throws CryptoException, NullPointerException {
        short currentOffset = inOffset;
        short counter = 0;
        short outoff2 = 0;

        /* check if a valid mode is provided */
        if (mode[0] == MODE_UNINITIALIZED)
        {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }
        
        if (inLength < 0)
        {
            throw new ArrayIndexOutOfBoundsException(); 
        }
        if (inLength > inBuff.length)
        {
            throw new ArrayIndexOutOfBoundsException(); 
        }           
        
        /* check if a valid key is provided */
        if (!akey.isInitialized()) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }
        
        /* simulate a null pointer exception if outBuff is null */
        short test = (short) outBuff.length;

        
        if (inLength == 0) { // nothing to update    
            prepareAndCipher(outBuff, outOffset, inLength);/*  mandatory for 0 byte input message */
            NativeMethods.sensitiveResultSet(counter);
            return counter;
        }                  
        
        
        // items can still be added to holding buffer
        if ((inLength + holdCount[0]) < AES_128_BLOCK_SIZE) {
            
            for (; (currentOffset < (inOffset + inLength)); currentOffset++, holdCount[0]++) {
                holdData[holdCount[0]] = inBuff[currentOffset];

            }
            

            if (finalState == CIPHER_FINAL_STATE)
            {
            prepareAndCipher(outBuff, outOffset, inLength);
            counter += inLength;
            holdCount[0] = (short) 0;
            }
        } else if ((short) (inLength + holdCount[0]) == AES_128_BLOCK_SIZE) {
            for (; (currentOffset < (inOffset + inLength)); currentOffset++, holdCount[0]++) {
                holdData[holdCount[0]] = inBuff[currentOffset];
            }
            prepareAndCipher(outBuff, outOffset, AES_128_BLOCK_SIZE);
            counter += AES_128_BLOCK_SIZE;
            holdCount[0] = (short) 0;//holdCount[0] = (short) -1;
        } else {
            /* items more than AES_BLK size, hence cipher and store 
             * more in holding buffer
             */
            //holdCount[0] = 0;
            outoff2 = outOffset;
            while ( currentOffset < (short) (inOffset + inLength)) {

                holdData[holdCount[0]] = inBuff[currentOffset];
               
                if ((short) (holdCount[0] + 1) == AES_128_BLOCK_SIZE) {
                    prepareAndCipher(outBuff, outoff2, AES_128_BLOCK_SIZE);
                    counter += AES_128_BLOCK_SIZE;
                    holdCount[0] = (short) -1;
                    outoff2 += AES_128_BLOCK_SIZE;
                }   
                currentOffset++;
                holdCount[0]++;
            }
            
            SecurityNativeMethods.DebugShort((short)8, holdCount[0]);
            /* this deals also with the blocks != AES_128_BLOCK_SIZE */
            if ((holdCount[0]>0) && (holdCount[0]<AES_128_BLOCK_SIZE) && (finalState == CIPHER_FINAL_STATE))
            {
                prepareAndCipher(outBuff, outoff2, holdCount[0]);
                counter += holdCount[0];
                holdCount[0] = (short) 0;
            }
        }

        update_status[0] = true;        
 
        SecurityNativeMethods.DebugShort((short)9, counter);
        NativeMethods.sensitiveResultSet(counter);
        return counter;   
    }
    
    void resetMe() {
        holdCount[0] = 0;
        
        /* reset the cypher object to it`s initial state */
        SecurityNativeMethods.AESGCMinit(akey.data, defaultNonce, 
                                        Util.getShort(NonceLength, (short)0), 
                                        Util.getShort(AADLength, (short)0),
                                        Util.getShort(MessageLength, (short)0),
                                        Util.getShort(TagLength, (short)0), 
                                        WARM_INIT,
                                        mempool);
        
  
       
        
        myqueue.clearQueue();        
        Util.arrayFillNonAtomic(intermediateOutput, (short) 0, AES_128_BLOCK_SIZE, (byte) 0x00);
        Util.arrayFillNonAtomic(holdData, (short) 0, AES_128_BLOCK_SIZE, (byte) 0x00);
    }

    @Override
    public short doFinal(byte[] inBuff, short inOffset, short inLength, byte[] outBuff, short outOffset) throws CryptoException, NullPointerException {
        /* Cannot check output buffer parameters in the general parameter 
         * checking method, since it is different for update and final.
         */
       short counter = 0;
       finalState = CIPHER_FINAL_STATE;
        
       SecurityNativeMethods.DebugShort((short)1, inOffset);

        /* check if a valid mode is provided */
        if (mode[0] == MODE_UNINITIALIZED)
        {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }     
        
        SecurityNativeMethods.DebugShort((short)2, inLength);
        
        if (inLength < 0)
        { 
            throw new ArrayIndexOutOfBoundsException(); 
        }
        if (inLength > inBuff.length)
        {
            throw new ArrayIndexOutOfBoundsException(); 
        }        

        
        SecurityNativeMethods.DebugShort((short)4, (short)0);
        if (mode[0] == MODE_ENCRYPT) {
            Util.arrayFillNonAtomic(mode, (short) 0, (short) 1, MODE_ENCRYPT_DONE);
        }
        
        if (mode[0] == MODE_DECRYPT) {
            Util.arrayFillNonAtomic(mode, (short) 0, (short) 1, MODE_DECRYPT_DONE);
        }         
               
        
        /* check if a valid key is provided */
        if (!akey.isInitialized()) {
            CryptoException.throwIt((short)CryptoException.UNINITIALIZED_KEY);
        }        

        
        SecurityNativeMethods.DebugShort((short)6, (short)0);
        
        
        counter = update(inBuff, inOffset, inLength, outBuff, outOffset);

        /* the below code is the same when inLength == 0, but, update is 
         * called before with block size.  Then we return the intermediate o/p.
         */
        if (myqueue.getCount() != 0) {
            CryptoException.throwIt((short)(CryptoException.ILLEGAL_USE));
        }
        
        resetMe();
        
        NativeMethods.sensitiveResultSet(counter);
        return counter;

    }


    @Override
    public short retrieveTag(byte[] tagBuf, short tagOff, short tagLen) throws CryptoException, NullPointerException {
  
        switch(tagLen)
        {
            case 4:
            case 8:
            case 12:
            case 13:
            case 14:
            case 15:
            case 16:break;
            default:
                CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
    
        if (mode[0] != MODE_ENCRYPT_DONE)
        {
            CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        }
        if ((tagOff<0) || (tagLen<0))
        {
            throw new ArrayIndexOutOfBoundsException(); 
        }
        
        if ((tagOff + tagLen) > tagBuf.length)
        {
            throw new ArrayIndexOutOfBoundsException(); 
        }
        
        if (tagOff > tagBuf.length)
        {
            throw new ArrayIndexOutOfBoundsException(); 
        }        

        short result = SecurityNativeMethods.AESGCMretrieveTag(tagBuf, tagOff, tagLen, mempool);
                
        NativeMethods.sensitiveResultSet(result);
        return result;
    }

    @Override
    public boolean verifyTag(byte[] receivedTagBuf, short receivedTagOff, short receivedTagLen, short requiredTagLen) throws CryptoException, NullPointerException {
        
        
        NativeMethods.sensitiveResultSetTagValUnassigned();
        if (mode[0] != MODE_DECRYPT_DONE)
        {
            CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        }
        if ((receivedTagOff<0) || (receivedTagLen<0) || (requiredTagLen<0))
        {
            throw new ArrayIndexOutOfBoundsException(); 
        }        
        if ((receivedTagOff + receivedTagLen) > receivedTagBuf.length)
        { 
            throw new ArrayIndexOutOfBoundsException(); 
        }        
        
        if (receivedTagLen != requiredTagLen)
        {
           CryptoException.throwIt(CryptoException.ILLEGAL_VALUE); 
        }
        
        //boolean result = SecurityNativeMethods.AESGCMverifyTag(receivedTagBuf, receivedTagOff, receivedTagLen, Util.getShort(TagLength, (short)0), mempool);
        boolean result = SecurityNativeMethods.AESGCMverifyTag(receivedTagBuf, receivedTagOff, receivedTagLen, receivedTagLen, mempool);
        
        if (result)
            NativeMethods.sensitiveResultSetBooleanTrue();
        else
            NativeMethods.sensitiveResultSetBooleanFalse();
       
        return result;
    }

    @Override
    public byte getAlgorithm() {
        return ALG_AES_GCM;
    }

    @Override
    public byte getCipherAlgorithm() {
        return ALG_AES_GCM;
    }

    @Override
    public byte getPaddingAlgorithm() {
        return PAD_NULL;
    }
    
    void prepareAndCipher(byte[] outBuff, short outOffset, short inLen) {
        for (short i = 0; i < inLen; i++) {
            myqueue.queuePut(holdData[i]);
        }
        cipherQueue(myqueue, outBuff, outOffset, inLen);
    }
    
    /**
     * Performs the cipher operation on the contents of the myqueue queue
     */
    protected void cipherQueue(CircularQueue queue, byte[] outBuff, short outOffset, short outLen) {

        short c = queue.getCount();
        
        for (short i = 0; i < outLen; i++) {
            data[i] = queue.queueGet();
        }

        /* We need to do this as a deselect or tear event will clear the 
         * the keyLength variable.  If akey is of type persistant, then
         * the key will be initialized, but, cipher.doFinal will fail w/o 
         * this after deselect.
         */
        Util.setShort(keyLength, (short) 0, akey.getSize());

        switch (Util.getShort(keyLength, (short) 0)) {
            case KeyBuilder.LENGTH_AES_128:
                if ((mode[0] == MODE_ENCRYPT_DONE) || (mode[0] == MODE_ENCRYPT)) {
                    // encrypt the data
                    SecurityNativeMethods.AESGCMencrypt(data, intermediateOutput, (byte)outLen, mempool);

                } else { if ((mode[0] == MODE_DECRYPT_DONE) || (mode[0] == MODE_DECRYPT)) {
                    // decrypt the data
                    SecurityNativeMethods.AESGCMdecrypt(data, intermediateOutput, (byte)outLen, mempool);             
                }
                
                }
                NativeMethods.arrayCopyNonAtomicForSensitiveArrays(intermediateOutput, (short) 0, outBuff, outOffset, outLen);
                break;
            default:
                CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
                break;
        }
    }    
    
}
