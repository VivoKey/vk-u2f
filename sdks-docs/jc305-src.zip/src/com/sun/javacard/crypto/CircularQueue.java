/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

import javacard.framework.JCSystem;
import javacard.framework.Util;
import javacard.security.CryptoException;

/**
 * Implements a circular queue.
 */

public class CircularQueue {
    /**
     * Used to implement a circular queue that stores data blocks entered using
     * 'update'.
     */
    protected byte[] circular = null;

    /*
     * count and end are variables (counters). If they are typed as primitives
     * say, short, they become part of a transaction when called in the
     * midst of say, an applet's transaction. This is not the desired behavior.
     * Hence we create a byte array in transient deselect space.
     * Also, creating counters in RAM is more efficient than in EEEPROM
     */

    /**
     * Number of elements in the circular queue
     */
    protected byte[] count;

    /**
     * Index of end of queue
     */
    protected byte[] end;

    public CircularQueue(short size) {
        circular = JCSystem.makeTransientByteArray(size, JCSystem.CLEAR_ON_DESELECT);
        count = JCSystem.makeTransientByteArray((short) 2, JCSystem.CLEAR_ON_DESELECT);
        end = JCSystem.makeTransientByteArray((short) 2, JCSystem.CLEAR_ON_DESELECT);
    }

    /**
     * Inserts a byte into the end of the queue. Note that if the number of
     * elements put into the queue is greater than the size of the queue, then
     * older elements will be overridden by newer elements
     * 
     * @param b
     *            the element to put at the tail of the queue
     */
    public void queuePut(byte b) {
        short t_end = Util.getShort(end, (short) 0);
        circular[t_end] = b;
        t_end++;
        Util.setShort(end, (short) 0, t_end);
        short t_count = Util.getShort(count, (short) 0);
        t_count++;
        Util.setShort(count, (short) 0, t_count);
    }

    /**
     * Removes and returns the byte at the beginning of the queue
     * 
     * @return the byte at the head of the queue
     * @throws CryptoException
     *             if the queue is empty
     */
    public byte queueGet() throws CryptoException {
        short t_count = Util.getShort(count, (short) 0);
        if (t_count == 0) {
            CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        }

        byte b = circular[0];
        for (short i = 0; i < (t_count - 1); i++) {
            circular[i] = circular[(short) (i + 1)];
        }
        // count--;
        t_count--;
        Util.setShort(count, (short) 0, t_count);
        // end--;
        short t_end = Util.getShort(end, (short) 0);
        t_end--;
        Util.setShort(end, (short) 0, t_end);
        return b;
    }

    /**
     * returns sequencial bytes from the queue, starting at the beginning, going
     * through count.
     * 
     * @param out
     *            the array to copy the queue contents to.
     */
    public void copy(byte[] out) {
        short t_count = Util.getShort(count, (short) 0);
        for (short i = 0; i < t_count; i++) {
            out[i] = circular[i];
        }
    }

    /**
     * Returns the number of elements in the queue
     * 
     * @return the number of elements in the queue
     */
    public short getCount() {
        return Util.getShort(count, (short) 0);
    }

    /**
     * Clears the queue of its contents
     */
    public void clearQueue() {
        for (short i = 0; i < circular.length; i++) {
            circular[i] = 0;
        }
        // set count = 0
        Util.setShort(count, (short) 0, (short) 0);
        // set end = 0;
        Util.setShort(end, (short) 0, (short) 0);
    }

    /**
     * Performs an XOR operation of the queue elements with the passed in array
     * Used to facilitate encryption and decryption in CBC mode ciphers
     * 
     * @param vec
     *            the array with which to XOR the elements of the queue
     */
    public void xorWith(byte[] vec) throws CryptoException {
        // if the vector length is different from the number of elements
        // in the queue then we throw an exception
        if (vec.length != Util.getShort(count, (short) 0)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        for (short i = 0; i < vec.length; i++) {
            circular[i] ^= vec[i];
        }// for

    }// xorWith

}
