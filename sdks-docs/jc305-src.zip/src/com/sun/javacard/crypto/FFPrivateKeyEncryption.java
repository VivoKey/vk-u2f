/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */
package com.sun.javacard.crypto;

import com.sun.javacard.impl.NativeMethods;
import javacard.framework.JCSystem;
import javacard.security.CryptoException;
import javacard.security.KeyBuilder;
import javacardx.crypto.Cipher;
import javacardx.crypto.KeyEncryption;

/**
 *
 * 
 */
public class FFPrivateKeyEncryption extends FFPrivateKeyImpl implements KeyEncryption{
    
    Cipher keyDecryptionCipher = null;
    
    private byte[] dec_X;

    public FFPrivateKeyEncryption(byte type, short bitLength) {
        super(type, bitLength);
        switch(type){
            case KeyBuilder.TYPE_DH_PRIVATE:
                dec_X = new byte[(short) (super.getMaxQSize() / 8 + super.ALIGNMENT_SPACE + super.BIGINT_STRUCT_SIZE)];
                break;
                
            case KeyBuilder.TYPE_DH_PRIVATE_TRANSIENT_RESET:
                dec_X = JCSystem.makeTransientByteArray((short) (super.getMaxQSize() / 8 + super.ALIGNMENT_SPACE + super.BIGINT_STRUCT_SIZE), JCSystem.MEMORY_TYPE_TRANSIENT_RESET);
                break;
                
            default:
                break;
        }
    }
    
    public void setX(byte[] buffer, short offset, short length) throws CryptoException {
        if(length == 0){
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
        NativeMethods.checkArrayArgs(buffer, offset, length);
        short len = (short)0;
        if(keyDecryptionCipher != null){
            try{
                len = keyDecryptionCipher.doFinal(buffer, offset, length, dec_X, (short)0);
            }
            catch(Exception e){
                CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
            }
            if(len > super.getMaxQSize()/8){
                CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
            }
        }
        super.setX(dec_X, (short)0, len);
    }
    
    
    public void setKeyCipher(Cipher keyCipher) {
        keyDecryptionCipher = keyCipher;
    }
    
    public Cipher getKeyCipher() {
        return keyDecryptionCipher;
    }
    
    
    
}
