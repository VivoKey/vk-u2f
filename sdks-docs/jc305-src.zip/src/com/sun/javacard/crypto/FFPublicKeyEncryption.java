/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */
package com.sun.javacard.crypto;

import com.sun.javacard.impl.NativeMethods;
import javacard.framework.JCSystem;
import javacard.security.CryptoException;
import javacard.security.KeyBuilder;
import javacardx.crypto.Cipher;
import javacardx.crypto.KeyEncryption;

/**
 *
 * 
 */
public class FFPublicKeyEncryption extends FFPublicKeyImpl implements KeyEncryption{

    Cipher keyDecryptionCipher = null;
    
    private byte[] dec_Y;
    
    public FFPublicKeyEncryption(byte type, short bitLength) {
        super(type, bitLength);
        switch(type){
            case KeyBuilder.TYPE_DH_PUBLIC:
                dec_Y = new byte[(short) (super.getSize() / 8 + super.ALIGNMENT_SPACE + super.BIGINT_STRUCT_SIZE)];
                break;
                
            case KeyBuilder.TYPE_DH_PUBLIC_TRANSIENT_RESET:
                dec_Y = JCSystem.makeTransientByteArray((short) (super.getSize() / 8 + super.ALIGNMENT_SPACE + super.BIGINT_STRUCT_SIZE), JCSystem.MEMORY_TYPE_TRANSIENT_RESET);
                break;
                
            default:
                break;
        }
    }
    
    public void setY(byte[] buffer, short offset, short length) throws CryptoException {
        if(length == 0){
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
        NativeMethods.checkArrayArgs(buffer, offset, length);
        short len = (short)0;
        if(keyDecryptionCipher != null){
            try{
                len = keyDecryptionCipher.doFinal(buffer, offset, length, dec_Y, (short)0);
            }catch(Exception e){
                CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
            }
            if(len > super.getSize()/8){
                CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
            }
        }
        super.setY(dec_Y, (short)0, len);
    }


 public void setKeyCipher(Cipher keyCipher) {
        keyDecryptionCipher = keyCipher;
    }
    
    public Cipher getKeyCipher() {
        return keyDecryptionCipher;
    }
    
}
