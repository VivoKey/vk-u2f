/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

public class DESCBCISO9797M2Cipher extends DESCBCCipher {
    public DESCBCISO9797M2Cipher(byte algorithm, byte cipherAlgorithm, byte paddingAlgorithm) {
        super(algorithm, cipherAlgorithm, paddingAlgorithm);
        // instantiate the correct padder object. This member is defined in the
        // base class
        padder = new ISO9797M2Padder();
    }
}// end class
