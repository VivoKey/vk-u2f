/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

import javacard.framework.Util;
import javacard.security.CryptoException;

import com.sun.javacard.impl.NativeMethods;

public class UtilityRandomData extends RandomDataInternal {

    static byte[] original_seed;

    private byte[] actual_seed;

    static final short SEED_LEN = (short) 8;

    public UtilityRandomData(byte algorithm) {
        super(algorithm);
        actual_seed = new byte[SEED_LEN];
        for (short i = 0; i < SEED_LEN; i++) {
            actual_seed[i] = original_seed[i];
        }
    }

    public void generateData(byte[] buffer, short offset, short length) {

        NativeMethods.checkArrayArgs(buffer, offset, length);

        if (length == 0) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
        SecurityNativeMethods.generateRandomData(buffer, offset, length, actual_seed, (short) 0, SEED_LEN);
    }

    public short nextBytes(byte[] buffer, short offset, short length) {
        NativeMethods.sensitiveResultSetTagValUnassigned();
        
        NativeMethods.checkArrayArgs(buffer, offset, length);

        if (length == 0) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
        SecurityNativeMethods.generateRandomData(buffer, offset, length, actual_seed, (short) 0, SEED_LEN);
        
        NativeMethods.sensitiveResultSet((short)(offset+length));
        return (short)(offset+length);
    }

    public void setSeed(byte buffer[], short offset, short length) {

        NativeMethods.checkArrayArgs(buffer, offset, length);

        if (length == 0) {
            return;
        }

        if (length >= SEED_LEN) {
            // Copy in the first SEED_LEN bytes from the users buffer
            Util.arrayCopyNonAtomic(buffer, offset, actual_seed, (short) 0, SEED_LEN);
        } else {
            // Place new seed data in the low order bytes. Fill in remaining
            // high order bytes with original_seed
            Util.arrayCopyNonAtomic(buffer, offset, actual_seed, (short) (SEED_LEN - length), length);
            // the rest of the bytes will have bits from the original seed.
            Util.arrayCopyNonAtomic(original_seed, (short) 0, actual_seed, (short) 0, (short) (SEED_LEN - length));
        }
    }

    // Called once in card lifetime in cardInit().
    public static void init() {

        original_seed = new byte[SEED_LEN];
        original_seed[0] = (byte) 0x67;
        original_seed[1] = (byte) 0x45;
        original_seed[2] = (byte) 0x23;
        original_seed[3] = (byte) 0x01;
        original_seed[4] = (byte) 0xef;
        original_seed[5] = (byte) 0xcd;
        original_seed[6] = (byte) 0xab;
        original_seed[7] = (byte) 0x89;
        NativeMethods.setJCREentry(original_seed, false);
    }
    
    public byte getAlgorithm() {
        byte result = RandomDataInternal.ALG_PSEUDO_RANDOM;
        NativeMethods.sensitiveResultSet(result);
        return result;
    }
}
