/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
// #ifdef_Target32Bit_
package com.sun.javacard.crypto;

import javacard.security.CryptoException;
import javacardx.crypto.KeyEncryption;

public class AESKeyEncryption extends AESKeyImpl implements KeyEncryption {

    protected CipherInternal keyDecryptionCipher = null;

    public AESKeyEncryption(byte type, short bitLength) {
        super(type, bitLength);
    }

    public void setKey(byte[] keyData, short kOff) {
        /*  
        *  If the keyDecryptionCipher is not null, first decrypt the data 
        *  at the appropriate offset in the buffer holds keyData after 
        *  decryption. We initialize it to keyData in case the decryption
        *  cipher is null
        */
        if (keyDecryptionCipher != null) {
            short dataLength = (short) 16; // need to initialize to a value

            if (keyDecryptionCipher instanceof DESCipher) {
                dataLength = (short) 24;
            } else if (keyDecryptionCipher instanceof AESCipher) {
                dataLength = (short) 16;
            } else {
                // (keyDecryptionCipher instanceof RSAPKCS1Cipher) {
                dataLength = (short) 64;

            }
            /* If we don't do this here, doFinal will throw a 
             * ArrayIndexOutOfBoundsException, a runtime exception
             * and we catch only CryptoException.
             * This check helps in Specification compliance.
             */
            if ((short) (keyData.length - kOff) < dataLength) {
                CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
            }

            try {
                keyDecryptionCipher.doFinal(keyData, kOff, dataLength, data, (short) 0);
            } catch (CryptoException e) {
                // throw correct error type for bad decrypted data
                CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
            }
            // now do the actual set operation
            super.setKey(data, (short) 0);
        } else {
            // now do the actual set operation
            super.setKey(keyData, kOff);
        }
    }

    public javacardx.crypto.Cipher getKeyCipher() {
        return keyDecryptionCipher;
    }

    public void setKeyCipher(javacardx.crypto.Cipher keyCipher) {
        keyDecryptionCipher = (com.sun.javacard.crypto.CipherInternal) keyCipher;
    }

}
// #endif_Target32Bit_
