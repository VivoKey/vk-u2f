/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

import javacard.security.Key;

public abstract class KeyInternal implements Key {
    private byte type;
    private short bitLength;

    public KeyInternal(byte type, short bitLength) {
        this.type = type;
        this.bitLength = bitLength;
    }

    public byte getType() {
        return type;
    }

    public short getSize() {
        return bitLength;
    }
}
