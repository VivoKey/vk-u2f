/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

public abstract class SignatureInternal extends javacard.security.Signature {
    private byte algorithm;
    private final byte messageDigestAlgorithm;
    private final byte cipherAlgorithm;
    private final byte paddingAlgorithm;

    public SignatureInternal(byte algorithm, byte messageDigestAlgorithm, byte cipherAlgorithm, byte paddingAlgorithm) {
        this.algorithm = algorithm;
        this.messageDigestAlgorithm = messageDigestAlgorithm;
        this.cipherAlgorithm = cipherAlgorithm;
        this.paddingAlgorithm = paddingAlgorithm;
    }

    public byte getAlgorithm() {
        return algorithm;
    }

    public byte getMessageDigestAlgorithm() {
        return messageDigestAlgorithm;
    }

    public byte getCipherAlgorithm() {
        return cipherAlgorithm;
    }

    public byte getPaddingAlgorithm() {
        return paddingAlgorithm;
    }
}
