/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

import javacard.security.CryptoException;

public abstract class MessageDigest extends javacard.security.InitializedMessageDigest {
    private byte algorithm;

    public MessageDigest(byte algorithm) {
        this.algorithm = algorithm;
    }

    public byte getAlgorithm() {
        return algorithm;
    }

    /* Note: assumes that val>0 && val<(2^15 -1)
     * arr[0] is least significant byte
     * arr[arr.length -1] is most significant byte
     **/
    static void addToArray(short[] arr, short val) {
        short carry = val;
        for (byte i = (byte) 0; i < arr.length; i++) {
            // if 0xFFFF - arr[i] is > val, carry is 1 else carry is 0
            if ((short) (((short) 0x8000) & arr[i]) == (short) 0) {
                // MSB is not set.carry =0
                arr[i] += carry;
                carry = (short) 0;
            } else {
                // msb is set.
                if (((short) 0xFFFF) - arr[i] >= carry) {
                    arr[i] += carry;
                    carry = (short) 0;
                } else {
                    arr[i] += carry;
                    carry = (short) 1;
                }
            }
        }
        // check that the length represented by val is < 2^61
        if ((short) (arr[(short) (arr.length - 1)] & 0xE000) != 0) {
            CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        }

        if (carry != 0) {
            // Overflow of most significant byte. Too much data digested
            CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        }
    }

    /**
     * left shifts the number in short[] by 3
     */
    static void leftShiftThree(short[] arr) {
        short carry = (short) 0;
        for (byte i = (byte) 0; i < arr.length; i++) {
            // take the 3 MSB bits of arr[i] since they will be carry of next
            // short
            short nextCarry = (short) ((arr[i] >> (short) 13) & (short) 0x0007);
            arr[i] = (short) (arr[i] << (short) 3);
            arr[i] += carry;
            carry = nextCarry;
        }
        if (carry != (short) 0) {
            // Overflow of most significant byte. Too much data digested
            CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        }
    }

    /**
     * return true if x falls below 2^61, and false otherwise
     */
    static boolean below2power61(byte[] x, short off, short len) {

        // any length below 8 certainly represents a value below 2^61
        if (len < (short) 8) {
            return true;
        }

        // len >= 8
        // let L = the 61 LSBs of x[off] to x[off + len - 1]
        // M = MSBs 62 and higher
        // if M consists entirely of zeros, return true, otherwise false
        boolean isZero = true;
        for (short j = off; j < (short) (off + len - 8); j++) {
            isZero = isZero && (x[j] == 0);
        }

        // must only consider the 3 MSBs of byte x[off + len - 8]
        isZero = isZero && ((byte) (x[(short) (off + len - 8)] & 0xE0) == 0);

        return isZero;
    }
}
