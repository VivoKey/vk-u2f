/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

import javacard.framework.JCSystem;
import javacard.framework.Util;
import javacard.security.CryptoException;
import javacard.security.KeyBuilder;
import javacardx.crypto.Cipher;

import com.sun.javacard.impl.NativeMethods;
import com.sun.javacard.impl.PrivAccess;

/**
 * Base class providing common functionality for the four DESMAC8 based
 * signature algorithms. The only difference between each one being the padding
 * scheme
 */
public abstract class DESMAC8Signature extends SignatureInternal {
    protected final static short BLOCK_SIZE = 8;
    /**
     * The cipher object used to create and verify the SignatureInternal
     */
    protected Cipher cipher;

    /**
     * The current operating mode (MODE_SIGN or MODE_VERIFY)
     */
    protected byte[] mode;
    protected byte modeNonTransient;

    /**
     * Indicates proper initialization of this signature object
     */
    protected boolean[] initFlag;
    protected boolean initFlagNonTransient;

    /**
     * This temporary buffer is used to hold the output from cipher.update().
     * Since this is DES, no more than BLOCKSIZE (8) bytes should be needed.
     */
    private byte[] temp = null;

    public DESMAC8Signature(byte algorithm, byte messageDigestAlgorithm, byte cipherAlgorithm, byte paddingAlgorithm) {
        super(algorithm, messageDigestAlgorithm, cipherAlgorithm, paddingAlgorithm);
        temp = JCSystem.makeTransientByteArray((short) (3 * BLOCK_SIZE), JCSystem.CLEAR_ON_DESELECT);
        mode = JCSystem.makeTransientByteArray((short) 1, JCSystem.CLEAR_ON_DESELECT);
        initFlag = JCSystem.makeTransientBooleanArray((short) 1, JCSystem.CLEAR_ON_DESELECT);
        initFlag[0] = false;
        initFlagNonTransient = false;
    }

    /**
     * Initialize the signature object. Calls the other init method passing in a
     * default IV of zeros
     */
    public void init(javacard.security.Key theKey, byte theMode) throws CryptoException {

        init(theKey, theMode, DESCBCCipher.defaultIV, (short) 0, (short) DESCBCCipher.defaultIV.length);
    }

    /**
     * Initializes the SignatureInternal object
     * 
     * @param theKey
     *            the key object to use for signing
     * @param theMode
     *            one of MODE_SIGN or MODE_VERIFY
     * @param bArray
     *            byte array containing the Initialization Vector for the
     *            cipher.
     * @param bOff
     *            offset within bArray where the Initialization Vector data
     *            begins.
     * @param bLen
     *            byte length of Initialization Vector. Should be 8
     * 
     */
    public void init(javacard.security.Key theKey, byte theMode, byte[] bArray, short bOff, short bLen)
            throws CryptoException, NullPointerException {
        // store a reference to the key. We must check it's initialization state
        // later
        // Verify that the key is initialized
        if (!theKey.isInitialized()) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }

        /* Ensure that the Initialization Vector length specified is of the 
         * correct length
         */
        if (bLen != BLOCK_SIZE) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        // Verify that the mode value is valid and set the mode for the
        // cipher accordingly
        switch (theMode) {
            /* The cipher object does an ENCRYPTION operation whether we are 
             * signing data or verifying a signature.
             * In a verification we sign the data and compare it to a passed in 
             * signature
             */
            case MODE_SIGN:
            case MODE_VERIFY:
                if (theKey.getType() == KeyBuilder.TYPE_DES) {
                    modeNonTransient = theMode;
                } else {
                    mode[0] = theMode;
                }
                break;

            default:
                CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        // Verify that the key is a DES key
        if (!(theKey instanceof DESKeyImpl)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        /* if we got this far then the input is valid and we can proceed
         * Initialize the cipher. It should be instantiated in the constructor of 
         * derived classes
         */
        cipher.init(theKey, Cipher.MODE_ENCRYPT, bArray, bOff, bLen);
        /* if the cipher.init didn't throw an exception then the initialization
         * succeeded
         */
        if (theKey.getType() == KeyBuilder.TYPE_DES) {
            initFlagNonTransient = true;
        } else {
            initFlag[0] = true;
        }
    }

    public void setInitialDigest(byte[] initialDigestBuf, short initialDigestOffset,
            short initialDigestLength, byte[] digestedMsgLenBuf, short digestedMsgLenOffset, short digestedMsgLenLength)
            throws CryptoException{
        CryptoException.throwIt(CryptoException.ILLEGAL_USE);
    }

    /**
     * Returns the length of the signature. For all these algorithms the
     * signature is an 8 byte value
     */
    public short getLength() throws CryptoException {
        /*
         * cipher.update is used here, to verify that the cipher key has been initialized
         * it will throw CryptoException.UNINITIALIZED_KEY, if the key is not initialized
         */
        cipher.update(temp, (short) 0, (short) 0, temp, (short) 0);

        if (!initFlag[0]) {
            if (!initFlagNonTransient) {
                CryptoException.throwIt(CryptoException.INVALID_INIT);
            }
        }

        return BLOCK_SIZE;
    }

    /**
     * Accumulates the next block of data for the signature
     */
    public void update(byte[] inBuff, short inOff, short inLen) throws CryptoException {
        /*
         * cipher.update is used here, to verify that the cipher key has been initialized
         * it will throw CryptoException.UNINITIALIZED_KEY, if the key is not initialized
         */
        cipher.update(temp, (short) 0, (short) 0, temp, (short) 0);
        // Ensure the SignatureInternal object is initialized for signing
        if (!initFlag[0]) {
            if (!initFlagNonTransient) {
                CryptoException.throwIt(CryptoException.INVALID_INIT);
            }
        }
        /** Checking array bounds to throw the right kind of exception */
        NativeMethods.checkArrayArgs(inBuff, inOff, inLen);
        /*
        * We don't need to store the output resulting from the update calls since
        * in all the DESMAC8 algorithms only the LAST 8 bytes encrypted comprise
        * the signature, so we can allow the cipher object to output its encrypted
        * output into a temporary buffer that we don't need to store
        * The spec says that we should throw a CryptoException(UNINITIALIZED_KEY) 
        * if the key is not initialized, but the cipher.update does that already
        */
        short inputLength = (short) temp.length;
        short inOffset = inOff;
        short remaining = inLen;
        while (remaining > inputLength) {
            cipher.update(inBuff, inOffset, inputLength, temp, (short) 0);
            inOffset += inputLength;
            remaining -= inputLength;
        }
        cipher.update(inBuff, inOffset, remaining, temp, (short) 0);

    }

    public short sign(byte[] inBuff, short inOff, short inLen, byte[] sigBuff, short sigOff) throws CryptoException {
        NativeMethods.sensitiveResultSetTagValUnassigned();
        /*
         * cipher.update is used here, to verify that the cipher key has been initialized
         * it will throw CryptoException.UNINITIALIZED_KEY, if the key is not initialized
         */
        cipher.update(temp, (short) 0, (short) 0, temp, (short) 0);

        /*To get the last 8 bytes of encrypted output all we need to do is doFinal 
         *on the cipher 
         *Ensure the SignatureInternal object is initialized for signing
         */

        if (initFlagNonTransient) {
            initFlag[0] = true;
            mode[0] = modeNonTransient;
        }

        if (!initFlag[0] || mode[0] != MODE_SIGN) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }

        /** Checking array bounds to throw the right kind of exception */
        NativeMethods.checkArrayArgs(inBuff, inOff, inLen);
        NativeMethods.checkArrayArgs(sigBuff, sigOff, BLOCK_SIZE);

        short ret = doSign(inBuff, inOff, inLen, sigBuff, sigOff);
        
        NativeMethods.sensitiveResultSet(ret);
        return ret;

    }

    public boolean verify(byte[] inBuff, short inOff, short inLen, byte[] sigBuff, short sigOff, short sigLen)
            throws CryptoException {
        NativeMethods.sensitiveResultSetTagValUnassigned();
        /*
         * cipher.update is used here, to verify that the cipher key has been initialized
         * it will throw CryptoException.UNINITIALIZED_KEY, if the key is not initialized
         */
        cipher.update(temp, (short) 0, (short) 0, temp, (short) 0);

        // Ensure the SignatureInternal object is initialized for verification
        if (initFlagNonTransient) {
            initFlag[0] = true;
            mode[0] = modeNonTransient;
        }
        if (!initFlag[0] || mode[0] != MODE_VERIFY) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }
        /** Checking array bounds to throw the right kind of exception */
        NativeMethods.checkArrayArgs(inBuff, inOff, inLen);
        NativeMethods.checkArrayArgs(sigBuff, sigOff, sigLen);

        if (sigLen != BLOCK_SIZE) {
            NativeMethods.sensitiveResultSetBooleanFalse();
            return false;
        }

        /*   
         * First call sign on this last bit of input and store the 
         * resulting signature in a temporary buffer.
         * The buffer (temp) need only be long enough to support 
         * the input length + possible padding bytes
         */

        // sign the data
        short finalBytes = doSign(inBuff, inOff, inLen, temp, (short) 0);
        // now compare the last sigLen bytes of temp
        for (short i = 0; i < sigLen; i++) {
            if (temp[(short) (finalBytes - sigLen + i)] != sigBuff[(short) (sigOff + i)]) {
                NativeMethods.sensitiveResultSetBooleanFalse();
                return false;
            }
        }

        NativeMethods.sensitiveResultSetBooleanTrue();
        return true;
    }

    protected short doSign(byte[] inBuff, short inOff, short inLen, byte[] sigBuff, short sigOff)
            throws CryptoException {
        /*
         * CryptoException.UNINITIALIZED_KEY and ILLEGAL_USE are thrown by 
         * doFinal if necessary
         * Apply doFinal to a temporary output buffer. The actual signature 
         * is the last 8 bytes of this final output
         * The length of this output buffer (temp) must be as long as at least
         * 2 * 8 plus 8 to hold possible padding bytes+residual bytes that 
         * may still be in the queue used by the cipher to buffer data. The
         * reason for 2 * 8 is that if the final remaining is exactly 8, there
         * will be 8 bytes held by update, plus exactly 8 bytes of padding.
         */
        short finalBytes;
        short inputLength = (short) (temp.length - 16);
        short inOffset = inOff;
        short remaining = inLen;

        if (inLen > inputLength) {
            while (remaining > inputLength) {
                cipher.update(inBuff, inOffset, inputLength, temp, (short) 0);
                inOffset += inputLength;
                remaining -= inputLength;
            }
        }
        finalBytes = cipher.doFinal(inBuff, inOffset, remaining, temp, (short) 0);
        /*    
         * We have finalBytes output to the temp buffer. We need to copy the last  
         * numSigBytes bytes of this into sigBuff
         */
        short numSigBytes = getLength();
        short tempSigOffset = (short) (finalBytes - numSigBytes);
        NativeMethods.arrayCopyNonAtomicForSensitiveArrays(temp, tempSigOffset, sigBuff, sigOff, numSigBytes);

        return numSigBytes;
    }

    public short signPreComputedHash(byte[] hashBuf, short hashOff, short hashLength, byte[] sigBuff, short sigOffset){
        NativeMethods.sensitiveResultSetTagValUnassigned();
        CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        
        NativeMethods.sensitiveResultSet((short) 0);
        return (short)0;
    }
    
    public boolean verifyPreComputedHash(byte[] hashBuff, short hashOffset, short hashLength, byte[] sigBuff, short sigOffset,
            short sigLength) throws CryptoException{
        NativeMethods.sensitiveResultSetTagValUnassigned();
        CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        
        NativeMethods.sensitiveResultSetBooleanFalse();
        return false;
    }
    
}
