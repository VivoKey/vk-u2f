/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

import javacard.framework.JCSystem;
import javacard.framework.Util;
import javacard.security.CryptoException;

import com.sun.javacard.impl.NativeMethods;

public class SHAMessageDigest extends MessageDigest {
    // SHA works on 64 byte blocks of data
    private static final short BLOCK_SIZE = 64;
    private boolean[] initial_status;

    /* Used to ensure data is sent to the Hash module in whole blocks on
    *  update 64 * 8 = 512 bits
    */
    private CircularQueue circular;

    private static byte[] original_digest;

    /* 
    * Hardcoded to length 20 bytes as we know that digest length = 20
    */
    private byte[] digest;

    /*
    * If we have local variables like, short[] totalInLength, they become 
    * part of a transaction when called in the midst of say, an applet's
    * transaction.  JC Spec says that update() should not be part of a 
    * transaction and hence we create a byte array in transient deselect
    * space.
    * element 0 is least significant byte.Example oxFFEE would be
    * EE FF 00 00 00..   - array
    * 0  1  2  3  4 ..   - indices
    */
    private short[] totalInLength; // Total length of input data

    /**
     * aftger completion of this constructor the following is true: 1. digest is
     * allocated to 20 bytes of transient-D space and set to initial_digest 2.
     * initial_status is allocated to 1 boolean array of transient-D space. Set
     * to true 3. totalInLength is allocated 2 bytes of transient-D space and
     * cleared 4. circular set to new instance of CircularQueue and cleared. 5.
     * reset() called.
     */
    public SHAMessageDigest(byte algorithm) throws CryptoException {
        super(algorithm);
        /* NOTE: 
        * I have to do a new instance of digest here for each instance of 
        * this class.  This variable cannot be shared accross instances.  
        *
        */
        digest = JCSystem
                .makeTransientByteArray(javacard.security.MessageDigest.LENGTH_SHA, JCSystem.CLEAR_ON_DESELECT);

        initial_status = JCSystem.makeTransientBooleanArray((short) 1, JCSystem.CLEAR_ON_DESELECT);
        totalInLength = JCSystem.makeTransientShortArray((short) 4, JCSystem.CLEAR_ON_DESELECT);

        circular = new CircularQueue(BLOCK_SIZE);

        /* Call reset to reset any stale references; 
        * especially useful after tears
        */
        reset();

    }

    /**
     * This method resets the digest and then initializes the starting hash
     * value in place of the default value of 0 used by the
     * <code>MessageDigest</code> superclass. The starting hash value
     * represents the previously computed hash (using the same algorithm) of the
     * first part of the message. The remaining bytes of the message must be
     * presented to this <code>MessageDigestInitialValue</code> object via the
     * <code>update</code> and <code>doFinal</code> methods to generate the
     * final message digest.
     * <p>
     * Note:
     * <ul>
     * <li><em>The maximum allowed value of the byte length of the first part of the message is
     * algorithm specific</em>
     * </ul>
     * 
     * @param initialDigestBuf
     *            input buffer containing the starting hash value representing
     *            the previously computed hash (using the same algorithm) of
     *            first part of the message
     * @param initialDigestOffset
     *            offset into <code>intitialDigestBuf</code> array where
     *            initial digest value data begins
     * @param initialDigestLength
     *            the length of data in <code>intitialDigestBuf</code> array.
     * @param digestedMsgLenBuf
     *            the byte array containing the number of bytes in the first
     *            part of the message that has previously been hashed to obtain
     *            the specified initial digest value value. Note that the
     *            element at index 0 is the most significant byte and the
     *            element at index digestedMsgLenLength-1 is least significant
     *            byte
     * @param digestedMsgLenOffset
     *            the offset within <CODE>digestedMsgLenBuf</CODE> where the
     *            digested length begins(the bytes starting at this offset for
     *            <CODE>digestedMsgLenLength</CODE> bytes are concatenated to
     *            form the actual digested message length value)
     * @param digestedMsgLenLength
     *            byte length of the digested length
     * @exception CryptoException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>CryptoException.ILLEGAL_VALUE</code> if the
     *                parameter <code>initialDigestLength</code> is not equal
     *                to the length of message digest of the algorithm (see
     *                LENGTH_* constants {@link #LENGTH_SHA}) or if the number
     *                of bytes in the first part of the message that has
     *                previously been hashed is 0 or not a multiple of the
     *                algorithm's block size (see ALG_* algorithm descriptions
     *                {@link #ALG_SHA}).
     *                </ul>
     */
    public void setInitialDigest(byte[] initialDigestBuf, short initialDigestOffset, short initialDigestLength,
            byte[] digestedMsgLenBuf, short digestedMsgLenOffset, short digestedMsgLenLength) throws CryptoException {
        // check that initialDigest is 20 bytes long
        NativeMethods.checkArrayArgs(initialDigestBuf, initialDigestOffset, javacard.security.MessageDigest.LENGTH_SHA);

        // if initialDigestLength !=20 exception
        if (initialDigestLength != javacard.security.MessageDigest.LENGTH_SHA) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        // verify that length of data digest so far is multiple of 64 bytes
        if ((short) (digestedMsgLenBuf[(short) (digestedMsgLenOffset + digestedMsgLenLength - 1)] & (short) 0x3F) != (short) 0) {
            // last six bits are not 0. => not a multiple of 64 bytes.
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        // verify that the number of bytes of data digest so far is not 0
        boolean zero = true;
        for (short i = digestedMsgLenOffset; i < (short) (digestedMsgLenOffset + digestedMsgLenLength); i++) {
            if (digestedMsgLenBuf[i] != (byte) 0) {
                zero = false;
            }
        }
        if (zero) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        // check that the length represented by digestedMsgLenBuf is below 2^61
        // bytes,
        // as the SHA maximum value is 2^64 bits
        if (!com.sun.javacard.crypto.MessageDigest.below2power61(digestedMsgLenBuf, digestedMsgLenOffset,
                digestedMsgLenLength)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        reset();

        // set the digest to initialDigest
        Util.arrayCopyNonAtomic(initialDigestBuf, initialDigestOffset, digest, (short) 0, initialDigestLength);

        // reverse the order of bytes since for our calculation, element 0 is
        // least significant byte.
        short i = 0, j = 0;
        for (i = (short) (digestedMsgLenLength - 1), j = (short) 0; (short) (i - 1) >= (short) 0; i -= (short) 2, j++) {
            // last byte of short
            totalInLength[j] = (digestedMsgLenBuf[(short) (i - 1)]);
            totalInLength[j] = (short) (totalInLength[j] << (short) 8);
            totalInLength[j] |= (short) (digestedMsgLenBuf[i] & (short) 0x00FF);
            // first byte of short
        }
        if (i == (short) 0) {
            // last byte left. capture in new short
            totalInLength[j] = (short) (digestedMsgLenBuf[i] & (short) 0x00FF);
        }

    }

    public short doFinal(byte[] inBuff, short inOffset, short inLength, byte[] outBuff, short outOffset) {
        NativeMethods.sensitiveResultSetTagValUnassigned();
        
        if (inLength != 0) {
            NativeMethods.checkArrayArgs(inBuff, inOffset, inLength);
        }

        // I shall check only for len = 20 as that is what I am interested in
        NativeMethods.checkArrayArgs(outBuff, outOffset, javacard.security.MessageDigest.LENGTH_SHA);
        if (!(initial_status[0])) {
            reset();
        }

        short length = inLength;
        short i = inOffset;

        while (length > 0) {
            // Fill up the queue and send it for update
            circular.queuePut(inBuff[i]);
            i++;
            length--;
            /*
            * We only want to update on the queue if there is
            * still input data, otherwise we must doFinal 
            */
            if (BLOCK_SIZE == circular.getCount()) {
                computeBlock(circular);
            }
        }

        com.sun.javacard.crypto.MessageDigest.addToArray(totalInLength, inLength);

        // first add 1 to the byte array
        if (circular.getCount() < 56) {
            circular.queuePut((byte) 0x80);
            // Pad 0's till we reach 448
            while (circular.getCount() < 56) {
                circular.queuePut((byte) 0x00);
            }
            /*
            * append message data Length to the data for the last 8 bytes
            */
            // left shift the whole number by 3 to represent number of bits
            com.sun.javacard.crypto.MessageDigest.leftShiftThree(totalInLength);
            for (short j = (short) (totalInLength.length - 1); j >= (short) 0; j--) {
                circular.queuePut((byte) (totalInLength[j] >> (short) 8));
                circular.queuePut((byte) (totalInLength[j]));
            }

            computeBlock(circular);
            Util.arrayCopy(digest, (short) 0, outBuff, outOffset, (short) digest.length);

        }

        /* 
        * Corner Case - if message length =448 bits or 56 bytes, 
        * when we add 1 bit or 0x80 byte to it the total length is  
        * now 449 or rounding it to the next byte, 57 bytes so we add
        * 511 0's or 63 bytes and then compute digest for each block.
        * 
        *  else ((circular.getCount() > 55) && (circular.getCount() < 64))
        */

        else {
            /*
            * the last 2 words which are reserved for length now have the
            * 0x8000 0000 0000 0000 padding
            */
            circular.queuePut((byte) 0x80);
            for (short j = 0; circular.getCount() < 64; j++) {
                circular.queuePut((byte) 0x00);
            }

            computeBlock(circular);
            Util.arrayCopy(digest, (short) 0, outBuff, outOffset, (short) digest.length);

            circular.clearQueue();

            while (circular.getCount() < 56) {
                circular.queuePut((byte) 0x00);
            }
            // left shift the whole number by 3 to represent number of bits
            com.sun.javacard.crypto.MessageDigest.leftShiftThree(totalInLength);
            for (short j = (short) (totalInLength.length - 1); j >= (short) 0; j--) {
                circular.queuePut((byte) (totalInLength[j] >> (short) 8));
                circular.queuePut((byte) (totalInLength[j]));
            }

            computeBlock(circular);
            Util.arrayCopy(digest, (short) 0, outBuff, outOffset, (short) digest.length);
        }

        reset();
        
        NativeMethods.sensitiveResultSet((short) digest.length);
        return (short) digest.length;
    }

    public void update(byte[] inBuff, short inOffset, short inLength) {

        NativeMethods.checkArrayArgs(inBuff, inOffset, inLength);

        if (!(initial_status[0])) {
            reset();
        }

        for (short i = 0; i < inLength; i++) {
            // Fill up the queue and send it for update
            circular.queuePut(inBuff[(short) (inOffset + i)]);
            if (BLOCK_SIZE == circular.getCount()) {
                computeBlock(circular);
            }
        }
        com.sun.javacard.crypto.MessageDigest.addToArray(totalInLength, inLength);
    }

    /*
    *  Computes SHA for one Block (64 bytes) of data
    */
    protected void computeBlock(CircularQueue cq) {
        SecurityNativeMethods.computeSHABlock(cq.circular, digest);
        circular.clearQueue();
    }

    public byte getLength() {
        return javacard.security.MessageDigest.LENGTH_SHA;
    }

    public void reset() {
        // totalInLength = (short)0;
        // TODO: Replace this with Joe's utility method
        for (short i = 0; i < totalInLength.length; i++) {
            totalInLength[i] = (short) 0;
        }
        circular.clearQueue();
        Util.arrayCopyNonAtomic(original_digest, (short) 0, digest, (short) 0,
                javacard.security.MessageDigest.LENGTH_SHA);
        initial_status[0] = true;
    }

    // Called once in card lifetime in cardInit().
    public static void init() {
        original_digest = new byte[20];
        original_digest[0] = (byte) 0x67;
        original_digest[1] = (byte) 0x45;
        original_digest[2] = (byte) 0x23;
        original_digest[3] = (byte) 0x01;
        original_digest[4] = (byte) 0xef;
        original_digest[5] = (byte) 0xcd;
        original_digest[6] = (byte) 0xab;
        original_digest[7] = (byte) 0x89;
        original_digest[8] = (byte) 0x98;
        original_digest[9] = (byte) 0xba;
        original_digest[10] = (byte) 0xdc;
        original_digest[11] = (byte) 0xfe;
        original_digest[12] = (byte) 0x10;
        original_digest[13] = (byte) 0x32;
        original_digest[14] = (byte) 0x54;
        original_digest[15] = (byte) 0x76;
        original_digest[16] = (byte) 0xc3;
        original_digest[17] = (byte) 0xd2;
        original_digest[18] = (byte) 0xe1;
        original_digest[19] = (byte) 0xf0;
        NativeMethods.setJCREentry(original_digest, false);
    }

}
