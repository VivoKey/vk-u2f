/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
// #ifdef_Target32Bit_
package com.sun.javacard.crypto;

import javacard.framework.JCSystem;
import javacard.framework.Util;
import javacard.security.Checksum;
import javacard.security.CryptoException;

import com.sun.javacard.impl.NativeMethods;

public class CRC32 extends javacard.security.Checksum {

    private byte[] checksum32; // holds checksum result
    private static final short CRC32_OUTBUF_LEN = (short) 4;
    // private static final int CRC32_FINAL_XOR = 0xFFFFFFFF;
    private static final byte CRC32_FINAL_XOR = (byte) 0xFF;
    // private static final int CRC32_POLYNOMIAL = 0x4C11DB7;
    private final byte[] CRC32_POLYNOMIAL = { (byte) 0x04, (byte) 0xc1, (byte) 0x1d, (byte) 0xb7 };

    /**
     * Default Constructor
     */
    public CRC32() {
        checksum32 = JCSystem.makeTransientByteArray((short) 4, JCSystem.CLEAR_ON_DESELECT);
    }

    public byte getAlgorithm() {
        return Checksum.ALG_ISO3309_CRC32;
    }

    public void init(byte[] bArray, short bOff, short bLen) throws CryptoException {

        /* Spec expects that init be provided with 4 bytes length of initial crc
         * Hence hardcoded check for 32 bits.
         */
        NativeMethods.checkArrayArgs(bArray, bOff, CRC32_OUTBUF_LEN);
        if (bLen != CRC32_OUTBUF_LEN) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        Util.arrayCopyNonAtomic(bArray, bOff, checksum32, (short) 0, bLen);
    }

    public short doFinal(byte[] inBuff, short inOffset, short inLength, byte[] outBuff, short outOffset) {

        NativeMethods.sensitiveResultSetTagValUnassigned();
        // check only for len=32 for checksum32
        NativeMethods.checkArrayArgs(outBuff, outOffset, CRC32_OUTBUF_LEN);
        // just call update which calculates checksum
        update(inBuff, inOffset, inLength);

        // XORing of checksum is done only for the final checksum value
        /* uncomment when using int 
           int temp = getInt(checksum32, (short)0);
           // reverse the bits and of the checksum
           temp = reverseInt(temp);
           temp ^= CRC32_FINAL_XOR; 
           setInt(checksum32, (short)0, temp);
        */

        // reverse the bites & bytes in checksum
        for (short i = 0; i < (short) 2; i++) {
            byte b = checksum32[i];
            checksum32[i] = reverseByte(checksum32[(short) (3 - i)]);
            checksum32[(short) (3 - i)] = reverseByte(b);
        }

        for (short i = 0; i < (short) 4; i++) {
            checksum32[i] ^= CRC32_FINAL_XOR;
        }
        // copy the checksum value to output buffer.
        Util.arrayCopy(checksum32, (short) 0, outBuff, outOffset, CRC32_OUTBUF_LEN);

        // reset to original checksum value, which is 0
        Util.arrayFillNonAtomic(checksum32, (short) 0, (short) checksum32.length, (byte) 0);
        
        NativeMethods.sensitiveResultSet(CRC32_OUTBUF_LEN);
        return CRC32_OUTBUF_LEN;
    }

    public void update(byte[] inBuff, short inOffset, short inLength) {
        NativeMethods.checkArrayArgs(inBuff, inOffset, inLength);
        // now we are ready to compute checksum
        computeChecksum(inBuff, inOffset, inLength);
    }

    /**
     * Calculate CRC for the data in inBuff and store result in checksum32
     * array.
     */

    /*  The below code uses only shorts and byte to compute checksum.  If 
     *	the underlying hardware supports int, this method should be commented out
     *  in favor of the one below in comments.
     */
    private void computeChecksum(byte[] inBuf, short inOff, short inLen) {

        // int fcs = getInt(checksum32, (short)0); // Stored CRC value

        short fcs_h = Util.getShort(checksum32, (short) 0);
        short fcs_l = Util.getShort(checksum32, (short) 2);
        short poly_h = Util.getShort(CRC32_POLYNOMIAL, (short) 0);
        short poly_l = Util.getShort(CRC32_POLYNOMIAL, (short) 2);
        byte carry = (byte) 0;
        short d_h, lfcs_h, lfcs_l;

        for (short i = inOff; i < (short) (inOff + inLen); i++) {
            byte inByte = reverseByte(inBuf[i]);

            // int d = inBuf[i] << 24;
            d_h = (short) (inByte << 8);

            for (short k = 0; k < 8; k++) {
                // if ( ((fcs ^ d) & 0x80000000) != 0) {
                if (((fcs_h ^ d_h) & 0x8000) != (short) 0) {

                    // fcs = ((fcs << 1) ^ CRC32_POLYNOMIAL);
                    carry = (byte) 0;
                    lfcs_h = LeftShiftOne(fcs_h);
                    if ((fcs_l & 0x8000) != (byte) 0) {
                        carry = (byte) 1;
                    }
                    lfcs_l = LeftShiftOne(fcs_l);
                    if (carry == (byte) 1) {
                        lfcs_h++;
                    }

                    fcs_h = (short) (lfcs_h ^ poly_h);
                    fcs_l = (short) (lfcs_l ^ poly_l);

                } else {
                    // fcs = (fcs << 1);
                    carry = (byte) 0;
                    lfcs_h = LeftShiftOne(fcs_h);
                    if ((fcs_l & 0x8000) != (byte) 0) {
                        carry = (byte) 1;
                    }
                    lfcs_l = LeftShiftOne(fcs_l);
                    if (carry == (byte) 1) {
                        lfcs_h++;
                    }
                    fcs_h = lfcs_h;
                    fcs_l = lfcs_l;

                }
                d_h <<= 1;
            }
        }
        Util.setShort(checksum32, (short) 2, fcs_l);
        Util.setShort(checksum32, (short) 0, fcs_h);
    }

    short LeftShiftOne(short s) {
        return (s <<= 1);
    }

    private static byte reverseByte(byte inByte) {
        // single bit in position 2 set so that shift left retains the 0's
        // shifted in.
        // This bit will fall off the end after the last shift.
        byte outByte = 0x02;

        for (byte k = 0; k < 7; k++) {
            outByte |= (inByte & 0x01);
            outByte = (byte) (outByte << 1);

            inByte = (byte) (inByte >> 1);
        }
        outByte |= (inByte & 0x01);

        return outByte;
    }

    /***************************************************************************
     * The below code uses int data type. If int is available on your system, it
     * is recommended that you uncomment this code and use it instead of the
     * other computeChecksum method as this is faster and efficient.
     * 
     **************************************************************************/
    /*    
    static int getInt(byte[] bArray, short bOff) {
    int raw_data =  0x00FF & bArray[bOff++];
    raw_data <<=  8;
    raw_data |= 0x00FF & bArray[bOff++];
    raw_data <<= 8;
    raw_data |=  0x00FF & bArray[bOff++];
    raw_data <<= 8;
    raw_data |=  0x00FF & bArray[bOff];
    return raw_data;
    }
        
    static void setInt( byte[] bArray, short bOff, int dat) {      
    bArray[bOff++] = (byte)(dat >> 24);
    bArray[bOff++] = (byte)(dat >> 16);
    bArray[bOff++] = (byte)(dat >> 8);
    bArray[bOff] = (byte)(dat);
    }

    private void computeChecksum(byte[] inBuf, short inOff, short inLen) {
    
    int fcs = getInt(checksum32, (short)0);      // Stored CRC value 
    for (short i=inOff; i< (short)(inOff+inLen); i++)  {
        byte inByte = reverseByte(inBuf[i]);
        int d =  inByte << 24;
        for (short k=0; k<8; k++) {
    	if ( ((fcs ^ d) & 0x80000000) != 0)  {
    	    fcs = ((fcs << 1) ^ CRC32_POLYNOMIAL);
    	}
    	else  {
    	    fcs = (fcs << 1);
    	}
    	d <<= 1;
        }
    }
    setInt(checksum32, (short)0, fcs);
    }

    private static int reverseInt(int inInt) {
    // single bit in position 2 set so that shift left retains the 0's shifted in.
    // This bit will fall off the end after the last shift.
    int outInt = 0x00000002;

    for (byte k=0; k<31; k++) {
        outInt |= (inInt & 0x00000001);
        outInt = (outInt << 1);

        inInt = (inInt >> 1);
    }
    outInt |= (inInt & 0x00000001);

    return outInt;
    }
    */
}
// #endif_Target32Bit_
