/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

/**
 * Implementors will provide padding schemes for the respective ciphers
 */
public interface Padder {
    /**
     * Pads the input according to the padding scheme dictated by the concrete
     * implementor
     * 
     * @param circular
     *            the queue containing the last bytes of data that must be
     *            padded
     * @return the number of padding bytes added
     */
    public short pad(CircularQueue circular);

    /**
     * Removes padding bytes that were added to the input
     * 
     * @param outBuff
     *            the output buffer
     * @return the number of padding bytes, allowing them to be removed prior to
     *         putting results in the users output buffer.
     */
    public short unPad(byte[] outBuff);
}
