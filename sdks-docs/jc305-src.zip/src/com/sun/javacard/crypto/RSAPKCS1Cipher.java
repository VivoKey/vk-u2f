/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

import javacard.framework.JCSystem;
import javacard.framework.Util;
import javacard.security.CryptoException;

import com.sun.javacard.impl.NativeMethods;

public class RSAPKCS1Cipher extends CipherInternal {

    private byte[] dataCache; // temporary storage for update method.

    /* holds offset into temporary storage between update calls.
     * also represents the length of the data to be encrypted/decrypted
     */
    private short offSet;
    private boolean encryptFlag; // used to determine MODE.
    private com.sun.javacard.crypto.RSAPublicKeyImpl pubKey;
    private com.sun.javacard.crypto.RSAPrivateKeyImpl privKey;
    private boolean initFlag; // indicates proper initialization.
    private byte BT; // block type for encryption

    private static final short RSA_LEN_512 = (short) 64;

    public RSAPKCS1Cipher(byte algorithm, byte cipherAlgorithm, byte paddingAlgorithm) {
        super(algorithm, cipherAlgorithm, paddingAlgorithm);
        dataCache = JCSystem.makeTransientByteArray((short) 64, JCSystem.CLEAR_ON_DESELECT);
    }

    public short getEncryptedLength( short plainLength){
        if (pubKey!=null) {
            return (short)(pubKey.getModulusLength());
        } else {
            return (short)(privKey.getModulusLength());
        }
    }

    /*
     * Note: this implementation assumes a key length of no more than 512 bits.
     */

    public void init(javacard.security.Key theKey, byte theMode) throws CryptoException {
        if (!theKey.isInitialized()) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }

        if ((theMode == MODE_ENCRYPT) && (theKey instanceof com.sun.javacard.crypto.RSAPublicKeyImpl)) {
            encryptFlag = true;
            pubKey = (com.sun.javacard.crypto.RSAPublicKeyImpl) theKey;
            BT = 0x02;
        } else if ((theMode == MODE_ENCRYPT) && (theKey instanceof com.sun.javacard.crypto.RSAPrivateKeyImpl)) {
            encryptFlag = true;
            privKey = (com.sun.javacard.crypto.RSAPrivateKeyImpl) theKey;
            BT = 0x01;
        } else if ((theMode == MODE_DECRYPT) && (theKey instanceof com.sun.javacard.crypto.RSAPrivateKeyImpl)) {
            encryptFlag = false;
            privKey = (com.sun.javacard.crypto.RSAPrivateKeyImpl) theKey;
            /* Though BT is not used for decrypt, it is also used to determine if we
             * have initialized with a public or private key.
             */
            BT = 0x01;
        } else if ((theMode == MODE_DECRYPT) && (theKey instanceof com.sun.javacard.crypto.RSAPublicKeyImpl)) {
            encryptFlag = false;
            pubKey = (com.sun.javacard.crypto.RSAPublicKeyImpl) theKey;
            BT = 0x02;
        } else {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        /*
         * An even modulus is clearly an invalid value for RSA.
         */
        if (((BT == 0x01 ? (privKey.modulus[(short) (privKey.getModulusLength() - 1)])
                : (pubKey.modulus[(short) (pubKey.getModulusLength() - 1)])) & (byte) 0x01) == 0) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        offSet = 0;
        initFlag = true;
    }

    public void init(javacard.security.Key theKey, byte theMode, byte bArray[], short bOff, short bLen)
            throws CryptoException {
        CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
    }

    public short doFinal(byte inBuff[], short inOffset, short inLength, byte outBuff[], short outOffset)
            throws CryptoException {
        short resultLength = (short) 0;

        NativeMethods.sensitiveResultSetTagValUnassigned();
        // doFinal() checks if outOffset >= outBuff.length
        NativeMethods.checkArrayArgs(outBuff, outOffset, (short) 1);

        // update() method checks array args
        update(inBuff, inOffset, inLength, outBuff, outOffset);

        if (encryptFlag) {
            // output buffer must have at least 64 bytes for encryption.
            NativeMethods.checkArrayArgs(outBuff, outOffset, RSA_LEN_512);
            if (BT == (byte) 0x01) {
                PKCS1.RSAES_V15_ENCRYPT(privKey.modulus, privKey.modulusLength, privKey.exponent,
                        privKey.exponentLength, dataCache, offSet, outBuff, outOffset, BT);
            } else {
                PKCS1.RSAES_V15_ENCRYPT(pubKey.modulus, pubKey.modulusLength, pubKey.exponent, pubKey.exponentLength,
                        dataCache, offSet, outBuff, outOffset, BT);
            }
            // for encrypt, return value is a constant
            resultLength = RSA_LEN_512;
        } else {
            /*
            * The output buffer and arguments will be checked by util.ArrayCopy
            * at the end of decrypt, when the results are copied
            * to the outBuff.
            */
            // if we have no data to decrypt at this point, it is an illegal
            // use.
            if (offSet == 0) {
                CryptoException.throwIt(CryptoException.ILLEGAL_USE);
            }
            if (BT == (byte) 0x01) {
                resultLength = PKCS1.RSADS_V15_DECRYPT(privKey.modulus, privKey.modulusLength, privKey.exponent,
                        privKey.exponentLength, dataCache, outBuff, outOffset);

            } else {
                resultLength = PKCS1.RSADS_V15_DECRYPT(pubKey.modulus, pubKey.modulusLength, pubKey.exponent,
                        pubKey.exponentLength, dataCache, outBuff, outOffset);
            }
        }
        if (resultLength < 0) {
            CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        }
        // re-initialize the data cache
        Util.arrayFillNonAtomic(dataCache, (short) 0, offSet, (byte) 0);

        offSet = 0;
        
        NativeMethods.sensitiveResultSet(resultLength);
        return resultLength;
    }

    public short update(byte inBuff[], short inOffset, short inLength, byte outBuff[], short outOffset)
            throws CryptoException {
        NativeMethods.sensitiveResultSetTagValUnassigned();
        if (!initFlag) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }
        if (!(BT == 0x01 ? privKey.isInitialized() : pubKey.isInitialized())) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }

        NativeMethods.checkArrayArgs(inBuff, inOffset, inLength);
        // update method could have zero length output buffer
        NativeMethods.checkArrayArgs(outBuff, outOffset, (short) 0);

        if (inLength == 0) {
            NativeMethods.sensitiveResultSet((short) 0);
            return (short) 0;
        }

        if ((((inLength + offSet) > 53) & encryptFlag) | ((inLength + offSet) > 64)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_USE);
        }

        Util.arrayCopy(inBuff, inOffset, dataCache, offSet, inLength);
        offSet += inLength;

        // the return value is the # of bytes in output buf.
        // For RSA, this is 0

        NativeMethods.sensitiveResultSet((short) 0);
        return 0;
    }

}
