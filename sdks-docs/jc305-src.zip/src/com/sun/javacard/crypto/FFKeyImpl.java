/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */
package com.sun.javacard.crypto;

import com.sun.javacard.impl.NativeMethods;
import javacard.framework.JCSystem;
import javacard.framework.Util;
import javacard.security.CryptoException;
import javacard.security.DHKey;
import javacard.security.KeyBuilder;

/**
 *
 * 
 */
public class FFKeyImpl implements DHKey{
    
    private static final byte P_PARM = (byte) 1;
    private static final byte Q_PARM = (byte) 2;
    private static final byte G_PARM = (byte) 3;
    
    private boolean[] pInitialized;
    private boolean[] qInitialized;
    private boolean[] gInitialized;
    
    protected byte[] keyType;
    protected short[] keyLength;

    byte[] memoryPool;
    protected byte[] P;
    protected byte[] Q;
    protected byte[] G;
    
    protected static final byte MEMORY_POOL_SIZE = (byte) 23;
    protected static final byte ALIGNMENT_SPACE = (byte) 5;
    
    protected static final byte BIGINT_STRUCT_SIZE = (byte) 7;
    

    public void setP(byte[] buffer, short offset, short length) throws CryptoException {
        NativeMethods.checkArrayArgs(buffer, offset, length);
        if(length != (short) (getSize() / 8)){
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
        setFFParameter(buffer, offset, length, P_PARM, P);
        pInitialized[(short)0] = true;
    }

    public void setQ(byte[] buffer, short offset, short length) throws CryptoException {
        NativeMethods.checkArrayArgs(buffer, offset, length);
        if(((keyLength[0] == KeyBuilder.LENGTH_DH_2048) && (length != (short) 32) && (length != 28)) ||
                ((keyLength[0] == KeyBuilder.LENGTH_DH_1024) && (length != (short) 20))){
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
        setFFParameter(buffer, offset, length, Q_PARM, Q);
        keyLength[(short)1] = (short)(length * 8);
        qInitialized[(short)0] = true;
    }

    public void setG(byte[] buffer, short offset, short length) throws CryptoException {
        NativeMethods.checkArrayArgs(buffer, offset, length);
        if(length > (short) (getSize() / 8)){
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
        setFFParameter(buffer, offset, length, G_PARM, G);
        gInitialized[(short)0] = true;
    }

    public short getP(byte[] buffer, short offset) {
        if (pInitialized[(short)0] != true) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }
        NativeMethods.checkArrayArgs(buffer, offset, (short) (getSize() / 8));
        return getFFParameter(buffer, offset, P_PARM);
    }

    public short getQ(byte[] buffer, short offset) {
        if (qInitialized[(short)0] != true) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }
        NativeMethods.checkArrayArgs(buffer, offset, (short) (getActualQSize() / 8));
        return getFFParameter(buffer, offset, Q_PARM);
    }
    
    public short getG(byte[] buffer, short offset) {
        if (gInitialized[(short)0] != true) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }
        NativeMethods.checkArrayArgs(buffer, offset, (short) (getSize() / 8));
        return getFFParameter(buffer, offset, G_PARM);
    }
    
    protected short getSize() {
        return keyLength[(short)0];
    }

    protected byte getType() {
        return keyType[(short)0];
    }

    protected boolean isInitialized() {
        return ((gInitialized[(short)0]) && (pInitialized[(short)0]));
    }

    protected void clearKey() {
        Util.arrayFillNonAtomic(P, (short) 0, (short) P.length, (byte) 0);
        pInitialized[(short)0] = false;
        Util.arrayFillNonAtomic(Q, (short) 0, (short) Q.length, (byte) 0);
        qInitialized[(short)0] = false;
        Util.arrayFillNonAtomic(G, (short) 0, (short) G.length, (byte) 0);
        gInitialized[(short)0] = false;
    }

    /**
     * Method called by ECPrivateKey and ECPublicKey constructor to initialize
     * storage for domain parameters and to set the keyType and Length.
     * 
     * @param type
     *            The type of key
     * @param bitLength
     *            The bit Length of the key.
     */
    protected void initializeDomainStorage(byte type, short bitLength) {
        switch(type){
            case KeyBuilder.TYPE_DH_PRIVATE:
            case KeyBuilder.TYPE_DH_PUBLIC:
                memoryPool = new byte[MEMORY_POOL_SIZE];
                P = new byte[(short) (bitLength / 8 + ALIGNMENT_SPACE + BIGINT_STRUCT_SIZE)];
                Q = new byte[(short) ((bitLength == KeyBuilder.LENGTH_DH_1024 ? 160 : 256) / 8 + ALIGNMENT_SPACE + BIGINT_STRUCT_SIZE)];
                G = new byte[(short) (bitLength / 8 + ALIGNMENT_SPACE + BIGINT_STRUCT_SIZE)];
                keyType = new byte[(short)1];
                keyLength = new short[(short)2];
                pInitialized = new boolean[(short)1];
                qInitialized = new boolean[(short)1];
                gInitialized = new boolean[(short)1];
                break;
                
            case KeyBuilder.TYPE_DH_PRIVATE_TRANSIENT_DESELECT:
            case KeyBuilder.TYPE_DH_PUBLIC_TRANSIENT_DESELECT:
                memoryPool = JCSystem.makeTransientByteArray(MEMORY_POOL_SIZE, JCSystem.MEMORY_TYPE_TRANSIENT_DESELECT);
                P = JCSystem.makeTransientByteArray((short) (bitLength / 8 + ALIGNMENT_SPACE + BIGINT_STRUCT_SIZE), JCSystem.MEMORY_TYPE_TRANSIENT_DESELECT);
                Q = JCSystem.makeTransientByteArray((short) ((bitLength == KeyBuilder.LENGTH_DH_1024 ? 160 : 256) / 8 + ALIGNMENT_SPACE + BIGINT_STRUCT_SIZE), JCSystem.MEMORY_TYPE_TRANSIENT_DESELECT);
                G = JCSystem.makeTransientByteArray((short) (bitLength / 8 + ALIGNMENT_SPACE + BIGINT_STRUCT_SIZE), JCSystem.MEMORY_TYPE_TRANSIENT_DESELECT);
                keyType = JCSystem.makeTransientByteArray((short)1, JCSystem.MEMORY_TYPE_TRANSIENT_DESELECT);
                keyLength = JCSystem.makeTransientShortArray((short)2, JCSystem.MEMORY_TYPE_TRANSIENT_DESELECT);
                pInitialized = JCSystem.makeTransientBooleanArray((short)1, JCSystem.MEMORY_TYPE_TRANSIENT_DESELECT);
                qInitialized = JCSystem.makeTransientBooleanArray((short)1, JCSystem.MEMORY_TYPE_TRANSIENT_DESELECT);
                gInitialized = JCSystem.makeTransientBooleanArray((short)1, JCSystem.MEMORY_TYPE_TRANSIENT_DESELECT);
                break;
                
            case KeyBuilder.TYPE_DH_PRIVATE_TRANSIENT_RESET:
            case KeyBuilder.TYPE_DH_PUBLIC_TRANSIENT_RESET:
                memoryPool = JCSystem.makeTransientByteArray(MEMORY_POOL_SIZE, JCSystem.MEMORY_TYPE_TRANSIENT_RESET);
                P = JCSystem.makeTransientByteArray((short) (bitLength / 8 + ALIGNMENT_SPACE + BIGINT_STRUCT_SIZE), JCSystem.MEMORY_TYPE_TRANSIENT_RESET);
                Q = JCSystem.makeTransientByteArray((short) ((bitLength == KeyBuilder.LENGTH_DH_1024 ? 160 : 256) / 8 + ALIGNMENT_SPACE + BIGINT_STRUCT_SIZE), JCSystem.MEMORY_TYPE_TRANSIENT_RESET);
                G = JCSystem.makeTransientByteArray((short) (bitLength / 8 + ALIGNMENT_SPACE + BIGINT_STRUCT_SIZE), JCSystem.MEMORY_TYPE_TRANSIENT_RESET);
                keyType = JCSystem.makeTransientByteArray((short)1, JCSystem.MEMORY_TYPE_TRANSIENT_RESET);
                keyLength = JCSystem.makeTransientShortArray((short)2, JCSystem.MEMORY_TYPE_TRANSIENT_RESET);
                pInitialized = JCSystem.makeTransientBooleanArray((short)1, JCSystem.MEMORY_TYPE_TRANSIENT_RESET);
                qInitialized = JCSystem.makeTransientBooleanArray((short)1, JCSystem.MEMORY_TYPE_TRANSIENT_RESET);
                gInitialized = JCSystem.makeTransientBooleanArray((short)1, JCSystem.MEMORY_TYPE_TRANSIENT_RESET);
                break; 
                
            default:
                break;
        }
        keyLength[(short)0] = bitLength;
        keyType[(short)0] = type;
    }

    /**
     * Private utility method used to do the work for all of the "set" methods
     * above.
     * 
     * @param buffer
     *            the value to set.
     * @param offset
     *            the offset where the value starts.
     * @param length
     *            the length of the value.
     * @param parameterType
     *            The type of parameter.
     * @param memoryPool2
     *            The storage for the value in the internal domain parameter
     *            structure.
     */
    private void setFFParameter(byte[] buffer, short offset, short length, byte parameterType, byte[] memoryPool2)
            throws CryptoException {
        
        if(length == 0){
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        if (!SecurityNativeMethods.setFFDomainParameter(isPersistent(), buffer, offset, length, parameterType, memoryPool, memoryPool2)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
    }

    /**
     * Private utility method used to do the work for all of the "get" methods
     * above.
     * 
     * @param buffer
     *            The buffer where the requested value is returned.
     * @param offset
     *            The offset were the value is to be placed in the buffer.
     * @param parameterType
     *            The type of parameter that is to be returned.
     * @return the length of the returned value.
     */
    private short getFFParameter(byte[] buffer, short offset, byte parameterType) throws CryptoException {
        return SecurityNativeMethods.getFFDomainParameter(parameterType, memoryPool, buffer, offset);
    }
    
    protected short isPersistent(){
        switch(keyType[(short)0]){
            case KeyBuilder.TYPE_DH_PRIVATE:
            case KeyBuilder.TYPE_DH_PUBLIC:
                return (short)1;
            default:
                return (short)0;
        }
    }
    
    protected short getMaxQSize(){
        switch(keyLength[0]){
            case KeyBuilder.LENGTH_DH_1024:
                return (short)160;
            case KeyBuilder.LENGTH_DH_2048:
                return (short)256;
            default:
                return (short)0;
        }
    }
    
    protected short getActualQSize(){
        return keyLength[(short)1];
    }
    
}
