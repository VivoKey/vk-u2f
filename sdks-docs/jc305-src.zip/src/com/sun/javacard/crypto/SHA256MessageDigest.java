/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
// #ifdef_Target32Bit_
package com.sun.javacard.crypto;

import javacard.framework.JCSystem;
import javacard.framework.Util;
import javacard.security.CryptoException;

import com.sun.javacard.impl.NativeMethods;

/**
 * Class SHA256MessageDigest provides an API to compute SHA256 Message Digest
 * Please refer to the FIPS 180-1 document for more information on SHA-256
 * algorithm - http://www.itl.nist.gov/fipspubs/fip180-1.htm
 */

public class SHA256MessageDigest extends MessageDigest {
    // SHA works on 64 byte blocks of data
    private static final short BLOCK_SIZE = 64;
    private boolean[] initial_status;

    /* Used to ensure data is sent to the Hash module in whole blocks on
     *  update 64 * 8 = 512 bits
     */
    private CircularQueue circular;

    private static byte[] original_digest;

    /* 
     * Hardcoded to length 32 bytes as we know that digest length = 32
     */
    private byte[] digest;

    /*
     * If we have local variables like, short totalInLength, they become 
     * part of a transaction when called in the midst of say, an applet's
     * transaction.  JC Spec says that update() should not be part of a 
     * transaction and hence we create a byte array in transient deselect
     * space.
     */
    private short[] totalInLength; // Total length of input data

    public SHA256MessageDigest(byte algorithm) throws CryptoException {
        super(ALG_SHA_256);
        /* NOTE: 
         * Need to do a new instance of digest here for each instance of 
         * this class.  This variable cannot be shared accross instances.  
         *
         */
        digest = JCSystem.makeTransientByteArray(javacard.security.MessageDigest.LENGTH_SHA_256,
                JCSystem.CLEAR_ON_DESELECT);

        initial_status = JCSystem.makeTransientBooleanArray((short) 1, JCSystem.CLEAR_ON_DESELECT);
        // Input data length can be upto 64 bytes hence the array size
        totalInLength = JCSystem.makeTransientShortArray((short) 4, JCSystem.CLEAR_ON_DESELECT);

        circular = new CircularQueue(BLOCK_SIZE);

        /* Call reset to reset any stale references; 
         * especially useful after tears
         */
        reset();

    }

    /**
     * Where initializedDigest contains the intermediate hash result at offset
     * initializedDigestOffset and for length initializedMessageDigestLength;
     * and msgLength contains the # of bytes of the message hashed thus far
     * starting offset msgLengthOffset with length msgLengthLength. The size of
     * InitializedMessageDigest and the maximum number of message bytes that can
     * processed by a message digest algorithm are specific to each individual
     * algorithm. Note: setInitialDigest can only be invoked prior to invoking
     * update. If the update method has already been invoked, the reset method
     * or doFinal must be invoked before calling setInitialDigest.
     * 
     * @param initializedMessageDigest
     *            contains the intermediate hash result
     * @param initializedDigestOffset
     *            offset into initializedDigest array where data begins
     * @param initializedDigestLength
     *            the length of data in initializedDigest array.
     * @param msgLength
     *            the array containing the number of bytes of data already
     *            digested in the initializedDigest passed in.
     * @param msgLengthOffset
     *            the offset into the msgLength array where length data begins.
     * @param msgLengthLength
     *            the length of data in msgLength array.
     * @throws CryptoException.ILLEGAL_USE
     *             if the method is called after calls to update() and before
     *             object state resets.
     */

    public void setInitialDigest(byte[] initializedDigest, short initializedDigestOffset,
            short initializedDigestLength, byte[] msgLength, short msgLengthOffset, short msgLengthLength)
            throws CryptoException {

        NativeMethods.checkArrayArgs(initializedDigest, initializedDigestOffset,
                javacard.security.MessageDigest.LENGTH_SHA_256);

        // if initialDigestLength !=32 exception
        if (initializedDigestLength != javacard.security.MessageDigest.LENGTH_SHA_256) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        // verify that length of data digest so far is multiple of 64 bytes
        if (((short) (msgLength[(short) (msgLengthOffset + msgLengthLength - 1)] & (short) 0x3F) != (short) 0)) {
            // last six bits are not 0. => not a multiple of 64 bytes.
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
        // verify that the number of bytes of data digest so far is not 0
        boolean zero = true;
        for (short i = msgLengthOffset; i < (short) (msgLengthOffset + msgLengthLength); i++) {
            if (msgLength[i] != (byte) 0) {
                zero = false;
                break;
            }

        }
        if (zero) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        if (!below2power61(msgLength, msgLengthOffset, msgLengthLength)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        // use the initialized message digest as the initial digest for the
        // remaining message
        Util.arrayCopyNonAtomic(initializedDigest, initializedDigestOffset, digest, (short) 0, initializedDigestLength);

        // reverse the order of bytes since for our calculation, element 0 is
        // least significant byte.
        short i = 0, j = 0;
        for (i = (short) (msgLengthLength - 1), j = (short) 0; (short) (i - 1) >= (short) 0; i -= (short) 2, j++) {
            // last byte of short
            totalInLength[j] = (msgLength[(short) (i - 1)]);
            totalInLength[j] = (short) (totalInLength[j] << (short) 8);
            totalInLength[j] |= (short) (msgLength[i] & (short) 0x00FF);
            // first byte of short
        }
        if (i == (short) 0) {
            // last byte left. capture in new short
            totalInLength[j] = (short) (msgLength[i] & (short) 0x00FF);
        }
    }

    /*
     * doFinal(byte[], short, short, byte[], short) 
     * Generates a hash of all/last input data. Completes and returns the hash computation after performing final
     * operations such as padding. The MessageDigest object is reset to the initial state after this call is made.
     * The input and output buffer data may overlap.
     * Parameters:
     *   @param inBuff - the input buffer of data to be hashed
     *   @param inOffset - the offset into the input buffer at which to begin hash generation
     *   @param inLength - the byte length to hash
     *   @param outBuff - the output buffer, may be the same as the input buffer
     *
     */
    public short doFinal(byte[] inBuff, short inOffset, short inLength, byte[] outBuff, short outOffset) {
        NativeMethods.sensitiveResultSetTagValUnassigned();
        
        NativeMethods.checkArrayArgs(inBuff, inOffset, inLength);
        NativeMethods.checkArrayArgs(outBuff, outOffset, javacard.security.MessageDigest.LENGTH_SHA_256);

        if (!(initial_status[0])) {
            reset();
        }

        short length = inLength;
        short i = inOffset;

        while (length > 0) {
            // Fill up the queue and send it for update
            circular.queuePut(inBuff[i]);
            i++;
            length--;
            /*
             * We only want to update on the queue if there is
             * still input data, otherwise we must doFinal 
             */
            if (BLOCK_SIZE == circular.getCount()) {
                computeBlock(circular);
            }
        }

        com.sun.javacard.crypto.MessageDigest.addToArray(totalInLength, inLength);

        // Padding and store

        /* first add 1 to the byte array*/
        if (circular.getCount() < 56) {
            circular.queuePut((byte) 0x80);
            // Pad 0's till we reach 448
            while (circular.getCount() < 56) {
                circular.queuePut((byte) 0x00);
            }
            /*
             * append message data Length to the data for the last 8 bytes
             */

            com.sun.javacard.crypto.MessageDigest.leftShiftThree(totalInLength);
            for (short j = (short) (totalInLength.length - 1); j >= (short) 0; j--) {
                circular.queuePut((byte) (totalInLength[j] >> (short) 8));
                circular.queuePut((byte) (totalInLength[j]));
            }

            computeBlock(circular);
            Util.arrayCopy(digest, (short) 0, outBuff, outOffset, (short) digest.length);

        }

        /* 
         * Corner Case - if message length =448 bits or 56 bytes, 
         * when we add 1 bit or 0x80 byte to it the total length is  
         * now 449 or rounding it to the next byte, 57 bytes so we add
         * 511 0's or 63 bytes and then compute digest for each block.
         * 
         *  else ((circular.getCount() > 55) && (circular.getCount() < 64))
         */

        else {
            /*
             * the last 2 words which are reserved for length now have the
             * 0x8000 0000 0000 0000 padding
             */
            circular.queuePut((byte) 0x80);
            for (short j = 0; circular.getCount() < 64; j++) {
                circular.queuePut((byte) 0x00);
            }
            computeBlock(circular);
            Util.arrayCopy(digest, (short) 0, outBuff, outOffset, (short) digest.length);

            circular.clearQueue();
            while (circular.getCount() < 56) {
                circular.queuePut((byte) 0x00);
            }
            /*
             * append message data Length to the data for the last 8 bytes
             */
            com.sun.javacard.crypto.MessageDigest.leftShiftThree(totalInLength);
            for (short j = (short) (totalInLength.length - 1); j >= (short) 0; j--) {
                circular.queuePut((byte) (totalInLength[j] >> (short) 8));
                circular.queuePut((byte) (totalInLength[j]));
            }
            computeBlock(circular);

            Util.arrayCopy(digest, (short) 0, outBuff, outOffset, (short) digest.length);
        }

        reset();
        
        NativeMethods.sensitiveResultSet((short) digest.length);
        return (short) digest.length;
    }

    /*
     *update(byte[], short, short) 
     *  Accumulates a hash of the input data. This method requires temporary storage of intermediate results. In
     *  addition, if the input data length is not block aligned (multiple of block size) then additional internal storage
     *  may be allocated at this time to store a partial input data block. This may result in additional resource
     *  consumption and/or slow performance. This method should only be used if all the input data required for
     *  the hash is not available in one byte array. If all of the input data required for the hash is located in a single
     *  byte array, use of the doFinal() method is recommended. The doFinal() method must be called to
     *  complete processing of input data accumulated by one or more calls to the update() method.
     *  @param inBuff - the input buffer of data to be hashed
     *  @param inOffset - the offset into the input buffer at which to begin hash generation
     *  @param inLength - the byte length to hash
     */
    public void update(byte[] inBuff, short inOffset, short inLength) {
        if (inLength == 0) {
            return;
        }

        NativeMethods.checkArrayArgs(inBuff, inOffset, inLength);

        if (!(initial_status[0])) {
            reset();
        }

        for (short i = 0; i < inLength; i++) {
            // Fill up the queue and send it for update
            circular.queuePut(inBuff[(short) (inOffset + i)]);
            if (BLOCK_SIZE == circular.getCount()) {
                computeBlock(circular);
            }

        }
        com.sun.javacard.crypto.MessageDigest.addToArray(totalInLength, inLength);
    }

    /*
     *  Computes SHA256 for one Block (64 bytes) of data
     */
    protected void computeBlock(CircularQueue cq) {
        SecurityNativeMethods.computeSHA256Block(cq.circular, digest);
        circular.clearQueue();
    }

    /*
     *getLength()
     * Returns the byte length of the hash.
     */
    public byte getLength() {
        return javacard.security.MessageDigest.LENGTH_SHA_256;
    }

    /*
     *reset()
     * Resets the MessageDigest object to the initial state for further use.
     */

    public void reset() {

        for (short i = 0; i < totalInLength.length; i++) {
            totalInLength[i] = (short) 0;
        }

        circular.clearQueue();

        Util.arrayCopyNonAtomic(original_digest, (short) 0, digest, (short) 0,
                javacard.security.MessageDigest.LENGTH_SHA_256);

        initial_status[0] = true;

    }

    // Called once in card lifetime in cardInit().
    public static void init() {
        original_digest = new byte[] { (byte) 0x6a, (byte) 0x09, (byte) 0xe6, (byte) 0x67, (byte) 0xbb, (byte) 0x67,
                (byte) 0xae, (byte) 0x85, (byte) 0x3c, (byte) 0x6e, (byte) 0xf3, (byte) 0x72, (byte) 0xa5, (byte) 0x4f,
                (byte) 0xf5, (byte) 0x3a, (byte) 0x51, (byte) 0x0e, (byte) 0x52, (byte) 0x7f, (byte) 0x9b, (byte) 0x05,
                (byte) 0x68, (byte) 0x8c, (byte) 0x1f, (byte) 0x83, (byte) 0xd9, (byte) 0xab, (byte) 0x5b, (byte) 0xe0,
                (byte) 0xcd, (byte) 0x19 };
        NativeMethods.setJCREentry(original_digest, false);
    }

}
// #endif_Target32Bit_

