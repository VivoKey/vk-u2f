/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

import javacard.security.CryptoException;

/**
 * When KeyBuilder.buildKey is called with keyEncryption = true, it must provide
 * a version of the specified key that implements the KeyEncryption interface.
 * This class is the version of DESKeyImpl that implements KeyEncryption
 */
public class DESKeyEncryption extends com.sun.javacard.crypto.DESKeyImpl implements javacardx.crypto.KeyEncryption {
    /*
    * The CipherInternal object that will be used to decrypt key parameters in 
    * 'set' methods
    */
    protected CipherInternal keyDecryptionCipher = null;

    public DESKeyEncryption(byte type, short bitLength) {
        super(type, bitLength);
    }

    public void setKey(byte[] keyData, short kOff) {
        /*  
        *  If the keyDecryptionCipher is not null, first decrypt the data 
        *  at the appropriate offset in the buffer holds keyData after 
        *  decryption. We initialize it to keyData in case the decryption
        *  cipher is null
        */
        if (keyDecryptionCipher != null) {

            short dataLength = keyDecryptionCipher.getEncryptedLength((short)(this.getSize()/8));
            /* If we don't do this here, doFinal will throw a 
            * ArrayIndexOutOfBoundsException, a runtime exception
            * and we catch only CryptoException.
            * This check helps in Specification compliance.
            */
            if ((short) (keyData.length - kOff) < dataLength) {
                CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
            }

            try {
                keyDecryptionCipher.doFinal(keyData, kOff, dataLength, data, (short) 0);
            } catch (CryptoException e) {
                // rethrow as correct error type for bad decrypted data
                CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
            }
            // now do the actual set operation
            super.setKey(data, (short) 0);
        } else {
            // now do the actual set operation
            super.setKey(keyData, kOff);
        }
    }

    public javacardx.crypto.Cipher getKeyCipher() {
        return keyDecryptionCipher;
    }

    public void setKeyCipher(javacardx.crypto.Cipher keyCipher) {
        keyDecryptionCipher = (com.sun.javacard.crypto.CipherInternal) keyCipher;
    }
}// end class
