/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

import javacard.framework.Util;
import javacard.security.CryptoException;
import javacard.security.KeyBuilder;
import javacard.security.KeyPair;
import javacard.security.PrivateKey;
import javacard.security.PublicKey;

/**
 * This class is a container for an EC key pair (a public key and a private
 * key).
 * <p>
 * In addition, this class features a key generation method.
 * 
 * @see PublicKey
 * @see PrivateKey
 */
public final class RSAKeyPair implements KeyPairInterfaceInternal {

    private PrivateKey privateKey;
    private PublicKey publicKey;
    private byte[] pub_mod;
    private byte[] pub_exp;
    private byte[] priv_exp;
    private byte[] theSeed;
    private static byte startingSeedValue = 0;
    private static final short PUB_MOD_LEN = 64;
    private short pub_exp_len;
    private short priv_exp_len;

    /**
     * Returns a reference to the public key component of this
     * <code>KeyPair</code> object.
     * 
     * @return a reference to the public key.
     */
    public PublicKey getPublic() {
        return publicKey;
    }

    /**
     * Returns a reference to the private key component of this
     * <code>KeyPair</code> object.
     * 
     * @return a reference to the private key.
     */
    public PrivateKey getPrivate() {
        return privateKey;
    }

    public RSAKeyPair(PublicKey public_key, PrivateKey private_key) throws CryptoException {

        keyStorageInit();
        switch (public_key.getType()) {
            case KeyBuilder.TYPE_RSA_PUBLIC:
                if (private_key.getType() == KeyBuilder.TYPE_RSA_PRIVATE) {
                    publicKey = public_key;
                    privateKey = private_key;
                } else {
                    CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
                }
                break;

            default:
                CryptoException.throwIt(CryptoException.NO_SUCH_ALGORITHM);
        }

    }

    public RSAKeyPair(byte algorithm, short keyLength) throws CryptoException {
        keyStorageInit();
        switch (algorithm) {
            case KeyPair.ALG_RSA:
                if (keyLength != KeyBuilder.LENGTH_RSA_512) {
                    CryptoException.throwIt(CryptoException.NO_SUCH_ALGORITHM);
                }

                privateKey = new com.sun.javacard.crypto.RSAPrivateKeyImpl(KeyBuilder.TYPE_RSA_PRIVATE,
                        KeyBuilder.LENGTH_RSA_512);

                publicKey = new com.sun.javacard.crypto.RSAPublicKeyImpl(KeyBuilder.TYPE_RSA_PUBLIC,
                        KeyBuilder.LENGTH_RSA_512);
                break;
            default:
                CryptoException.throwIt(CryptoException.NO_SUCH_ALGORITHM);
                break;
        }

    }

    public final void genKeyPair() throws CryptoException {
        byte pub_type = publicKey.getType();
        short pub_len = privateKey.getSize();
        byte priv_type = privateKey.getType();

        if ((pub_type == KeyBuilder.TYPE_RSA_PUBLIC) && (priv_type == KeyBuilder.TYPE_RSA_PRIVATE)) {
            if (pub_len == KeyBuilder.LENGTH_RSA_512) {
                try {
                    RSAPublicKeyImpl k = (RSAPublicKeyImpl) publicKey;
                    pub_exp_len = k.getExponent(pub_exp, (short) 0);
                } catch (CryptoException ce) {
                    pub_exp[0] = (byte) 0x01;
                    pub_exp[1] = (byte) 0x00;
                    pub_exp[2] = (byte) 0x01;
                    pub_exp_len = 3;
                }
                priv_exp_len = SecurityNativeMethods.generateRSAKeyData(pub_mod, PUB_MOD_LEN, pub_exp, pub_exp_len,
                        priv_exp, theSeed);

                ((RSAPublicKeyImpl) publicKey).setModulus(pub_mod, (short) 0, PUB_MOD_LEN);
                ((RSAPublicKeyImpl) publicKey).setExponent(pub_exp, (short) 0, pub_exp_len);

                // private modulus and public modulus data are the same
                ((RSAPrivateKeyImpl) privateKey).setModulus(pub_mod, (short) 0, PUB_MOD_LEN);
                ((RSAPrivateKeyImpl) privateKey).setExponent(priv_exp, (short) 0, priv_exp_len);
                Util.arrayFillNonAtomic(pub_exp, (short) 0, (short) pub_exp.length, (byte) 0);
                Util.arrayFillNonAtomic(pub_mod, (short) 0, (short) pub_mod.length, (byte) 0);
                Util.arrayFillNonAtomic(priv_exp, (short) 0, (short) priv_exp.length, (byte) 0);

            } else {
                // Alg len not supported
                CryptoException.throwIt(CryptoException.NO_SUCH_ALGORITHM);
            }
        } else {
            // Alg not of type RSA and not supported.
            CryptoException.throwIt(CryptoException.NO_SUCH_ALGORITHM);
        }

    }

    // Called once at instantiation.
    private void keyStorageInit() {

        pub_mod = new byte[64];
        pub_exp = new byte[64];
        priv_exp = new byte[64];
        theSeed = new byte[8];
        theSeed[0] = (byte) ((byte) 0x01 | startingSeedValue);
        theSeed[1] = (byte) ((byte) 0x02 | startingSeedValue);
        theSeed[2] = (byte) ((byte) 0x03 | startingSeedValue);
        theSeed[3] = (byte) ((byte) 0x04 | startingSeedValue);
        theSeed[4] = (byte) ((byte) 0x05 | startingSeedValue);
        theSeed[5] = (byte) ((byte) 0x06 | startingSeedValue);
        theSeed[6] = (byte) ((byte) 0x07 | startingSeedValue);
        theSeed[7] = (byte) ((byte) 0x08 | startingSeedValue);
        startingSeedValue += 1;
    }

}
