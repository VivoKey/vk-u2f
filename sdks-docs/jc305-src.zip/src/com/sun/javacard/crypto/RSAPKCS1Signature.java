/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

import javacard.framework.JCSystem;
import javacard.framework.Util;
import javacard.security.CryptoException;

import com.sun.javacard.impl.NativeMethods;

public class RSAPKCS1Signature extends com.sun.javacard.crypto.SignatureInternal {
    private javacard.security.InitializedMessageDigest messageDigest;
    private byte[] DigestBuff;
    private boolean initFlag;
    private RSAPrivateKeyImpl privKey;
    private RSAPublicKeyImpl pubKey;
    private byte mode;
    private static final short RSA_LEN_512 = (short) 64;

    public RSAPKCS1Signature(byte algorithm, byte messageDigestAlgorithm, byte cipherAlgorithm, byte paddingAlgorithm) {
        super(algorithm, messageDigestAlgorithm, cipherAlgorithm, paddingAlgorithm);
        DigestBuff = JCSystem.makeTransientByteArray((short) 20, JCSystem.CLEAR_ON_DESELECT);
        messageDigest = javacard.security.MessageDigest.getInitializedMessageDigestInstance(javacard.security.MessageDigest.ALG_SHA, false);
    }

    /*
     * Note: this implementation assumes a key length of no more than 512 bits. 
     */

    public void init(javacard.security.Key theKey, byte theMode) throws CryptoException {
        if ((theMode == MODE_SIGN) && (theKey instanceof com.sun.javacard.crypto.RSAPrivateKeyImpl)) {
            mode = MODE_SIGN;
            privKey = (com.sun.javacard.crypto.RSAPrivateKeyImpl) theKey;
        } else if ((theMode == MODE_VERIFY) && (theKey instanceof com.sun.javacard.crypto.RSAPublicKeyImpl)) {
            mode = MODE_VERIFY;
            pubKey = (com.sun.javacard.crypto.RSAPublicKeyImpl) theKey;
        } else {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        /*
         * An even modulus is clearly an invalid value for RSA.
         */
        if (((mode == MODE_SIGN ? (privKey.modulus[(short) (privKey.getModulusLength() - 1)])
                : (pubKey.modulus[(short) (pubKey.getModulusLength() - 1)])) & (byte) 0x01) == 0) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        messageDigest.reset();

        initFlag = true;
    }

    public void init(javacard.security.Key theKey, byte theMode, byte[] bArray, short bOff, short bLen)
            throws CryptoException {
        CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
    }

    public void setInitialDigest(byte[] initialDigestBuf, short initialDigestOffset,
            short initialDigestLength, byte[] digestedMsgLenBuf, short digestedMsgLenOffset, short digestedMsgLenLength)
            throws CryptoException{
        messageDigest.setInitialDigest( initialDigestBuf, initialDigestOffset,
                initialDigestLength, digestedMsgLenBuf, digestedMsgLenOffset,
                digestedMsgLenLength);
    }

    public short getLength() {
        if (!initFlag) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }
        return RSA_LEN_512;
    }

    public void update(byte[] inBuff, short inOff, short inLen) throws CryptoException {
        if (inLen == 0) {
            return;
        }
        if (!initFlag) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }

        if (!(mode == MODE_SIGN ? privKey.isInitialized() : pubKey.isInitialized())) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }
        /*
         * Input array bounds checking is not done as MessageDigest.update
         * does the same thing.
         */
        messageDigest.update(inBuff, inOff, inLen);
    }

    public short sign(byte[] inBuff, short inOff, short inLen, byte[] sigBuff, short sigOff) throws CryptoException {
        NativeMethods.sensitiveResultSetTagValUnassigned();
        if (!initFlag) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }
        if (mode == MODE_SIGN) {
            if (!privKey.isInitialized()) {
                CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
            }

            /**
             * Checking array bounds to throw the right kind of exception Input
             * array bounds checking is not done as MessageDigest.doFinal does
             * the same thing.
             */

            NativeMethods.checkArrayArgs(sigBuff, sigOff, RSA_LEN_512);
            messageDigest.doFinal(inBuff, inOff, inLen, DigestBuff, (short) 0);

            PKCS1.RSASA_V15_SIGN(privKey.modulus, privKey.modulusLength, privKey.exponent, privKey.exponentLength,
                    DigestBuff, sigBuff, sigOff);
        } else {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }
        messageDigest.reset();

        NativeMethods.sensitiveResultSet(RSA_LEN_512);
        // for sign, return value is a constant
        return RSA_LEN_512;
    }

    public short signPreComputedHash(byte[] hashBuf, short hashOff, short hashLength, byte[] sigBuff, short sigOffset){
        NativeMethods.sensitiveResultSetTagValUnassigned();
        
        if (!initFlag) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }
        if (mode == MODE_SIGN) {
            if (!privKey.isInitialized()) {
                CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
            }

            NativeMethods.checkArrayArgs(hashBuf, hashOff, hashLength);

            if (hashLength != messageDigest.getLength()){
                CryptoException.throwIt(CryptoException.ILLEGAL_USE);
            }

            NativeMethods.checkArrayArgs(sigBuff, sigOffset, RSA_LEN_512);

            Util.arrayCopy(hashBuf, hashOff,  DigestBuff, (short) 0, hashLength);

            PKCS1.RSASA_V15_SIGN(privKey.modulus, privKey.modulusLength, privKey.exponent, privKey.exponentLength,
                    DigestBuff, sigBuff, sigOffset);
        } else {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }
        messageDigest.reset();

        NativeMethods.sensitiveResultSet(RSA_LEN_512);
        // for sign, return value is a constant
        return RSA_LEN_512;
    }
    
    public boolean verifyPreComputedHash(byte[] hashBuff, short hashOffset, short hashLength, byte[] sigBuff, short sigOffset,
            short sigLength) throws CryptoException{
        NativeMethods.sensitiveResultSetTagValUnassigned();
        
        if (!initFlag) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }
        boolean verified = false;
        if (mode == MODE_VERIFY) {
            if (!pubKey.isInitialized()) {
                CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
            }
            /**
             * Checking array bounds to throw the right kind of exception Input
             * array bounds checking is not done as MessageDigest.doFinal does
             * the same thing.
             */
            NativeMethods.checkArrayArgs(hashBuff, hashOffset, hashLength);

            if (hashLength != messageDigest.getLength()){
                CryptoException.throwIt(CryptoException.ILLEGAL_USE);
            }
            
            NativeMethods.checkArrayArgs(sigBuff, sigOffset, RSA_LEN_512);
            
            Util.arrayCopy(hashBuff, hashOffset,  DigestBuff, (short) 0, hashLength);

            // note: in PKCS1 V2.0, sigBuff, sigOff, sigLen is equivalent to S
            verified = PKCS1.RSASA_V15_VERIFY(pubKey.modulus, pubKey.modulusLength, pubKey.exponent,
                    pubKey.exponentLength, DigestBuff, sigBuff, sigOffset, sigLength);
        } else {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }
        messageDigest.reset();
        
        if (verified)
            NativeMethods.sensitiveResultSetBooleanTrue();
        else
            NativeMethods.sensitiveResultSetBooleanFalse();
        return verified;
    }
    

    public boolean verify(byte[] inBuff, short inOff, short inLen, byte[] sigBuff, short sigOff, short sigLen)
            throws CryptoException {
        
        NativeMethods.sensitiveResultSetTagValUnassigned();
        
        if (!initFlag) {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }
        boolean verified = false;
        if (mode == MODE_VERIFY) {
            if (!pubKey.isInitialized()) {
                CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
            }
            /**
             * Checking array bounds to throw the right kind of exception Input
             * array bounds checking is not done as MessageDigest.doFinal does
             * the same thing.
             */
            NativeMethods.checkArrayArgs(sigBuff, sigOff, sigLen);

            messageDigest.doFinal(inBuff, inOff, inLen, DigestBuff, (short) 0);

            // note: in PKCS1 V2.0, sigBuff, sigOff, sigLen is equivalent to S
            verified = PKCS1.RSASA_V15_VERIFY(pubKey.modulus, pubKey.modulusLength, pubKey.exponent,
                    pubKey.exponentLength, DigestBuff, sigBuff, sigOff, sigLen);
        } else {
            CryptoException.throwIt(CryptoException.INVALID_INIT);
        }
        messageDigest.reset();
        
        if (verified)
            NativeMethods.sensitiveResultSetBooleanTrue();
        else
            NativeMethods.sensitiveResultSetBooleanFalse();
        return verified;
    }

}
