/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

public abstract class CipherInternal extends javacardx.crypto.Cipher {
    private byte algorithm;
    private final byte cipherAlgorithm;
    private final byte paddingAlgorithm;

    public CipherInternal(byte algorithm, byte cipherAlgorithm, byte paddingAlgorithm) {
        this.algorithm = algorithm;
        this.cipherAlgorithm = cipherAlgorithm;
        this.paddingAlgorithm = paddingAlgorithm;
    }

    public byte getAlgorithm() {
        return algorithm;
    }

    public byte getCipherAlgorithm() {
        return cipherAlgorithm;
    }

    public byte getPaddingAlgorithm() {
        return paddingAlgorithm;
    }

    public abstract short getEncryptedLength( short plainLength);

}
