/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
// #ifdef_Target32Bit_
package com.sun.javacard.crypto;

import javacard.framework.Util;
import javacard.security.CryptoException;
import javacard.security.KeyBuilder;

import com.sun.javacard.impl.NativeMethods;

public class AES128CBCCipher extends AESCipher {

    static byte[] defaultIV;    

    public AES128CBCCipher(byte algorithm, byte cipherAlgorithm, byte paddingAlgorithm) {
        super(algorithm, cipherAlgorithm, paddingAlgorithm);
    }

    public void init(javacard.security.Key theKey, byte theMode) throws CryptoException {
        init(theKey, theMode, defaultIV, (short) 0, (short) defaultIV.length);
    }

    public void init(javacard.security.Key theKey, byte theMode, byte bArray[], short bOff, short bLen)
            throws CryptoException {
        if (bLen != AES_128_BLOCK_SIZE) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        Util.arrayCopy(bArray, bOff, intermediateOutput, (short) 0, AES_128_BLOCK_SIZE);
        super.init(theKey, theMode);
    }

    /**
     * Resets the Cipher to post init state
     */
    protected void resetIV() {
        Util.arrayCopy(defaultIV, (short) 0, intermediateOutput, (short) 0, AES_128_BLOCK_SIZE);
    }

    // Called once in card lifetime by cardInit().
    public static void initIV() {
        byte[] dIV = { (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
                (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
                (byte) 0x00 };
        /* default IV is allocated in COD memory.  You can only
         * initialize an array when your are defining it
         * ex.  byte [] b = {1, 2, 3}
         * you cannot do byte[] b = new byte[3];
         * then say b = {1,2,3}
         * hence the below code.
         */
        defaultIV = dIV;
        NativeMethods.setJCREentry(defaultIV, false);
    }

    protected void cipherQueue(CircularQueue queue, byte[] outBuff, short outOffset) {
        if (data == null) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }
        if (queue == null) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        /* We need to do this as a deselect or tear event will clear the 
         * the keyLength variable.  If akey is of type persistant, then
         * the key will be initialized, but, cipher.doFinal will fail w/o 
         * this after deselect.
         */
        Util.setShort(keyLength, (short) 0, akey.getSize());

        switch (Util.getShort(keyLength, (short) 0)) {
            case KeyBuilder.LENGTH_AES_128:
                if (mode[0] == MODE_ENCRYPT) {

                    /* as we are doing CBC, we need to XOR the data with the 
                     * intermediate output
                     */
                    queue.xorWith(intermediateOutput);
                    for (short i = 0; i < AES_128_BLOCK_SIZE; i++) {
                        data[i] = queue.queueGet();
                    }
                    super.cipherQueue(queue, outBuff, outOffset);
                    // copy the output into outBuff
                    NativeMethods.arrayCopyNonAtomicForSensitiveArrays(intermediateOutput, (short) 0, outBuff, outOffset, AES_128_BLOCK_SIZE);
                    queue.clearQueue();

                } else {// if (mode == MODE_DECRYPT) {
                    for (short i = 0; i < AES_128_BLOCK_SIZE; i++) {
                        data[i] = queue.queueGet();
                    }
                    /* before decrypting, save the intermediate state to the queue 
                     * buffer which is used a scratch space.  We know that 
                     * CircularQueue cannot have any useful data at this time.  
                     * This is done for CBC purposes.
                     */
                    for (short i = 0; i < AES_128_BLOCK_SIZE; i++) {
                        queue.queuePut(intermediateOutput[i]);
                    }
                    super.cipherQueue(queue, outBuff, outOffset);
                    // after decrypting, xor with holdData
                    queue.xorWith(intermediateOutput);

                    for (short i = 0; i < AES_128_BLOCK_SIZE; i++) {
                        intermediateOutput[i] = queue.queueGet();
                    }

                    // copy the output into outBuff
                    NativeMethods.arrayCopyNonAtomicForSensitiveArrays(intermediateOutput, (short) 0, outBuff, outOffset, AES_128_BLOCK_SIZE);
                    Util.arrayCopyNonAtomic(data, (short) 0, intermediateOutput, (short) 0, AES_128_BLOCK_SIZE);
                    queue.clearQueue();

                }
                break;
                
            default:
                break;
        }
    }
}
// #endif_Target32Bit_
