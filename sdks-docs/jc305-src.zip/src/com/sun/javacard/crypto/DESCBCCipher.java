/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.crypto;

import javacard.framework.JCSystem;
import javacard.framework.Util;
import javacard.security.CryptoException;

import com.sun.javacard.impl.NativeMethods;

public class DESCBCCipher extends DESCipher {
    private byte[] chainingBlock;
    private byte[] holdChainingBlock;
    static byte[] defaultIV;

    public DESCBCCipher(byte algorithm, byte cipherAlgorithm, byte paddingAlgorithm) {
        super(algorithm, cipherAlgorithm, paddingAlgorithm);
        chainingBlock = JCSystem.makeTransientByteArray(BLOCK_SIZE, JCSystem.CLEAR_ON_DESELECT);
        holdChainingBlock = JCSystem.makeTransientByteArray(BLOCK_SIZE, JCSystem.CLEAR_ON_DESELECT);
    }

    public void init(javacard.security.Key theKey, byte theMode) throws CryptoException {

        init(theKey, theMode, defaultIV, (short) 0, (short) defaultIV.length);
    }

    public void init(javacard.security.Key theKey, byte theMode, byte bArray[], short bOff, short bLen)
            throws CryptoException {
        if (bLen != BLOCK_SIZE) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        Util.arrayCopy(bArray, bOff, chainingBlock, (short) 0, BLOCK_SIZE);

        super.init(theKey, theMode);
    }

    /**
     * Resets the Cipher to post init state
     */
    protected void resetIV() {
        Util.arrayCopy(defaultIV, (short) 0, chainingBlock, (short) 0, BLOCK_SIZE);
    }

    /**
     * Ciphers the queue while handling chaining properly.
     */
    protected void cipherQueue(CircularQueue queue, byte[] outBuff, short outOffset) {
        if (mode[0] == javacardx.crypto.Cipher.MODE_ENCRYPT) {
            // XOR the queue contents with the current chaining block
            queue.xorWith(chainingBlock);
            // encrypt the XOR'd queue
            super.cipherQueue(queue, outBuff, outOffset);
            // copy the encrypted queue data into the chaining block
            Util.arrayCopy(outBuff, outOffset, chainingBlock, (short) 0, BLOCK_SIZE);
        } else { // DECRYPT

            // get a copy of the queue because we need it later for the chaining
            // block
            short count = queue.getCount();
            queue.copy(holdChainingBlock);
            // decrypt the queue
            super.cipherQueue(queue, outBuff, outOffset);
            // XOR the results, which are now in outBuff, with the current
            // chaining block
            for (short i = 0; i < BLOCK_SIZE; i++) {
                outBuff[(short) (outOffset + i)] ^= chainingBlock[i];
            }
            // now place the original queue in chaining block for the next round
            for (short i = 0; i < count; i++) {
                chainingBlock[i] = holdChainingBlock[i];
            }
        }// if ... else ...
    }// end method

    // Called once in card lifetime by cardInit().
    public static void initIV() {
        byte[] dIV = { (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
                (byte) 0x00 };
        defaultIV = dIV;
        NativeMethods.setJCREentry(defaultIV, false);
    }
}// end class
