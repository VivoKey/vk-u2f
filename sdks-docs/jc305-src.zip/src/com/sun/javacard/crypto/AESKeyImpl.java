/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
// #ifdef_Target32Bit_
package com.sun.javacard.crypto;

import javacard.framework.JCSystem;
import javacard.framework.Util;
import javacard.security.AESKey;
import javacard.security.CryptoException;
import javacard.security.KeyBuilder;

public class AESKeyImpl extends KeyInternal implements AESKey {

    protected byte[] data = null;
    /*
     * byte array to indicate if key has been initialized.
     * must be of same storage type as data. If initialized, set to 1, 
     * otherwise false.
     */
    private byte[] isInitialized;

    public AESKeyImpl(byte type, short bitLength) {
        super(type, bitLength);
        // value of getSize() is nothing but bitLength
        short byteLength = (short) (getSize() / 8);
        /*
         * byteLength will be 16, 24 or 32 for AES 128-bit, 196-bit or 256-bit 
         * respectively
         */

        /*
        * Depending on the type specified create the data array to be transient
        * or not.  Note that makeTransientByteArray may throw a SystemException
        * which will just be propagated to the JCRE
        */

        switch (type) {
            case KeyBuilder.TYPE_AES_TRANSIENT_DESELECT:
                data = JCSystem.makeTransientByteArray(byteLength, JCSystem.CLEAR_ON_DESELECT);
                isInitialized = JCSystem.makeTransientByteArray((short) 1, JCSystem.CLEAR_ON_DESELECT);
                break;

            case KeyBuilder.TYPE_AES_TRANSIENT_RESET:
                data = JCSystem.makeTransientByteArray(byteLength, JCSystem.CLEAR_ON_RESET);
                isInitialized = JCSystem.makeTransientByteArray((short) 1, JCSystem.CLEAR_ON_RESET);
                break;

            case KeyBuilder.TYPE_AES: // fall through
            default:
                data = new byte[byteLength];
                isInitialized = new byte[1];
                break;
        }
        // explicitly set to false just for clarity
        isInitialized[0] = (byte) 0;

    }

    public void setKey(byte[] keyData, short kOff) throws CryptoException, NullPointerException,
            ArrayIndexOutOfBoundsException {
        short byteLength = (short) (getSize() / 8);
        Util.arrayCopy(keyData, kOff, data, (short) 0, byteLength);
        /* If the arraycopy succeeded (i.e. didn't throw an exception) 
         * then the key is initialized
         */
        isInitialized[0] = (byte) 1;
    }

    public byte getKey(byte[] keyData, short kOff) throws CryptoException {
        // getSize(returns the bit length (from class KeyInternal))
        byte byteLength = (byte) (getSize() / 8);
        if (isInitialized[0] != (byte) 1) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }
        Util.arrayCopy(data, (short) 0, keyData, kOff, byteLength);

        return byteLength;
    }

    public boolean isInitialized() {
        return (isInitialized[0] == (byte) 1);
    }

    public void clearKey() {
        // reset the data to its default (zero) value
        Util.arrayFillNonAtomic(data, (short) 0, (short) data.length, (byte) 0x00);
        // reset the init flag
        isInitialized[0] = (byte) 0;
    }
}
// #endif_Target32Bit_
