/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */
package com.sun.javacard.crypto;

import com.sun.javacard.impl.NativeMethods;
import javacard.framework.Util;
import javacard.security.CryptoException;
import javacard.security.ECKey;

/**
 *
 * 
 */
public class ECSharedDomainPublicKeyImpl extends ECMemoryPoolKey implements javacard.security.ECPublicKey {
    
    private static final byte MEMORY_POOL_SIZE = (byte) 11;

   private static final byte PUBLIC_KEY_X = (byte) 8;
    private static final byte PUBLIC_KEY_Y = (byte) 9;
    private boolean wInitialized;

    private byte[] publicKeyX;
    private byte[] publicKeyY;
    
    private ECKeyImpl sharedDomain = null;
    
    private byte[] memoryPool;
    
    private boolean shared;
    
    private byte keyType;

    public ECSharedDomainPublicKeyImpl(byte type, javacard.security.Key sharedDomainParams) {
        sharedDomain = (ECKeyImpl)sharedDomainParams;
        memoryPool = new byte[MEMORY_POOL_SIZE];
        publicKeyX = new byte[(byte) (sharedDomain.getSize() / 8 + ECKeyImpl.ALIGNMENT_SPACE + ECKeyImpl.BIGINT_STRUCT_SIZE)];
        publicKeyY = new byte[(byte) (sharedDomain.getSize() / 8 + ECKeyImpl.ALIGNMENT_SPACE + ECKeyImpl.BIGINT_STRUCT_SIZE)];
        wInitialized = false;
        shared = true;
        keyType = type;
    }
    
    public ECSharedDomainPublicKeyImpl(byte type, short size) {
        sharedDomain = new ECKeyImpl(type, size);
        memoryPool = new byte[MEMORY_POOL_SIZE];
        publicKeyX = new byte[(byte) (sharedDomain.getSize() / 8 + ECKeyImpl.ALIGNMENT_SPACE + ECKeyImpl.BIGINT_STRUCT_SIZE)];
        publicKeyY = new byte[(byte) (sharedDomain.getSize() / 8 + ECKeyImpl.ALIGNMENT_SPACE + ECKeyImpl.BIGINT_STRUCT_SIZE)];
        wInitialized = false;
        shared = false;
        keyType = type;
    }

    public void setW(byte buffer[], short offset, short length) {

        if ((length > (short) ((sharedDomain.getSize() / 8) * 2 + 1)) || (buffer[offset] != 0x04)) {
            CryptoException.throwIt(CryptoException.ILLEGAL_VALUE);
        }

        short lengthX = (short) ((length - 1) / (short) 2);
        NativeMethods.checkArrayArgs(buffer, offset, length);
        short tempOffset = (short) (offset + 1);
        // Set values
        SecurityNativeMethods.setECDomainParameter(PERSISTENT, buffer, tempOffset, lengthX, PUBLIC_KEY_X, memoryPool,
                publicKeyX);
        tempOffset += lengthX;
        SecurityNativeMethods.setECDomainParameter(PERSISTENT, buffer, tempOffset, lengthX, PUBLIC_KEY_Y, memoryPool,
                publicKeyY);
        wInitialized = true;

    }

    public short getW(byte buffer[], short offset) {

        if (wInitialized == false) {
            CryptoException.throwIt(CryptoException.UNINITIALIZED_KEY);
        }

        NativeMethods.checkArrayArgs(buffer, offset, (short) ((sharedDomain.getSize() / 8) * 2 + 1));
        buffer[offset] = 0x04;
        // get x and y coordinates of G
        short xLength = SecurityNativeMethods.getECDomainParameter(PUBLIC_KEY_X, memoryPool, buffer,
                (short) (offset + 1));
        short yLength = SecurityNativeMethods.getECDomainParameter(PUBLIC_KEY_Y, memoryPool, buffer,
                (short) (offset + 1 + xLength));
        short xySize = xLength > yLength ? xLength : yLength;
        short totalSize = (short) (2 * xySize + 1);

        /*
         * A very large percentage of the time, X and Y will be the same size,
         * but for those few times this is not true, we need to pad appropriately.
         * To allow this to happen without use of another buffer (transient RAM
         * memory), X and Y are retrieved into buffer again with appropriate 0
         * padding. Repeat, this should happen very infrequently.
         */
        if (xLength != yLength) {
            NativeMethods.arrayFillNonAtomicForSensitiveArrays(buffer, (short) (offset + 1), totalSize, (byte) 0);
            SecurityNativeMethods.getECDomainParameter(PUBLIC_KEY_X, memoryPool, buffer,
                    (short) (offset + xySize - xLength + 1));
            SecurityNativeMethods.getECDomainParameter(PUBLIC_KEY_Y, memoryPool, buffer,
                    (short) (offset + totalSize + yLength));
        }

        return totalSize;
    }

    public boolean isInitialized() {
        if ((sharedDomain.isInitialized()) && (wInitialized)) {
            return true;
        } else {
            return false;
        }
    }

    public void clearKey() {
        if(!shared){
            sharedDomain.clearKey();
        }
        Util.arrayFillNonAtomic(publicKeyX, (short) 0, (short) publicKeyX.length, (byte) 0);
        Util.arrayFillNonAtomic(publicKeyY, (short) 0, (short) publicKeyY.length, (byte) 0);
        wInitialized = false;
    }

    public short getSize() {
        return sharedDomain.getSize();
    }

    public byte getType() {
        return keyType;
    }

    public void setFieldFP(byte[] buffer, short offset, short length) throws CryptoException {
        sharedDomain.setFieldFP(buffer, offset, length);
    }

    public void setFieldF2M(short e) throws CryptoException {
        sharedDomain.setFieldF2M(e);
    }

    public void setFieldF2M(short e1, short e2, short e3) throws CryptoException {
        sharedDomain.setFieldF2M(e1, e2, e3);
    }

    public void setA(byte[] buffer, short offset, short length) throws CryptoException {
        sharedDomain.setA(buffer, offset, length);
    }

    public void setB(byte[] buffer, short offset, short length) throws CryptoException {
        sharedDomain.setB(buffer, offset, length);
    }

    public void setG(byte[] buffer, short offset, short length) throws CryptoException {
        sharedDomain.setG(buffer, offset, length);
    }

    public void setR(byte[] buffer, short offset, short length) throws CryptoException {
        sharedDomain.setR(buffer, offset, length);
    }

    public void setK(short K) {
        sharedDomain.setK(K);
    }

    public short getField(byte[] buffer, short offset) throws CryptoException {
        return sharedDomain.getField(buffer, offset);
    }

    public short getA(byte[] buffer, short offset) throws CryptoException {
        return sharedDomain.getA(buffer, offset);
    }

    public short getB(byte[] buffer, short offset) throws CryptoException {
        return sharedDomain.getB(buffer, offset);
    }

    public short getG(byte[] buffer, short offset) throws CryptoException {
        return sharedDomain.getG(buffer, offset);
    }

    public short getR(byte[] buffer, short offset) throws CryptoException {
        return sharedDomain.getR(buffer, offset);
    }

    public short getK() throws CryptoException {
        return sharedDomain.getK();
    }

    public void copyDomainParametersFrom(ECKey ecKey) throws CryptoException {
        sharedDomain.copyDomainParametersFrom(ecKey);
    }

    byte[] getOwnMemoryPoolReference() {
        return memoryPool;
    }

    byte[] getDomainMemoryPoolReference() {
        return sharedDomain.getDomainMemoryPoolReference();
    }

    boolean isDomainInitialized() {
        return sharedDomain.isInitialized();
    }
    
}
