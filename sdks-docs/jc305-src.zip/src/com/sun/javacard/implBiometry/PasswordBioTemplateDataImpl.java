/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */
package com.sun.javacard.implBiometry;

import com.sun.javacard.impl.NativeMethods;
import javacard.framework.JCSystem;
import javacard.framework.Util;
import javacardx.biometry1toN.Bio1toNBuilder;
import javacardx.biometry1toN.Bio1toNException;
import javacardx.biometry1toN.BioMatcher;
import javacardx.biometry1toN.OwnerBioTemplateData;

/**
 *
 * 
 */
public class PasswordBioTemplateDataImpl implements OwnerBioTemplateData, InternalSharedPasswordBioTemplateData{
    
    private byte[] passwd;
    public static final byte MIN_PASSWD_LEN = (byte) 5;
    public static final byte MAX_PASSWD_LEN = (byte) 50;

    private boolean[] initCalled;// denotes weather a successfull
    // match has happened
    // since the last call to init() or resetUnblockAndSetTryLimit()
    // byte at index 1 indicates weather init() method has been called. false
    // means
    // no, true means yes. Checked by doFinal()
    // byte at index 2 is used during matching session and denotes weather
    // initMatch() is called
    private byte dataLenEnrolled;// denotes length of data enrolled.
    private boolean initialized;// denotes weather the reference template has
    
    private byte[] publicData;

    public PasswordBioTemplateDataImpl() {
        initialized = false;
        initCalled = JCSystem.makeTransientBooleanArray((byte) 1, JCSystem.CLEAR_ON_RESET);
        passwd = new byte[MAX_PASSWD_LEN];
        publicData = new byte[(short)4];
        publicData[0] = (byte)1;
        publicData[1] = (byte)0;
        publicData[2] = (byte)0;
        publicData[3] = MAX_PASSWD_LEN;
    }


    public void init(byte[] bArray, short offset, short length) throws Bio1toNException {
        if (length < (short) 0 || length > MAX_PASSWD_LEN) {
            // Must not be greater than MAX_PASSWD_LEN and
            // must not be negative. Since we can still add
            // more data, check to make sure that we have
            // at least minimum amount of data avaialble is
            // not required here. It is only reuqired in
            // doFinal.
            Bio1toNException.throwIt(Bio1toNException.INVALID_DATA);
        }
        NativeMethods.checkArrayArgs(bArray, offset, length);
        initialized = false;
        // resets the initial reference
        if (passwd != null && JCSystem.isObjectDeletionSupported()) {
            JCSystem.requestObjectDeletion();
        }
        Util.arrayCopy(bArray, offset, passwd, (short) 0, length);
        dataLenEnrolled = (byte) length;
        initCalled[0] = true;
    }


    public void update(byte[] bArray, short offset, short length) throws Bio1toNException {
        // verify that init() was called and that the length of data
        // enrolled is less than MIN_PASSWD_LEN
        if (!initCalled[0]) {
            // init method sets the initialized field to false
            Bio1toNException.throwIt(Bio1toNException.ILLEGAL_USE);
        }
        if (dataLenEnrolled + ((byte) length) > MAX_PASSWD_LEN) {
            Bio1toNException.throwIt(Bio1toNException.INVALID_DATA);
        }
        Util.arrayCopy(bArray, offset, passwd, dataLenEnrolled, length);
        dataLenEnrolled += length;
    }


    public void doFinal() throws Bio1toNException {
        // verify that init() was called and that the length of data
        // enrolled is at least equal to MIN_PASSWD_LEN
        if (!initCalled[0]) {
            // init method sets the initialized field to false
            Bio1toNException.throwIt(Bio1toNException.ILLEGAL_USE);
        }
        if (dataLenEnrolled < MIN_PASSWD_LEN) {
            // init method sets the initialized field to false
            Bio1toNException.throwIt(Bio1toNException.INVALID_DATA);
        }
        initCalled[0] = false;
        initialized = true;
    }


    public byte getBioType() {
        return Bio1toNBuilder.PASSWORD;
    }


    public boolean isInitialized() {
        return initialized;
    }


    public short getPublicData(short publicOffset, byte[] dest, short destOffset, short length) throws Bio1toNException {
        if (!initialized) {
            Bio1toNException.throwIt(Bio1toNException.NO_BIO_TEMPLATE_ENROLLED);
        }
        if(publicOffset >= (short) publicData.length){
            return (short)0;
        }
        short tempLength = (short)((short) publicData.length - publicOffset);
        tempLength = (length < tempLength) ? length : tempLength;
        NativeMethods.checkArrayArgs(dest, destOffset, tempLength);
        NativeMethods.checkArrayArgs(publicData, publicOffset, tempLength);
        Util.arrayCopy(publicData, publicOffset, dest, destOffset, tempLength);
        return tempLength;
    }
    
    public short match(byte[] candidate, short offset, short length, short lastLength) throws Bio1toNException{
        if (!initialized) {
            return (short)0;
        }

        if (lastLength + length > dataLenEnrolled) {
            return (short)0;
        }

        // compare partial passwd with partial enrolled passwd at index
        // matchDataLen[0]
        if(Util.arrayCompare(passwd, lastLength, candidate, offset, length) != (byte) 0){
            return (short)0;
        }
        
        if(lastLength + length < dataLenEnrolled){
            return BioMatcher.MATCH_NEEDS_MORE_DATA;
        }
        
        return BioMatcher.MINIMUM_SUCCESSFUL_MATCH_SCORE;
    }
    
}
