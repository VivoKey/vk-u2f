/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.implBiometry;

import javacard.framework.JCSystem;
import javacard.framework.Util;
import javacardx.biometry.BioBuilder;
import javacardx.biometry.BioException;
import javacardx.biometry.BioTemplate;
import javacardx.biometry.OwnerBioTemplate;

import com.sun.javacard.impl.NativeMethods;

public class PasswordBioImpl implements OwnerBioTemplate {
    private byte[] passwd;
    private byte[] tryLimit;// The number of tries remaining. Blocked state is
    // represented by this number being 0;
    // tryLimit, is declared as an array so
    // that arrayCopyNonAtomic can be used during decrement.
    private byte origTryLimit;
    public static final byte MIN_PASSWD_LEN = (byte) 5;
    public static final byte MAX_PASSWD_LEN = (byte) 50;

    private boolean[] validatedAndInitCalled;// denotes weather a successfull
    // match has happened
    // since the last call to init() or resetUnblockAndSetTryLimit()
    // byte at index 1 indicates weather init() method has been called. false
    // means
    // no, true means yes. Checked by doFinal()
    // byte at index 2 is used during matching session and denotes weather
    // initMatch() is called
    private byte dataLenEnrolled;// denotes length of data enrolled.
    private byte[] matchDataLen;// denotes the length of data to be matched
    private boolean initialized;// denotes weather the reference template has

    // been

    // set.

    /**
     * Constructor
     */
    public PasswordBioImpl(byte tryL) {
        tryLimit = new byte[1];
        tryLimit[0] = tryL;
        origTryLimit = tryL;
        initialized = false;
        validatedAndInitCalled = JCSystem.makeTransientBooleanArray((byte) 3, JCSystem.CLEAR_ON_RESET);
        validatedAndInitCalled[0] = false;
        validatedAndInitCalled[1] = false;
        validatedAndInitCalled[2] = false;
        matchDataLen = JCSystem.makeTransientByteArray((byte) 1, JCSystem.CLEAR_ON_RESET);
        passwd = new byte[MAX_PASSWD_LEN];
    }

    /**
     * Initializes the enrollment of a reference template. It is also used to
     * update a reference template. It resets the validated flag and, in the
     * update case, uninitializes the previous reference. Note: A correct
     * enrollment sequence is : init[update]doFinal. Calling init and doFinal is
     * mandatory, calling update is optional. The array containing password data
     * must have the password layed out as a byte array with each character
     * represented by a byte starting from index offset. There should be no
     * other information in the byte array from index offset to index
     * offset+length-1. For example, password "tests" must be represented by the
     * byte array {116, 101, 115, 116, 115} starting at index 0 with length 5
     * 
     * This implementation requires that the array passed in contain the passwd
     * data at index offset.
     * 
     * @param bArray
     *            the array of data.
     * @param offset
     *            the offset where data starts
     * @param length
     *            the length of the data.
     * @throws BioException.INVALID_DATA
     *             if data passed in does not represent a byte value
     */
    public void init(byte[] bArray, short offset, short length) throws BioException {
        if (length < (short) 0 || length > MAX_PASSWD_LEN) {
            // Must not be greater than MAX_PASSWD_LEN and
            // must not be negative. Since we can still add
            // more data, check to make sure that we have
            // at least minimum amount of data avaialble is
            // not required here. It is only reuqired in
            // doFinal.
            BioException.throwIt(BioException.INVALID_DATA);
        }
        NativeMethods.checkArrayArgs(bArray, offset, length);
        initialized = false;
        validatedAndInitCalled[0] = false;
        validatedAndInitCalled[1] = true;
        validatedAndInitCalled[2] = false;
        // resets the initial reference
        if (passwd != null && JCSystem.isObjectDeletionSupported()) {
            JCSystem.requestObjectDeletion();
        }
        Util.arrayCopy(bArray, offset, passwd, (short) 0, length);
        dataLenEnrolled = (byte) length;
    }

    /**
     * Continues the enrollment of a reference template. This method should only
     * be used if all the input data required for the init is not available in
     * one byte array. It can be called several times. Note: A correct
     * enrollment sequence is : init[update]doFinal. Calling init and doFinal is
     * mandatory, calling update is optional. The array containing password data
     * must have the password layed out as a byte array with each character
     * represented by a byte starting from index offset. There should be no
     * other information in the byte array from index offset to index
     * offset+length-1. For example, password "tests" must be represented by the
     * byte array {116, 101, 115, 116, 115} starting at index 0 with length 5
     */
    public void update(byte[] bArray, short offset, short length) throws BioException {
        // verify that init() was called and that the length of data
        // enrolled is less than MIN_PASSWD_LEN
        if (!validatedAndInitCalled[1]) {
            // init method sets the initialized field to false
            BioException.throwIt(BioException.ILLEGAL_USE);
        }
        if (dataLenEnrolled + ((byte) length) > MAX_PASSWD_LEN) {
            BioException.throwIt(BioException.INVALID_DATA);
        }
        Util.arrayCopy(bArray, offset, passwd, dataLenEnrolled, length);
        dataLenEnrolled += length;
    }

    /**
     * Finalizes the enrollment of a reference template. Final action of
     * enrollment is to designate a reference template as being complete and
     * ready for use (marks the reference as initialized, resets the try counter
     * and unblocks the reference). This routine may also include some error
     * checking prior to the validation of reference template as ready for use.
     * Note: A correct enrollment sequence is : init[update]doFinal. Calling
     * init and doFinal is mandatory, calling update is optional. In our
     * implementation, the data passed in contains just the passwd data.
     */
    public void doFinal() throws BioException {
        // verify that init() was called and that the length of data
        // enrolled is at least equal to MIN_PASSWD_LEN
        if (!validatedAndInitCalled[1]) {
            // init method sets the initialized field to false
            BioException.throwIt(BioException.ILLEGAL_USE);
        }
        if (dataLenEnrolled < MIN_PASSWD_LEN) {
            // init method sets the initialized field to false
            BioException.throwIt(BioException.INVALID_DATA);
        }
        validatedAndInitCalled[1] = false;
        initialized = true;
    }

    /**
     * Get the biometric type. Valid type are described in BioBuilder.
     */
    public byte getBioType() {
        return BioBuilder.PASSWORD;
    }

    /**
     * Get the matching algorithm version and ID.
     */
    public short getVersion(byte[] dest, short offset) {
        // always stores three bytes dest[0]=1, dest[1]=0, dest[2]=0
        // representing 1.0.0
        NativeMethods.checkArrayArgs(dest, offset, (short) 3);
        dest[offset++] = (byte) 1;
        dest[offset++] = (byte) 0;
        dest[offset] = (byte) 0;
        return (short) 3;
    }

    /**
     * Get public part of the reference template. It copies all or a piece of
     * the reference public data to the destination array. This implementation
     * returns back the version information and the password length. The version
     * for this impl is 1.0.0 so the dest array would be: dest[0]=1 dest[1]=0
     * dest[2]=0; dest[3] = <passwd length>
     */
    public short getPublicTemplateData(short publicOffset, byte[] dest, short destOffset, short length)
            throws BioException {
        if (!initialized) {
            BioException.throwIt(BioException.NO_TEMPLATES_ENROLLED);
        }
        if (length < (short) 4) {
            BioException.throwIt(BioException.ILLEGAL_VALUE);
        }
        NativeMethods.checkArrayArgs(dest, destOffset, (short) 4);
        getVersion(dest, destOffset);
        dest[(short) (destOffset + 3)] = (byte) (passwd.length);
        return (short) 4;
    }

    /**
     * Returns the number of times remaining that an incorrect candidate
     * template can be presented before the reference template is blocked. the
     * number of tries remaining.
     */
    public byte getTriesRemaining() {
        if (!initialized) {
            BioException.throwIt(BioException.NO_TEMPLATES_ENROLLED);
        }
        byte result = tryLimit[0];
        NativeMethods.sensitiveResultSet(result);
        return result;
    }

    /**
     * Initialize or re-initialize a biometric matching session. The exact
     * return score value is implementation dependant and can be used, for
     * example, to code a confidence rate. If the reference is not blocked, a
     * matching session starts and, before any other processing, the validated
     * flag is reset, the try counter is decremented if it has reached zero, the
     * reference is blocked. This method makes the matching session : 1. end
     * with success state if the templates match: the validated flag is set and
     * the try counter is reset to its maximum; or 2. end with failed state if
     * the templates don t match ; or 3. continue if the matching needs more
     * data : match method has to be called to continue the matching session.
     * Notes: A correct matching sequence is : initMatch[match]. Calling
     * initMatch is mandatory, calling match is optional. If a matching session
     * is in progress (case needs more data), a call to initMatch makes the
     * current session to fail and starts a new matching session. Even if a
     * transaction is in progress, internal state such as the try counter, the
     * validated flag and the blocking state must not be conditionally updated.
     * 
     * This implementation require that all the passwd data be given in this
     * method. The match() method should never be called.
     * 
     * The array containing password data must have the password layed out as a
     * byte array with each character represented by a byte starting from index
     * offset. There should be no other information in the byte array from index
     * offset to index offset+length-1. For example, password "tests" must be
     * represented by the byte array {116, 101, 115, 116, 115} starting at index
     * 0 with length 5
     */
    public short initMatch(byte[] candidate, short offset, short length) throws BioException {
        
        NativeMethods.sensitiveResultSetTagValUnassigned();
        
        if (!initialized) {
            BioException.throwIt(BioException.NO_TEMPLATES_ENROLLED);
        }
        // check if reference blocked
        if (tryLimit[0] == (byte) 0) {
            BioException.throwIt(BioException.ILLEGAL_USE);
        }
        // initialize the matching session
        Util.arrayFillNonAtomic(tryLimit, (short) 0, (short) 1, (byte) (tryLimit[0] - 1));
        // check that the data coming in has the correct length
        NativeMethods.checkArrayArgs(candidate, offset, length);
        validatedAndInitCalled[0] = false;
        if (length > dataLenEnrolled) {
            // matching failed
            NativeMethods.sensitiveResultSet( (short)0);
            return (short) 0;
        }
        matchDataLen[0] = (byte) length;
        // check if password (potentially partial) is equal to partial enrolled.
        if (Util.arrayCompare(passwd, (short) 0, candidate, offset, length) != (byte) 0) {
            NativeMethods.sensitiveResultSet( (short)0);
            return (short) 0;
        }

        // if partial, ask for more
        if (length < dataLenEnrolled) {
            validatedAndInitCalled[2] = true;
            short result = BioTemplate.MATCH_NEEDS_MORE_DATA;
            NativeMethods.sensitiveResultSet(result);
            return result;
        }

        // validated
        validatedAndInitCalled[0] = true;
        Util.arrayFillNonAtomic(tryLimit, (short) 0, (short) 1, origTryLimit);
        
        short result = BioTemplate.MINIMUM_SUCCESSFUL_MATCH_SCORE;
        NativeMethods.sensitiveResultSet(result);
        return result;
    }

    /**
     * Returns true if the reference template is completely loaded and ready for
     * matching functions. This is independent of whether or not the match
     * process has been initialized (see initMatch).
     */
    public boolean isInitialized() {
        return initialized;
    }

    /**
     * Returns true if the template has been successfully checked since the last
     * card reset or last call to reset().
     */
    public boolean isValidated() {
        boolean result = validatedAndInitCalled[0];
        
        if (result)
            NativeMethods.sensitiveResultSetBooleanTrue();
        else
            NativeMethods.sensitiveResultSetBooleanFalse();
        
        return result;
    }

    /**
     * continues the matching session and returns codes just like initMatch.
     */
    public short match(byte[] candidate, short offset, short length) throws BioException {
        NativeMethods.sensitiveResultSetTagValUnassigned();
        
        if (!validatedAndInitCalled[2]) {
            BioException.throwIt(BioException.ILLEGAL_USE);
        }

        if (matchDataLen[0] + length > dataLenEnrolled) {
            validatedAndInitCalled[2] = false;
            NativeMethods.sensitiveResultSet((short) 0);
            return (short) 0;
        }

        // compare partial passwd with partial enrolled passwd at index
        // matchDataLen[0]
        if (Util.arrayCompare(passwd, matchDataLen[0], candidate, offset, length) != (byte) 0) {
            validatedAndInitCalled[2] = false;
            NativeMethods.sensitiveResultSet((short) 0);
            return (short) 0;
        }
        // check data matching complete
        if (matchDataLen[0] + length == dataLenEnrolled) {
            // match complete
            // validated
            validatedAndInitCalled[0] = true;
            validatedAndInitCalled[2] = false;
            Util.arrayFillNonAtomic(tryLimit, (short) 0, (short) 1, origTryLimit);
            short result = BioTemplate.MINIMUM_SUCCESSFUL_MATCH_SCORE;
            NativeMethods.sensitiveResultSet((short) result);
            return result;
        }
        // otherwise keep accumulating
        matchDataLen[0] += length;
        short result = BioTemplate.MATCH_NEEDS_MORE_DATA;
        NativeMethods.sensitiveResultSet((short) result);
        return result;
    }

    /**
     * Resets the reference validated flag. This could be appropriate as a last
     * action after an access is completed.
     */
    public void reset() {
        validatedAndInitCalled[0] = false;
        // The tryLimit was already set to max at successful validation or at
        // enrollment which ever was last.
    }

    /**
     * Resets the validated flag, unblocks the reference, updates the try limit
     * value and resets the try counter to the try limit value.
     */
    public void resetUnblockAndSetTryLimit(byte newTryLimit) throws BioException {
        if (newTryLimit < (byte) 1) {
            BioException.throwIt(BioException.ILLEGAL_VALUE);
        }
        validatedAndInitCalled[0] = false;
        tryLimit[0] = newTryLimit;
        origTryLimit = newTryLimit;
    }
}
