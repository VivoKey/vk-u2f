/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */
package com.sun.javacard.implBiometry;

import com.sun.javacard.impl.NativeMethods;
import javacard.framework.JCSystem;
import javacard.framework.Util;
import javacardx.biometry1toN.Bio1toNBuilder;
import javacardx.biometry1toN.Bio1toNException;
import javacardx.biometry1toN.BioTemplateData;
import javacardx.biometry1toN.OwnerBioMatcher;
import javacardx.biometry1toN.OwnerBioTemplateData;

/**
 *
 * 
 */
public class PasswordBioMatcherImpl implements OwnerBioMatcher{
    
    public static final short MAX_NUMBER_OF_TEMPLATES = (short)50;
    
    private BioTemplateData[] templates;
    private byte[] tryLimit;
    private byte origTryLimit;
    private boolean initialized;
    private boolean[] validatedAndInitCalled;
    private short[] lastMatchedIndex;
    private short[] lastLength;

    public PasswordBioMatcherImpl(short maxNbOfBioTemplateData, byte tryLimit) {
        templates = new OwnerBioTemplateData[maxNbOfBioTemplateData];
        origTryLimit = tryLimit;
        initialized = false;
        this.tryLimit = JCSystem.makeTransientByteArray((short)1, JCSystem.MEMORY_TYPE_TRANSIENT_RESET);
        validatedAndInitCalled = JCSystem.makeTransientBooleanArray((short)2, JCSystem.MEMORY_TYPE_TRANSIENT_RESET);
        lastMatchedIndex = JCSystem.makeTransientShortArray((short)1, JCSystem.MEMORY_TYPE_TRANSIENT_RESET);
        lastLength = JCSystem.makeTransientShortArray((short)1, JCSystem.MEMORY_TYPE_TRANSIENT_RESET);
        this.tryLimit[0] = origTryLimit;
        validatedAndInitCalled[0] = false;
        validatedAndInitCalled[1] = false;
    }
    
    public void putBioTemplateData(short index, BioTemplateData templateData) throws Bio1toNException, SecurityException {
        
        if(index > (short)templates.length || index < 1){
            Bio1toNException.throwIt(Bio1toNException.ILLEGAL_VALUE);
        }
        
        if(templateData == null){
            JCSystem.beginTransaction();
            templates[(short)(index - 1)] = null;
            if(validatedAndInitCalled[0] && lastMatchedIndex[0] == (byte)index){
                validatedAndInitCalled[0] = false;
                validatedAndInitCalled[1] = false;
            }
            initialized = false;
            for(short i = 0; i<(short)templates.length; i++){
                if(templates[i] != null){
                    initialized = true;
                    break;
                }
            }
            JCSystem.commitTransaction();
            return;
        }
        
        if(!templateData.isInitialized()){
            Bio1toNException.throwIt(Bio1toNException.NO_BIO_TEMPLATE_ENROLLED);
        }
        if(templateData.getBioType() != Bio1toNBuilder.PASSWORD){
            Bio1toNException.throwIt(Bio1toNException.MISMATCHED_BIO_TYPE);
        }
        
        if(!(templateData instanceof InternalSharedPasswordBioTemplateData)){
            Bio1toNException.throwIt(Bio1toNException.MISMATCHED_BIO_TYPE);
        }
        templates[(short)(index - 1)] = templateData;
        initialized = true;  
    }

    public void resetUnblockAndSetTryLimit(byte newTryLimit) throws Bio1toNException {
        if (newTryLimit < (byte) 1) {
            Bio1toNException.throwIt(Bio1toNException.ILLEGAL_VALUE);
        }
        validatedAndInitCalled[0] = false;
        validatedAndInitCalled[1] = false;
        tryLimit[0] = newTryLimit;
        origTryLimit = newTryLimit;
    }

    public short getIndexOfLastMatchingBioTemplateData() {
        if(!initialized || !validatedAndInitCalled[0]){
            Bio1toNException.throwIt(Bio1toNException.ILLEGAL_USE);
        }
        return lastMatchedIndex[0];
    }

    public OwnerBioTemplateData getBioTemplateData(short index) {
        if(index > (short)templates.length || index < (short)1){
             return null;
        }
        return (OwnerBioTemplateData)templates[(short)(index - 1)];
    }

    public boolean isInitialized() {
        return initialized;
    }

    public boolean isValidated() {
        boolean result = validatedAndInitCalled[0];
        if (result)
            NativeMethods.sensitiveResultSetBooleanTrue();
        else
            NativeMethods.sensitiveResultSetBooleanFalse();
        return result;
    }

    public void reset() {
        validatedAndInitCalled[0] = false;
    }

    public byte getTriesRemaining() {
        if(!initialized){
            Bio1toNException.throwIt(Bio1toNException.NO_BIO_TEMPLATE_ENROLLED);
        }
        byte result = tryLimit[0];
        NativeMethods.sensitiveResultSet(result);
        return result;
    }

    public byte getBioType() {
        return Bio1toNBuilder.PASSWORD;
    }

    public short getVersion(byte[] dest, short offset) {
        NativeMethods.checkArrayArgs(dest, offset, (short) 3);
        dest[offset++] = (byte) 1;
        dest[offset++] = (byte) 0;
        dest[offset] = (byte) 0;
        return (short) 3;
    }

    public short initMatch(byte[] candidate, short offset, short length) throws Bio1toNException {
        NativeMethods.sensitiveResultSetTagValUnassigned();
        
        if (!initialized) {
            Bio1toNException.throwIt(Bio1toNException.NO_BIO_TEMPLATE_ENROLLED);
        }
        // check if reference blocked
        if (tryLimit[0] == (byte) 0) {
            NativeMethods.sensitiveResultSet((short) 0);
            return (short)0;
        }
        // initialize the matching session
        Util.arrayFillNonAtomic(tryLimit, (short) 0, (short) 1, (byte) (tryLimit[0] - 1));
        // check that the data coming in has the correct length
        NativeMethods.checkArrayArgs(candidate, offset, length);
        validatedAndInitCalled[0] = false;
        validatedAndInitCalled[1] = false;
        for(short i = 0; i<(short)templates.length; i++){
            if(templates[i] != null && templates[i].isInitialized()){
                short result = ((InternalSharedPasswordBioTemplateData)templates[i]).match(candidate, offset, length, (short)0);
                if(result == MINIMUM_SUCCESSFUL_MATCH_SCORE){
                    Util.arrayFillNonAtomic(tryLimit, (short) 0, (short) 1, origTryLimit);
                    validatedAndInitCalled[0] = true;
                    lastMatchedIndex[0] = (short)(i + 1);
                    
                    NativeMethods.sensitiveResultSet(MINIMUM_SUCCESSFUL_MATCH_SCORE);
                    return MINIMUM_SUCCESSFUL_MATCH_SCORE;
                }
                if(result == MATCH_NEEDS_MORE_DATA){
                    validatedAndInitCalled[1] = true;
                }
            }
        }
        if(validatedAndInitCalled[1]){
            lastLength[0] = length;
            
            NativeMethods.sensitiveResultSet(MATCH_NEEDS_MORE_DATA);
            return MATCH_NEEDS_MORE_DATA;
        }
        
        NativeMethods.sensitiveResultSet((short) 0);
        return (short)0;
    }

    public short match(byte[] candidate, short offset, short length) throws Bio1toNException {
        NativeMethods.sensitiveResultSetTagValUnassigned();
        
        if (!validatedAndInitCalled[1]) {
            Bio1toNException.throwIt(Bio1toNException.ILLEGAL_USE);
        }
        validatedAndInitCalled[1] = false;
        for(short i = 0; i<(short)templates.length; i++){
            if(templates[i] != null && templates[i].isInitialized()){
                short result = ((InternalSharedPasswordBioTemplateData)templates[i]).match(candidate, offset, length, lastLength[0]);
                if(result == MINIMUM_SUCCESSFUL_MATCH_SCORE){
                    Util.arrayFillNonAtomic(tryLimit, (short) 0, (short) 1, origTryLimit);
                    validatedAndInitCalled[0] = true;
                    lastMatchedIndex[0] = (short)(i + 1);
                    
                    NativeMethods.sensitiveResultSet(MINIMUM_SUCCESSFUL_MATCH_SCORE);
                    return MINIMUM_SUCCESSFUL_MATCH_SCORE;
                }
                if(result == MATCH_NEEDS_MORE_DATA){
                    validatedAndInitCalled[1] = true;
                }
            }
        }
        if(validatedAndInitCalled[1]){
            lastLength[0] = (short)(lastLength[0] + length);
            
            NativeMethods.sensitiveResultSet(MATCH_NEEDS_MORE_DATA);
            return MATCH_NEEDS_MORE_DATA;
        }
        
        NativeMethods.sensitiveResultSet((short)0);
        return (short)0;
    }

    public short getMaxNbOfBioTemplateData() {
        return (short)templates.length;
    }
    
}
