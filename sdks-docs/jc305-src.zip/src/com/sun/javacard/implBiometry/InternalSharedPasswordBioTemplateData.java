/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */
package com.sun.javacard.implBiometry;

import javacard.framework.Shareable;
import javacardx.biometry1toN.Bio1toNException;

/**
 *
 * 
 */
public interface InternalSharedPasswordBioTemplateData extends Shareable{
    
    public short match(byte[] candidate, short offset, short length, short lastLength) throws Bio1toNException;
    
}
