/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.impl;

class ComponentInfo {
    //public short size;
    //public short address;

    /**
     * Constructor
     * 
     * @param compSize
     *            is the component size in memory
     * @param compAddr
     *            is the component start address in memory
     */
    public ComponentInfo(short compSize, short compAddr) {
        //size = compSize;
        //address = compAddr;
    }
}
