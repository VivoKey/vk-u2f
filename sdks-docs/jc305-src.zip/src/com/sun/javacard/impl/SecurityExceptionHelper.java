/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

package com.sun.javacard.impl;

public class SecurityExceptionHelper{
    private static SecurityException se;

    public static void initSE(SecurityException seObj){
        se = seObj;
    }
    public static void throwSE() throws SecurityException{
        throw se;
    }
}
