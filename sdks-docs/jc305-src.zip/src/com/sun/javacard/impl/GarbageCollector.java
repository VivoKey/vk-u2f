/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.impl;

import javacard.framework.SystemException;
import javacard.framework.ISOException;
import javacard.framework.JCSystem;

/**
 * This class is responsible for driving garbage collection, applet deletion and
 * package deletion.
 * 
 */
public class GarbageCollector {
    /**
     * Flag that shows if GC is requested
     */
    static byte GCRequested = (byte) -1;
    
    public static void setGCRequested(byte req){
        GCRequested = req;
    }
    /**
     * Flag that shows that package deletion is in progress
     */
    static boolean deletingPackage = false;

    /**
     * Flag that shows that sweep cycle is started. This flag is used at reset
     * to determine if there was GC in progress when the card lost power. If
     * this flag is set, we'll restart the GC cycle to collect the remaining
     * garbage.
     */
    static boolean sweepStarted = false;
    
    public static boolean getSweepStarted(){
        return sweepStarted;
    }

    /**
     * In case package deletion is in progress, this variable contains the index
     * of the package being deleted.
     */
    static byte packageBeingDeleted = PackageMgr.ILLEGAL_ID;

    /**
     * RMIs exported objects array
     */
    static short[] RMIExpObjArray = null;

    /**
     * Set the exported objects array for RMI. This need to be cleaned up after
     * every successful GC operation.
     * 
     * @param exported
     *            objects array which contains object IDs
     */
    public static void setExpObjArray(short[] expArray) {
        RMIExpObjArray = expArray;
    }

    /**
     * Starting point for garbage collection procedure.
     * 
     * @return the status for gc
     */
    public static boolean startGC() {
        boolean doCommit = false;
        // Mark all root objects which includes applet table and static
        // reference type fields
        if (!markObjects()) {
            // this should never happen, since this can only fail during applet
            // deletion
            return false;
        }

        // Set the flag to indicate the sweep cycle has started
        sweepStarted = true;

        // now that we are done marking objects, it is time for the sweep cycle
        NativeMethods.startSweepCycle();

        // reset the sweepStarted flag to indicate that sweep completed
        // successfully
        sweepStarted = false;

        // After GC there may be invalid references in exported objects array
        // which need to be cleaned up
        cleanupExportedObjectsArray();
        return true;
    }

    private static boolean markObjects() {
        boolean gcRequested = PrivAccess.getPrivAccess().isGarbageCollectionRequested();
        PrivAccess.getPrivAccess().setGCRequestedFlag(false);
        try {
            /*
            This method takes care of starting garbage collection.
            It first calls the native method initializeGC().
             */
            NativeMethods.initializeGC();
        } catch (SystemException e) {
            // check if this method was called as a result of requested object
            // deletion.
            // if this was the case, we cannot do anything with the exception
            // since there
            // is no entity that would catch it and deal with it which is why we
            // suppress
            // it right here and just return false. Otherwise, we throw an
            // exception
            if (!gcRequested) {
                /*there was not enough memory available to complete operation*/
                ISOException.throwIt(Errors.MEMORY_CONSTRAINTS);
            } else {
                return false;
            }
        }
        /*
        Call the native method to mark the applet table as the root of roots :)
        passing it the address to the applet table. What garbage collector does with
        it is upto it
         */
        NativeMethods.markAppletRoots(AppletMgr.theAppTable);

        // Do the following step only if the package table has been initialized.
        if (PackageMgr.f_pkgTable != null) {
            /*
            For all the packages in the memory, call the native method markStaticRoots()
            to mark the objects pointed to by statics as roots
             */
            for (byte i = 0; i < PackageMgr.ON_CARD_PKG_MAX; i++) {
                if (PackageMgr.f_pkgTable[i] != null) {
                    short refCount = PackageMgr.f_pkgTable[i].pkgStaticReferenceCount;
                    // if the package is being deleted or the package does not
                    // have any
                    // reference type fields, then simply continue
                    if ((deletingPackage && packageBeingDeleted == i) || (refCount == 0)) {
                        continue;
                    }
                    if (NativeMethods.markStaticRoots(i, refCount) == 0) {
                        // error
                        return false;
                    }
                }
            }
        }

        // mark all the non-root objects
        if (!NativeMethods.markNonRootObjects()) {
            // this should only be in case of applet deletion.
            return false;
        }

        return true;
    }

    /**
     * This method calls the corresponding native method which goes through the
     * complete exported objects arrays and removes any entries from it that do
     * not point to objects existing on the card.
     */
    private static void cleanupExportedObjectsArray() {
        if (RMIExpObjArray != null) {
            NativeMethods.cleanupExportedObjectsArray(RMIExpObjArray);
        }
    }

    /**
     * Used to delete one or more than one applet instances from EEPROM. Note:
     * This method is not called from within a transaction.
     * 
     * @param contexts
     *            array is the one that contains the ids or applet contexts of
     *            all the applets being deleted.
     * @param count
     *            is the count of applets being deleted.
     * @return status
     */
    public static void deleteApplets(byte[] contexts, byte count) throws ISOException {
        boolean markSuccessful = false;
        /*
         * pass the context information about the applets to be deleted to garbage
         *  collector
         */

        NativeMethods.initializeAppletDeletion(contexts, count);

        // Remove the applets from the applet table and then mark
        // reachable objects for GC. If marking fails, it will be
        // because one of the applet had some dependencies on it.
        // If marking fails, we have to restore the applet table
        // to its previous state and abort applet deletion, which
        // is why we do the removal of applets from the applet
        // table and marking of objects, in a transaction. If
        // marking is successful, applet deletion is considered
        // successful at which point, these applets and their
        // objects become garbage and are collected through regular
        // sweep cycle. Sweep cycle happens outside the main
        // applet deletion transaction so that it is not restricted
        // by the transaction buffer size.

        JCSystem.beginTransaction(); // no transaction should be in progress
        // at this time
        /*
         * Remove the applet(s) from the applet table
         */
        for (byte i = 0; i < count; i++) {
            AppletMgr.removeApplet((byte) (contexts[i] & 0x0F));
        }

        try {
            markSuccessful = markObjects();
        } catch (ISOException e) {
            // applet deletion failed because of memory constraints.
            // Abort the transaction and rethrow the exception
            JCSystem.abortTransaction();
            ISOException.throwIt(e.getReason());
        }

        // mark objects
        if (!markSuccessful) {
            // there are dependencies on the applet
            // restore the state of applet table by aborting the transaction
            JCSystem.abortTransaction();
            // throw appropriate exception
            ISOException.throwIt(Errors.DEPENDENCIES_ON_APPLET);
        }
        // at this point we know the applets can be deleted therefore we
        // commit the state of the applet table and continue with regular
        // garbage collection.
        JCSystem.commitTransaction();

        // Run the sweep cycle
        NativeMethods.startSweepCycle();

        // After sweep cycle there may be invalid references in exported objects
        // array
        // which need to be cleaned up
        cleanupExportedObjectsArray();
    }

    /**
     * This method initializes the package deletion so that while doing applet
     * deletion (in case of applet and package deletion) we don't mark the
     * objects being pointed to by the static fields of the package being
     * deleted.
     * 
     * @param index
     *            of the package being deleted in the package table.
     */
    public static void initPackageDeletion(byte index) {
        deletingPackage = true;
        packageBeingDeleted = index;
    }

    /**
     * This method resets the fields that were set for package deletion.
     */
    public static void resetPackageDeletion() {
        packageBeingDeleted = PackageMgr.ILLEGAL_ID;
        deletingPackage = false;
    }

    /**
     * Clean up package table entries etc.
     * 
     * @param index
     *            is the index in the package table
     */
    public static void cleanupTables(byte index) {

        // check that entry in the package table at the given index is not null
        // if the entry is null the package has nothing. Just return.
        if (PackageMgr.f_pkgTable[index] == null) {
            return;
        }
        /**
         * If the package is an applet package, we need to remove it from the
         * contexts table as well to make room for new applet packages.
         */
        if (PackageMgr.f_pkgTable[index].appletCount > 0) {
            PackageMgr.packageContextTable[PackageMgr.getPkgContext(index)] = PackageMgr.ILLEGAL_ID;
            PackageMgr.appletPkgCount--;
        }
        PackageMgr.f_pkgTable[index] = null;
        resetPackageDeletion();

        /** Clear up any garbage left over by table cleanup */
        startGC();
    }

    /**
     * delete a package Note: This method is not called from within a
     * transaction
     * 
     * @param index
     *            is the is the index of the package in the package table.
     */
    public static void deletePackage(byte index) throws ISOException {
        // the package being processed is the package being deleted, set this
        // if it has not already been set. We do not need to set it if this is
        // applet and package deletion since method deletePackageAndApplets has
        // already set it. Saving an extra EEPROM write.
        if (PackageMgr.g_packageInProcess == PackageMgr.ILLEGAL_ID) {
            PackageMgr.g_packageInProcess = index;
        }
        /**
         * call to the following method results in removal of: 1. all the
         * components of the package from the memory. 2. the exception table
         * entry corresponding to this package. 3. Any references that belong to
         * this package from the global reference table
         */
        NativeMethods.removePackage(index, (byte) 0);
        JCSystem.beginTransaction();
        cleanupTables(index);
        JCSystem.commitTransaction();
    }

    /**
     * delete a package along with it's applets Note: This method is not called
     * from within a transaction
     * 
     * @param index
     *            is the is the index of the package in the package table.
     * @param buffer
     *            contains the IDs of the applets belonging to the package being
     *            deleted.
     * @appCount applet count
     */
    public static void deletePackageAndApplets(byte index, byte[] buffer, byte appCount) throws ISOException {
        // the package being processed is the package being deleted
        PackageMgr.g_packageInProcess = index;
        initPackageDeletion(index);
        if (appCount != 0) {
            try {
                // delete all the applets first.
                deleteApplets(buffer, appCount);
            } catch (ISOException e) {
                PackageMgr.g_packageInProcess = PackageMgr.ILLEGAL_ID;
                resetPackageDeletion();
                ISOException.throwIt(e.getReason());
            }
        }
        deletePackage(index);
    }
}
