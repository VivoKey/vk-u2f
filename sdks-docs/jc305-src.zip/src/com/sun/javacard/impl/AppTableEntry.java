/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.impl;

import javacard.framework.AID;
import javacard.framework.Applet;

/**
 * This class contains the data structure used by the AppletMgr class to creat
 * Applet Table.
 */
class AppTableEntry {
    Applet theApplet; // applet instance.
    AID theAID; // AID of applet instance.
    byte theContext; // packageId of applet class
}
