/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.impl;

/**
 * This interface contains implementation specific constants
 */
public interface Constants {

    /**
     * Length in bytes of the APDU Buffer
     */
    public final short APDU_BUFFER_LENGTH = 133;

}
