/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.impl;

// #ifdef_Target32Bit_
import com.sun.javacard.crypto.AES128CBCCipher;
// #endif_Target32Bit_
import com.sun.javacard.crypto.DESCBCCipher;

// #ifdef_Target32Bit_
import com.sun.javacard.crypto.SHA256MessageDigest;
// #endif_Target32Bit_
import com.sun.javacard.crypto.SHAMessageDigest;
import com.sun.javacard.crypto.UtilityRandomData;
import com.sun.javacard.impl.Options;

public class CryptoInit {
    public static void initCryptoStorage() {
        
        if (Options.RANDOMDATA_ALG_PSEUDO_RANDOM){
            UtilityRandomData.init();
        }

        if (Options.CIPHER_ALG_DES_CBC_ISO9797_M2
                || Options.SIGNATURE_ALG_DES_MAC8_ISO9797_M2
                || Options.SIGNATURE_ALG_AES_MAC_128_NOPAD){
            DESCBCCipher.initIV();
        }
        
        if (Options.MESSAGEDIGEST_ALG_SHA){
            SHAMessageDigest.init();
        }
        // #ifdef_Target32Bit_
        if (Options.CIPHER_ALG_AES_BLOCK_128_CBC_NOPAD){
            AES128CBCCipher.initIV();
        }

        if (Options.MESSAGEDIGEST_ALG_SHA_256){
            SHA256MessageDigest.init();
        }
        // #endif_Target32Bit_
    }
}
