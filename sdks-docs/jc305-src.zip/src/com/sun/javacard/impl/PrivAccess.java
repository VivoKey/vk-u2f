/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.impl;

import javacard.framework.Util;
import javacard.framework.AID;
import javacard.framework.Applet;
import javacard.framework.APDU;
import javacard.framework.JCSystem;
import javacard.framework.Shareable;
import javacard.framework.ISO7816;
import javacard.framework.ISOException;
import javacard.framework.SystemException;
import javacard.framework.MultiSelectable;
import javacard.framework.service.ServiceException;
import javacardx.biometry.BioException;
import javacardx.biometry1toN.Bio1toNException;
import javacardx.framework.tlv.TLVException;
import javacardx.framework.util.UtilException;

/**
 * This static class (no object instances) contains native and non-native
 * methods for the Runtime Environment to control and select applets.
 */
public class PrivAccess {
    public static final byte APP_FIRST = AppletMgr.APP_FIRST;
    public static final byte APPS_MAX = AppletMgr.APPS_MAX;
    public static final byte APP_NULL = AppletMgr.APP_NULL;

    public static final byte JCRE_CONTEXTID = (byte) 0x00;
    public static final byte NULL_CONTEXTID = (byte) 0x0F;
    public static final byte APPID_BITMASK = (byte) 0xF;

    private static final byte BASIC_CHANNEL = (byte) 0x00;

    public static final byte INTERFACE_PRIMARY = (byte) 0;
    public static final byte INTERFACE_SECONDARY = (byte) 1;

    // Context specific constants
    static final byte APPLET_MULTISELECTED = (byte) (0x08);
    static final byte APPLET_ACTIVE = (byte) (0x04);
    static final byte PACKAGE_MULTISELECTED = (byte) 0x02;
    static final byte PACKAGE_ACTIVE = (byte) 0x01;

    // Logical channel operations
    private static final byte OP_CHANNEL_CLOSE = (byte) 0x00;
    private static final byte OP_CHANNEL_OPEN = (byte) 0x01;
    private static final byte OP_CHANNEL_OPEN_AUTOSELECT = (byte) 0x02;

    // Channel status constants
    private static final byte CHANNEL_CLOSED = (byte) 0x00;
    private static final byte CHANNEL_DISABLED = (byte) 0x01;
    private static final byte CHANNEL_OPEN = (byte) 0x02;
    private static final byte CHANNEL_OPEN_MS = (byte) 0x03;

    // Useful constants
    private static final byte CHANNEL_MS_MASK = (byte) 0x01;
    private static final byte CHANNEL_OPEN_MASK = (byte) 0x02;

    // The maximum number of logical channels supported by this
    // implementation is 20 (ISO 7816-4:2013). However, the number of
    // Logical Channels supported by this card might be less, and depends
    // on resource avilability.
    public static final byte NUM_ISO_CHANNELS = (byte) 20;

    private static PackedBoolean thePackedBoolean;
    private static PrivAccess thePrivAccess;
    private static final byte NUMBER_SYSTEM_BOOLS = 24;

    private static byte selectingAppletFlag;
    private static byte processMethodFlag;

    private static byte appCurrentlySelected = (byte) -1;
    private static byte newAppBeingSelected = (byte)-1;
    private static byte newAppBeingSelectedOnChannel = (byte)-1;
    private static byte newAppBeingSelectedOnInterface = (byte)-1;
    private static boolean deselectionInProgress = false;

    /*private static short[] internArraySensitiveResultStateMachine;
    private static short lenInternArrSensitResStateMachine = (short)0x05;*/
    
    /**
     * Singleton constructor. Dispatcher creates
     */
    public PrivAccess() {
        thePrivAccess = this;
    }

    /**
     */
    public static PackedBoolean getPackedBoolean() {
        if (thePackedBoolean == null) {
            thePackedBoolean = new PackedBoolean((byte) (((NUMBER_SYSTEM_BOOLS - 1) >> 3) + 1));
        }
        return thePackedBoolean;
    }

    /**
     */
    /*public static short[] getInternalStateMachineSensitiveResultArray() {
        if (internArraySensitiveResultStateMachine == null) {
            //internArraySensitiveResultStateMachine = JCSystem.makeTransientShortArray(lenInternArrSensitResStateMachine, JCSystem.CLEAR_ON_DESELECT);
            internArraySensitiveResultStateMachine = JCSystem.makeTransientShortArray(lenInternArrSensitResStateMachine, JCSystem.CLEAR_ON_RESET);
        }
        return internArraySensitiveResultStateMachine;
    }*/
    
    /**
     */
    public static PrivAccess getPrivAccess() {
        return thePrivAccess;
    }

    // selection related methods

    public static void setSelectingAppletFlag() {
        thePackedBoolean.set(selectingAppletFlag);
    }

    public static void resetSelectingAppletFlag() {
        thePackedBoolean.reset(selectingAppletFlag);
    }

    // process() method related methods

    public static void setProcessMethodFlag() {
        thePackedBoolean.set(processMethodFlag);
    }

    public static void resetProcessMethodFlag() {
        thePackedBoolean.reset(processMethodFlag);
    }

    /**
     * This method returns the currently selected appId from the currently
     * selected contextId.
     *
     * @param channelId
     *            Logical channel from which we wish to get information from
     * @return the currently selected appId
     */
    public static byte getSelectedAppID(byte channelId, byte interfaceId) {
        byte contextId = NativeMethods.getChannelContext(channelId, interfaceId);
        if (contextId == NULL_CONTEXTID) {
            return APP_NULL;
        }
        return (byte) (contextId & APPID_BITMASK);
    }

    /**
     * This method returns the applet instance of the currently selected applet.
     *
     * @param channelId
     *            Logical channel from which we wish to get information from
     * @return the selected applet instance
     */
    public static Applet getSelectedApplet(byte channelId, byte interfaceId) {
        return AppletMgr.theAppTable[getSelectedAppID(channelId, interfaceId)].theApplet;
    }

    /**
     * Sets the default applet for a channel
     *
     * @param apdu
     *            is the command APDU that contains the channel number and AID
     *            of the applet that is to be made the default applet on that
     *            channel
     */
    public static void setDefaultApplet(APDU apdu) {
        // APDU is formatted in the following fashion
        // CLA = Installer CLA
        // INS = AppletMgr.SET_DEFAULT_APPLET
        // P1 = Channel number
        // P2 = (0 == contacted, 1 == contactless)
        // Lc = AID length
        // Data = AID
        // Le = ignored

        // Assume that the number of contacted and contaless channels is
        // the same, and equal to the number of maximum allowed Logical
        // Channels bythe ISO 7816-4:2013 specification.
        byte numContactedChannels = NUM_ISO_CHANNELS;
        byte numContactlessChannels;

        if (NativeMethods.getCardInterfaceCount() == 2) {
            numContactlessChannels = NUM_ISO_CHANNELS;
        } else {
            numContactlessChannels = 0;
        }

        byte[] buffer = apdu.getBuffer();
        byte channelNumber = buffer[ISO7816.OFFSET_P1];
        if (buffer[ISO7816.OFFSET_P2] != 0 && buffer[ISO7816.OFFSET_P2] != 1) {
            ISOException.throwIt(ISO7816.SW_INCORRECT_P1P2);
        }
        // Check if channel requested is valid
        if (buffer[ISO7816.OFFSET_P2] == (byte) 0) {
            // Check if contacted channel number is valid
            if (channelNumber < 0 || channelNumber >= numContactedChannels) {
                ISOException.throwIt(Errors.INVALID_CHANNEL);
            }
        } else {
            // check if contacted channel number is valid
            if (channelNumber < 0 || channelNumber >= numContactlessChannels) {
                ISOException.throwIt(Errors.INVALID_CHANNEL);
            }
        }
        byte defaultAppletArrayOffset = buffer[ISO7816.OFFSET_P2] == (byte) 0 ? (byte) 0 : numContactedChannels;
        byte aidlength = buffer[ISO7816.OFFSET_LC];

        // get the data
        apdu.setIncomingAndReceive();

        byte appId = AppletMgr.findApplet(buffer, ISO7816.OFFSET_CDATA, aidlength);
        if (appId == APP_NULL) {
            // error: Applet not found
            ISOException.throwIt(Errors.APPLET_NOT_FOUND);
        }
        AppletMgr.defaultApplets[(short) (defaultAppletArrayOffset + channelNumber)] = appId;
    }

    // Get the contactless interface ready for work by
    // selecting the contactless default applet in the
    // basic contactless logical channel
    public static void powerUpContactless() {
        if (NativeMethods.getCardInterfaceCount() == 2) {
            NativeMethods.channelManage(BASIC_CHANNEL, INTERFACE_SECONDARY, OP_CHANNEL_OPEN);
            try {
                selectDefaultApplet(BASIC_CHANNEL, INTERFACE_SECONDARY);
            } catch (Exception ex) {
                // Ignore all exceptions - simply set the context to
                // "NO APPLET SELECTED"
            }
        }
    }

    // Contactless dual interafce shutdown procedure
    // Close all contactless channels and call APplet.deselect(..) or
    // MultiSelectable.deselect(..) on all selected applets in the
    // contactless interface.
    public static void powerDownContactless() {
        if (NativeMethods.getCardInterfaceCount() == 2) {
            for (byte i = BASIC_CHANNEL; i < NUM_ISO_CHANNELS; i++) {
                byte channelStatus = NativeMethods.getChannelStatus(i, INTERFACE_SECONDARY);
                if ((channelStatus == CHANNEL_OPEN) || (channelStatus == CHANNEL_OPEN_MS)) {
                    // Clear transient objects before closing the channel.
                    byte appContextId = NativeMethods.getChannelContext(i, INTERFACE_SECONDARY);
                    byte contextStatus = NativeMethods.getContextStatus(appContextId);
                    // clear CLEAR_ON_DESELECT transient data
                    if ((byte) (contextStatus & PACKAGE_MULTISELECTED) == (byte) 0) {
                        NativeMethods.clearTransientObjs(i, INTERFACE_SECONDARY, JCSystem.CLEAR_ON_DESELECT);
                    }
                    // Do not deselect applets, just close the logical channels
                    NativeMethods.setChannelContext(i, INTERFACE_SECONDARY, NULL_CONTEXTID, false);
                    NativeMethods.channelManage(i, INTERFACE_SECONDARY, OP_CHANNEL_CLOSE);
                }
            }
        }
    }

    /**
     * This method is executed each time the card is reset.
     *
     * @param channelId
     *            Logical channel in which we wish to perfroms the selection
     */
    public static void selectDefaultApplet(byte channelId, byte interfaceId) throws ISOException {
        deselectOnly(channelId, interfaceId);
        byte defaultAppId = AppletMgr.defaultApplets[channelId];
        if (defaultAppId != (byte) (-1)) {
            selectOnly(channelId, interfaceId, defaultAppId);
        }
    }

    /**
     * This method is used by the Dispatcher to precheck about potential
     * multiselection issues with the specified applet on the specified channel.
     * The currently active applet on the channel has not been deselected.
     *
     * @param channelId
     *            Logical channel in which we wish to perfrom the selection
     * @param theAppID
     *            the applet ID to be selected
     * @return true if OK to select; false otherwise
     */
    public static boolean isMultiSelectionOK(byte channelId, byte interfaceId, byte theAppID) {
        Applet appToSelect = AppletMgr.theAppTable[theAppID].theApplet;
        if (appToSelect instanceof MultiSelectable) {
            return true;
        }

        byte theContextID = getContextId(theAppID);
        byte maxChannels = NativeMethods.getMaxChannels();
        byte maxInterfaces = NativeMethods.getCardInterfaceCount();
        byte appContextID = NULL_CONTEXTID;

        for (byte i = (byte) 0; i < maxChannels; i++) {
            for (byte j = (byte) 0; j < maxInterfaces; j++) {
                if (i != channelId) { // currently active applet will be
                    // deselected
                    if (j != interfaceId) {
                        appContextID = NativeMethods.getChannelContext(i, j);
                        // check if context is active on the channel (check high
                        // nibble)
                        if ((appContextID != NULL_CONTEXTID) && (((appContextID ^ theContextID) & 0xF0) == 0)) {
                            return false;
                        }
                    }
                }
            }
        }

        return true;
    }

    /**
     * Select the specified applet. Select APP_NULL on selection failure.
     *
     * @param channelId
     *            Logical channel in which we wish to perfrom the selection
     * @param appID
     *            applet ID to select
     */
    public static void selectOnly(byte channelId, byte interfaceId, byte theAppID) throws ISOException {
        boolean success = false;
        byte appContextId = getContextId(theAppID);
        boolean multiSelectFailed = false;
        byte contextStatus = 0;

        setSelectingAppletFlag();
        try {
            Applet appToSelect = AppletMgr.theAppTable[theAppID].theApplet;
            contextStatus = NativeMethods.getContextStatus(appContextId);

            // Select applet at the specified channel.
            // VM will allocate COD space underneath.
            if (NativeMethods.setChannelContext(channelId, interfaceId, appContextId,
                    (appToSelect instanceof MultiSelectable))) {

                // Perform an execution context switch on the new channel
                NativeMethods.setCurrentlySelectedChannel(channelId, interfaceId);

                // Check for multiselection and call respective select method.
                if ((byte) (contextStatus & PACKAGE_ACTIVE) != (byte) 0) {
                    MultiSelectable msApp = (MultiSelectable) (getSelectedApplet(channelId, interfaceId));
                    success = msApp.select(((byte) (contextStatus & APPLET_ACTIVE) != (byte) 0));
                } else {
                    success = getSelectedApplet(channelId, interfaceId).select();
                }
            } else {
                appCurrentlySelected = -1;
                ISOException.throwIt(ISO7816.SW_CONDITIONS_NOT_SATISFIED);
            }
        } catch (ISOException isoEx) {
            // Rethrow exception so that it can be caught in main
            // Dispatcher loop
            if (isoEx.getReason() == ISO7816.SW_CONDITIONS_NOT_SATISFIED) {
                ISOException.throwIt(isoEx.getReason());
            }
            // Rethrow exception so that it can be caught in main
            // Dispatcher loop
        } catch (SystemException se) {
            appCurrentlySelected = -1;
            // This is the case where a Clear-On-Deselect space is
            // required, but not available.
            if (se.getReason() == SystemException.NO_RESOURCE) {
                ISOException.throwIt(ISO7816.SW_FUNC_NOT_SUPPORTED);
            }
        } catch (Throwable e) {
            // success==false
            appCurrentlySelected = -1;
        }

        // Restore execution context to managing channel's context
        NativeMethods.setCurrentlySelectedChannel(APDU.getCLAChannel(), interfaceId);
        // abort transaction if applet forgot to commit it
        if (JCSystem.getTransactionDepth() != 0) {
            success = false;
            JCSystem.abortTransaction();
        }
        if (success) {
            return;
        }
        appCurrentlySelected = -1;
        // no selected applet if select returns false or throws exception.
        NativeMethods.setChannelContext(channelId, interfaceId, NULL_CONTEXTID, false);
        ISOException.throwIt(ISO7816.SW_APPLET_SELECT_FAILED);
    }

    /**
     * Deselect the currently selected applet.
     *
     * @param channelId
     *            Logical channel in which we wish to perfrom the deselection
     */
    public static void deselectOnly(byte channelId, byte interfaceId) {
        // Return if deselect on null context ID attempted
        if (NativeMethods.getChannelContext(channelId, interfaceId) == NULL_CONTEXTID) {
            return;
        }

        Applet theApp = getSelectedApplet(channelId, interfaceId);
        if (theApp == null) {
            return;
        }

        // Check if applet has to be multiselected-deselected
        byte appContextId = NativeMethods.getChannelContext(channelId, interfaceId);
        // Returns true if context selected more than once
        byte contextStatus = NativeMethods.getContextStatus(appContextId);

        try {
            // Perform an execution context switch on the deselect channel
            NativeMethods.setCurrentlySelectedChannel(channelId, interfaceId);

            // deselect the currently selected applet
            // Check for multiselection and call respective deselect method.
            if ((byte) (contextStatus & PACKAGE_MULTISELECTED) != (byte) 0) {
                MultiSelectable msApp = (MultiSelectable) (getSelectedApplet(channelId, interfaceId));
                msApp.deselect((byte) (contextStatus & APPLET_MULTISELECTED) != (byte) 0);
            } else {
                theApp.deselect();
            }
        } catch (Throwable e) {
            // ignore all exceptions from the deselect
        }

        // Restore execution context to managing channel's context
        NativeMethods.setCurrentlySelectedChannel(APDU.getCLAChannel(), interfaceId);

        // clear CLEAR_ON_DESELECT transient data
        if ((byte) (contextStatus & PACKAGE_MULTISELECTED) == (byte) 0) {
            NativeMethods.clearTransientObjs(channelId, interfaceId, JCSystem.CLEAR_ON_DESELECT);
        }
        // no selected applet if select returns false or throws exception.
        NativeMethods.setChannelContext(channelId, interfaceId, NULL_CONTEXTID, false);
        // abort transaction if applet forgot to commit it
        if (JCSystem.getTransactionDepth() != 0) {
            JCSystem.abortTransaction();
        }
    }

    /**
     * Deselect the currently selected applet and select the specified applet as
     * the new selected applet.
     *
     * @param channelId
     *            Logical channel in which we wish to perfrom the deselection
     * @param appID
     *            applet ID to select
     */
    public static void selectApplet(byte channelID, byte interfaceId, byte theAppID) throws ISOException {
        appCurrentlySelected = PrivAccess.getSelectedAppID(channelID, interfaceId);
        newAppBeingSelected = theAppID;
        newAppBeingSelectedOnInterface = interfaceId;
        newAppBeingSelectedOnChannel = channelID;
        deselectionInProgress = true;
        deselectOnly(channelID, interfaceId);
        deselectionInProgress = false;
        selectOnly(channelID, interfaceId, theAppID);
    }

    // applet state methods

    public static final byte APP_STATE_NONE = (byte) 0;
    public static final byte APP_STATE_REGISTERED = (byte) 1;
    public static final byte APP_STATE_SELECTABLE = (byte) 2;

    /**
     * Get the applet life cycle state of the applet.
     *
     * @param theAID
     *            the AID of the applet.
     * @return state of the applet. See APP_STATE..
     */
    public static byte getAppState(AID theAID) {
        byte appID = AppletMgr.findApplet(theAID);
        if (appID != AppletMgr.APP_NULL) {
            return AppletMgr.theAppState[appID];
        }
        return APP_STATE_NONE;
    }

    /**
     * Set the applet life cycle state of the applet.
     *
     * @param theAID
     *            the AID of the applet
     * @param theState
     *            the new state of the applet.
     */
    public static void setAppState(AID theAID, byte theState) {
        byte appID = AppletMgr.findApplet(theAID);
        AppletMgr.theAppState[appID] = theState;
    }

    // context management utility methods

    /**
     * This method returns the currently active appId from the currently active
     * contextId.
     *
     * @return the currently active appId
     */
    public static byte getCurrentAppID() {
        byte contextId = NativeMethods.getCurrentContext();

        return (byte) (contextId & APPID_BITMASK);
    }

    /**
     * This method returns the previously active appId from the previous active
     * contextId.
     *
     * @return the previously active appId
     */
    public static byte getPreviousAppID() {
        byte contextId = NativeMethods.getPreviousContext();

        return (byte) (contextId & APPID_BITMASK);
    }

    /**
     * Get the ContextId of the applet using the App ID
     *
     * @return ContextId of the applet.
     */
    public static byte getContextId(byte appID) {
        return (byte) (AppletMgr.theAppTable[appID].theContext << 4 | appID);
    }

    // install related methods
    // card initialization

    /**
     * Called by the Dispatcher during card initialization. This method creates
     * the installer applet or other romized apps if the installer is not there.
     * Assumption is that installer applet is the first applet in the applets
     * array in the mask.
     */
    public static void initialize(APDU theAPDU) {
        PackageMgr.init();
        
        // initialize System flag
        selectingAppletFlag = getPackedBoolean().allocate();
        processMethodFlag = getPackedBoolean().allocate();
       
        //internArraySensitiveResultStateMachine = getInternalStateMachineSensitiveResultArray();
        //NativeMethods.sensitiveResultInitialize(internArraySensitiveResultStateMachine);
        
        // the following is to get the actual package ID for the installer
        // applet. We know the context for the installer is going to be 0
        // so we use that to get the actual package ID.
        // This would return -1 if the installer applet is not there
        byte pkgId = PackageMgr.getPkgIdForContext((byte) 0);
        // if pkgId for context 0 is -1, that means that there is no installer applet
        if(pkgId != -1){
            // only create the installer applet
            // installer context is always 0
            createRomizedAppInstance(pkgId, (byte)0, theAPDU);
        }
    }

    static void createRomizedAppInstance(byte pkgId, byte pkgContext, APDU theAPDU){
        // borrow the APDU buffer for temporary scratch pad array
        byte[] bArray = theAPDU.getBuffer();
        short AIDLength = 0;
        short appletCount = (short)PackageMgr.f_pkgTable[pkgId].applets.length;
        for(short i = 0; i < appletCount; i++){
            // reset the apdu buffer
            Util.arrayFillNonAtomic(bArray, (short)0, (short)bArray.length, (byte)0);
            short bOffset = (short) 0;
            javacard.framework.AID aid = PackageMgr.f_pkgTable[pkgId].applets[i].theClassAID;
            // copy the class AID in the APDU buffer
            AIDLength = bOffset = aid.getBytes(bArray, bOffset);
            AppletMgr.currentAppletIndex = (byte)i;
            /*
             * createApplet(byte[] bArray, short bOffset, byte bLength, byte pkgContext)
             */
            AID theAID = AppletMgr.createApplet(bArray, (byte)0, (byte)AIDLength, pkgContext);
            if (theAID != null) {
                setAppState(theAID, PrivAccess.APP_STATE_SELECTABLE);
            }
        }
    }

    // instance methods. The following are Java Card runtime environment entry
    // points.
    // The Java Card runtime environment entry point methods are called from
    // static API methods.

    /**
     * @return true if the system if an applet is begin selected.
     */
    public boolean selectingApplet() {
        return thePackedBoolean.get(selectingAppletFlag);
    }

    public boolean amIBeingReselected(){
        if(deselectionInProgress){
            byte currentAppId = getSelectedAppID(newAppBeingSelectedOnChannel, newAppBeingSelectedOnInterface);
            if(currentAppId == newAppBeingSelected){
                return true;
            }else{
                return false;
            }
        }
        byte newlySelectedApp = PrivAccess.getPreviousAppID();
        return appCurrentlySelected == newlySelectedApp;
    }

    /**
     * @return true if executing in the Applet.process() method.
     */
    public boolean inProcessMethod() {
        return thePackedBoolean.get(processMethodFlag);
    }

    /**
     * Register the applet object with the Class AID as instance AID.
     *
     * @param theApplet
     *            the applet instance
     */
    public final void register(Applet theApplet) {
        AppletMgr.register(theApplet, null);
    }

    /**
     * Register the applet object with with the specified AID as the instance
     * AID.
     *
     * @param theApplet
     *            the applet instance.
     * @param bArray
     *            the byte array containing the AID bytes.
     * @param bOffset
     *            offset in bArray where AID bytes begin
     * @param bLength
     *            length of AID bytes.
     * @return applet instance of the AID object.
     */
    public final void register(Applet theApplet, byte[] bArray, short bOffset, byte bLength) {

        // create new AID to represent applet instance.
        // Mark as permanent Java Card runtime environment Entry Point object
        AID theAID = new AID(bArray, bOffset, bLength);
        NativeMethods.setJCREentry(theAID, false);

        AppletMgr.register(theApplet, theAID);
    }

    /**
     * Get the servers Shareable interface on behalf of the server applet.
     *
     * @param serverAID
     *            AID of the server applet.
     * @param clientAID
     *            AID of the client applet
     * @return Shareable instance from the client or null.
     */
    public Shareable getSharedObject(AID serverAID, byte param) {
        byte clientContext = NativeMethods.getPreviousContext();
        AID clientAID = getAID((byte) (clientContext & APPID_BITMASK));
        if (clientAID == null) {
            return null; // caller is not registered correctly
        }
        byte serverAppID = AppletMgr.findApplet(serverAID);
        if (serverAppID != APP_NULL) {
            if(!(AppletMgr.theAppTable[serverAppID].theApplet instanceof MultiSelectable)){
                byte serverContextId = getContextId(serverAppID);
                if((clientContext & 0xF0) != (serverContextId & 0xF0)){
                    // server from a different package
                    byte contextStatus = NativeMethods.getContextStatus(serverContextId);
                if ((byte) (contextStatus & PACKAGE_ACTIVE) != (byte) 0) {
                    SecurityExceptionHelper.throwSE();
                }
            }
            }
            try {
                return (AppletMgr.theAppTable[serverAppID].theApplet.getShareableInterfaceObject(clientAID, param));
            } catch (Exception ie) {
            }
        }
        return null;
    }

    /**
     * Get the applet AID using the applet instance AID byte array.
     *
     * @param aidArray
     *            the array containing the AID bytes of the applet class.
     * @param aidOff
     *            the offset within aidArray to start
     * @param aidLength
     *            the length of the AID array.
     * @return AID of the applet.
     */
    public AID getAID(byte[] aidArray, short aidOff, byte aidLength) {
        byte appID = AppletMgr.findApplet(aidArray, aidOff, aidLength);
        if (appID != AppletMgr.APP_NULL) {
            return AppletMgr.theAppTable[appID].theAID;
        }

        return null;
    }

    /**
     * Get the AID of the applet using the App ID
     *
     * @return AID of the applet.
     */
    public AID getAID(byte appID) {
        return AppletMgr.theAppTable[appID].theAID;
    }

    /**
     * Gets the package Id for the package that covers a range of addresses that
     * include the address passed to this method as the parameter.
     *
     * @param address
     * @return package Id
     */
    public byte getPkgIDForAddress(int addr) {
        return (PackageMgr.getPkgIDForAddress(addr));
    }

    /**
     * Gets the package name for the package that covers a range of addresses
     * that include the address passed to this method as the parameter. If such
     * a package is found, the package manager sets it's length and name bytes
     * in the buffer and returns the total amount of data set.
     *
     * @param classAddress
     * @param buffer
     * @param offset
     *            is the offset from where the data needs to be set in the
     *            buffer
     * @return Total amount of data set in the buffer
     */
    public byte getPkgNameForClass(int classAddress, byte[] buffer, byte offset) {
        return (PackageMgr.getPkgNameForClass(classAddress, buffer, offset));
    }

    /**
     * Sets the garbage collection requested flag to the value passed as the
     * parameter
     *
     * @param flag
     *            which can be either true or false.
     */
    public void setGCRequestedFlag(boolean flag) {
        if (flag) {
            thePackedBoolean.set(GarbageCollector.GCRequested);
        } else {
            thePackedBoolean.reset(GarbageCollector.GCRequested);
        }
    }

    /**
     * Gets the garbage collection requested flag to the value passed as the
     * parameter
     *
     * @return either true or false depending on the flag value in Packed
     *         Boolean
     */
    public boolean isGarbageCollectionRequested() {
        return thePackedBoolean.get(GarbageCollector.GCRequested);
    }

    public void initBio1ToNException(){
        Bio1toNException ex = new Bio1toNException((short) 0);
        NativeMethods.setJCREentry(ex, true);
    }
    
    public void initBioException(){
        BioException ex = new BioException((short) 0);
        NativeMethods.setJCREentry(ex, true);
    }

    public void initTLVException(){
        TLVException ex = new TLVException((short) 0);
        NativeMethods.setJCREentry(ex, true);
    }

    public void initServiceException(){
        ServiceException ex = new ServiceException((short) 0);
        NativeMethods.setJCREentry(ex, true);
    }

    public short[] initRemoteObjArray(short size) {
        short[] array = new short[size];
        NativeMethods.setJCREentry(array, false); // false = not temporary
        GarbageCollector.setExpObjArray(array);
        return array;
    }
}
