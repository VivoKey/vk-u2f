/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.impl;

import javacard.framework.AID;

class AppletInfo {
    AID theClassAID;
    short installMethodAddr;

    /**
     * Constructor
     * 
     * @param aid
     *            is the class AID of the applet
     * @param methodAddr
     *            is the address of the applet's install method
     */
    public AppletInfo(AID aid, short methodAddr) {
        theClassAID = aid;
        installMethodAddr = methodAddr;
    }
}
