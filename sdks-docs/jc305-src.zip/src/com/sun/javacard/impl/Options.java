/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.sun.javacard.impl;

import static javacard.security.Signature.ALG_AES_CMAC_128;

/**
 *
 * 
 */
public interface Options {
    public static final boolean APDU_PROTOCOL_T0 = true;
    public static final boolean APDU_PROTOCOL_T1 = true;

    // Begin Crypto Constants

    public static final boolean KEYBUILDER_TYPE_DES_TRANSIENT_RESET = true;
    public static final boolean KEYBUILDER_TYPE_DES_TRANSIENT_DESELECT = true;
    public static final boolean KEYBUILDER_TYPE_DES = true;
    public static final boolean KEYBUILDER_TYPE_RSA_PUBLIC = true;
    public static final boolean KEYBUILDER_TYPE_RSA_PRIVATE = true;
    public static final boolean KEYBUILDER_TYPE_RSA_CRT_PRIVATE = true;
    public static final boolean KEYBUILDER_TYPE_DSA_PUBLIC = true;
    public static final boolean KEYBUILDER_TYPE_DSA_PRIVATE = true;
    public static final boolean KEYBUILDER_TYPE_EC_F2M_PUBLIC = true;
    public static final boolean KEYBUILDER_TYPE_EC_F2M_PRIVATE = true;
    public static final boolean KEYBUILDER_TYPE_EC_FP_PUBLIC = true;
    public static final boolean KEYBUILDER_TYPE_EC_FP_PRIVATE = true;
    public static final boolean KEYBUILDER_TYPE_FF_PLAIN_PUBLIC = true;
    public static final boolean KEYBUILDER_TYPE_FF_PLAIN_PRIVATE = true;
    public static final boolean KEYBUILDER_TYPE_AES_TRANSIENT_RESET = true;
    public static final boolean KEYBUILDER_TYPE_AES_TRANSIENT_DESELECT = true;
    public static final boolean KEYBUILDER_TYPE_AES = true;
    public static final boolean KEYBUILDER_TYPE_KOREAN_SEED_TRANSIENT_RESET = true;
    public static final boolean KEYBUILDER_TYPE_KOREAN_SEED_TRANSIENT_DESELECT = true;
    public static final boolean KEYBUILDER_TYPE_KOREAN_SEED = true;
    public static final boolean KEYBUILDER_TYPE_HMAC_TRANSIENT_RESET = true;
    public static final boolean KEYBUILDER_TYPE_HMAC_TRANSIENT_DESELECT = true;
    public static final boolean KEYBUILDER_TYPE_HMAC = true;
    public static final boolean KEYBUILDER_TYPE_RSA_PRIVATE_TRANSIENT_RESET = true;
    public static final boolean KEYBUILDER_TYPE_RSA_PRIVATE_TRANSIENT_DESELECT = true;
    public static final boolean KEYBUILDER_TYPE_RSA_CRT_PRIVATE_TRANSIENT_RESET = true;
    public static final boolean KEYBUILDER_TYPE_RSA_CRT_PRIVATE_TRANSIENT_DESELECT = true;
    public static final boolean KEYBUILDER_TYPE_DSA_PRIVATE_TRANSIENT_RESET = true;
    public static final boolean KEYBUILDER_TYPE_DSA_PRIVATE_TRANSIENT_DESELECT = true;
    public static final boolean KEYBUILDER_TYPE_EC_F2M_PRIVATE_TRANSIENT_RESET = true;
    public static final boolean KEYBUILDER_TYPE_EC_F2M_PRIVATE_TRANSIENT_DESELECT = true;
    public static final boolean KEYBUILDER_TYPE_EC_FP_PRIVATE_TRANSIENT_RESET = true;
    public static final boolean KEYBUILDER_TYPE_EC_FP_PRIVATE_TRANSIENT_DESELECT = true;
    public static final boolean KEYBUILDER_TYPE_EC_FP_PARAMETERS = true;
    
    public static final boolean KEYPAIR_ALG_RSA = true;
    public static final boolean KEYPAIR_ALG_RSA_CRT = true;
    public static final boolean KEYPAIR_ALG_DSA = true;
    public static final boolean KEYPAIR_ALG_EC_F2M = true;
    public static final boolean KEYPAIR_ALG_EC_FP = true;
    public static final boolean KEYPAIR_ALG_FF_PLAIN = true;

    public static final boolean SIGNATURE_ALG_DES_MAC4_NOPAD = true;
    public static final boolean SIGNATURE_ALG_DES_MAC8_NOPAD = true;
    public static final boolean SIGNATURE_ALG_DES_MAC4_ISO9797_M1 = true;
    public static final boolean SIGNATURE_ALG_DES_MAC8_ISO9797_M1 = true;
    public static final boolean SIGNATURE_ALG_DES_MAC4_ISO9797_M2 = true;
    public static final boolean SIGNATURE_ALG_DES_MAC8_ISO9797_M2 = true;
    public static final boolean SIGNATURE_ALG_DES_MAC4_PKCS5 = true;
    public static final boolean SIGNATURE_ALG_DES_MAC8_PKCS5 = true;
    public static final boolean SIGNATURE_ALG_RSA_SHA_ISO9796 = true;
    public static final boolean SIGNATURE_ALG_RSA_SHA_PKCS1 = true;
    public static final boolean SIGNATURE_ALG_RSA_MD5_PKCS1 = true;
    public static final boolean SIGNATURE_ALG_RSA_RIPEMD160_ISO9796 = true;
    public static final boolean SIGNATURE_ALG_RSA_RIPEMD160_PKCS1 = true;
    public static final boolean SIGNATURE_ALG_DSA_SHA = true;
    public static final boolean SIGNATURE_ALG_RSA_SHA_RFC2409 = true;
    public static final boolean SIGNATURE_ALG_RSA_MD5_RFC2409 = true;
    public static final boolean SIGNATURE_ALG_ECDSA_SHA = true;
    public static final boolean SIGNATURE_ALG_AES_MAC_128_NOPAD = true;
    public static final boolean SIGNATURE_ALG_AES_CMAC_128 = true;
    public static final boolean SIGNATURE_ALG_DES_MAC4_ISO9797_1_M2_ALG3 = true;
    public static final boolean SIGNATURE_ALG_DES_MAC8_ISO9797_1_M2_ALG3 = true;
    public static final boolean SIGNATURE_ALG_RSA_SHA_PKCS1_PSS = true;
    public static final boolean SIGNATURE_ALG_RSA_MD5_PKCS1_PSS = true;
    public static final boolean SIGNATURE_ALG_RSA_RIPEMD160_PKCS1_PSS = true;
    public static final boolean SIGNATURE_ALG_HMAC_SHA1 = true;
    public static final boolean SIGNATURE_ALG_HMAC_SHA_256 = true;
    public static final boolean SIGNATURE_ALG_HMAC_SHA_384 = true;
    public static final boolean SIGNATURE_ALG_HMAC_SHA_512 = true;
    public static final boolean SIGNATURE_ALG_HMAC_MD5 = true;
    public static final boolean SIGNATURE_ALG_HMAC_RIPEMD160 = true;
    public static final boolean SIGNATURE_ALG_RSA_SHA_ISO9796_MR = true;
    public static final boolean SIGNATURE_ALG_RSA_RIPEMD160_ISO9796_MR = true;
    public static final boolean SIGNATURE_ALG_KOREAN_SEED_MAC_NOPAD = true;
    public static final boolean SIGNATURE_ALG_ECDSA_SHA_256 = true;
    public static final boolean SIGNATURE_ALG_ECDSA_SHA_384 = true;
    public static final boolean SIGNATURE_ALG_AES_MAC_192_NOPAD = true;
    public static final boolean SIGNATURE_ALG_AES_MAC_256_NOPAD = true;
    public static final boolean SIGNATURE_ALG_ECDSA_SHA_224 = true;
    public static final boolean SIGNATURE_ALG_ECDSA_SHA_512 = true;
    public static final boolean SIGNATURE_ALG_RSA_SHA_224_PKCS1 = true;
    public static final boolean SIGNATURE_ALG_RSA_SHA_256_PKCS1 = true;
    public static final boolean SIGNATURE_ALG_RSA_SHA_384_PKCS1 = true;
    public static final boolean SIGNATURE_ALG_RSA_SHA_512_PKCS1 = true;
    public static final boolean SIGNATURE_ALG_RSA_SHA_224_PKCS1_PSS = true;
    public static final boolean SIGNATURE_ALG_RSA_SHA_256_PKCS1_PSS = true;
    public static final boolean SIGNATURE_ALG_RSA_SHA_384_PKCS1_PSS = true;
    public static final boolean SIGNATURE_ALG_RSA_SHA_512_PKCS1_PSS = true;

    public static final boolean CHECKSUM_ALG_ISO3309_CRC16 = true;
    public static final boolean CHECKSUM_ALG_ISO3309_CRC32 = true;

    public static final boolean RANDOMDATA_ALG_PSEUDO_RANDOM = true;
    public static final boolean RANDOMDATA_ALG_SECURE_RANDOM = true;

    public static final boolean MESSAGEDIGEST_ALG_SHA = true
                                                        || SIGNATURE_ALG_RSA_SHA_ISO9796_MR
                                                        || SIGNATURE_ALG_RSA_SHA_PKCS1
                                                        || SIGNATURE_ALG_ECDSA_SHA;
    public static final boolean MESSAGEDIGEST_ALG_MD5 = true;
    public static final boolean MESSAGEDIGEST_ALG_RIPEMD160 = true;
    public static final boolean MESSAGEDIGEST_ALG_SHA_256 = true;
    public static final boolean MESSAGEDIGEST_ALG_SHA_384 = true;
    public static final boolean MESSAGEDIGEST_ALG_SHA_512 = true;
    public static final boolean MESSAGEDIGEST_ALG_SHA_224 = true;

    public static final boolean KEYAGREEMENT_ALG_FF_SVDP_DH = true;
    public static final boolean KEYAGREEMENT_ALG_EC_SVDP_DH = true;
    public static final boolean KEYAGREEMENT_ALG_EC_SVDP_DH_KDF = true;
    public static final boolean KEYAGREEMENT_ALG_EC_SVDP_DHC = true;
    public static final boolean KEYAGREEMENT_ALG_EC_PACE_GM = true;
    public static final boolean KEYAGREEMENT_ALG_EC_SVDP_DH_PLAIN_XY = true;
    public static final boolean KEYAGREEMENT_ALG_EC_SVDP_DHC_KDF = true;
    public static final boolean KEYAGREEMENT_ALG_EC_SVDP_DH_PLAIN = true;
    public static final boolean KEYAGREEMENT_ALG_EC_SVDP_DHC_PLAIN = true;

    public static final boolean CIPHER_ALG_DES_CBC_NOPAD = true;
    public static final boolean CIPHER_ALG_DES_CBC_ISO9797_M1 = true;
    public static final boolean CIPHER_ALG_DES_CBC_ISO9797_M2 = true
                                                                || SIGNATURE_ALG_DES_MAC8_ISO9797_M2
                                                                || SIGNATURE_ALG_AES_MAC_128_NOPAD;
    public static final boolean CIPHER_ALG_DES_CBC_PKCS5 = true;
    public static final boolean CIPHER_ALG_DES_ECB_NOPAD = true;
    public static final boolean CIPHER_ALG_DES_ECB_ISO9797_M1 = true;
    public static final boolean CIPHER_ALG_DES_ECB_ISO9797_M2 = true;
    public static final boolean CIPHER_ALG_DES_ECB_PKCS5 = true;
    public static final boolean CIPHER_ALG_RSA_ISO14888 = true;
    public static final boolean CIPHER_ALG_RSA_PKCS1 = true;
    public static final boolean CIPHER_ALG_RSA_ISO9796 = true;
    public static final boolean CIPHER_ALG_RSA_NOPAD = true;
    public static final boolean CIPHER_ALG_AES_BLOCK_128_CBC_NOPAD = true;
    public static final boolean CIPHER_ALG_AES_BLOCK_128_ECB_NOPAD = true;
    public static final boolean CIPHER_ALG_RSA_PKCS1_OAEP = true;
    public static final boolean CIPHER_ALG_KOREAN_SEED_ECB_NOPAD = true;
    public static final boolean CIPHER_ALG_KOREAN_SEED_CBC_NOPAD = true;
    public static final boolean CIPHER_ALG_AES_BLOCK_192_CBC_NOPAD = true;
    public static final boolean CIPHER_ALG_AES_BLOCK_192_ECB_NOPAD = true;
    public static final boolean CIPHER_ALG_AES_BLOCK_256_CBC_NOPAD = true;
    public static final boolean CIPHER_ALG_AES_BLOCK_256_ECB_NOPAD = true;
    public static final boolean CIPHER_ALG_AES_CBC_ISO9797_M1 = true;
    public static final boolean CIPHER_ALG_AES_CBC_ISO9797_M2 = true;
    public static final boolean CIPHER_ALG_AES_CBC_PKCS5 = true;
    public static final boolean CIPHER_ALG_AES_ECB_ISO9797_M1 = true;
    public static final boolean CIPHER_ALG_AES_ECB_ISO9797_M2 = true;
    public static final boolean CIPHER_ALG_AES_ECB_PKCS5 = true;
    public static final boolean CIPHER_ALG_AES_CCM = true;
    public static final boolean CIPHER_ALG_AES_GCM = true;
}
