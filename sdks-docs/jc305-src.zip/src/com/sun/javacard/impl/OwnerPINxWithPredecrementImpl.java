/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */
package com.sun.javacard.impl;

import javacard.framework.JCSystem;
import javacard.framework.OwnerPINxWithPredecrement;
import javacard.framework.PINException;
import javacard.framework.Util;

/**
 *
 * 
 */
public class OwnerPINxWithPredecrementImpl implements OwnerPINxWithPredecrement{
    
    private byte tryLimit;
    private byte maxPINSize;
    private byte[] pinValue;
    private byte pinSize;
    private boolean[] flags; // default null
    private static final byte VALIDATED = (byte) 0;
    private static final byte PREDECREMENTED = (byte) 1;
    private static final byte NUMFLAGS = (byte) (PREDECREMENTED + 1);
    
    private boolean getValidatedFlag() {
        return flags[VALIDATED];
    }

    private void setValidatedFlag(boolean value) {
        flags[VALIDATED] = value;
    }
    
    private void setPredecrementedFlag(boolean value) {
        flags[PREDECREMENTED] = value;
    }

    private byte[] triesLeft;

    private void resetTriesRemaining() {
        Util.arrayFillNonAtomic(triesLeft, (short) 0, (short) 1, tryLimit);
    }

    private void decrementTriesRemainingInternal() {
        Util.arrayFillNonAtomic(triesLeft, (short) 0, (short) 1, (byte) (triesLeft[0] - 1));
    }

    public OwnerPINxWithPredecrementImpl(byte tryLimit, byte maxPINSize) throws PINException {

        if ((tryLimit < 1) || (maxPINSize < 1)) {
            PINException.throwIt(PINException.ILLEGAL_VALUE);
        }
        pinValue = new byte[maxPINSize]; // default value 0
        this.pinSize = maxPINSize; // default
        this.maxPINSize = maxPINSize;
        this.tryLimit = tryLimit;

        triesLeft = new byte[1];
        resetTriesRemaining();

        flags = JCSystem.makeTransientBooleanArray(NUMFLAGS, JCSystem.CLEAR_ON_RESET);
        setValidatedFlag(false);
        setPredecrementedFlag(false);
    }

    public byte getTriesRemaining() {
        byte result = (triesLeft[0] < 0 ? (byte)0 : triesLeft[0]);
        NativeMethods.sensitiveResultSet(result);
        return result;
    }

    public boolean check(byte[] pin, short offset, byte length) throws ArrayIndexOutOfBoundsException,
            NullPointerException {

        if(!flags[PREDECREMENTED]){
           PINException.throwIt(PINException.ILLEGAL_STATE);
        }
        
        setValidatedFlag(false);
        setPredecrementedFlag(false);
        
        if(triesLeft[0] < 0){
            NativeMethods.sensitiveResultSetBooleanFalse();
            return false;
        }
        
        if (length > 0) {
            byte tester = pin[(short) (offset + length - 1)];
            if (length != pinSize) {
                NativeMethods.sensitiveResultSetBooleanFalse();
                return false;
            }
        }

        if ((Util.arrayCompare(pin, offset, pinValue, (short) 0, length) == (byte) 0) && (length == pinSize)) {
            setValidatedFlag(true);
            resetTriesRemaining();
            NativeMethods.sensitiveResultSetBooleanTrue();
            return true;
        }
        
        NativeMethods.sensitiveResultSetBooleanFalse();
        return false;
    }

    public boolean isValidated() {
        boolean result = getValidatedFlag();
        
        if (result)
            NativeMethods.sensitiveResultSetBooleanTrue();
        else
            NativeMethods.sensitiveResultSetBooleanFalse();
        
        return result;
    }

    public void reset() {
        setPredecrementedFlag(false);
        if (isValidated()) {
            resetAndUnblock();
        }
    }

    public void update(byte[] pin, short offset, byte length) throws PINException {
        if (length > maxPINSize) {
            PINException.throwIt(PINException.ILLEGAL_VALUE);
        }
        Util.arrayCopy(pin, offset, pinValue, (short) 0, length);
        pinSize = length;
        triesLeft[0] = tryLimit;
        setValidatedFlag(false);
        setPredecrementedFlag(false);
    }

    public void resetAndUnblock() {
        resetTriesRemaining();
        setValidatedFlag(false);
        setPredecrementedFlag(false);
    }

    public byte getTryLimit() {
        byte result = tryLimit;
        NativeMethods.sensitiveResultSet(result);
        return result;
    }

    public void setTryLimit(byte limit) {
        if (limit < 1) {
            PINException.throwIt(PINException.ILLEGAL_VALUE);
        }
        setValidatedFlag(false);
        setPredecrementedFlag(false);
        this.tryLimit = limit;
        resetTriesRemaining();
    }

    public void setTriesRemaining(byte remaining) {
        if((remaining < 0) || (remaining > tryLimit)){
            PINException.throwIt(PINException.ILLEGAL_VALUE);
        }
        setValidatedFlag(false);
        setPredecrementedFlag(false);
        Util.arrayFillNonAtomic(triesLeft, (short) 0, (short) 1, remaining);
    }

    public byte decrementTriesRemaining() {
        if(triesLeft[0] >= 0){
            decrementTriesRemainingInternal();
        }
        setPredecrementedFlag(true);
        setValidatedFlag(false);
        return getTriesRemaining();
    }
    
}
