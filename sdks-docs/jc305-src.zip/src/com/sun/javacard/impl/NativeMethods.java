/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package com.sun.javacard.impl;

import javacard.framework.SystemException;

public class NativeMethods {

    // T=1 I/O Methods

  // #ifdef_Target32Bit_

    /**
     * This method sends a T=1 block data in the APDU buffer specified bythe
     * offset and length passed, and waits for acknowledgement transmission,
     * without copying any data that might come along on that transmission. On
     * dual interface cards, the acknowledgement might come from a different
     * interface if the interface is not locked. Only Java Card runtime
     * environment can invoke this method.
     *
     * @param blockOffset
     *            offset in APDU buffer where data to be sent is.
     * @param blockLen
     *            data length to send.
     * @param isLastBlock
     *            <br>
     *            true</br> if this is the last block of data to send to
     *            terminal, <br>
     *            false</br> otherwise.
     * @return 0 on success, other value in error.
     */
    public static native short t1SndBlockRcvAck(short blockOffset, short blockLen, boolean isLastBlock,
            boolean switchInterfaces);

    /**
     * This method receives a T=1 block of data - if none are pending - or
     * copies the data of an already- received block into the APDU buffer at the
     * offset specified. If the data cannot fit into the APDU buffer, the
     * remaining data will be copied the next time this method is called. Only
     * Java Card runtime environment can invoke this method.
     *
     * @param blockOffset
     *            offset in APDU buffer where data is to be received.
     * @param dataLimit
     *            maxium amount of data to receive
     * @return number of bytes received on success, negative values on error.
     */
    public static native short t1RcvBlock(short blockOffset, short dataLimit);

    /**
     * This method is used to discard any remaining incoming data if the applet
     * has called setOutgoing() method without receiving all the incoming data
     * first. Only Java Card runtime environment can invoke this method.
     *
     * @param numBytesExpected
     *            Number of bytes expected from the terminal side.
     * @param numBytesReceived
     *            Number of bytes already received from the terminal side
     * @return value for Le
     */
    public static native short t1RcvAndDiscardData(short numBytesExpected, short numBytesReceived);

    /**
     * This method initiates a T=1 abort sequence to indicate the terminal not
     * to send any more incoming data, and be ready for outgoing data. Only Java
     * Card runtime environment can invoke this method.
     *
     * @return 0 on success.
     */
    public static native short t1Abort();

    /**
     * This method initiates a T=1 wait sequence to indicate the terminal that
     * more time is required to process input, and thus avoid a timeout. Only
     * Java Card runtime environment can invoke this method.
     *
     * @return 0 on success.
     */
    public static native short t1Wait();

    /**
     * This method returns the T=1 NAD byte for the last block received. Only
     * Java Card runtime environment can invoke this method.
     *
     * @return T=1 NAD value.
     */
    public static native byte t1GetNAD();

    /**
     * This method returns <br>
     * true</br> if the last T=1 block in a chain has been received (i.e. block
     * with the M bit set to 1), <br>
     * false</br> otherwise. Only Java Card runtime environment can invoke this
     * method.
     *
     * @return <br>
     *         true</br> if last block recevied, <br>
     *         false</br> otherwise.
     */
    public static native boolean t1LastBlockReceived();

    /**
     * This method returns the T=1 maximum supported card Information Field
     * block size (IFSC). Only Java Card runtime environment can invoke this
     * method.
     *
     * @return T=1 IFSC value.
     */
    public static native short t1GetIFSC();

    /**
     * This method returns the T=1 maximum supported device Information Field
     * block size (IFSD). Only Java Card runtime environment can invoke this
     * method.
     *
     * @return T=1 IFSD value.
     */
    public static native short t1GetIFSD();

    /**
     * Returns the event associated with the secondary interface. This event can
     * be a power-up, a power-down or none. This call clears the event as well.
     * Only Java Card runtime environment can invoke this method.
     *
     * @return Event asociated with the card's secondary interface.
     */
    public static native byte getSecondaryInterfaceEvent();

    // #endif_Target32Bit_

    /**
     * This method returns the communication protocol associated with the
     * currently active interface (i.e. the interface where the last APDU was
     * recevied). Only Java Card runtime environment can invoke this method.
     *
     * @param activeInterface
     *            active interface ID
     * @return 0 for T=0, 1 for T=1, and 0x91 for T=CL.
     */
    public static native byte getCommProtocol(byte activeInterface);

    /**
     * This method returns the currently active interface in the smart card. The
     * active interface is that wehre the last APDU was received. Only Java Card
     * runtime environment can invoke this method.
     *
     * @return 0 if the primary interface is active, 1 if the secondary
     *         interface is active. Both interfaces are mutually actively
     *         exclusive.
     */
    public static native byte getActiveInterface();

    /**
     * Returns the number of active interafces in this card. Interafce 0 is the
     * primary, interafce 1 is the secondary. Only Java Card runtime environment
     * can invoke this method.
     *
     * @return Number of interafces active in this card.
     */
    public static native byte getCardInterfaceCount();

    //
    // T=0 I/O Methods
    //

    /**
     * This method receives a five byte T=0 protocol command APDU into the APDU
     * buffer. This method is invoked following the ATR before starting the send
     * and receive cycle. Only Java Card runtime environment can invoke this
     * method.
     *
     * @return 0 on success; 0xC0xx on error.
     */
    public static native short t0RcvCommand();

    /**
     * This method sends the previously logged status bytes and receives a five
     * byte T=0 protocol command APDU into the APDU buffer. Only Java Card
     * runtime environment can invoke this method.
     *
     * @param command
     *            the byte array to receive into. Must be >= 5 bytes long.
     * @return 0 on success; 0xC0xx on error.
     */
    public static native short t0SndStatusRcvCommand();

    /**
     * This method is used to receive as much data portion of a T=0 protocol
     * APDU as will fit into the APDU buffer safely. Only Java Card runtime
     * environment can invoke this method.
     *
     * @param offset
     *            the offset within the APDU buffer array to start.
     * @return byte count < 256 on success; 0xC0xx on error.
     */
    public static native short t0RcvData(short offset);

    /**
     * This method is used to send the data portion of a T=0 protocol APDU. The
     * procedure byte to be used prior to sending the data is passed as a
     * parameter. The length parameter should be consistent with the procedure
     * byte parameter used. Only Java Card runtime environment can invoke this
     * method.
     *
     * @param data
     *            the byte array to send from.
     * @param offset
     *            the offset within the array to start.
     * @param length
     *            the length of the data bytes to be sent.
     * @param procByteType =
     *            0 (no procByte), 1 (INS), 2 (~INS)
     * @return 0 on success; 0xC0xx on error.
     */
    public static native short t0SndData(byte[] data, short offset, short length, byte procByteType);

    /**
     * This method is used to send the previously logged 61xx status, followed
     * by reception of the subsequent GET RESPONSE APDU from the IFD. Only Java
     * Card runtime environment can invoke this method.
     *
     * @return GET RESPONSE P3 value; 0xC006 if no GET RESPONSE; 0xC0xx on
     *         error.
     */
    public static native short t0SndGetResponse(byte channelId);

    /**
     * This method is used to request a wait time extension from the IFD. Only
     * Java Card runtime environment can invoke this method.
     *
     * @return 0 on success; 0xC0xx on error.
     */
    public static native short t0Wait();

    /**
     * This method copies the content of the scratch buffer into the APDU
     * buffer, so that the applet has a consistent view of the APDU without
     * receiving protocol scratch exchanges. Only Java Card runtime environment
     * can invoke this method.
     */
    public static native void t0CopyToAPDUBuffer(short offset, short length);

    /**
     * This method returns a APDU buffer byte array object, initializing it for
     * use with the T=0 protocol. Only Java Card runtime environment can invoke
     * this method.
     *
     * @return APDU buffer byte array on success; null on error.
     */
    public static native byte[] initAPDUBuffer();

    /**
     * This method returns a scratch APDU buffer byte array object, initializing
     * it for use with the T=0 protocol. Only Java Card runtime environment can
     * invoke this method.
     *
     * @return Scratch APDU buffer byte array on success; null on error.
     */
    public static native byte[] t0InitScratchAPDUBuffer();

    /**
     * This method is called to set the APDU response status to be sent. Only
     * Java Card runtime environment can invoke this method.
     *
     * @param sw1Sw2
     *            the 61xx status bytes to be sent.
     * @return 0 on success; 0xC0xx on error.
     */
    public static native short t0SetStatus(short sw1Sw2);

    //
    // Transience management methods
    //

    /**
     * Called from Dispatcher to clear transient objects.
     *
     * @param channelId
     *            the logical channel to which the operation will apply.
     * @param interfaceId
     *            the interface where this action was triggered
     * @param event
     *            the event which caused the array elements to be cleared.
     */
    public static native void clearTransientObjs(byte channelId, byte interfaceId, byte event);

    /**
     * Called from AppletMgr when an applet creation fails. This method removes
     * references to objects that were created during applet creation from RTR
     * arrays since those objects no longer exist (because of applet creation
     * failure)
     */
    public static native void clearInvalidTransientReferences();

    //
    // Firewall Management methods
    // Format of contextId byte = 4 bits of context | 4 bits of applet id.
    //

    /**
     * This method is called to set the current selected applet's contextId at
     * the logical channel specified as parameter. This contextId is used by the
     * VM to check access to CLEAR_ON_DESELECT transient objects. It is also
     * used to restrict the creation of CLEAR_ON_DESELECT transient objects.
     * CLEAR_ON_DESELECT objects can only be created or accessed when the
     * currently selected applet's context is the currently active context. The
     * multi-selection information is used by the Java Card runtime environment
     * to enforce selection rules regarding applets from the same package being
     * active on different logical channels. When allocating a context, the Java
     * Card runtime environment also allocates or assigns a CLEAR_ON_DESELECT
     * space to the current context. When setting the "no applet selected"
     * context (ID = 0x0F) the CLEAR_ON_DESELECT space is automatically
     * deallocated.
     *
     * @param channelId
     *            the logical channel where the applet is being selected
     * @param interfaceId
     *            the interface where the channel is assigned to
     * @param contextId
     *            the contextId of selected applet
     * @param isMultiSelectable
     *            flag that specifies whether this applet belongs to a
     *            multiselectable package or not.
     * @return <b>true</b> if channel context set successfully, <b>false</b>
     *         otherwise.
     */
    public static native boolean setChannelContext(byte channelId, byte interfaceId, byte contextId,
            boolean isMultiSelectable);

    /**
     * This method returns the current selected applet's contextId, at the
     * logical channel specified as parameter. This contextId is used by the VM
     * to check access to CLEAR_ON_DESELECT transient objects. It is also used
     * to restrict the creation of CLEAR_ON_DESELECT transient objects.
     *
     * @param channelId
     *            the desired logical channel
     * @param interfaceId
     *            the interface where the channel is assigned to
     * @return the selected applet's contextId
     */
    public static native byte getChannelContext(byte channelId, byte interfaceId);

    /**
     * This method returns the currently active contextId. ContextId is used by
     * the VM to enforce the firewall access checking. This method is used by
     * JCSystem to implement the <code>getAID()</code> method. Note that this
     * method is called from the Java Card runtime environment context and must
     * return the contextId in the last stack frame.
     *
     * @return the currently active contextId
     */
    public static native byte getCurrentContext();

    /**
     * This method returns the previously active contextId. The contextId that
     * is returned is the contextId value at the time of the last context
     * switch. This method is used by JCSystem to implement the
     * <code>getPreviousContextAID()</code> and the
     * <code>getAppletShareableInterface()</code> methods. Note that this
     * method is called from the Java Card runtime environment context and must
     * begin searching for a change in the context nibble starting with the last
     * stack frame.
     *
     * @return the previously active contextId
     */
    public static native byte getPreviousContext();

    /**
     * This method checks if access is to be allowed to the object being passed
     * to it from the previous context. This method just returns if the access
     * to the object from the previous context (this can be if the previous
     * context is either Java Card runtime environment or object owner's
     * context) is okay, otherwise it throws a security exception. It is assumed
     * that the object being passed to this method is not null and proper
     * precautions have been taken regarding this before this method is called.
     * This method's behaviour is non-deterministic if the object passed to it
     * is null.
     *
     * @param theObject
     *            for which it is to be determined if the access from the
     *            previous context should be allowed.
     */
    public static native void checkPreviousContextAccess(Object theObject);

    /**
     * This method is called to mark the specified object as being a Java Card
     * runtime environment entry point object. Java Card runtime environment
     * entry point objects' methods are accessible from any applet context. In
     * addition, the the Java Card runtime environment Entry point object is
     * marked as temporary or permanent based on the boolean parameter. User
     * applets cannot store temporary Entry Point Objects in class variables or
     * array components. This method is also used for global arrays.
     *
     * @param theObject
     *            the object to be marked as a Java Card runtime environment
     *            Entry point object
     * @param temporary
     *            <code>true<code> if the Java Card runtime environment Entry point object is a
     * temporary Java Card runtime environment EP object.
     */
    public static native void setJCREentry(Object theObject, boolean temporary);

    /**
     * This method is called to set the owner context of the object referenced
     * by the parameter to the specified contextId parameter. This method is
     * used by the installer to stamp the owner context on <clinit> initialized
     * arrays created by the Installer on behalf of the applet package.
     *
     * @param clinitArray
     *            the object on which to set owner contextId
     * @param contextId
     *            the contextId to assign to the the
     *            <code>clinitArray<code> object
     */
    public static native void setObjectContext(Object clinitArray, byte contextId);
    
    public static native short getObjectContext(Object clinitArray);

    // Logical channels support native methods

    /**
     * This method is used to open and close logical channels in the card.
     * Operations can be open channel, close channel open autoselect channel.
     *
     * @param channelId
     *            the channel to be managed, or ignored for open autoselect.
     * @param interfaceId
     *            the interface where the channel is assigned to
     * @param operation
     *            the operation to perform on the target channel.
     * @return 0 or -1 in case of success/failure, or channelId in case of
     *         autoselect.
     */
    public static native byte channelManage(byte channelId, byte interfaceId, byte operation);

    /**
     * This method is used to query the status of a logical channel in the card.
     * Channel status can be open, open multiselected, closed, or deactivated.
     *
     * @param channelId
     *            the channel whose status is desired.
     * @param interfaceId
     *            the interface where the channel is assigned to
     * @return logical channel status code.
     */
    public static native byte getChannelStatus(byte channelId, byte interafceId);

    /**
     * This method returns the maximum number of ISO 7816-4 compliant logical
     * channels supported in the smart card.
     *
     * @return maximum number of channels supported.
     */
    public static native byte getMaxChannels();

    /**
     * This method is used to query the status of a particular applet context.
     * Applet contexts can be package active, package active multiselected,
     * applet active, applet active multiselected, or inactive.
     *
     * @param contextId
     *            the applet context whose status is desired.
     * @return logical channel status code.
     */
    public static native byte getContextStatus(byte contextId);

    /**
     * This method sets the currently selected logical channel in the card. The
     * currently selected channel is the channel where the current APDU command
     * is targeted to. All CLEAR_ON_DESELECT transient array accesses are only
     * allowed to the active package in the currently selected channel.
     *
     * @param channelId
     *            the logical channel to be specified as currently selected
     * @param interafceId
     *            the interface where the channel we are running is
     */
    public static native void setCurrentlySelectedChannel(byte channelId, byte interfaceId);

    /**
     * This method returns the currently selected logical channel in the card.
     * The currently selected channel is the channel where the current APDU
     * command is targeted to.
     *
     * @return the currently selected channel in the card.
     */
    public static native byte getCurrentlySelectedChannel();

    //
    // Installer Mask Access methods
    //

    /**
     * This method returns the highest package identifier allocated to the
     * packages in the ROM mask. Package ids are used for context assignment.
     * This method is used by the Installer to manage its Package management
     * tables and for package id assignment for installed packages. Package ids
     * are used as contexts.
     *
     * @return the highest package identifier in ROM.
     */
    public static native byte getMaxPackageIdentifier();

    /**
     * This method returns the address to the export component associated with
     * the specified pacakge identifier. This method is used by the installer to
     * resolve classes, methods and fields accessed in the ROM package.
     *
     * @param packageId
     *            the package identifier in ROM
     * @return the address of associated export component or -1 if not found.
     */
    public static native int getPackageExportComponent(byte packageId);

    //
    // Installer Memory Management Methods
    //

    /**
     * This method starts a transaction once it has been made sure that no
     * transaction is started by the installer to call the install method of an
     * applet.
     */
    public static native void beginTransactionNative() throws javacard.framework.TransactionException;

    /**
     * This method commits a transaction once it has been made sure that no
     * transaction is started by the installer to call the install method of an
     * applet.
     */
    public static native void commitTransactionNative() throws javacard.framework.TransactionException;

    /**
     * This method aborts a transaction once it has been made sure that no
     * transaction is started by the installer to call the install method of an
     * applet.
     */
    public static native void abortTransactionNative() throws javacard.framework.TransactionException;

    /**
     * This method allocates EEPROM heap space for the specified number of bytes
     * and returns the associated address. The address returned is used in the
     * read, write, copy methods by the Installer to download and install a CAP
     * file. The Installer may use the returned address in a later call to the
     * <code>restore()</code> method to restore heap to the state at the time
     * of invoking this method.
     *
     * @param chunkSize
     *            the byte length of heap space to allocate
     * @return the address of allocated heap space or 0 on failure.
     */
    public static native int allocate(short chunkSize);

    /**
     * This method frees EEPROM heap space for the specified number of bytes and
     * the specified address. The space is then added to the heap table for
     * later allocations.
     *
     * @param address
     *            the address of the memory to be freed.
     * @param length
     *            the length in bytes of the memory to be returned.
     */
    public static native void freeHeap(int address, short length);

    /**
     * the next three methods will return the amount of memory left in the three
     * memory pools E2P_Available returns the amount of available E2P memory
     * rtr_Available() returns the amount of clear on reset transient memory
     * available dtr_Available() returns the amount of clear on deselect
     * transient memory available
     *
     * @retun the amount of memory avaiable in bytes.
     */
    public static native short E2P_Available();

    public static native short dtr_Available();

    public static native short rtr_Available();

    public static native void availableEEPROM(short[] outputBuffer, short offset);

    /**
     * This method writes the specified <code>data</code> byte at the
     * specified byte <code>offset</code> relative the the specified
     * <code>address</code>.
     *
     * @param address
     *            the address to the heap space to reference
     * @param offset
     *            the byte offset relative to the specified address to write.
     * @param data
     *            the byte value to deposit at that specified offset.
     */
    public static native void writeByte(int address, short offset, byte data);

    /**
     * This method writes the bytes comprising the high and low byte
     * respectively of the specified short <code>data</code> parameter value
     * at the specified byte <code>offset</code> relative the the specified
     * <code>address</code>.
     *
     * @param address
     *            the address to the heap space to reference
     * @param offset
     *            the byte offset relative to the specified address to write.
     * @param data
     *            the short value to deposit at that specified offset.
     */
    public static native void writeShort(int address, short offset, short data);

    /**
     * It checks the Method.cap component from Applet CAP file (see Chapter 6
     * of JCVM 3.x Classic Edition specifications - 6.9 Method Component). This
     * method is used by the Installer to deposit CAP file data into the heap
     * area allocated using the <code>allocate()</code> method.
     *
     * @param addressMethodComponent
     *            method_component address.
     * @param sizeMethodComponent
     *            method_component size.
     * @param addressMethodInfo
     *            method_info address.
     * @return <code>void</code> but may throw SECURITY_EXCEPTION if a logical 
     * attack is detected.
     */
    public static native short checkMethod(int addressMethodComponent, int sizeMethodComponent, int addressMethodInfo);
    
    /**
     * Copies the specified number of bytes, from the specified source array,
     * beginning at the specified position, to the destination location
     * specified by the address and the address relative byte offset. This
     * method is used by the Installer to deposit CAP file data into the heap
     * area allocated using the <code>allocate()</code> method.
     *
     * @param src
     *            source byte array.
     * @param srcOff
     *            offset within source byte array to start copy from.
     * @param address
     *            the destination address to the heap space to reference.
     * @param offset
     *            the byte offset relative to the specified address to start
     *            copy into.
     * @param length
     *            byte length to be copied.
     * @return <code>offset+length</code>
     */
    public static native short copyBytes(byte[] src, short srcOff, int address, short offset, short length);

    /**
     * This method returns the byte at the specified byte <code>offset</code>
     * relative the the specified <code>address</code>.
     *
     * @param address
     *            the address to the heap space to reference
     * @param offset
     *            the byte offset relative to the specified address to read.
     * @return the byte value at that specified offset.
     */
    public static native byte readByte(int address, short offset);

    /**
     * This method returns the short value at the specified byte
     * <code>offset</code> relative to the specified <code>address</code>.
     *
     * @param address
     *            the address to the heap space to reference
     * @param offset
     *            the byte offset relative to the specified address to read.
     * @return the short value at that specified offset.
     */
    public static native short readShort(int address, short offset);

    //
    // Installer Exception Table Management Methods
    //

    /* This method is used by the installer to create an exception table structure
     * which is to be inserted into the VM Exception table linked list.<p>
     * @param package Id of the package to which this exception list belongs
     */
    public static native void addExcTable(byte pkgId);

    //
    // Installer Create Method
    //

    /**
     * This method is used by the installer to create a new applet instance.
     * This method invokes the specified <code>install()</code> method of the
     * Applet class in the specified execution context.
     *
     * @param address
     *            the offset of Applet's install() method in method component of
     *            the package
     * @param contextId
     *            the contextId to set as current active context for the
     *            <code>install()</code> method.
     * @param bArray
     *            the byte array parameter to pass to the <code>install()</code>
     *            method.
     * @param bOffset
     *            the byte array offset parameter to pass to the
     *            <code>install()</code> method.
     * @param bLength
     *            the length parameter to pass to the <code>install()</code>
     *            method.
     * @param pkgId
     *            the id of the package to which the applet belongs.
     */
    public static native void callInstall(short address, byte contextId, byte[] bArray, short bOffset, byte bLength,
            byte pkgId);

    /**
     * This method writes the reference of the specified Object <code>obj</code>
     * parameter value at the specified byte <code>offset</code> relative the
     * the specified <code>address</code>.
     *
     * @param address
     *            the address to the heap space to reference
     * @param offset
     *            the byte offset relative to the specified address to write.
     * @param obj
     *            the Object whose reference to deposit at that specified
     *            offset.
     */
    public static native void writeObjectReference(int address, short offset, Object obj);

    /**
     * This method passes debug address information on a package downloaded via
     * the installer. For internal JavaCard VM debug purposes only.
     *
     * @param aidLength
     *            the length of the package AID.
     * @param aid
     *            the AID of the package being installed, starting at index 0.
     * @param addresses
     *            the memory addresses where the CAP file components were
     *            installed. Component addresses are stored in the following
     *            order, starting at index 1: header, directory, applet, import,
     *            constantpool, class, method, static field, reference location
     *            and export.
     */
    public static native void installDebugInfo(byte aidLength, byte[] aid, int[] addresses);

    /**
     * This method is used to tell the VM that the card initialization has been
     * completed successfully.
     */
    public static native void setCardInitialized();

    /**
     * This method is used to check if card has been already initialized.
     */
    public static native boolean isCardInitialized();

    /**
     * Garbage Collection Method responsible for initializing the state for
     * garbage collection.
     */
    public static native void initializeGC();

    /**
     * For garbage collection this method marks the root of all applets, the
     * applet table.
     *
     * @param reference
     *            to applet table as an object
     * @return 0 if failed a non-zero value if successful
     */
    public static native byte markAppletRoots(Object applets);

    /**
     * This method is called for all the packages to mark the objects being
     * pointed to by static reference type fields.
     *
     * @param package
     *            id
     * @param number
     *            of reference fields in the the static field component
     * @return 0 if failed and non-zero value if succesful.
     */
    public static native byte markStaticRoots(byte pkgId, short refCount);

    /**
     * This method is called to mark all the reachable objects from designated
     * root objects.
     *
     * @return false if during applet deletion, we come across an object that
     *         belongs to one of the applets being deleted.
     */
    public static native boolean markNonRootObjects();

    /**
     * Starts the sweep phase of object deletion.
     */
    public static native void startSweepCycle();

    /**
     * This method initializes the underlying garbage collection module for
     * applet deletion which is basically a special case of applet deletion.
     * This method sets up proper variables which will be checked during marking
     * phase to check if an object owned by the applet being deleted is being
     * marked.
     *
     * @param contextsArray
     *            is the array of contexts of applets that are to be deleted.
     * @param count
     *            is the number of applets being deleted.
     */
    public static native void initializeAppletDeletion(byte[] contextsArray, byte count);

    /**
     * This method removes the package and all its components and references
     * from the memory
     *
     * @param pkgId
     * @param isInstallAbort
     *            tells the native implementation if the package has to be
     *            removed completely within a transaction (package deletion) or
     *            can be removed in mutliple small transactions (in case of
     *            aborted installation due to an error).
     */
    public static native byte removePackage(byte pkgId, byte isInstallAbort);

    /**
     * The remaining native methods are used to support remote RMI.
     */

    /**
     * This method goes through the complete exported objects arrays and removes
     * any entries from it that do not point to objects existing on the card.
     *
     * @param RMIExpObjArray
     *            containing the object IDs of the objects exported.
     */
    public static native void cleanupExportedObjectsArray(short[] RMIExpObjArray);

    public static native short getObjectID(Object obj);

    /**
     * Used to check if the object ID being placed in the exported RMI object
     * array is owned by the caller. If it is not, will throw a security
     * exception.
     *
     * @param objectID
     *            the object ID to be checked
     */
    public static native void checkAccess(short objectID);

    /**
     * This method is used to find a ROM package that has the class component
     * covering the address containing the address provided to this method as
     * the parameter once such package is found, it's ID is returned
     *
     * @param address
     *            which is to be in the range of the class component
     * @return package Id
     */
    public static native byte getPkgIDForAddress(int address);

    /**
     * Array arguments range checking is the main purpose of this class at this
     * time. Calls to the native method are made to check of array arguments and
     * thus generating the right kind of exceptions.
     *
     * This does not check for zero length arrays as in some cases, zero length
     * is a special case requiring a special exception, say, ILLEGAL_USE.
     *
     * Note that this method could throw the following exceptions for errors:
     * ArrayIndexOutOfBoundsException, NullPointerException
     *
     * @param bufin
     *            Input buffer
     * @param inoffset
     *            Input buffer offset
     * @param inlen
     *            Lenght of the input buffer under consideration.
     */

    public static native void checkArrayArgs(byte[] bufin, short inoffset, short inlen);

    /*New methods for the installer: Related to the 64K project*/

    /**
     * This method adds the reference to the global reference table and returns
     * the resulting reference to the entry in the global reference table.
     *
     * @param refAddress
     *            is the actual address of class/interface, method or field.
     * @param package
     *            Id
     * @return reference from the global reference table.
     */
    public static native short addReferenceAddress(int refAddress, byte pkgId);

    /**
     * This method gets the address corresponding to a reference in the global
     * reference table.
     *
     * @param reference
     *            inside the global reference table.
     * @return actual address of class/interface, method or field.
     */
    public static native int getReferenceAddress(short ref);

    /**
     * This method sets the location and size information regarding all the
     * components of the package being downloaded on the card.
     *
     * @param package
     *            Id
     * @param component
     *            Id
     * @param component
     *            address
     * @param component
     *            size
     */
    public static native void setComponentInfoForPkg(byte pkgId, byte componentID, int address, short size);

    /**
     * This method gets the location information for a components of the package
     * being downloaded on the card.
     *
     * @param package
     *            Id
     * @param component
     *            Id
     * @return package component's actual address in memory
     */
    public static native int getPackageComponentLocation(byte pkgId, byte compId);

    /***************************************************************************
     * Math Utility Methods start from here *
     **************************************************************************/

    /**
     * Converts the input BCD data into hexadecimal format.
     * <p>
     * Note:
     * <ul>
     * <li><em>If </em><code>bOff</code><em> or </em><code>bLen</code><em> or </em><code>outOff</code><em> parameter
     * is negative an </em><code>ArrayIndexOutOfBoundsException</code><em> exception is thrown.</em>
     * <li><em>If </em><code>bOff+bLen</code><em> is greater than </em><code>bcdArray.length</code><em>, the length
     * of the </em><code>bcdArray</code><em> array a </em><code>ArrayIndexOutOfBoundsException</code><em> exception is thrown
     * and no conversion is performed.</em>
     * <li><em>If the output bytes need to be written at an offset greater than </em><code>hexArray.length</code><em>, the length
     * of the </em><code>hexArray</code><em> array an </em><code>ArrayIndexOutOfBoundsException</code><em> exception is thrown
     * and no conversion is performed.</em>
     * <li><em>If </em><code>bcdArray</code><em> or </em><code>hexArray</code><em> parameter is </em><code>null</code><em>
     * a </em><code>NullPointerException</code><em> exception is thrown.</em>
     * <li><em>If the <code>bcdArray</code> and <code>hexArray</code> arguments refer to the same array object,
     * then the conversion is performed as if the components at positions </em><code>bOff</code><em>
     * through </em><code>bOff+bLen-1</code><em> were first copied to a temporary array with </em><code>bLen</code><em> components
     * and then the contents of the temporary array were converted into
     * positions </em><code>outOff</code><em> onwards for the converted bytes of the output array.</em>
     * </ul>
     *
     * @param bcdArray
     *            input byte array
     * @param bOff
     *            offset within byte array containing first byte (the high order
     *            byte)
     * @param bLen
     *            byte length of input BCD data
     * @param hexArray
     *            output byte array
     * @param outOff
     *            offset within hexArray where output data begins
     * @return the byte length of the output hexadecimal data
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if converting would cause access of data outside array
     *                bounds
     * @exception java.lang.NullPointerException
     *                if either <code>bcdArray</code> or <code>hexArray</code>
     *                is <code>null</code>
     * @exception java.lang.ArithmeticException
     *                if the input byte array format is not a correctly formed
     *                BCD value or the size of the BCD value requires greater
     *                than supported maximum number of bytes to represent in hex
     *                format or if bLen is 0.
     */
    public static native short convertToHex(byte[] bcdArray, short bOff, short bLen, byte[] hexArray, short outOff);

    /**
     * Converts the input hexadecimal data into BCD format. The output data is
     * right justified. If the number of output BCD nibbles is odd, the first
     * BCD nibble written is 0.
     * <p>
     * Note:
     * <ul>
     * <li><em>If </em><code>bOff</code><em> or </em><code>bLen</code><em> or </em><code>outOff</code><em> parameter
     * is negative an </em><code>ArrayIndexOutOfBoundsException</code><em> exception is thrown.</em>
     * <li><em>If </em><code>bOff+bLen</code><em> is greater than </em><code>hexArray.length</code><em>, the length
     * of the </em><code>hexArray</code><em> array a </em><code>ArrayIndexOutOfBoundsException</code><em> exception is thrown
     * and no conversion is performed.</em>
     * <li><em>If the output bytes need to be written at an offset greater than </em><code>bcdArray.length</code><em>, the length
     * of the </em><code>bcdArray</code><em> array an </em><code>ArrayIndexOutOfBoundsException</code><em> exception is thrown
     * and no conversion is performed.</em>
     * <li><em>If </em><code>bcdArray</code><em> or </em><code>hexArray</code><em> parameter is </em><code>null</code><em>
     * a </em><code>NullPointerException</code><em> exception is thrown.</em>
     * <li><em>If the <code>bcdArray</code> and <code>hexArray</code> arguments refer to the same array object,
     * then the conversion is performed as if the components at positions </em><code>bOff</code><em>
     * through </em><code>bOff+bLen-1</code><em> were first copied to a temporary array with </em><code>bLen</code><em> components
     * and then the contents of the temporary array were converted into
     * positions </em><code>outOff</code><em> onwards for the converted bytes of the output array.</em>
     * </ul>
     *
     * @param hexArray
     *            input byte array
     * @param bOff
     *            offset within byte array containing first byte (the high order
     *            byte)
     * @param bLen
     *            byte length of input hex data
     * @param bcdArray
     *            output byte array
     * @param outOff
     *            offset within bcdArray where output data begins
     * @return the byte length of the output bcd formatted data
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if converting would cause access of data outside array
     *                bounds
     * @exception java.lang.NullPointerException
     *                if either <code>bcdArray</code> or <code>hexArray</code>
     *                is <code>null</code>
     * @exception java.lang.ArithmeticException
     *                if the length of the input hex value is larger than the
     *                supported maximum number of bytes or bLen is 0.
     */
    public static native short convertToBCD(byte[] hexArray, short bOff, short bLen, byte[] bcdArray, short outOff);

    /**
     * Checks if the input data is in BCD format
     *
     * @param bcdArray
     *            input byte array
     * @param bOff
     *            offset within byte array containing first byte (the high order
     *            byte)
     * @param bLen
     *            byte length of input BCD data
     * @return true if input data is in BCD format, false otherwise
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access of data
     *                outside array bounds
     * @exception java.lang.NullPointerException
     *                if <code>bcdArray</code> is <code>null</code>
     * @exception java.lang.ArithmeticException
     *                If bLen is 0.
     */
    public static native boolean isBCDFormat(byte[] bcdArray, short bOff, short bLen);

    /**
     * Checks if requested size is valid or not. If it is not valid,
     * ArithmeticException is thrown.
     *
     * @param supportedMax
     *            is the maximum number size supported
     * @param maxSizeRequested
     *            is the size of number requested
     */
    public static native void checkForValidBNSize(short supportedMax, short maxSizeRequested);

    /**
     * Sets the maximum value that the BigNumber may contain. Attempts to
     * increase beyond the maximum results in an exception. If this method is
     * not called, the maximum value is the maximum hex value that fits within
     * the configured maximum number of bytes.
     *
     * @param input
     *            is the array that contains the number that is to be set as
     *            maximum
     * @param bOff
     *            is the offset of input number in the input array
     * @param bLen
     *            is the length of the input number
     * @param arrayFormat
     *            indicates the format of the input data. Valid codes listed in
     *            FORMAT_.. constants. See {@link #FORMAT_BCD}.
     * @param dest
     *            is the destination array in which the max is to be set
     * @param currentNumber
     *            is the currently encapsulated number. An attempt to set a max
     *            which is less than the current number results in
     *            ArithmeticException being thrown.
     * @exception java.lang.ArithmeticException
     *                if the specified maximum value is smaller than the
     *                encapsulated big number or if the specified maximum value
     *                is larger than will fit within the supported maximum
     *                number of bytes or if the input byte array format is not
     *                conformant with the specified <code>arrayFormat</code>
     *                parameter or if bLen is 0
     */
    public static native void setMaxBNValue(byte[] input, short bOff, short bLen, byte arrayFormat, byte[] dest,
            byte[] currentNumber);

    /**
     * Initializes the big number using the input data
     *
     * @param bArray
     *            input byte array
     * @param bOff
     *            offset within byte array containing first byte (the high order
     *            byte)
     * @param bLen
     *            byte length of input data
     * @param arrayFormat
     *            indicates the format of the input data. Valid codes listed in
     *            FORMAT_.. constants. See {@link #FORMAT_BCD}.
     * @param dest
     *            is the destination array in which the input number is to be
     *            set.
     * @param maxValue
     *            is the maxValue that has been set for this BigNumber object.
     *            Attempt to set a number which is larger than maxValue results
     *            in ArithmeticExcepion being thrown.
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access outside
     *                array bounds
     * @exception java.lang.NullPointerException
     *                if <code>bArray</code> is <code>null</code>
     * @exception java.lang.ArithmeticException
     *                if the input byte array format is not conformant with the
     *                specified <code>arrayFormat</code> parameter or if the
     *                specified input data represents a number which is larger
     *                than the maximum value configured or larger than will fit
     *                within the supported maximum number of bytes or if bLen is
     *                0.
     */
    public static native void initBigNumber(byte[] bArray, short bOff, short bLen, byte arrayFormat, byte[] dest,
            byte[] maxValue);

    /**
     * Increments the internal big number by the specified operand value
     *
     * @param bArray
     *            input byte array
     * @param bOff
     *            offset within input byte array containing first byte (the high
     *            order byte)
     * @param bLen
     *            byte length of input data
     * @param arrayFormat
     *            indicates the format of the input data. Valid codes listed in
     *            FORMAT_.. constants. See {@link #FORMAT_BCD}.
     * @param addTo
     *            is the array that contains the current value encapsulated in
     *            the BigNumber object
     * @param maxSize
     *            contains the number which is max that has been set for the
     *            BigNumber object
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access of data
     *                outside array bounds
     * @exception java.lang.NullPointerException
     *                if <code>bArray</code> is <code>null</code>
     * @exception java.lang.ArithmeticException
     *                if the input byte array format is not conformant with the
     *                specified <code>arrayFormat</code> parameter or if the
     *                result of the addition results in a big number which
     *                cannot be represented within the maximum supported bytes
     *                or the configured maximum value or if bLen is 0. The
     *                internal big number is left unchanged.
     */
    public static native void addBigNumbers(byte[] bArray, short bOff, short bLen, byte arrayFormat, byte[] addTo,
            byte[] maxSize);

    /**
     * Decrements the internal big number by the specified operand value
     *
     * @param bArray
     *            input byte array
     * @param bOff
     *            offset within input byte array containing first byte (the high
     *            order byte)
     * @param bLen
     *            byte length of input data
     * @param arrayFormat
     *            indicates the format of the input data. Valid codes listed in
     *            FORMAT_.. constants. See {@link #FORMAT_BCD}.
     * @param subFrom
     *            is the array that contains the current value encapsulated in
     *            the BigNumber object
     * @param maxSize
     *            contains the number which is max that has been set for the
     *            BigNumber object
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access of data
     *                outside array bounds
     * @exception java.lang.NullPointerException
     *                if <code>bArray</code> is <code>null</code>
     * @exception java.lang.ArithmeticException
     *                if the input byte array format is not conformant with the
     *                specified <code>arrayFormat</code> parameter or if the
     *                result of the addition results in a negative number or if
     *                bLen is 0. The internal big number is left unchanged.
     */
    public static native void subtractBigNumbers(byte[] bArray, short bOff, short bLen, byte arrayFormat, byte[] addTo,
            byte[] maxSize);

    /**
     * Multiplies the internal big number by the specified operand value
     *
     * @param bArray
     *            input byte array
     * @param bOff
     *            offset within input byte array containing first byte (the high
     *            order byte)
     * @param bLen
     *            byte length of input data
     * @param arrayFormat
     *            indicates the format of the input data. Valid codes listed in
     *            FORMAT_.. constants. See {@link #FORMAT_BCD}.
     * @param op1Array
     *            is the array that contains the current value encapsulated in
     *            the BigNumber object
     * @param maxSize
     *            contains the number which is max that has been set for the
     *            BigNumber object
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access of data
     *                outside array bounds
     * @exception java.lang.NullPointerException
     *                if <code>bArray</code> is <code>null</code>
     * @exception java.lang.ArithmeticException
     *                if the input byte array format is not conformant with the
     *                specified <code>arrayFormat</code> parameter or if the
     *                result of the multiplication results in a big number which
     *                cannot be represented within the maximum supported bytes
     *                or the configured max value or if bLen is 0. The internal
     *                big number is left unchanged.
     */
    public static native void multiplyBigNumbers(byte[] bArray, short bOff, short bLen, byte arrayFormat, byte[] addTo,
            byte[] maxSize);

    /**
     * Compares the internal big number against the specified operand. The
     * operand is specified in an input byte array.
     *
     * @param bArray
     *            input byte array
     * @param bOff
     *            offset within input byte array containing first byte (the high
     *            order byte)
     * @param bLen
     *            byte length of input data
     * @param format
     *            indicates the format of the input data. Valid codes listed in
     *            FORMAT_.. constants. See {@link #FORMAT_BCD}.
     * @param thisNum
     *            contains the number encapsulated in the BigNumber object on
     *            which compare method was originally called
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access of data
     *                outside array bounds
     * @exception java.lang.NullPointerException
     *                if <code>bArray</code> is <code>null</code>
     * @exception java.lang.ArithmeticException
     *                if the input byte array format is not conformant with the
     *                specified <code>arrayFormat</code> parameter or if bLen
     *                is 0.
     * @return the result of the comparison as follows:
     *         <ul>
     *         <li> <code>0</code> if identical</li>
     *         <li> <code>-1</code> if the internal big number is less than
     *         the specified operand</li>
     *         <li> <code>1</code> if the internal big number is greater than
     *         the specified operand</li>
     *         </ul>
     */
    public static native byte compareBigNumbers(byte[] bArray, short bOff, short bLen, byte format, byte[] thisNumArray);

    /**
     * Writes the internal big number out in the desired format. Note that the
     * value output into the specified byte array is right justified for the
     * number of requested bytes. BCD 0 nibbles are prepended to the output BCD
     * data written out.
     *
     * @param outBuf
     *            output byte array
     * @param bOff
     *            offset within byte array containing first byte (the high order
     *            byte)
     * @param numBytes
     *            number of output bytes required
     * @param arrayFormat
     *            indicates the format of the input data. Valid codes listed in
     *            FORMAT_.. constants. See {@link #FORMAT_BCD}.
     * @param buff
     *            is the array that contains the number encapsulated in the
     *            BigNumber object
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the output array would cause access of data
     *                outside array bounds
     * @exception java.lang.NullPointerException
     *                if <code>outBuf</code> is <code>null</code>
     * @exception ArithmeticException
     *                if numBytes is not sufficient to represent the big number
     *                in the desired format or if arrayFormat is not one of the
     *                FORMAT_ constants or if numBytes is 0
     */
    public static native void bigNumberToBytes(byte[] outBuf, short bOff, short numBytes, byte arrayFormat, byte[] buff);

    /**
     * Returns the number of bytes required to represent the big number using
     * the desired format
     *
     * @param bn
     *            is the number encapsulated in the BigNumber object
     * @param arrayFormat
     *            indicates the format of the output data. Valid codes listed in
     *            FORMAT_.. constants. See {@link #FORMAT_BCD}.
     * @return the byte length of big number
     * @exception ArithmeticException
     *                if arrayFormat is not one of the FORMAT_ constants.
     */
    public static native byte getBNByteLength(byte[] bn, byte arrayFormat);

    /**
     * Returns if the passed objID is under current transaction log.
     */
    public static native boolean isWithinTransactionLogs(short objID);

    
    /**************************************
     * SensitiveResult internal and API methods
     **************************************/
    
    /**
     * Constructor used to initialize the SensitiveResult internal state To be
     * called by the platform, therefore private declared
     */
    //public static native void sensitiveResultInitialize(short[] internalState, Object[] objectReference, byte sizeIState, byte sizeOReference, byte iMemory, byte oMemory);
    public static native void sensitiveResultInitialize(short[] internalStateMachineArray);
    
    /**
     * Set secure result to type boolean and value true OS internal function,
     * therefore private declaration
     */
    public static native void sensitiveResultSetBooleanTrue();
    
    /**
     * Set secure result to type boolean and value false OS internal function,
     * therefore private declaration
     */
    public static native void sensitiveResultSetBooleanFalse();
    
    /**
     * Sets the short value of the SensitiveResult This is normally only available
     * in the OS, therefore private declaration
     *
     * @param x The short value that corresponds to the return value of the called
     * method
     */
    public static native void sensitiveResultSet(short x);
    
    /**
     * Sets the object value of the SensitiveResult This is normally only
     * available in the OS, therefore private declaration
     *
     * @param array The object value that corresponds to the return value of the
     * called method
     */
    public static native void sensitiveResultSetObject(Object array);
    
    
    /**
     * Sets the short value of the SensitiveResult, when everything is:
     * Ok 
     * XOR 
     * Unassigned - if "a method returns abnormally with an exception 
     * then the stored result is tagged as Unassigned and any subsequent 
     * assertion of the result will fail." This is normally only available
     * in the OS, therefore private declaration
     *
     * @param x The short value that corresponds to the return value of the called
     * method
     */
    public static native void sensitiveResultSetTagValUnassigned();
    
    /*
    * SensitiveResult class API methods call in native code
    */
    public static native void sensitiveResultAssertEqualsObj(Object obj);
    public static native void sensitiveResultAssertEquals(short val);
    public static native void sensitiveResultAssertTrue();    
    public static native void sensitiveResultAssertFalse();
    public static native void sensitiveResultAssertGreaterThan(short val);
    public static native void sensitiveResultAssertLessThan(short val);
    public static native void sensitiveResultAssertNegative();
    public static native void sensitiveResultAssertPositive();
    public static native void sensitiveResultAssertZero();
    public static native void sensitiveResultReset();
    
    public static native void arrayCopyNonAtomicForSensitiveArrays(byte[] src, short srcOff, byte[] dest, short destOff,
            short length) throws ArrayIndexOutOfBoundsException, NullPointerException;
    
    public static final native short arrayFillNonAtomicForSensitiveArrays(byte[] bArray, short bOff, short bLen, byte bValue)
            throws ArrayIndexOutOfBoundsException, NullPointerException;
    
    public static native Object makeGlobalArray(byte type, short length)
            throws NegativeArraySizeException, SystemException;
}
