/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package java.rmi;

/**
 * The Remote interface serves to identify interfaces whose methods may be
 * invoked from a CAD client application. An object that is a remote object must
 * directly or indirectly implement this interface. Only those methods specified
 * in a "remote interface", an interface that extends
 * <CODE>java.rmi.Remote</CODE> are available remotely.
 * 
 * Implementation classes can implement any number of remote interfaces and can
 * extend other remote implementation classes. RMI for the Java Card platform
 * provides a convenience class called
 * <CODE>javacard.framework.service.CardRemoteObject</CODE> that remote object
 * implementations can extend which facilitates remote object creation. For
 * complete details on RMI for the Java Card platform, see the <I>Runtime
 * Environment Specification, Java Card Platform, Classic Edition</I> and the
 * <CODE>javacard.framework.service</CODE> API package.
 */

public interface Remote {
}
