/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
// #ifdef_Target32Bit_
package javacard.framework;

import com.sun.javacard.impl.Constants;
import com.sun.javacard.impl.NativeMethods;
import com.sun.javacard.impl.PackedBoolean;
import com.sun.javacard.impl.PrivAccess;

class T1APDUImpl implements APDUComm {

    // This T1APDUImpl class implements the T=1 APDU transport protocol.

    private static final short BUFFERSIZE = Constants.APDU_BUFFER_LENGTH;

    private static APDUComm theAPDU;
    /**
     * The APDU will use the buffer byte[] to store data for input and output.
     */
    private byte[] buffer;

    // Define two state variable buffers: short-length and byte-length.
    private static byte[] ramByteVars;
    private static short[] ramShortVars;

    // RAM state variables requiring 2 bytes to store
    private static final byte LE = (byte) 0;
    private static final byte LR = (byte) (LE + 1);
    private static final byte LC = (byte) (LR + 1);
    private static final byte LS = (byte) (LC + 1);
    private static final byte LO = (byte) (LS + 1);
    private static final byte PRE_READ_LENGTH = (byte) (LO + 1);
    private static final byte INCOMIMG_LENGTH = (byte) (PRE_READ_LENGTH + 1);
    private static final byte DATA_PROCESSED_LENGTH = (byte) (INCOMIMG_LENGTH + 1);
    private static final byte RAM_SHORT_VARS_LENGTH = (byte) (DATA_PROCESSED_LENGTH + 1);

    // RAM state variables requiring 1 byte to store
    private static final byte CURRENT_STATE = (byte) 0;
    private static final byte LOGICAL_CHN = (byte) (CURRENT_STATE + 1);
    private static final byte RAM_BYTE_VARS_LENGTH = (byte) (LOGICAL_CHN + 1);

    // APDU cases
    private final static short CASE_1 = (short) 1;
    private final static short CASE_2S = (short) 2;
    private final static short CASE_3S = (short) 3;
    private final static short CASE_4S = (short) 4;
    private final static short CASE_2E = (short) 6;
    private final static short CASE_3E = (short) 7;
    private final static short CASE_4E = (short) 8;

    private final static byte T1_EVENT_NONE = (byte) 0;
    private final static byte T1_EVENT_POWERUP = (byte) 1;
    private final static byte T1_EVENT_POWERDOWN = (byte) 2;
    private final static byte T1_EVENT_POWERRESET = (byte) 3;

    private static final short MAX_LE = (short) 256;
    private static final short MAX_EXT_LE = (short) 32767;

    // PackedBolean data members
    private PackedBoolean thePackedBoolean;
    private byte incomingFlag, outgoingFlag, outgoingLenSetFlag, sendInProgressFlag, noChainingFlag;
    private byte extendedAPDUFlag, determinedLE, type16Flag, extendedSupportFlag;

    // RAM vars management methods
    // Le = terminal expected length
    private short getLe() {
        if (ramShortVars[LE] == 0 && getDeterminedLEFlag()) {
            if (getExtendedAPDUFlag()) {
                return MAX_EXT_LE;
            } else {
                return MAX_LE;
            }
        }
        return ramShortVars[LE];
    }

    private void setLe(short data) {
        // for further checks on Le, we do not
        // mask the sign bit and store Le as it is so that if
        // has a negative value, we can throw ISO7816.SW_WRONG_LENGTH
        // error status back to the interface device.
        ramShortVars[LE] = data;
    }

    private short getIL() {
        return ramShortVars[INCOMIMG_LENGTH];
    }

    private void setIL(short data) {
        ramShortVars[INCOMIMG_LENGTH] = data;
    }

    // Lr = our response length
    private short getLr() {
        return ramShortVars[LR];
    }

    private void setLr(short data) {
        ramShortVars[LR] = data;
    }

    // Lc = terminal incoming length
    private short getLc() {
        return ramShortVars[LC];
    }

    private void setLc(short data) {
        ramShortVars[LC] = data;
    }

    // Ls = data we have not sent yet in APDU buffer
    private short getLs() {
        return ramShortVars[LS];
    }

    private void setLs(short data) {
        ramShortVars[LS] = (short) (data & (short) 0x7FFF);
    }

    // Lo = offset for data to send in Ls
    private short getLo() {
        return ramShortVars[LO];
    }

    private void setLo(short data) {
        ramShortVars[LO] = data;
    }

    // PreReadLength = length already received via setIncommingAndReceive().
    // Used for undo operation.
    private short getPreReadLength() {
        return ramShortVars[PRE_READ_LENGTH];
    }

    private void setPreReadLength(short data) {
        ramShortVars[PRE_READ_LENGTH] = data;
    }

    // currentState = APDU processing state
    private byte getCurrState() {
        return ramByteVars[CURRENT_STATE];
    }

    private void setCurrState(byte data) {
        ramByteVars[CURRENT_STATE] = data;
    }

    private void resetCurrState() {
        ramByteVars[CURRENT_STATE] = APDU.STATE_INITIAL;
    }

    private void setLogicalChannel(byte data) {
        ramByteVars[LOGICAL_CHN] = data;
    }

    // Methods to manage APDU object/transport flags.
    private boolean getIncomingFlag() {
        return thePackedBoolean.get(incomingFlag);
    }

    private void setIncomingFlag() {
        thePackedBoolean.set(incomingFlag);
    }

    private void resetIncomingFlag() {
        thePackedBoolean.reset(incomingFlag);
    }

    private boolean getDeterminedLEFlag() {
        return thePackedBoolean.get(determinedLE);
    }

    private void setDeterminedLEFlag() {
        thePackedBoolean.set(determinedLE);
    }

    private void resetDeterminedLEFlag() {
        thePackedBoolean.reset(determinedLE);
    }

    private boolean getSendInProgressFlag() {
        return thePackedBoolean.get(sendInProgressFlag);
    }

    private void setSendInProgressFlag() {
        thePackedBoolean.set(sendInProgressFlag);
    }

    private void resetSendInProgressFlag() {
        thePackedBoolean.reset(sendInProgressFlag);
    }

    private boolean getOutgoingFlag() {
        return thePackedBoolean.get(outgoingFlag);
    }

    private void setOutgoingFlag() {
        thePackedBoolean.set(outgoingFlag);
    }

    private void resetOutgoingFlag() {
        thePackedBoolean.reset(outgoingFlag);
    }

    private boolean getOutgoingLenSetFlag() {
        return thePackedBoolean.get(outgoingLenSetFlag);
    }

    private void setOutgoingLenSetFlag() {
        thePackedBoolean.set(outgoingLenSetFlag);
    }

    private void resetOutgoingLenSetFlag() {
        thePackedBoolean.reset(outgoingLenSetFlag);
    }

    private boolean getExtendedAPDUFlag() {
        return thePackedBoolean.get(extendedAPDUFlag);
    }

    private void setExtendedAPDUFlag() {
        thePackedBoolean.set(extendedAPDUFlag);
    }

    private void resetExtendedAPDUFlag() {
        thePackedBoolean.reset(extendedAPDUFlag);
    }

    private boolean getType16Flag() {
        return thePackedBoolean.get(type16Flag);
    }

    private void setType16Flag() {
        thePackedBoolean.set(type16Flag);
    }

    private void resetType16Flag() {
        thePackedBoolean.reset(type16Flag);
    }

    private boolean getExtendedSupportFlag() {
        return thePackedBoolean.get(extendedSupportFlag);
    }

    private void setExtendedSupportFlag() {
        thePackedBoolean.set(extendedSupportFlag);
    }

    private void resetExtendedSupportFlag() {
        thePackedBoolean.reset(extendedSupportFlag);
    }

    // Object constructor - called by the JCRE upon initialization.
    T1APDUImpl() {
        buffer = NativeMethods.initAPDUBuffer();
        ramByteVars = JCSystem.makeTransientByteArray(RAM_BYTE_VARS_LENGTH, JCSystem.CLEAR_ON_RESET);
        ramShortVars = JCSystem.makeTransientShortArray(RAM_SHORT_VARS_LENGTH, JCSystem.CLEAR_ON_RESET);

        thePackedBoolean = PrivAccess.getPackedBoolean();
        incomingFlag = thePackedBoolean.allocate();
        sendInProgressFlag = thePackedBoolean.allocate();
        outgoingFlag = thePackedBoolean.allocate();
        outgoingLenSetFlag = thePackedBoolean.allocate();
        extendedAPDUFlag = thePackedBoolean.allocate();
        noChainingFlag = thePackedBoolean.allocate();
        determinedLE = thePackedBoolean.allocate();
        type16Flag = thePackedBoolean.allocate();
        extendedSupportFlag = thePackedBoolean.allocate();
        theAPDU = this;
    }

    // This private method implements ISO 7816-4 logic to determine
    // the logical channel to whom this APDU command is intended to.
    private byte getChannelInfo() {
        byte theAPDUChannel;

        if((short)(buffer[ISO7816.OFFSET_CLA] & 0x00FF) == 0x00FF){
            theAPDUChannel = (byte) 0;
        }
        else if (isType16CLA()) {
            theAPDUChannel = (byte) (buffer[ISO7816.OFFSET_CLA] & APDU.LOGICAL_CHN_MASK_TYPE16);
            theAPDUChannel = (byte) (theAPDUChannel + (byte) 4);
        } else {
            if ((byte) (buffer[ISO7816.OFFSET_CLA] & APDU.APDU_INVALID_TYPE4_MASK) != (byte) 0) {
                theAPDUChannel = (byte) 0;
            } else {
                theAPDUChannel = (byte) (buffer[ISO7816.OFFSET_CLA] & APDU.LOGICAL_CHN_MASK_TYPE4);
            }
        }
        return theAPDUChannel;
    }

    // Logical Channel to whom the APDU is intended to (CLA byte)
    public byte getLogicalChannel() {
        return ramByteVars[LOGICAL_CHN];
    }

    // noChainingFlag = do not set the M bit when sending an I-block.
    public boolean getNoChainingFlag() {
        return thePackedBoolean.get(noChainingFlag);
    }

    private void setNoChainingFlag() {
        thePackedBoolean.set(noChainingFlag);
    }

    private void resetNoChainingFlag() {
        thePackedBoolean.reset(noChainingFlag);
    }

    public void resetAPDU() {
        // Reset state flags to prepare for new APDU processing
        resetIncomingFlag();
        resetOutgoingFlag();
        resetOutgoingLenSetFlag();
        resetSendInProgressFlag();
        resetType16Flag();
        resetExtendedAPDUFlag();
        resetDeterminedLEFlag();
        resetNoChainingFlag();
        setPreReadLength((byte) 0);
        ramShortVars[DATA_PROCESSED_LENGTH] = (short) 0;
    }

    private void setAPDUParameters(short Lc, short Le, short Lr, short preReadLength, short incomingLength) {
        // Sets initial APDU parameter estimates based on content analysis.
        setLe(Le);
        setLc(Lc);
        setLr(Lr);
        setIL(incomingLength);
        resetCurrState();
        setPreReadLength(preReadLength);
        if (isType16CLA()) {
            setType16Flag();
        }
        setLogicalChannel(getChannelInfo());
    }

    private void preProcessAPDU(short recvBytes) {
        // Analyze received APDU data and try to predict its structure
        // based on analysis of its content. Used to maintain a consistent
        // internal state and synchronize communications.
        // We try to preduct this by looking at LC and comparing it to the
        // APDU data received. Not in all cases can we determine this, so
        // we try to do a best effort.
        short apduCase;
        short Le, Lc, Lr, pRL;

        // First find out the APDU case
        if (recvBytes == (short) 4) {
            // Case 1 APDU
            setAPDUParameters((short) 0, (short) 0, (short) 0, (short) 0, (short) 0);
            setDeterminedLEFlag();
            return;
        }

        if (recvBytes == (short) 5) {
            // Case 2S APDU
            Le = (short) (buffer[ISO7816.OFFSET_LC] & 0x00ff);
            setAPDUParameters((short) 0, Le, (short) 0, (short) 0, (short) 0);
            setDeterminedLEFlag();
            return;
        }

        if (recvBytes == (short) 7) {
            // Case 3S(2), 4S(LC = 1) or 2E
            byte bLc = buffer[ISO7816.OFFSET_LC];
            if (bLc == (byte) 0) {
                // Case 2E
                Le = (short) (buffer[(short) (ISO7816.OFFSET_LC + (short) 1)] & (short) 0x00ff);
                Le = (short) ((short) (Le << 8) | (short) (buffer[(short) (ISO7816.OFFSET_LC + (short) 2)] & (short) 0x00ff));
                setAPDUParameters((short) 0, Le, (short) 0, (short) 0, (short) 0);
                setDeterminedLEFlag();
                setExtendedAPDUFlag();
                return;
            } else {
                // Case 3S(LC = 2) or 4S(LC = 1)
                Lc = (short) (bLc & 0x00FF);
                if (bLc != (byte) 2) {
                    // Case 4S with LC = 1
                    Le = (short) ((buffer[(short) (ISO7816.OFFSET_LC + (short) 2)]) & (short) 0x00FF);
                    Lc = (short) (Lc - (short) 1);
                    setAPDUParameters(Lc, Le, (short) 0, (short) 1, (short) 1);
                    setDeterminedLEFlag();
                    return;
                }
                Lc = (short) (Lc - (short) 2);
                setAPDUParameters(Lc, (short) 0, (short) 0, (short) 2, (short) 2);
                setDeterminedLEFlag();
                return;
            }
        } /* recvBytes = 7 */

        // Try to differenciate between Case 3S(LC != 2), 3E, 4S and 4E
        if (recvBytes > (short) 5) {
            // Differenciate between Simple and Extended cases
            byte bLc = buffer[ISO7816.OFFSET_LC];
            if (bLc == (byte) 0) {
                // Extended cases - cannot differenciate between 3E and 4E yet
                Lc = (short) (buffer[(short) (ISO7816.OFFSET_LC + (short) 1)] & (short) 0x00ff);
                Lc = (short) ((short) (Lc << 8) | (short) (buffer[(short) (ISO7816.OFFSET_LC + (short) 2)] & (short) 0x00ff));

                // Extended case due to LE being large?
                if (recvBytes == (short) (Lc + 9)) {
                    pRL = (short) (recvBytes - (short) 9);
                    Le = (short) (buffer[(short) (ISO7816.OFFSET_EXT_CDATA + pRL)] & (short) 0x00ff);
                    Le = (short) ((short) (Le << 8) | (short) (buffer[(short) (ISO7816.OFFSET_EXT_CDATA + pRL + (short) 1)] & (short) 0x00ff));
                    Lc = (short) (-2);
                } else {
                    pRL = (short) (recvBytes - (short) 7);
                    Le = (short) 0;
                    Lc = (short) (Lc - pRL);
                }
                setAPDUParameters(Lc, Le, (short) 0, pRL, (short) (Lc + pRL));
                setExtendedAPDUFlag();
                resetDeterminedLEFlag();
                return;
            }
            Lc = (short) (bLc & (short) 0x00FF);
            if (Lc > (short) (BUFFERSIZE - 5)) {
                // Cannot determine Cases 3S(LC > 128) or 4S(LC > 128) yet
                pRL = (short) (recvBytes - (short) 5);
                Lc = (short) (Lc - pRL);
                setAPDUParameters(Lc, (short) 0, (short) 0, pRL, (short) (Lc + pRL));
                resetDeterminedLEFlag();
                return;
            }

            if (Lc < (short) (recvBytes - 5)) {
                // Case 4S
                Le = (short) (buffer[(short) (recvBytes - (short) 1)] & (short) 0x00FF);
                pRL = (short) (recvBytes - (short) 6);
                Lc = (short) (Lc - pRL);
                setAPDUParameters(Lc, Le, (short) 0, pRL, (short) (Lc + pRL));
                setDeterminedLEFlag();
                return;
            }

            // Case 3S or 4S with LC = 128
            Le = (short) 0;
            pRL = (short) (recvBytes - (short) 5);
            Lc = (short) (Lc - pRL);
            setAPDUParameters(Lc, Le, (short) 0, pRL, (short) (Lc + pRL));
            resetDeterminedLEFlag();
            return;
        } else {
            // Error case - should not get here either
            return;
        } /* recvBytes > 5 if-then-else statement */
    }

    // APDU.complete() method to send status and retrieve next APDU
    public void complete(short status) throws APDUException {
        short result;

        // The first time... do not send anythig back.
        if (status != 0) {
            // If there are incoming blocks pending and no Abort has been sent,
            // send an Abort signal to the terminal.
            if (!getOutgoingFlag()) {
                if (!NativeMethods.t1LastBlockReceived()) {
                    result = NativeMethods.t1Abort();
                    if (result < 0) {
                        // In this case, simply return 0x6F00 to the terminal
                        status = ISO7816.SW_UNKNOWN;
                    }
                }
            }
            // Send all remaining data in APDU buffer and status code
            // At this point, an interface switch is allowed, so the result
            // might come at a different interface.
            if (getSendInProgressFlag()) {
                // If we had the last block pending...
                // Ls points to the amount of data to be sent
                // Lo points to the offset of the next byte of data to be sent
                // This case happens when sendBytes(..) was called but data
                // remained unsent to make communications more efficient.
                short Ls = getLs();
                short Lo = getLo();

                if ((short) (Ls + Lo + (short) 1) >= BUFFERSIZE) {
                    result = NativeMethods.t1SndBlockRcvAck(Lo, Ls, false, false);
                    Ls = (short) 0;
                    Lo = (short) 0;
                }

                byte sw1 = (byte) ((byte) (status >> 8) & 0x00FF);
                byte sw2 = (byte) (status & 0x00FF);
                buffer[(short) (Ls + Lo)] = sw1;
                buffer[(short) (Ls + Lo + (short) 1)] = sw2;
                result = NativeMethods.t1SndBlockRcvAck(Lo, (short) (Ls + 2), true, true);
            } else {
                // Just send a last I-block with SW1 and SW2
                byte sw1 = (byte) ((byte) (status >> 8) & 0x00FF);
                byte sw2 = (byte) (status & 0x00FF);
                buffer[(short) 0] = sw1;
                buffer[(short) 1] = sw2;
                result = NativeMethods.t1SndBlockRcvAck((short) 0, (short) 2, true, true);
            }
            if (result != (short) 0) {
                APDUException.throwIt(APDUException.IO_ERROR);
            }

        }
        // Zero out APDU buffer
        Util.arrayFillNonAtomic(buffer, (short) 0, BUFFERSIZE, (byte) 0);

        byte cardEvent = NativeMethods.getSecondaryInterfaceEvent();

        // Process contactless interface events
        if (cardEvent == T1_EVENT_POWERUP) {
            // Power-up on secondary interface - open basic
            // logical channel on that interface and select default
            // applet
            PrivAccess.powerUpContactless();
        } else if (cardEvent == T1_EVENT_POWERDOWN) {
            // Power-down on secondary interface - close all logical
            // channels on that interface
            PrivAccess.powerDownContactless();
        } else if (cardEvent == T1_EVENT_POWERRESET) {
            // Power reset on secondary interface - close all logical
            // channels on secondary interface, open basic logical channel
            // and select default applet
            PrivAccess.powerDownContactless();
            PrivAccess.powerUpContactless();
        }

        short bOff = (short) 0;
        short bytesReceived = (short) 0;

        // Receive I-blocks until M bit is set or until current
        // APDU buffer is full
        while ((bOff < BUFFERSIZE) && !NativeMethods.t1LastBlockReceived()) {
            // Retrieve new I-Block corresponding to a new APDU
            result = NativeMethods.t1RcvBlock(bOff, BUFFERSIZE);
            if (result < (short) 0) {
                APDUException.throwIt(APDUException.IO_ERROR);
            }
            bOff = (short) (bOff + result);
            bytesReceived = (short) (bytesReceived + result);
        }

        // Reset state for new incoming APDU
        resetExtendedSupportFlag();
        resetAPDU();
        // Pre-process APDU to try to figure out its parameters
        // Determine the case of the APDU and set LC and LE values accordingly
        preProcessAPDU(bytesReceived);
        return;
    }

    // Called by Dispatcher to set the pre read length for SELECT APDU commands
    public void undoIncomingAndReceive() {
        setPreReadLength((short) ((buffer[ISO7816.OFFSET_LC] - getLc()) & 0x7FFF));
        setCurrState(APDU.STATE_INITIAL);
        return;
    }

    public byte getCLAChannel() {
        return theAPDU.getLogicalChannel();
    }

    public void waitExtension() throws APDUException {
        if (theAPDU.getNoChainingFlag()) {
            APDUException.throwIt(APDUException.ILLEGAL_USE);
        }

        short result = NativeMethods.t1Wait();
        if (result != (short) 0) {
            APDUException.throwIt(APDUException.IO_ERROR);
        }
    }

    private boolean isExtended() {
        return getExtendedSupportFlag();
    }

    public boolean isValidCLA() {
        byte cla = buffer[ISO7816.OFFSET_CLA];
        return (((((byte)(cla&0xE0)==(byte)0x20))||(cla==(byte)0xFF)) ? false:true);
    }

    public boolean isCommandChainingCLA() {
        byte theCLAChaining;

        if (!isValidCLA()) { return false; }
        theCLAChaining = (byte) (buffer[ISO7816.OFFSET_CLA] & APDU.APDU_CHAINING_MASK);
        if (theCLAChaining == (byte) 0x10) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isSecureMessagingCLA() {
        byte secureMsgFlag;

        if (!isValidCLA()) { return false; }
        if (isType16CLA()) {
            secureMsgFlag = (byte) (buffer[ISO7816.OFFSET_CLA] & APDU.APDU_SM_MASK_TYPE16);
        } else {
            secureMsgFlag = (byte) (buffer[ISO7816.OFFSET_CLA] & APDU.APDU_SM_MASK_TYPE4);
        }

        if (secureMsgFlag == (byte) 0) {
            return false;
        } else {
            return true;
        }
    }

    public boolean isISOInterindustryCLA() {
        byte theCLAType;

        theCLAType = (byte) (buffer[ISO7816.OFFSET_CLA] & APDU.APDU_ISOCLASS_MASK);
        if (theCLAType == (byte) 0x00) {
            return true;
        } else {
            return false;
        }
    }

    private boolean isType16CLA() {
        byte theCLAType;

        theCLAType = (byte) (buffer[ISO7816.OFFSET_CLA] & APDU.APDU_TYPE_MASK);
        if (theCLAType == 0x40) {
            return true;
        } else {
            return false;
        }
    }

    public byte[] getBuffer() {
        return buffer;
    }

    public short getInBlockSize() {
        return NativeMethods.t1GetIFSC();
    }

    public short getOutBlockSize() {
        return NativeMethods.t1GetIFSD();
    }

    public byte getProtocol() {
        if (NativeMethods.getCommProtocol(NativeMethods.getActiveInterface()) == APDU.PROTOCOL_T1) {
            return (byte) (APDU.PROTOCOL_MEDIA_DEFAULT + APDU.PROTOCOL_T1);
        } else if (NativeMethods.getCommProtocol(NativeMethods.getActiveInterface()) == APDU.PROTOCOL_TCL) {
            return (byte) (APDU.PROTOCOL_MEDIA_CONTACTLESS_TYPE_A + APDU.PROTOCOL_T1);
        } else {
            return (byte) (-1);
        }
    }

    public byte getNAD() {
        return NativeMethods.t1GetNAD();
    }

    /**
     * If the card applet calls setOutgoing method before all the data from the
     * terminal was received, we still have to send it back the right Le. The
     * only way to do it is to get all the data from the terminal. Since the
     * card application obviously wants nothing to do with the data, we just
     * discard the received data.
     */
    private void receiveBytesAndDiscard() {
        if (!getIncomingFlag()) {
            setIncomingFlag();
        }
        // If we have read any bytes before...
        short pre = getPreReadLength();
        if (pre != 0) {
            setPreReadLength((short) 0);
            ramShortVars[DATA_PROCESSED_LENGTH] += pre;
        }
        short Le = NativeMethods.t1RcvAndDiscardData(getIL(), ramShortVars[DATA_PROCESSED_LENGTH]);
        if (Le == (short) -2) {
            ISOException.throwIt(ISO7816.SW_WRONG_LENGTH); // wrong Le
        } else if (Le >= (short) 0) {
            setLe(Le);
            setDeterminedLEFlag();
        } // we do not care about other cases because in other cases
        // there is no Le.
    }

    public short setOutgoing() throws APDUException {
        // if we've previously called this method, then throw an exception
        if (getOutgoingFlag()) {
            APDUException.throwIt(APDUException.ILLEGAL_USE);
        }

        if (!NativeMethods.t1LastBlockReceived()) {
            // We still haven't received all the data from the terminal to
            // determine Le. Receive and discard to rest of the data and
            // determine Le.
            receiveBytesAndDiscard();
        }
        setOutgoingFlag();
        setCurrState(APDU.STATE_OUTGOING);

        if (getLe() < (short) 0) {
            ISOException.throwIt(ISO7816.SW_WRONG_LENGTH);
        }

        return getLe();
    }

    public short setOutgoingNoChaining() throws APDUException {
        // if we've previously called this method, then throw an exception
        if (getOutgoingFlag()) {
            APDUException.throwIt(APDUException.ILLEGAL_USE);
        }

        if (!NativeMethods.t1LastBlockReceived()) {
            short result = NativeMethods.t1Abort();
            if (result < 0) {
                APDUException.throwIt(APDUException.IO_ERROR);
            }
        }

        setOutgoingFlag();
        setNoChainingFlag();
        setCurrState(APDU.STATE_OUTGOING);
        return getLe();
    }

    public void setOutgoingLength(short len) throws APDUException {
        if (!getOutgoingFlag()) {
            APDUException.throwIt(APDUException.ILLEGAL_USE);
        }

        // If we've previously called this method, then throw an exception
        if (getOutgoingLenSetFlag()) {
            APDUException.throwIt(APDUException.ILLEGAL_USE);
        }

        // If the outbound length is set to more than 256 and the applet
        // does not implement the ExtendedAPDU interface, throw an exception.
        if ((len > MAX_LE) && (!getExtendedSupportFlag())) {
            APDUException.throwIt(APDUException.BAD_LENGTH);
        }

        // Check upper and lower limits
        /*if (len > MAX_EXT_LE) {
            APDUException.throwIt(APDUException.BAD_LENGTH);
        }*/

        if (len < 0) {
            APDUException.throwIt(APDUException.BAD_LENGTH);
        }

        // If no chaining flag is enabled, do not allo more data
        // to be sent other than that fittig within an I-block
        if (len > (short) (NativeMethods.t1GetIFSD() - (short) 2)) {
            if (getNoChainingFlag()) {
                APDUException.throwIt(APDUException.BAD_LENGTH);
            }
        }

        setOutgoingLenSetFlag();
        setCurrState(APDU.STATE_OUTGOING_LENGTH_KNOWN);
        setLr(len);
        setDeterminedLEFlag();

        if (len > MAX_LE) {
            setExtendedAPDUFlag();
        }
    }

    public short receiveBytes(short bOff) throws APDUException {
        if (getIL() == 0) {
            // there is no data there to be read. This is a case 1 or
            // 2 command on which the applet has called setIncomingAndReceive.
            // We should throw APDUException with error code IO_ERROR
            APDUException.throwIt(APDUException.IO_ERROR);
        }

        if (!getIncomingFlag() || getOutgoingFlag()) {
            APDUException.throwIt(APDUException.ILLEGAL_USE);
        }
        short Lc = getLc();

        if (bOff < 0) {
            APDUException.throwIt(APDUException.BUFFER_BOUNDS);
        }

        // If we have read any bytes before...
        short pre = getPreReadLength();
        if (pre != 0) {
            setPreReadLength((short) 0);
            if (Lc <= 0) {
                setCurrState(APDU.STATE_FULL_INCOMING);
            } else {
                setCurrState(APDU.STATE_PARTIAL_INCOMING);
            }
            ramShortVars[DATA_PROCESSED_LENGTH] += pre;
            return pre;
        }

        // Receive data into APDU buffer
        short len = 0;
        if (Lc > (short) 0) {
            short accumLen = 0;
            short bOff2 = bOff;
            // Fill APDU buffer with data, receiving as many I-blocks as
            // necessary
            while ((bOff2 < BUFFERSIZE) && (Lc > (short) 0)) {
                accumLen = NativeMethods.t1RcvBlock(bOff2, BUFFERSIZE);
                if (accumLen < 0) {
                    // ERROR
                    APDUException.throwIt(APDUException.IO_ERROR);
                }
                Lc = (short) (Lc - accumLen);
                bOff2 += accumLen;
                len += accumLen;
            }

            // Try to get LE if possible. Only case 4 APDUs will be able to
            // get this information.
            if (Lc < (short) 0) {
                if (Lc == (short) -1) {
                    // Partially received LE - t1LastBlockReceived is FALSE
                    // indicates partial reception
                    if (getExtendedAPDUFlag()) {
                        setLe((short) ((buffer[(short) (bOff + len - (short) 1)] & (short) 0x00FF) << (short) 8));
                    } else {
                        setLe((short) ((buffer[(short) (bOff + len - (short) 1)] & (short) 0x00FF)));
                    }
                    Lc = (short) 0;
                    len = (short) (len - (short) 1);
                    setDeterminedLEFlag();

                } else {
                    // case 4E: Received LE in message
                    setLe((short) (((buffer[(short) (bOff + len - (short) 2)] & (short) 0x00FF) << (short) 8) | (short) (buffer[(short) (bOff
                            + len - (short) 1)] & (short) 0x00FF)));
                    Lc = (short) 0;
                    len = (short) (len - (short) 2);
                    // Determined LE set and Envelope Flag not set indicates
                    // full LE reception
                    setDeterminedLEFlag();
                }
            }
            setLc(Lc); // update RAM copy of Lc, the count remaining
            if (Lc == (short) 0) {
                setCurrState(APDU.STATE_FULL_INCOMING);
            } else {
                setCurrState(APDU.STATE_PARTIAL_INCOMING);
            }
            ramShortVars[DATA_PROCESSED_LENGTH] += len;
            return len;
        } else {
            // This is the case where LE is missing...
            // Try to get it from the next block
            if (!NativeMethods.t1LastBlockReceived()) {
                len = NativeMethods.t1RcvBlock(bOff, BUFFERSIZE);
                if (len < (short) 0) {
                    APDUException.throwIt(APDUException.IO_ERROR);
                }

                if (getExtendedAPDUFlag()) {
                    if (getDeterminedLEFlag()) {
                        // LE missing 1 byte... Process that one byte LE
                        setLe((short) (getLe() | ((buffer[(short) (bOff + len - (short) 1)] & (short) 0x00FF))));
                    } else {
                        // Get LE from last I-block from message
                        setLe((short) (((buffer[(short) (bOff + len - (short) 2)] & (short) 0x00FF) << (short) 8) | (short) (buffer[(short) (bOff
                                + len - (short) 1)] & (short) 0x00FF)));
                        setDeterminedLEFlag();
                    }
                } else {
                    if (!getDeterminedLEFlag()) {
                        setLe((short) (buffer[(short) (bOff + len - (short) 1)] & (short) 0x00FF));
                    }
                }
            }
            setLc((short) 0);
        }
        // Set state to fully received APDU
        setCurrState(APDU.STATE_FULL_INCOMING);
        return (short) 0;
    }

    public void sendBytes(short bOff, short len) throws APDUException {
        short result = (short) 0;

        if ((bOff < 0) || (len < 0) || ((short) ((bOff + len)) > BUFFERSIZE)) {
            APDUException.throwIt(APDUException.BUFFER_BOUNDS);
        }
        if (!getOutgoingLenSetFlag()) {
            APDUException.throwIt(APDUException.ILLEGAL_USE);
        }
        if (len == 0) {
            return;
        }
        short Lr = getLr();
        if (len > Lr) {
            APDUException.throwIt(APDUException.ILLEGAL_USE);
        }

        short Le = getLe();
        short blockSize = NativeMethods.t1GetIFSD();
        short lenSent = (short) 0;
        short bOff2 = bOff;

        // If you cannot send the whole APDU response in one T=1 Block,
        // thorw an exception if the No Chaining flag is set.
        if (getNoChainingFlag()) {
            if (Lr > blockSize) {
                APDUException.throwIt(APDUException.ILLEGAL_USE);
            }
        }
        short initLen = len;
        while (lenSent < initLen) {
            short sendLen = blockSize;
            if (len < blockSize) {
                sendLen = len;
                // If all that is remaining to be sent plus 2 bytes for
                // SW1SW2 fits within one block, hold off the last I-block
                // to be sent only when calling APDU.complete() and set the
                // "send in progress" flag
                if ((Lr == len) && ((short) (len + (short) 2) <= blockSize)) {
                    setLs(len);
                    setLo(bOff2);
                    setLr((short) 0);
                    setLe((short) 0);
                    setCurrState(APDU.STATE_FULL_OUTGOING);
                    setSendInProgressFlag();
                    return;
                }
            }
            // Send the I-block back to the terminal
            result = NativeMethods.t1SndBlockRcvAck(bOff2, sendLen, false, false);

            if (result != 0) {
                APDUException.throwIt(APDUException.IO_ERROR);
            }

            // Adjust iternal variables to reflect data sent
            bOff2 = (short) (bOff2 + sendLen);
            lenSent = (short) (sendLen + lenSent);
            Lr = (short) (Lr - sendLen);
            len = (short) (len - sendLen);
        }
        Le = Lr;
        // Determine if all data has been sent, or if data remains to be
        // sent, as specified in APDU.setOutgoingLength(..) call
        if (Lr == 0) {
            setCurrState(APDU.STATE_FULL_OUTGOING);
        } else {
            setCurrState(APDU.STATE_PARTIAL_OUTGOING);
        }
        setLe(Le); // update RAM copy of Le, the expected count remaining
        setLr(Lr); // update RAM copy of Lr, the response count remaining
    }

    public void sendBytesLong(byte[] outData, short bOff, short len) throws APDUException, SecurityException {
        NativeMethods.checkArrayArgs(outData, bOff, len);
        NativeMethods.checkPreviousContextAccess(outData);
        short sendLength = (short) buffer.length;
        while (len > 0) {
            if (len < sendLength) {
                sendLength = len;
            }
            Util.arrayCopy(outData, bOff, buffer, (short) 0, sendLength);
            sendBytes((short) 0, sendLength);
            len -= sendLength;
            bOff += sendLength;
        }
    }

    private void setIncoming() throws APDUException {
        // if Java Card runtime environment has undone a previous
        // setIncomingAndReceive ignore
        if (getPreReadLength() != (short) 0) {
            setIncomingFlag();
            return;
        }
        // if we've previously called this or setOutgoing() method,
        // then throw an exception
        if (getIncomingFlag() || getOutgoingFlag()) {
            APDUException.throwIt(APDUException.ILLEGAL_USE);
        }
        setIncomingFlag(); // indicate that this method has been called

        // If the incoming data is greater than 256
        // However, it should never fall into this case as cases 3E and 4E
        // APDUs are never forwarded to an incapable applet.
        if ((!getExtendedSupportFlag()) && (getLc() > MAX_LE)) {
            APDUException.throwIt(ISO7816.SW_WRONG_LENGTH);
        }

        if (getLc() < (short) 0) {
            APDUException.throwIt(ISO7816.SW_WRONG_LENGTH);
        }

    }

    public short setIncomingAndReceive() throws APDUException {
        setIncoming();
        // Extended APDU support: receive bytes at an offset of
        // 5 (that is, 5 + 1).
        if (getExtendedAPDUFlag()) {
            return receiveBytes((short) (ISO7816.OFFSET_CDATA + (short) 2));
        } else {
            return receiveBytes(ISO7816.OFFSET_CDATA);
        }
    }

    public void setOutgoingAndSend(short bOff, short len) throws APDUException {
        setOutgoing();
        setOutgoingLength(len);
        sendBytes(bOff, len);
    }

    public byte getCurrentState() {
        return getCurrState();
    }

    public byte[] getCurrentAPDUBuffer() throws SecurityException {
        return theAPDU.getBuffer();
    }

    public void markExtendedSupport(boolean extAPDUOK) {
        if (extAPDUOK == false) {
            resetExtendedSupportFlag();
            // Check if not an extended APDU.
            // Please note: only on cases 3E and 4E will this be known when
            // unwrapping the APDU from ENVELOPE command.
            // This line would prevent forwarding such APDUs to unsuspecting
            // applets.
            if (getExtendedAPDUFlag()) {
                ISOException.throwIt(ISO7816.SW_WRONG_LENGTH);
            }
        } else {
            setExtendedSupportFlag();
        }
    }

    public short getIncomingLength() {
        return getIL();
    }

    public short getOffsetCdata() {
        if (!getExtendedAPDUFlag()) {
            return (short) (ISO7816.OFFSET_CDATA & (short) 0x7FFF);
        } else {
            return (short) ((short) (ISO7816.OFFSET_CDATA + (short) 2) & (short) 0x7FFF);
        }
    }

    public void verifyLe() {
        if (getLe() < (short) 0) {
            ISOException.throwIt(ISO7816.SW_WRONG_LENGTH);
        }
    }
}
// #endif_Target32Bit_

// End class
