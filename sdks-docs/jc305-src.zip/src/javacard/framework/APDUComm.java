/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package javacard.framework;

interface APDUComm {

    // Package visible methods
    byte getLogicalChannel();

    boolean getNoChainingFlag();

    void resetAPDU();

    void complete(short status) throws APDUException;

    void undoIncomingAndReceive();

    // External visible buffers
    byte getCLAChannel();

    void waitExtension() throws APDUException;

    byte[] getBuffer();

    short getInBlockSize();

    short getOutBlockSize();

    byte getProtocol();

    byte getNAD();

    short setOutgoing() throws APDUException;

    short setOutgoingNoChaining() throws APDUException;

    void setOutgoingLength(short len) throws APDUException;

    short receiveBytes(short bOff) throws APDUException;

    short setIncomingAndReceive() throws APDUException;

    void sendBytes(short bOff, short len) throws APDUException;

    void sendBytesLong(byte[] outData, short bOff, short len) throws APDUException, SecurityException;

    void setOutgoingAndSend(short bOff, short len) throws APDUException;

    byte getCurrentState();

    byte[] getCurrentAPDUBuffer() throws SecurityException;

    void markExtendedSupport(boolean extAPDUOK) throws APDUException;

    short getIncomingLength();

    short getOffsetCdata();

	public boolean isValidCLA();
    
    public boolean isCommandChainingCLA();

    public boolean isSecureMessagingCLA();

    public boolean isISOInterindustryCLA();

    // in case of T=0 this will simply return since we don't have the Le
    // in case of T=1 this will check for the negative Le.
    void verifyLe();
}
