/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package javacard.framework;

import com.sun.javacard.impl.Constants;
import com.sun.javacard.impl.NativeMethods;
import com.sun.javacard.impl.PackedBoolean;
import com.sun.javacard.impl.PrivAccess;

class T0APDUImpl implements APDUComm {

    // This APDU class implements the T=0 transport protocol.

    private static final short BUFFERSIZE = Constants.APDU_BUFFER_LENGTH;
    private static final short MAX_XFER_DATA_LENGTH = (short) (BUFFERSIZE - (short) 5);

    // information field size for ICC i.e Maximum Incoming BlockSize in T=1
    private static final byte IFSC = 1;

    // information field size for IFD i.e Maximum Outgoing BlockSize in T=1
    private static final short IFSD = 258;

    private static APDUComm theAPDU;
    /**
     * The APDU will use the buffer byte[] to store data for input and output.
     */
    private byte[] buffer;
    private byte[] scratchBuffer;

    // Define two state variable buffers: short-length and byte-length.
    private static byte[] ramByteVars;
    private static short[] ramShortVars;

    // State variable 16 bits in length
    private static final byte LE = (byte) 0;
    private static final byte LR = (byte) (LE + 1);
    private static final byte LC = (byte) (LR + 1);
    private static final byte PRE_READ_LENGTH = (byte) (LC + 1);
    private static final byte INCOMIMG_LENGTH = (byte) (PRE_READ_LENGTH + 1);
    private static final byte RAM_SHORT_VARS_LENGTH = (byte) (INCOMIMG_LENGTH + 1);

    // State variables 8 bits in length
    private static final byte CURRENT_STATE = (byte) 0;
    private static final byte LOGICAL_CHN = (byte) (CURRENT_STATE + 1);
    private static final byte RAM_BYTE_VARS_LENGTH = (byte) (LOGICAL_CHN + 1);

    // status code constants
    private static final short BUFFER_OVERFLOW = (short) 0xC001;
    private static final short READ_ERROR = (short) 0xC003;
    private static final short WRITE_ERROR = (short) 0xC004;
    private static final short INVALID_GET_RESPONSE = (short) 0xC006;
    private static final byte ENVELOPE_INS = (byte) 0xC2;

    private static final short MAX_LE = (short) 256;
    private static final short MAX_EXT_LE = (short) 32767;

    // procedure byte type constants
    private static final byte ACK_NONE = (byte) 0;
    private static final byte ACK_INS = (byte) 1;
    private static final byte ACK_NOT_INS = (byte) 2;

    // Le = terminal expected length
    private short getLe() {
        if (ramShortVars[LE] == (short) 0) {
            if (getExtendedSupportFlag()) {
                return MAX_EXT_LE;
            } else {
                return MAX_LE;
            }
        } else {
            return ramShortVars[LE];
        }
    }

    private void setLe(short data) {
        ramShortVars[LE] = (short) (data & (short) 0x7FFF);
    }

    private short getIL() {
        return ramShortVars[INCOMIMG_LENGTH];
    }

    private void setIL(short data) {
        ramShortVars[INCOMIMG_LENGTH] = data;
    }

    // Lr = our response length
    private short getLr() {
        return ramShortVars[LR];
    }

    private void setLr(short data) {
        ramShortVars[LR] = data;
    }

    // Lc = terminal incoming length
    private short getLc() {
        return ramShortVars[LC];
    }

    private void setLc(short data) {
        ramShortVars[LC] = data;
    }

    // PreReadLength = length already received via setIncommingAndReceive().
    // Used for undo operation.short
    private short getPreReadLength() {
        return ramShortVars[PRE_READ_LENGTH];
    }

    private void setPreReadLength(short data) {
        ramShortVars[PRE_READ_LENGTH] = data;
    }

    // currentState = APDU processing state
    private byte getCurrState() {
        return ramByteVars[CURRENT_STATE];
    }

    private void setCurrState(byte data) {
        ramByteVars[CURRENT_STATE] = data;
    }

    private void resetCurrState() {
        ramByteVars[CURRENT_STATE] = APDU.STATE_INITIAL;
    }

    // Logical Channel to whom the APDU is intended to (CLA byte)
    public byte getLogicalChannel() {
        return ramByteVars[LOGICAL_CHN];
    }

    private void setLogicalChannel(byte data) {
        ramByteVars[LOGICAL_CHN] = data;
    }

    private PackedBoolean thePackedBoolean;
    private byte incomingFlag, outgoingFlag, outgoingLenSetFlag, sendInProgressFlag, noChainingFlag, noGetResponseFlag;

    // New APDU flags
    private byte extendedAPDUFlag, envelopeFlag, extendedSupportFlag, determinedLE;

    // IncomingFlag = setIncoming() has been invoked.
    private boolean getIncomingFlag() {
        return thePackedBoolean.get(incomingFlag);
    }

    private void setIncomingFlag() {
        thePackedBoolean.set(incomingFlag);
    }

    private void resetIncomingFlag() {
        thePackedBoolean.reset(incomingFlag);
    }

    private boolean getDeterminedLEFlag() {
        return thePackedBoolean.get(determinedLE);
    }

    private void setDeterminedLEFlag() {
        thePackedBoolean.set(determinedLE);
    }

    private void resetDeterminedLEFlag() {
        thePackedBoolean.reset(determinedLE);
    }

    // SendInProgressFlag = No procedure byte needs to be sent.
    private boolean getSendInProgressFlag() {
        return thePackedBoolean.get(sendInProgressFlag);
    }

    private void setSendInProgressFlag() {
        thePackedBoolean.set(sendInProgressFlag);
    }

    private void resetSendInProgressFlag() {
        thePackedBoolean.reset(sendInProgressFlag);
    }

    // OutgoingFlag = setOutgoing() has been invoked.
    private boolean getOutgoingFlag() {
        return thePackedBoolean.get(outgoingFlag);
    }

    private void setOutgoingFlag() {
        thePackedBoolean.set(outgoingFlag);
    }

    private void resetOutgoingFlag() {
        thePackedBoolean.reset(outgoingFlag);
    }

    // OutgoingLenSetFlag = setOutgoingLength() has been invoked.
    private boolean getOutgoingLenSetFlag() {
        return thePackedBoolean.get(outgoingLenSetFlag);
    }

    private void setOutgoingLenSetFlag() {
        thePackedBoolean.set(outgoingLenSetFlag);
    }

    private void resetOutgoingLenSetFlag() {
        thePackedBoolean.reset(outgoingLenSetFlag);
    }

    public boolean getNoChainingFlag() {
        return thePackedBoolean.get(noChainingFlag);
    }

    private void setNoChainingFlag() {
        thePackedBoolean.set(noChainingFlag);
    }

    private void resetNoChainingFlag() {
        thePackedBoolean.reset(noChainingFlag);
    }

    // noGetResponseFlag = GET RESPONSE command was not received from CAD.
    private boolean getNoGetResponseFlag() {
        return thePackedBoolean.get(noGetResponseFlag);
    }

    private void setNoGetResponseFlag() {
        thePackedBoolean.set(noGetResponseFlag);
    }

    private void resetNoGetResponseFlag() {
        thePackedBoolean.reset(noGetResponseFlag);
    }

    private boolean getExtendedAPDUFlag() {
        return thePackedBoolean.get(extendedAPDUFlag);
    }

    private void setExtendedAPDUFlag() {
        thePackedBoolean.set(extendedAPDUFlag);
    }

    private void resetExtendedAPDUFlag() {
        thePackedBoolean.reset(extendedAPDUFlag);
    }

    private boolean getEnvelopeFlag() {
        return thePackedBoolean.get(envelopeFlag);
    }

    private void setEnvelopeFlag() {
        thePackedBoolean.set(envelopeFlag);
    }

    private void resetEnvelopeFlag() {
        thePackedBoolean.reset(envelopeFlag);
    }

    private boolean getExtendedSupportFlag() {
        return thePackedBoolean.get(extendedSupportFlag);
    }

    private void setExtendedSupportFlag() {
        thePackedBoolean.set(extendedSupportFlag);
    }

    private void resetExtendedSupportFlag() {
        thePackedBoolean.reset(extendedSupportFlag);
    }

    // This private method implements ISO 7816-4 logic to determine
    // the logical channel to whom this APDU command is intended to.
    private byte getChannelInfo() {
        byte theAPDUChannel;

        if((short)(scratchBuffer[ISO7816.OFFSET_CLA] & 0x00FF) == 0x00FF){
            theAPDUChannel = (byte) 0;
        }
        else if (isType16CLA(scratchBuffer)) {
            theAPDUChannel = (byte) (scratchBuffer[ISO7816.OFFSET_CLA] & APDU.LOGICAL_CHN_MASK_TYPE16);
            theAPDUChannel = (byte) (theAPDUChannel + (byte) 4);
        } else {
            if ((byte) (scratchBuffer[ISO7816.OFFSET_CLA] & APDU.APDU_INVALID_TYPE4_MASK) != (byte) 0) {
                theAPDUChannel = (byte) 0;
            } else {
                theAPDUChannel = (byte) (scratchBuffer[ISO7816.OFFSET_CLA] & APDU.LOGICAL_CHN_MASK_TYPE4);
            }
        }
        return theAPDUChannel;
    }

    // Current State Constants
    T0APDUImpl() {
        buffer = NativeMethods.initAPDUBuffer();
        scratchBuffer = NativeMethods.t0InitScratchAPDUBuffer();
        ramByteVars = JCSystem.makeTransientByteArray(RAM_BYTE_VARS_LENGTH, JCSystem.CLEAR_ON_RESET);
        ramShortVars = JCSystem.makeTransientShortArray(RAM_SHORT_VARS_LENGTH, JCSystem.CLEAR_ON_RESET);

        thePackedBoolean = PrivAccess.getPackedBoolean();
        incomingFlag = thePackedBoolean.allocate();
        sendInProgressFlag = thePackedBoolean.allocate();
        outgoingFlag = thePackedBoolean.allocate();
        outgoingLenSetFlag = thePackedBoolean.allocate();
        noChainingFlag = thePackedBoolean.allocate();
        noGetResponseFlag = thePackedBoolean.allocate();
        extendedAPDUFlag = thePackedBoolean.allocate();
        envelopeFlag = thePackedBoolean.allocate();
        extendedSupportFlag = thePackedBoolean.allocate();
        determinedLE = thePackedBoolean.allocate();
        theAPDU = this;
    }

    public byte[] getBuffer() {
        return buffer;
    }

    public short getInBlockSize() {
        return IFSC;
    }

    public short getOutBlockSize() {
        return IFSD;
    }

    public byte getProtocol() {
        return (byte) (APDU.PROTOCOL_MEDIA_DEFAULT + APDU.PROTOCOL_T0);
    }

    public byte getNAD() {
        return (byte) 0;
    }

    private void getRemainingInbound() {
        // This is for case of extended APDU, when the applet decides to
        // switch towards the outbound direction or send status
        // without first receiving all incoming data.
        // Get all remaining extended APDU data before turning around
        // and sending a reply. This is necessary to ensure synchronization
        // between T=0 clients and terminals supporting extended APDU.
        // We accomplish this by sending 0x9000 status replies and receiving
        // all remaining Envelope commands for this APDU.
        if (getEnvelopeFlag()) {
            while (getEnvelopeFlag() || !getDeterminedLEFlag()) {
                // Attempt to get any remaining data from this ENVELOPE command
                short len = NativeMethods.t0RcvData(ISO7816.OFFSET_CDATA);
                if (len == 0) {
                    // If no data available in this envelope command, attempt
                    // to retrieve the next envelope command.
                    NativeMethods.t0SetStatus((short) 0x9000);
                    short result = NativeMethods.t0SndStatusRcvCommand();
                    len = processEnvelopeData((ISO7816.OFFSET_CDATA));
                }

                if (len == (short) (-1)) {
                    // Did not receive ENVELOPE command
                    // It is possible that the card and terminal are
                    // out of sync.
                    // T=0 provides no resynching mechanisms other than error
                    // status on APDUs, so throw an error and hopefully the
                    // teminal will resync.
                    APDUException.throwIt(APDUException.IO_ERROR);
                }
                short Lc = getLc();
                Lc = (short) (Lc - len);
                if (Lc < (short) 0) {
                    short bOff = (ISO7816.OFFSET_CDATA);
                    if (Lc == (short) -1) {
                        if (!getDeterminedLEFlag()) {
                            // Partially received LE - setting the flag
                            // with Envelope indicates partial reception
                            // comment out for bugfix No LE in T=0 Extended TPDU
							// setLe((short) ((scratchBuffer[(short) (bOff + len - (short) 1)] & (short) 0x00FF) << (short) 8));
                            setDeterminedLEFlag();
                            Lc = (short) 0;
                        } else {
                            // Partially received LE - setting the flag
                            // with Envelope indicates partial reception
                            // comment out for bugfix No LE in T=0 Extended TPDU
							// setLe((short) (getLe() | ((scratchBuffer[(short) (bOff + len - (short) 1)] & (short) 0x00FF))));
                            resetEnvelopeFlag();
                            Lc = (short) 0;
                        }
                    } else {
                        // Case 4E: LE information has been received in the
                        // last t0RcvData call or in the last ENVELOPE command
                        // comment out for bugfix No LE in T=0 Extended TPDU
						// setLe(Util.makeShort(scratchBuffer[(short) (bOff + len - (short) 2)],
                        //        scratchBuffer[(short) (bOff + len - (short) 1)]));
                        Lc = (short) 0;
                        len = (short) (len - (short) 2);
                        // Determined LE set and Envelope Flag not set
                        // indicates full LE reception
                        setDeterminedLEFlag();
                        resetEnvelopeFlag();
                    }
                } // LC data complete
                setLc(Lc); // update RAM copy of Lc, the count remaining
            } // while loop
        } // if more blocks coming...
    }

    public short setOutgoing() throws APDUException {

        // If we've previously called this method, then throw an exception
        if (getOutgoingFlag()) {
            APDUException.throwIt(APDUException.ILLEGAL_USE);
        }
        // Get all remaining inbound data
        getRemainingInbound();
        setOutgoingFlag();
        setCurrState(APDU.STATE_OUTGOING);
        return getLe();

    }

    public short setOutgoingNoChaining() throws APDUException {
        // if we've previously called this method, then throw an exception
        if (getOutgoingFlag()) {
            APDUException.throwIt(APDUException.ILLEGAL_USE);
        }
        getRemainingInbound();
        setOutgoingFlag();
        setNoChainingFlag();
        setCurrState(APDU.STATE_OUTGOING);
        short le = getLe();
        if (le==MAX_EXT_LE) { le = MAX_LE; }
        return le;
    }

    public void setOutgoingLength(short len) throws APDUException {
        if (!getOutgoingFlag()) {
            APDUException.throwIt(APDUException.ILLEGAL_USE);
        }

        // if we've previously called this method, then throw an exception
        if (getOutgoingLenSetFlag()) {
            APDUException.throwIt(APDUException.ILLEGAL_USE);
        }

        // If the outbound length is being set to more than 256 and the applet
        // does not implement the ExtendedAPDU interface, throw an exception.
        if ((len > MAX_LE) && (!getExtendedSupportFlag())) {
            APDUException.throwIt(APDUException.BAD_LENGTH);
        }

        // If the outbound length is being set to more than 256 and the applet
        // has requested no chaining throw an exception
        if ((len > MAX_LE) && (getNoChainingFlag())) {
            APDUException.throwIt(APDUException.BAD_LENGTH);
        }

        if (len < 0) {
            APDUException.throwIt(APDUException.BAD_LENGTH);
        }
        setOutgoingLenSetFlag();
        setCurrState(APDU.STATE_OUTGOING_LENGTH_KNOWN);
        setLr(len);

        if (len > MAX_LE) {
            setExtendedAPDUFlag();
        }
    }

    private void setIncoming() throws APDUException {
        // if Java Card runtime environment has undone a previous
        // setIncomingAndReceive ignore
        if (getPreReadLength() != (short) 0) {
            return;
        }
        // if we've previously called this or setOutgoing() method,
        // then throw an exception
        if (getIncomingFlag() || getOutgoingFlag()) {
            APDUException.throwIt(APDUException.ILLEGAL_USE);
        }
        setIncomingFlag(); // indicate that this method has been called
        short Lc = getLe(); // what we stored in Le was really Lc

        // If the incoming data is greater than 256 and the applet does
        // not support extended APDUs...
        if ((!getExtendedSupportFlag()) && (Lc > (short) 256)) {
            APDUException.throwIt(ISO7816.SW_WRONG_LENGTH);
        }
        setLc(Lc);
        setIL(Lc);
        setLe((short) 0); // in T=0, the real Le is now unknown (assume 256)
    }

    public short receiveBytes(short bOff) throws APDUException {
        // Main receive method. This method will receive data from the CAD,
        // or it will issue a positive reply toretrieve the next APDU command.
        // Only APDUs case 3 and 4 are expected to call this method.
        if (!getIncomingFlag() || getOutgoingFlag()) {
            APDUException.throwIt(APDUException.ILLEGAL_USE);
        }
        short Lc = (short) (getLc() & (short) 0x7FFF);

        if (bOff < 0) {
            APDUException.throwIt(APDUException.BUFFER_BOUNDS);
        }

        short pre = (short) (getPreReadLength() & (short) 0x7FFF);
        if (pre != 0) {
            setPreReadLength((short) 0);
            if (Lc == 0) {
                setCurrState(APDU.STATE_FULL_INCOMING);
            } else {
                setCurrState(APDU.STATE_PARTIAL_INCOMING);
            }
            return pre;
        }

        short len;
        if (Lc != (short) 0) {
            if (!getEnvelopeFlag()) {

                // Non-envelope case - call t0RcvData
                len = NativeMethods.t0RcvData(bOff);
                if (len < (short) 0) {
                    APDUException.throwIt(APDUException.IO_ERROR);
                }
            } else {
                // Envelope case - call t0RcvData first
                len = NativeMethods.t0RcvData(bOff);
                if (len < (short) 0) {
                    APDUException.throwIt(APDUException.IO_ERROR);
                }

                if (len == 0) {
                    // Envelope case - retrieve next ENVELOPE APDU if needed
                    NativeMethods.t0SetStatus((short) 0x9000);
                    NativeMethods.t0SndStatusRcvCommand();
                    // verify that data is properly received in an
                    // Envelope command
                    len = processEnvelopeData(bOff);
                }
            }
            // Move from scratch buffer to APDU buffer
            NativeMethods.t0CopyToAPDUBuffer(bOff, len);
            Lc = (short) (Lc - len);
            if (Lc < (short) 0) {
                if (Lc == (short) -1) {
                    // Partially received LE - setting the flag with Envelope
                    // indicates partial reception
                    // comment out for bugfix No LE in T=0 Extended TPDU
					// setLe((short) ((buffer[(short) (bOff + len - (short) 1)] & (short) 0x00FF) << (short) 8));
                    Lc = (short) 0;
                    len = (short) (len - (short) 1);
                    setDeterminedLEFlag();

                } else {
                    // case 4E: Received LE in message
                    // comment out for bugfix No LE in T=0 Extended TPDU
					// comment out for bugfix No LE in T=0 Extended TPDU
					// setLe(Util.makeShort(buffer[(short) (bOff + len - (short) 2)],
                    //        buffer[(short) (bOff + len - (short) 1)]));
                    Lc = (short) 0;
                    len = (short) (len - (short) 2);
                    // Determined LE set and Envelope Flag not set indicates
                    // full LE reception
                    setDeterminedLEFlag();
                    resetEnvelopeFlag();
                }
            }
            setLc(Lc); // update RAM copy of Lc, the count remaining
            if (Lc == (short) 0) {
                setCurrState(APDU.STATE_FULL_INCOMING);
            } else {
                setCurrState(APDU.STATE_PARTIAL_INCOMING);
            }
            return len;
        } else {
            // This is the case where LE is missing one byte
            if (getEnvelopeFlag() && getDeterminedLEFlag()) {
                len = NativeMethods.t0RcvData(bOff);
                if (len < (short) 0) {
                    APDUException.throwIt(APDUException.IO_ERROR);
                }

                if (len == 0) {
                    // Envelope case
                    Util.arrayFillNonAtomic(buffer, (short) 0, BUFFERSIZE, (byte) 0);
                    NativeMethods.t0SetStatus((short) 0x9000);
                    NativeMethods.t0SndStatusRcvCommand();
                    // verify that data is properly received in an
                    // Envelope command if it is not...
                    len = processEnvelopeData(bOff);
                }

                // Copy data to APDU buffer
                NativeMethods.t0CopyToAPDUBuffer(bOff, len);
                // Process that one byte LE
                // comment out for bugfix No LE in T=0 Extended TPDU
				// setLe((short) (getLe() | ((buffer[(short) (bOff + len - (short) 1)] & (short) 0x00FF))));
                resetEnvelopeFlag();
            }
        }

        setCurrState(APDU.STATE_FULL_INCOMING);
        return (short) 0;
    }

    public short setIncomingAndReceive() throws APDUException {
        setIncoming();
        // Extended APDU support: receive bytes at an offset of
        // 5 (that is, 5 + 1).
        if (getExtendedAPDUFlag()) {
            return receiveBytes((short) (ISO7816.OFFSET_CDATA + (short) 2));
        } else {
            return receiveBytes(ISO7816.OFFSET_CDATA);
        }
    }

    private short send61xx(short len) {

        byte originChannel = getCLAChannel();
        short expLen = len;
        do {
            // Set SW1SW2 as 61xx. For Case 2E and 4E, set to 6100 if more
            // than 256 bytes are to be sent inthe outbound direction.
            if (len >= MAX_LE) {
                NativeMethods.t0SetStatus((ISO7816.SW_BYTES_REMAINING_00));
            } else {
                NativeMethods.t0SetStatus((short) (ISO7816.SW_BYTES_REMAINING_00 + (short) (len & (short) 0x00FF)));
            }
            short newLen = NativeMethods.t0SndGetResponse(originChannel);
            if (newLen == INVALID_GET_RESPONSE) {
                // Get Response not received
                setNoGetResponseFlag();
                APDUException.throwIt(APDUException.NO_T0_GETRESPONSE);
            } else if (newLen > 0) {
                setLe(newLen);
                expLen = getLe();
            } else {
                APDUException.throwIt(APDUException.IO_ERROR);
            }
        } while (expLen > len);

        resetSendInProgressFlag();
        return expLen;
    }

    public void sendBytes(short bOff, short len) throws APDUException {

        short result;
        if ((bOff < 0) || (len < 0) || ((short) ((bOff + len)) > BUFFERSIZE)) {
            APDUException.throwIt(APDUException.BUFFER_BOUNDS);
        }
        if (!getOutgoingLenSetFlag() || getNoGetResponseFlag()) {
            APDUException.throwIt(APDUException.ILLEGAL_USE);
        }
        if (len == 0) {
            return;
        }
        short Lr = getLr();
        if (len > Lr) {
            APDUException.throwIt(APDUException.ILLEGAL_USE);
        }

        short Le = getLe();

        if (getNoChainingFlag()) {
            // Need to force GET RESPONSE for
            // Case 4 or
            // Case 2 but sending less than CAD expects
            if (getIncomingFlag() || (Lr < Le)) {
                Le = send61xx(Lr); // expect Le==Lr,resets sendInProgressFlag
                resetIncomingFlag(); // no more incoming->outgoing switch.
            }

            while (len > Le) { // sending more than Le
                if (!getSendInProgressFlag()) {
                    result = NativeMethods.t0SndData(buffer, bOff, Le, ACK_INS);
                    setSendInProgressFlag();
                } else {
                    result = NativeMethods.t0SndData(buffer, bOff, Le, ACK_NONE);
                }

                if (result != 0) {
                    APDUException.throwIt(APDUException.IO_ERROR);
                }

                bOff += Le;
                len -= Le;
                Lr -= Le;
                Le = send61xx(Lr); // resets sendInProgressFlag.
            }

            if (!getSendInProgressFlag()) {
                result = NativeMethods.t0SndData(buffer, bOff, len, ACK_INS);
                setSendInProgressFlag();
            } else {
                result = NativeMethods.t0SndData(buffer, bOff, len, ACK_NONE);
            }

            if (result != 0) {
                APDUException.throwIt(APDUException.IO_ERROR);
            }
            Lr -= len;
            Le -= len;
        } else { // noChainingFlag = FALSE
            while (len > 0) {
                short temp = len;
                // Need to force GET RESPONSE for Case 4 & for partial blocks
                if ((len != Lr) || getIncomingFlag() || (Lr != Le) || getSendInProgressFlag()) {
                    temp = send61xx(len); // resets sendInProgressFlag.
                    resetIncomingFlag(); // no more incoming->outgoing
                    // switch.
                }
                result = NativeMethods.t0SndData(buffer, bOff, temp, ACK_INS);
                setSendInProgressFlag();

                if (result != 0) {
                    APDUException.throwIt(APDUException.IO_ERROR);
                }
                bOff += temp;
                len -= temp;
                Lr -= temp;
                Le = Lr;
            }
        }

        if (Lr == 0) {
            setCurrState(APDU.STATE_FULL_OUTGOING);
        } else {
            setCurrState(APDU.STATE_PARTIAL_OUTGOING);
        }
        setLe(Le); // update RAM copy of Le, the expected count remaining
        setLr(Lr); // update RAM copy of Lr, the response count remaining
    }

    public void sendBytesLong(byte[] outData, short bOff, short len) throws APDUException, SecurityException {
        NativeMethods.checkArrayArgs(outData, bOff, len);
        NativeMethods.checkPreviousContextAccess(outData);
        short sendLength = (short) buffer.length;
        while (len > 0) {
            if (len < sendLength) {
                sendLength = len;
            }
            Util.arrayCopy(outData, bOff, buffer, (short) 0, sendLength);
            sendBytes((short) 0, sendLength);
            len -= sendLength;
            bOff += sendLength;
        }
    }

    public void setOutgoingAndSend(short bOff, short len) throws APDUException {
        setOutgoing();
        setOutgoingLength(len);
        sendBytes(bOff, len);
    }

    public byte getCurrentState() {
        return getCurrState();
    }

    public byte[] getCurrentAPDUBuffer() throws SecurityException {
        return theAPDU.getBuffer();
    }

    public byte getCLAChannel() {
        return theAPDU.getLogicalChannel();
    }

    public void resetAPDU() {
        // Reset flags
        resetIncomingFlag();
        resetOutgoingFlag();
        resetOutgoingLenSetFlag();
        resetSendInProgressFlag();
        resetNoChainingFlag();
        resetNoGetResponseFlag();
        resetExtendedAPDUFlag();
        resetEnvelopeFlag();
        resetDeterminedLEFlag();
        setPreReadLength((byte) 0);
    }

    private short processEnvelopeData(short bOffset) {
        // This method is called when an ENVELOPE command is expected
        // in order to retrieve its payload.
        // If this is not an ENVELOPE command... send I/O Error.
        if ((isISOInterindustryCLA(scratchBuffer)) && (scratchBuffer[ISO7816.OFFSET_INS] == ENVELOPE_INS)) {
            // retrieve the data and put it where it is requested.
            short len = NativeMethods.t0RcvData(bOffset);
            if (len < (short) 0) {
                APDUException.throwIt(APDUException.IO_ERROR);
            }
            return len;
        } else {
            APDUException.throwIt(APDUException.IO_ERROR);
        }
        return (short) (-1);
    }

    private void processEnvelopeAPDU() throws APDUException {
        if ((isISOInterindustryCLA(scratchBuffer)) && (scratchBuffer[ISO7816.OFFSET_INS] == ENVELOPE_INS)) {
            // This is an envelope command - de-envelope APDU

            // Now, unwrap the APDU and find out LE and LC.
            short apduLen = setIncomingAndReceive();

            // The data is in the APDU buffer. Shift it to make it look like
            // the wrapped APDU and recalculate APDU object state.
            for (short i = (short) 0; i < apduLen; i++) {
                scratchBuffer[i] = scratchBuffer[(short) (ISO7816.OFFSET_CDATA + i)];
            }
            // Zero out what has been shifted
            Util.arrayFillNonAtomic(scratchBuffer, apduLen, (short) (BUFFERSIZE - apduLen), (byte) 0);

            // We know that this APDU is either case 3 or 4, so LC has a value.
            // Parse APDU and figure out LC, LE and whether this APDU is
            // extended or not.
            short apduDataLen = (short) (apduLen - (short) 5);

            // Process the recently unwrapped APDU - by resetting the old one.
            resetAPDU();
            preProcessAPDU();
            setEnvelopeFlag();
            // Case 1: LC would be 0, apduDataLen would be 0
            // Case 3S: LC would be equal to apduDataLen.
            // Case 4S: LC would be apduDataLen - 1
            // case 3E, 4E: LC would be something else...
            setLc(getLe());
            setIL(getLc());
            short shortLC = getLc();

            short extendedLC = Util.makeShort(scratchBuffer[ISO7816.OFFSET_CDATA],
                    scratchBuffer[(short) (ISO7816.OFFSET_CDATA + (short) 1)]);

            if (shortLC == apduDataLen) {
                // Case 3S
                setLe((short) 0);
            } else if (shortLC == (short) (apduDataLen - (short) 1)) {
                // Case 4S
                setLe((scratchBuffer[(short) (apduLen - (short) 1)]));
            } else if (extendedLC > apduDataLen) {
                // Extended cases
                setExtendedAPDUFlag();
                setLc((short) (extendedLC - (apduDataLen - (short) 2)));
                setIL(extendedLC);
                // Set LE temporarily to 0
                setLe((short) 0);
            } // else if cases 1S and 2S

            // Allow the applet to call setIncomingAndReceive() again.
            // Also, set the pre- read length to a known value.
            undoIncomingAndReceiveForEnvelope((short) (extendedLC - getLc()));
            setLogicalChannel(getChannelInfo());
        }
        // Copy entire scratch buffer to APDU buffer
        NativeMethods.t0CopyToAPDUBuffer((short) 0, BUFFERSIZE);
    }

    private void undoIncomingAndReceiveForEnvelope(short totalLength) {
        setPreReadLength(totalLength);
        setCurrState(APDU.STATE_INITIAL);
        // Case 3E or 4E APDU - setIncoming flag is set, not setOutgoing
        setIncomingFlag();
        resetOutgoingFlag();
    }

    private void preProcessAPDU() {
        // as described earlier, we assume case 1 or 2S, so Le=P3 and Lc=0
        setLe((short) (scratchBuffer[ISO7816.OFFSET_LC] & 0x00ff));
        setLc((short) 0);
        setIL((short) (scratchBuffer[ISO7816.OFFSET_LC] & 0x00ff));
        resetCurrState();

        // set logical channel information as specified in the APDU CLA byte
        setLogicalChannel(getChannelInfo());
        setLr((short) 0);
    }

    public void markExtendedSupport(boolean extAPDUOK) throws APDUException {
        if (extAPDUOK == false) {
            resetExtendedSupportFlag();
            // Check if not an extended APDU.
            // Please note: only on cases 3E and 4E will this be known when
            // unwrapping the APDU from ENVELOPE command.
            // This line would prevent forwarding such APDUs to unsuspecting
            // applets.
            if (getExtendedAPDUFlag()) {
                ISOException.throwIt(ISO7816.SW_WRONG_LENGTH);
            }
            // In case 2E and applet does not support ExtendedLength,
            // set LE to 256.
            if ((getLe() == 0) && (!getEnvelopeFlag())) {
                setLe(MAX_LE);
            }
        } else {
            setExtendedSupportFlag();
            // In case 2E, set LE to 32,767 if P3 = 0.
            if ((getLe() == MAX_LE) && (!getEnvelopeFlag())) {
                setLe(MAX_EXT_LE);
            }
        }
    }

    public void complete(short status) throws APDUException {
        short result;

        // Zero out APDU buffer
        Util.arrayFillNonAtomic(buffer, (short) 0, BUFFERSIZE, (byte) 0);

        if ((!getNoGetResponseFlag()) && (getSendInProgressFlag())) {
            short Le = (byte) getLe();
            short sendLen = MAX_XFER_DATA_LENGTH;
            while (Le > 0) {
                if (Le < MAX_XFER_DATA_LENGTH) {
                    sendLen = Le;
                }
                result = NativeMethods.t0SndData(buffer, (byte) 0, sendLen, ACK_NONE);
                if (result != 0) {
                    APDUException.throwIt(APDUException.IO_ERROR);
                }
                Le -= sendLen;
            }
        }

        buffer[0] = (byte) (status >> 8);
        buffer[1] = (byte) status;

        if (status == 0) {
            result = NativeMethods.t0RcvCommand();
        } else {
            getRemainingInbound(); // discard any remaining incoming Envelope commands
            NativeMethods.t0SetStatus(status);
            result = NativeMethods.t0SndStatusRcvCommand();
        }

        if (result != 0) {
            APDUException.throwIt(APDUException.IO_ERROR);
        }

        resetExtendedSupportFlag();
        resetAPDU();
        preProcessAPDU();
        processEnvelopeAPDU();
    }

    public void undoIncomingAndReceive() {
        setPreReadLength((short) ((buffer[ISO7816.OFFSET_LC] - getLc()) & 0x7FFF));
        setCurrState(APDU.STATE_INITIAL);
    }

    public void waitExtension() throws APDUException {

        if (theAPDU.getNoChainingFlag()) {
            APDUException.throwIt(APDUException.ILLEGAL_USE);
        }
        // send a procedure byte of 0x60 to request additional waiting time.
        short result = NativeMethods.t0Wait();
        if (result != 0) {
            APDUException.throwIt(APDUException.IO_ERROR);
        }
    }

    private boolean isExtended() {
        return getExtendedSupportFlag();
    }

    public boolean isValidCLA() {
        byte cla = buffer[ISO7816.OFFSET_CLA];        
        return (((((byte)(cla&0xE0)==(byte)0x20))||(cla==(byte)0xFF)) ? false:true);
    }

    public boolean isCommandChainingCLA() {
        byte theCLAChaining;

        if (!isValidCLA()) { return false; }
        theCLAChaining = (byte) (buffer[ISO7816.OFFSET_CLA] & APDU.APDU_CHAINING_MASK);
        if (theCLAChaining == (byte) 0x10) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isSecureMessagingCLA() {
        byte secureMsgFlag;
        
        if (!isValidCLA()) { return false; }
        if (isType16CLA(buffer)) {
            secureMsgFlag = (byte) (buffer[ISO7816.OFFSET_CLA] & APDU.APDU_SM_MASK_TYPE16);
        } else {
            secureMsgFlag = (byte) (buffer[ISO7816.OFFSET_CLA] & APDU.APDU_SM_MASK_TYPE4);
        }

        if (secureMsgFlag == (byte) 0) {
            return false;
        } else {
            return true;
        }
    }

    public boolean isISOInterindustryCLA() {

        return isISOInterindustryCLA(buffer);
    }

    private boolean isISOInterindustryCLA(byte[] aBuffer) {
        byte theCLAType;

        theCLAType = (byte) (aBuffer[ISO7816.OFFSET_CLA] & APDU.APDU_ISOCLASS_MASK);
        if (theCLAType == (byte) 0x00) {
            return true;
        } else {
            return false;
        }
    }

    private boolean isType16CLA(byte[] aBuffer) {
        byte theCLAType;

        theCLAType = (byte) (aBuffer[ISO7816.OFFSET_CLA] & APDU.APDU_TYPE_MASK);
        if (theCLAType == 0x40) {
            return true;
        } else {
            return false;
        }
    }

    public short getIncomingLength() {
        return getIL();
    }

    public short getOffsetCdata() {
        if (!getExtendedAPDUFlag()) {
            return (short) (ISO7816.OFFSET_CDATA & (short) 0x7FFF);
        } else {
            return (short) (ISO7816.OFFSET_EXT_CDATA & (short) 0x7FFF);
        }
    }

    public void verifyLe() {
        // do nothing, simply return
    }

}
