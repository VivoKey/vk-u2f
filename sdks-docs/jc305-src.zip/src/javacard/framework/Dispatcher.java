/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package javacard.framework;

import javacard.framework.service.ServiceException;
import javacard.security.CryptoException;
import javacardx.apdu.ExtendedLength;
import javacardx.biometry.BioException;
import javacardx.framework.tlv.TLVException;
import javacardx.framework.util.UtilException;
// #ifdef_Target32Bit_
import javacardx.framework.string.StringException;
// #endif_Target32Bit_

import com.sun.javacard.impl.AppletMgr;
import com.sun.javacard.impl.CryptoInit;
import com.sun.javacard.impl.GarbageCollector;
import com.sun.javacard.impl.NativeMethods;
import com.sun.javacard.impl.PackageMgr;
import com.sun.javacard.impl.PrivAccess;
import com.sun.javacard.impl.SecurityExceptionHelper;

/**
 * The Dispatcher class contains the main entry point and the main loop of the
 * card; it dispatches APDUs to applets.
 */
class Dispatcher {
    // Constants
    private static final byte INS_SELECT = (byte) 0xA4;
    private static final byte INS_MANAGECHANNEL = (byte) 0x70;
    private static final byte P1_SELECT_DFBYNAME = (byte) 0x04;

    private static final byte P2_SELECT_OPTIONS = (byte) 0xE3;
    private static final byte P2_SELECT_OPTIONS_ONLY = 0x00;

    private static final byte P1_OPEN_CHANNEL = (byte) 0x00;
    private static final byte P1_CLOSE_CHANNEL = (byte) 0x80;
    private static final byte P2_AUTOSELECT_CHANNEL = (byte) 0x00;
    private static final byte ERR_NO_CHANNEL_AVAILABLE = (byte) 0xFF;
    private static final byte BASIC_CHANNEL = (byte) 0x00;

    // Exceptions for system
    private static ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException;
    private static NegativeArraySizeException negativeArraySizeException;
    private static NullPointerException nullPointerException;
    private static ClassCastException classCastException;
    private static ArithmeticException arithmeticException;
    static SecurityException securityException; // used by APDU to flag security
    // exception
    private static ArrayStoreException arrayStoreException;
    private static SystemException systemException;
    private static TransactionException transactionException;
    //private static ServiceException serviceException;
    private static UtilException utilException;

    // #ifdef_Target32Bit_
    private static StringException stringException;
    // #endif_Target32Bit_

    // Logical channel operations
    private static final byte OP_CHANNEL_CLOSE = (byte) 0x00;
    private static final byte OP_CHANNEL_OPEN = (byte) 0x01;
    private static final byte OP_CHANNEL_OPEN_AUTOSELECT = (byte) 0x02;

    // Channel status constants
    private static final byte CHANNEL_CLOSED = (byte) 0x00;
    private static final byte CHANNEL_DISABLED = (byte) 0x01;
    private static final byte CHANNEL_OPEN = (byte) 0x02;
    private static final byte CHANNEL_OPEN_MS = (byte) 0x03;

    // Useful constants
    private static final byte CHANNEL_MS_MASK = (byte) 0x01;
    private static final byte CHANNEL_OPEN_MASK = (byte) 0x02;

    // Static class fields, with initialization done in init()
    private static APDU theAPDU;
    private static byte[] theAPDUBuffer;
    private static PrivAccess thePrivAccess;
    private static short[] internArraySensitiveResultStateMachine;
    private static short lenInternArrSensitResStateMachine = (short)0x05;

    // other static fields
    static Dispatcher theDispatcher;

    /**
     * Main entry point invoked by the virtual machine when the card is reset.
     */
    static void main() {
        if (!NativeMethods.isCardInitialized()) {
            cardInit(); // card initialization (first time only)
        }
        cardReset(); // session initialization (each card reset)
        short sw = 0;

        // main loop
        while (true) {
            PrivAccess.resetSelectingAppletFlag();
            PrivAccess.resetProcessMethodFlag();
            theAPDU.complete(sw); // respond to previous APDU and get next
            byte activeInterface = NativeMethods.getActiveInterface();
            try {
                // Before we proceed we need to check if Le has correct value.
                // We need to do this check here because we want to send back
                // error SW_WRONG_LENGTH to the interface device. The following
                // line may throw ISOException(SW_WRONG_LENGTH)
                theAPDU.verifyLe();

                // Process channel information
                if (processAndForward()) { // Dispatcher handles the SELECT
                    // APDU
                    // dispatch to the currently selected applet
                    byte commandChannel = NativeMethods.getCurrentlySelectedChannel();
                    if (PrivAccess.getSelectedAppID(commandChannel, activeInterface) == PrivAccess.APP_NULL) {
                        // if no applet selected
                        ISOException.throwIt(ISO7816.SW_APPLET_SELECT_FAILED);
                    }
                    PrivAccess.setProcessMethodFlag();

                    // Extended APDU support by applet
                    Applet selectedApplet = PrivAccess.getSelectedApplet(commandChannel, activeInterface);
                    if (selectedApplet instanceof ExtendedLength) {
                        theAPDU.markExtendedSupport(true);
                    } else {
                        theAPDU.markExtendedSupport(false);
                    }
                    // Call the Applet's process method
                    selectedApplet.process(theAPDU);
                    // abort transaction if applet forgot to commit it
                    if (JCSystem.getTransactionDepth() != 0) {
                        TransactionException.throwIt(TransactionException.IN_PROGRESS);
                    }
                }
                sw = ISO7816.SW_NO_ERROR;
            } catch (ISOException ex) {
                // get SW from ISOException reason
                sw = ex.getReason();
            } catch (Throwable e) {
                // any other exception is unknown reason
                sw = ISO7816.SW_UNKNOWN;
            }

            // abort transaction if still in progress
            if (JCSystem.getTransactionDepth() != 0) {
                JCSystem.abortTransaction();
            }

            // did the applet request garbage collection? If it did, call the
            // garbage collector
            if (thePrivAccess.isGarbageCollectionRequested()) {
                GarbageCollector.startGC();
            }
        }
    }

    /**
     * Called by processAndForward(..) to set logical Channels Information
     * correctly.
     */
    private static void setAPDUChannel(boolean forISOStandardAPDU) throws SystemException {

        // Analyze APDU CLA byte
        byte theAPDUChannel = APDU.getCLAChannel();

        // If channel > max channel, throw exception
        if (theAPDUChannel >= PrivAccess.NUM_ISO_CHANNELS) {
            ISOException.throwIt(ISO7816.SW_LOGICAL_CHANNEL_NOT_SUPPORTED);
        }

        byte channelStatus = NativeMethods.getChannelStatus(theAPDUChannel, NativeMethods.getActiveInterface());

        if(!forISOStandardAPDU){
            // for non-ISO industry commands if the channel is not already
            // open, throw SW_LOGICAL_CHANNEL_NOT_SUPPORTED
            if(channelStatus == CHANNEL_CLOSED){
                ISOException.throwIt(ISO7816.SW_LOGICAL_CHANNEL_NOT_SUPPORTED);
            }
        }

        // Set the APDU channel according to channel encoding
        NativeMethods.setCurrentlySelectedChannel(theAPDUChannel, NativeMethods.getActiveInterface());

    }

    /**
     * Processes the APDUs handled by the Dispatcher. This method also
     * determines whether the APDU should be forwarded to the applet.
     *
     * @return true if APDU is to be forwarded to applet, false otherwise
     * @exception ISOException
     *                if an ISO 7816 error code is generated during command
     *                processing
     */
    private static boolean processAndForward() throws ISOException {
        // Filter channel information to detect ISO APDUs
        if (theAPDU.isISOInterindustryCLA()) {
            // SM bits are equal to 00
            setAPDUChannel(true);
            switch (theAPDUBuffer[ISO7816.OFFSET_INS]) {
                // ISO 7816-4 SELECT FIlE command
                case INS_SELECT:
                    // Check for secure messaging bits - if set, return error
                    if (theAPDU.isSecureMessagingCLA()) {
                        // Pass APDU to application for proecessing if
                        // Secure Messaging bits are set
                        break;
                    }
                    theDispatcher.selectAPDU(theAPDU);
                    return true;
                    // ISO 7816-4 MANAGE CHANNEL command
                case INS_MANAGECHANNEL:
                    // Check for secure messaging bits - if set, return error
                    if (theAPDU.isSecureMessagingCLA()) {
                        // MANAGE CHANNEL commands with secure messaging
                        // bits should not be passed to the application.
                        ISOException.throwIt(ISO7816.SW_SECURE_MESSAGING_NOT_SUPPORTED);
                    }
                    theDispatcher.manageChannelAPDU(theAPDU);
                    return false;
            }
        }else{
            setAPDUChannel(false);
        }
        return true;
    }

    void manageChannelAPDU(APDU theAPDU) throws ISOException {

        byte newChannel = (byte) (0xFF);
        final byte cmdChannel = NativeMethods.getCurrentlySelectedChannel();
        byte channelStatus;
        final byte maxChannels = NativeMethods.getMaxChannels();
        byte activeInterface = NativeMethods.getActiveInterface();

        // If card has only one channel, functionality is not
        // supported.
        if (maxChannels == (byte) 1) {
            ISOException.throwIt(ISO7816.SW_LOGICAL_CHANNEL_NOT_SUPPORTED);
        }

        // If managing channel is closed, return error
        if (NativeMethods.getChannelStatus(cmdChannel, activeInterface) == CHANNEL_CLOSED) {
            ISOException.throwIt(ISO7816.SW_LOGICAL_CHANNEL_NOT_SUPPORTED);
        }

        byte opType = theAPDUBuffer[ISO7816.OFFSET_P1];
        byte managedChannel = theAPDUBuffer[ISO7816.OFFSET_P2];

        // Check if managed channel is within range of legal channels
        // based on ISO7816-4.
        if ((managedChannel > (byte) (PrivAccess.NUM_ISO_CHANNELS - 1)) || (managedChannel < (byte) 0)) {
            ISOException.throwIt(ISO7816.SW_FUNC_NOT_SUPPORTED);
        }

        channelStatus = NativeMethods.getChannelStatus(managedChannel, activeInterface);

        switch (opType) {
            case P1_CLOSE_CHANNEL:
                // Basic channel cannot be closed
                if ((managedChannel == BASIC_CHANNEL)) {
                    ISOException.throwIt(ISO7816.SW_FUNC_NOT_SUPPORTED);
                }

                // If channel is open, close it
                if ((channelStatus & CHANNEL_OPEN_MASK) == CHANNEL_OPEN) {

                    // Deselect applet in channel
                    PrivAccess.deselectOnly(managedChannel, activeInterface);

                    // Close channel
                    NativeMethods.channelManage(managedChannel, activeInterface, OP_CHANNEL_CLOSE);
                } else {
                    // If channel is closed, throw a warning
                    ISOException.throwIt(ISO7816.SW_WARNING_STATE_UNCHANGED);
                }
                break;
            case P1_OPEN_CHANNEL:
                if (managedChannel == P2_AUTOSELECT_CHANNEL) {

                    // First, check outbound data length to ensure that 1 byte
                    // is expected
                    // Expected: 1 byte of data
                    short le = theAPDU.setOutgoing();
                    if (le != 1) {
                        ISOException.throwIt((short) (ISO7816.SW_CORRECT_LENGTH_00 + (short) 0x01));
                    }

                    // In autoselect, let Java Card runtime environment choose
                    // channel automatically
                    newChannel = NativeMethods.channelManage((byte) (-1), activeInterface, OP_CHANNEL_OPEN_AUTOSELECT);
                    if (newChannel == ERR_NO_CHANNEL_AVAILABLE) {
                        ISOException.throwIt(ISO7816.SW_FUNC_NOT_SUPPORTED);
                    }
                } else {
                    // Check channel availability and open it
                    if ((NativeMethods.channelManage(managedChannel, activeInterface, OP_CHANNEL_OPEN)) != (byte) (0xFF)) {
                        newChannel = managedChannel;
                    } else {
                        ISOException.throwIt(ISO7816.SW_INCORRECT_P1P2);
                    }
                }

                try {
                    // Select applets in selected channel.
                    if (cmdChannel == BASIC_CHANNEL) {
                        // If managing channel is the basic channel, select the
                        // default applet in the newly open channel.
                        // The command channel is passed to allow other
                        // implementations
                        // to select a different default applet according to the
                        // selection channel.
                        PrivAccess.selectDefaultApplet(newChannel, activeInterface);
                    } else {
                        // If managing channel is not the basic channel,
                        // select the currently selected applet in the managing
                        // channel.
                        byte selAppletID = PrivAccess.getSelectedAppID(cmdChannel, activeInterface);
                        // If no applet selected on origin channel, skip
                        // selection process.
                        if (selAppletID != (byte) (-1)) {
                            PrivAccess.selectOnly(newChannel, activeInterface, selAppletID);
                        }
                    }
                } catch (ISOException isoEx) {
                    // An ISO exception will happen if applet fails to be
                    // selected.
                    // Close the channel if applet rejects selection or cannot
                    // be selected.
                    NativeMethods.channelManage(newChannel, activeInterface, OP_CHANNEL_CLOSE);
                    // Rethrow exception so that it can be caught in main
                    // Dispatcher loop
                    ISOException.throwIt(isoEx.getReason());
                } catch (SystemException se) {
                    // This is the case where a Clear-On-Deselect space is
                    // required, but not available.
                    // An ISO exception will happen if applet fails to be
                    // selected.
                    // Close the channel if applet rejects selection or cannot
                    // be selected.
                    NativeMethods.channelManage(newChannel, activeInterface, OP_CHANNEL_CLOSE);
                    if (se.getReason() == SystemException.NO_RESOURCE) {
                        if (managedChannel == P2_AUTOSELECT_CHANNEL) {
                            ISOException.throwIt(ISO7816.SW_FUNC_NOT_SUPPORTED);
                        } else {
                            ISOException.throwIt(ISO7816.SW_INCORRECT_P1P2);
                        }
                    }
                }
                // In case of open auto-select successful, return channel
                // information
                if (managedChannel == P2_AUTOSELECT_CHANNEL) {

                    // Write channel info to APDU buffer
                    theAPDU.setOutgoingLength((byte) 1);
                    theAPDUBuffer[0] = (newChannel);
                    theAPDU.sendBytes((short) 0, (short) 1);
                }

                break;
            default:
                ISOException.throwIt(ISO7816.SW_FUNC_NOT_SUPPORTED);
        }
    }

    /**
     *
     * Handles SELECT commands and checks for the supported options.
     * <p>
     * <ul>
     * <li>If the applet selection command is supported and the applet is
     * identified, then the current applet is deselected and the new applet is
     * selected. </li>
     * <li>If the applet cannot be selected due to multiselection issues, then
     * the current applet remains selected and an <tt>ISOException</tt> is
     * thrown.</li>
     * <li>If applet selection fails, or if the identified applet state is not
     * selectable, then the current applet is deselected and left in the "no
     * applet selected" state. </li>
     * </ul>
     * This method rewinds the APDU if <code>setIncomingAndReceive()</code> is
     * called.
     */
    void selectAPDU(APDU theAPDU) throws ISOException {
        byte selectChannel = NativeMethods.getCurrentlySelectedChannel();
        byte selectInterface = NativeMethods.getActiveInterface();

        // If managing channel is closed, open a new channel
        if (NativeMethods.getChannelStatus(selectChannel, selectInterface) == CHANNEL_CLOSED) {
            byte openOK = NativeMethods.channelManage(selectChannel, selectInterface, OP_CHANNEL_OPEN);
            if (openOK == (byte) (-1)) {
                ISOException.throwIt(ISO7816.SW_LOGICAL_CHANNEL_NOT_SUPPORTED);
            }
        }

        try {
            // ensure that P1==4 and (P2 & 0xF3)==0
            if (theAPDUBuffer[2] == P1_SELECT_DFBYNAME) {

                // check P2 = 0x0, 0x04, 0x08 or 0x0C
                if ((theAPDUBuffer[3] & P2_SELECT_OPTIONS) != P2_SELECT_OPTIONS_ONLY) {
                    return;
                }

                // read AID and check APDU data length
                byte len = (byte) (theAPDU.setIncomingAndReceive());

                if (len == theAPDUBuffer[4]) {

                    // search for applet with AID
                    byte i = AppletMgr.findApplet(theAPDUBuffer, (short) 5, len);

                    // find AID in AppletMgr
                    // if no match of AID found in AppletMgr. Java Card runtime
                    // environment assumes that the command is
                    // not being used to select an applet and will invoke
                    // process() method
                    // of the currently select applet (if there is one)
                    if (i != AppletMgr.APP_NULL) {
                        // is applet selectable?
                        if (PrivAccess.getAppState(thePrivAccess.getAID(i)) >= PrivAccess.APP_STATE_SELECTABLE) {
                            if (!(PrivAccess.isMultiSelectionOK(selectChannel, selectInterface, i))) {
                                ISOException.throwIt(ISO7816.SW_CONDITIONS_NOT_SATISFIED);
                            }
                            PrivAccess.selectApplet(selectChannel, selectInterface, i);
                        } else {
                            // if applet is not selectable, no applet selected
                            PrivAccess.deselectOnly(selectChannel, selectInterface);
                            NativeMethods.setChannelContext(selectChannel, selectInterface, PrivAccess.JCRE_CONTEXTID,
                                    false);
                        }
                    }
                }
                // "undo" the receive so that the applet can do it
                undoReceive();
            }
        } catch (SystemException se) {
            // This is the case where a Clear-On-Deselect space is
            // required, but not available.
            // An ISO exception will happen if applet fails to be selected.
            // Close the channel if applet cannot be selected.
            if (selectChannel != BASIC_CHANNEL) {
                NativeMethods.channelManage(selectChannel, selectInterface, OP_CHANNEL_CLOSE);
            }
            if (se.getReason() == SystemException.NO_RESOURCE) {
                ISOException.throwIt(ISO7816.SW_LOGICAL_CHANNEL_NOT_SUPPORTED);
            } else {
                SystemException.throwIt(se.getReason());
            }
        }
    }

    void undoReceive() {
        // "undo" the receive so that the applet can do it
        theAPDU.undoIncomingAndReceive();
    }

    /**
     * Performs all reset-time-only initializations, such as Dispatcher,
     * PrivAccess, and "system". This method is executed each time the card is
     * reset, which, in turn, initializes the Dispatcher.
     *
     */
    static void cardReset() {
        if (internArraySensitiveResultStateMachine == null) {
            internArraySensitiveResultStateMachine = JCSystem.makeTransientShortArray(lenInternArrSensitResStateMachine, JCSystem.CLEAR_ON_RESET);
        }
        NativeMethods.sensitiveResultInitialize(internArraySensitiveResultStateMachine);
        //NativeMethods.sensitiveResultInitialize(PrivAccess.getInternalStateMachineSensitiveResultArray());
        // This implementation selects a default applet on the
        // contacted interface on card reset.
        PrivAccess.selectDefaultApplet(BASIC_CHANNEL, PrivAccess.INTERFACE_PRIMARY);

        // Ensure that there was no GC in progress when the card was reset
        // if there was GC in progress, start the process again. This
        // also takes care of applets being deleted when the card was reset
        if (GarbageCollector.getSweepStarted()) {
            GarbageCollector.startGC();
        }

        // Ensure that package table is consistent and that there
        // is no package in progress.
        PackageMgr.restore();

        // other card reset time initialization such as initializing
        // transient objects not shown here.
    }

    /**
     * Performs all first-time-only initializations, such as Dispatcher,
     * PrivAccess, and "system". This method is executed exactly once in the
     * lifetime of the card.
     */
    static void cardInit() {
        initSystemExceptions();

        if (theDispatcher == null) {
            theDispatcher = new Dispatcher();
        }

        // create Java Card runtime environment-owned instances of exceptions
        // and designate as temporary Entry Point Objects
        // Exception classes init their own static systemInstance reference
        Exception ex;
        ex = new CardException((short) 0);
        NativeMethods.setJCREentry(ex, true);
        ex = new APDUException((short) 0);
        NativeMethods.setJCREentry(ex, true);
        ex = new ISOException((short) 0);
        NativeMethods.setJCREentry(ex, true);
        ex = new PINException((short) 0);
        NativeMethods.setJCREentry(ex, true);
        ex = new UserException((short) 0);
        NativeMethods.setJCREentry(ex, true);
        ex = new CryptoException((short) 0);
        NativeMethods.setJCREentry(ex, true);


        // create Java Card runtime environment-owned instance of the APDU and
        // designate as temporary Entry Point Object
        theAPDU = new APDU();
        NativeMethods.setJCREentry(theAPDU, true);

        // create JCRE-owned instance of PrivAccess and designate as permanent
        // Entry Point Object
        thePrivAccess = JCSystem.thePrivAccess = new PrivAccess();
        NativeMethods.setJCREentry(thePrivAccess, false);

        // get the GCRequested packed boolean value and set it false
        GarbageCollector.setGCRequested(PrivAccess.getPackedBoolean().allocate());

        // get APDU buffer and mark as (temporary) Global Array.
        theAPDUBuffer = theAPDU.getBuffer();
        NativeMethods.setJCREentry(theAPDUBuffer, true);

        CryptoInit.initCryptoStorage();
        PrivAccess.initialize(theAPDU);

        NativeMethods.setCardInitialized();
    }

    /**
     * Initializes the <tt>java.lang</tt> exceptions, and exceptions to which
     * the system must hold a pointer. This is done exactly once.
     */
    private static void initSystemExceptions() {
        arrayIndexOutOfBoundsException = new ArrayIndexOutOfBoundsException();
        NativeMethods.setJCREentry(arrayIndexOutOfBoundsException, true);

        negativeArraySizeException = new NegativeArraySizeException();
        NativeMethods.setJCREentry(negativeArraySizeException, true);

        nullPointerException = new NullPointerException();
        NativeMethods.setJCREentry(nullPointerException, true);

        classCastException = new ClassCastException();
        NativeMethods.setJCREentry(classCastException, true);

        arithmeticException = new ArithmeticException();
        NativeMethods.setJCREentry(arithmeticException, true);

        securityException = new SecurityException();
        NativeMethods.setJCREentry(securityException, true);
        // so that this can be used by classes which are not part of
        // javacard.framework package
        SecurityExceptionHelper.initSE(securityException);

        arrayStoreException = new ArrayStoreException();
        NativeMethods.setJCREentry(arrayStoreException, true);

        // CardRuntimeException exception needs to be initialized before
        // systemException and TransactionException are initialized
        // because this is the parent of the later 2.
        Exception ex = new CardRuntimeException((short) 0);
        NativeMethods.setJCREentry(ex, true);

        systemException = new SystemException((short) 0);
        NativeMethods.setJCREentry(systemException, true);

        transactionException = new TransactionException((short) 0);
        NativeMethods.setJCREentry(transactionException, true);

        // Following exception is for an optional package. If the
        // javacardx.framework.util optional package is excluded
        // from the cref, the following lines must be taken out
        utilException = new UtilException((short) 0);
        NativeMethods.setJCREentry(utilException, true);

        // #ifdef_Target32Bit_
        stringException = new StringException((short) 0);
        NativeMethods.setJCREentry(stringException, true);
        // #endif_Target32Bit_
        
    }

    /**
     * Only the Java Card runtime environment can use the constructor. No need
     * to construct this class anyway. No instance methods/fields.
     */
    Dispatcher() {
    }

}
