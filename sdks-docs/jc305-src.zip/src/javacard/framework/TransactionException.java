/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package javacard.framework;

/**
 * <code>TransactionException</code> represents an exception in the
 * transaction subsystem. The methods referred to in this class are in the
 * <code>JCSystem</code> class.
 * <p>
 * The <code>JCSystem</code> class and the transaction facility throw Java
 * Card runtime environment-owned instances of <code>TransactionException</code>.
 * <p>
 * Java Card runtime environment-owned instances of exception classes are
 * temporary Java Card runtime environment Entry Point Objects and can be
 * accessed from any applet context. References to these temporary objects
 * cannot be stored in class variables or instance variables or array
 * components. See
 * <em>Runtime Environment Specification, Java Card Platform, Classic Edition</em>,
 * section 6.2.1 for details.
 * 
 * @see JCSystem JCSystem
 */

public class TransactionException extends CardRuntimeException {

    // constants
    /**
     * This reason code is used by the <code>beginTransaction</code> method to
     * indicate a transaction is already in progress.
     */
    public final static short IN_PROGRESS = 1; // beginTransaction called when
    // already in progress

    /**
     * This reason code is used by the <code>abortTransaction</code> and
     * <code>commitTransaction</code> methods when a transaction is not in
     * progress.
     */
    public final static short NOT_IN_PROGRESS = 2; // commit/abortTransaction
    // called when not in
    // progress

    /**
     * This reason code is used during a transaction to indicate that the commit
     * buffer is full.
     */
    public final static short BUFFER_FULL = 3; // commit buffer is full

    /**
     * This reason code is used during a transaction to indicate an internal
     * Java Card runtime environment problem (fatal error).
     */
    public final static short INTERNAL_FAILURE = 4; // internal Java Card
    // runtime environment
    // problem (fatal error)
    
     /**
     * This reason code is used by the transaction methods to indicate that
     * the method is not available in the caller's environment.
     */
    public final static short ILLEGAL_USE = 5;

    // initialized when created by Dispatcher
    private static TransactionException systemInstance;

    /**
     * Constructs a TransactionException with the specified reason. To conserve
     * on resources use <code>throwIt()</code> to use the Java Card runtime
     * environment-owned instance of this class.
     */
    public TransactionException(short reason) {
        super(reason);
        if (systemInstance == null) {
            systemInstance = this;
        }
    }

    /**
     * Throws the Java Card runtime environment-owned instance of
     * <code>TransactionException</code> with the specified reason.
     * <p>
     * Java Card runtime environment-owned instances of exception classes are
     * temporary Java Card runtime environment Entry Point Objects and can be
     * accessed from any applet context. References to these temporary objects
     * cannot be stored in class variables or instance variables or array
     * components. See
     * <em>Runtime Environment Specification, Java Card Platform, Classic Edition</em>,
     * section 6.2.1 for details.
     * 
     * @exception TransactionException
     *                always
     */
    public static void throwIt(short reason) {
        systemInstance.setReason(reason);
        throw systemInstance;
    }
}
