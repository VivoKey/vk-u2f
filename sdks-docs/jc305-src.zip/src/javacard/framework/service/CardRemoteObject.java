/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package javacard.framework.service;

import java.rmi.Remote;

import javacard.framework.SystemException;

import com.sun.javacard.impl.GarbageCollector;
import com.sun.javacard.impl.NativeMethods;
import com.sun.javacard.impl.PrivAccess;

/**
 * A convenient base class for remote objects for the Java Card platform. An
 * instance of a subclass of this <CODE>CardRemoteObject</CODE> class will be
 * exported automatically upon construction.
 * 
 * @version 1.0
 * 
 */
public class CardRemoteObject extends Object implements java.rmi.Remote {

    private static final short MAX_OBJECTS = (short) 16;

    private static short[] array;

    /**
     * Creates a new <CODE>CardRemoteObject</CODE> and automatically exports
     * it. When exported, the object is enabled for remote access from outside
     * the card until unexported. Only when the object is enabled for remote
     * access can it be returned as the initial reference during selection or
     * returned by a remote method. In addition, remote methods can be invoked
     * only on objects enabled for remote access.
     */
    public CardRemoteObject() {
        export(this);
    }

    /**
     * Exports the specified remote object. The object is now enabled for remote
     * access from outside the card until unexported. In order to remotely
     * access the remote object from the terminal client, it must either be set
     * as the initial reference or be returned by a remote method.
     * 
     * @param obj
     *            the remotely accessible object
     * @throws SecurityException
     *             if the specified obj parameter is not owned by the caller
     *             context
     * @throws SystemException
     *             with the following reason codes:
     *             <ul>
     *             <li><code>SystemException.NO_RESOURCE</code> if too many
     *             exported remote objects. All implementations must support a
     *             minimum of 16 exported remote objects.
     *             </ul>
     */
    public static void export(Remote obj) throws SecurityException {

        if (array == null) {
            array = PrivAccess.getPrivAccess().initRemoteObjArray(MAX_OBJECTS);
        }

        if (obj == null) {
            return;
        }

        short id = NativeMethods.getObjectID(obj);
        export(id);
    }

    /**
     * Unexports the specified remote object. After applying this method, the
     * object cannot be remotely accessed from outside the card until it is
     * exported again.
     * <p>
     * Note:
     * <ul>
     * <li><em>If this method is called during the session in which the specified
     * remote object parameter is the initial reference object or has been
     * returned by a remote method,
     * the specified remote object will continue to be remotely accessible until the end of
     * the associated selection session(s).</em>
     * </ul>
     * 
     * @param obj
     *            the remotely accessible object
     * @throws SecurityException
     *             if the specified obj parameter is not owned by the caller
     *             context
     */
    public static void unexport(Remote obj) throws SecurityException {

        if (obj == null) {
            return;
        }

        short objID = NativeMethods.getObjectID(obj);
        unexport(objID);
    }

    private static void unexport(short objID) throws SecurityException {
        NativeMethods.checkAccess(objID);

        if (array == null) {
            return;
        }

        for (short i = 0; i < MAX_OBJECTS; ++i) {
            if (array[i] == objID) {
                array[i] = 0;
            }
        }

    }

    private static void export(short objID) throws SecurityException {
        NativeMethods.checkAccess(objID);

        for (short i = 0; i < MAX_OBJECTS; ++i) {
            if (array[i] == 0) {
                array[i] = objID;
                return;
            }
        }

        SystemException.throwIt(SystemException.NO_RESOURCE); // no slots
        return; // never reached
    }

    static boolean isExported(Remote obj) throws SecurityException {

        if (obj == null) {
            return true;
        }

        short objID = NativeMethods.getObjectID(obj);
        return isExported(objID);
    }

    private static boolean isExported(short objID) throws SecurityException {
        NativeMethods.checkAccess(objID);

        if (array == null) {
            return false;
        }

        for (short i = 0; i < MAX_OBJECTS; ++i) {
            if (array[i] == objID) {
                return true;
            }
        }

        return false;
    }

}
