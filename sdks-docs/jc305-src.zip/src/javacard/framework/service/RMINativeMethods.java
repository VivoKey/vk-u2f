/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package javacard.framework.service;

import java.rmi.Remote;

class RMINativeMethods {

    /**
     * This method is used to copy a string in the format { u1 length, u1[]}
     * into a given byte array.
     * 
     * @param pointer
     *            to the string to be copied
     * @param byte
     *            array to copy the string into.
     * @param offset
     *            into the byte array to copy to.
     * @return the next offset.
     */
    public static native short copyStringIntoBuffer(int ptr_to_string, byte[] buffer, short offset);

    public static native int getClassNameAddress(Remote rem_object);

    /**
     * Used to get the address of the remote method information found in the
     * class_info structure
     * 
     * @param objID
     *            the object ID of the object from which the remote method
     *            information is needed.
     * @param methodID
     *            the unique hash for the remote method ultimately to be
     *            invoked.
     * @return the address of the remote method information.
     */
    public static native int getRemoteMethodInfo(short objID, short methodID);

    /**
     * Returns the return type of a remote method from a given object. Used by
     * RMI to determine which remote method invocation to use. Also does some
     * validation that this is a real and remote object.
     * 
     * @param address
     *            of the remote method information of the given object ID
     * @param the
     *            object ID for the object which has the remote method to be
     *            invoked
     * @return return code of the return type for the remote method
     */
    public static native short getReturnType(int remote_method_info);

    /**
     * a cleanup method used to delete any temporary arrays used to pass
     * parameters to an invoked remote method. No parameters or return.
     */

    public static native void deleteAllTempArrays();

    /**
     * used to check if an exception is a Java Card api exception.
     * 
     * @param ex
     *            the exception to be checked
     * @return true if exception is Java Card api exception, otherwise false.
     */

    public static native boolean isAPIException(Throwable ex);

    /**
     * Copy anti-collision string into apdu buffer.
     * 
     * @param RemoteObj
     *            The remote object to get the anti-collision string for.
     * @param buffer
     *            The APDU buffer.
     * @param offset
     *            The starting offset in the APDU buffer to which the collision
     *            string is to be copied.
     * @return the next offset.
     */
    public static native short getAnticollisionString(Remote RemoteObj, byte[] buffer, byte offset);

    /**
     * This method is used to obtain the number of remote interfaces of the
     * given remote object.
     * 
     * @param RemoteObj
     *            The remote object to get the number of remote interfaces for.
     * @return noOfRemInterfaces the returned number of remote interfaces.
     */
    public static native byte getRemoteInterfaceNumber(Remote RemoteObj);

    /**
     * Returns the remote interface address from the class structure for the
     * given interface index.
     * 
     * @param remoteObject
     *            The remote object that is to have it's class structure
     *            quiried.
     * @param interfaceIndex
     *            The interface index used to find the remote interface address.
     * @return the interface address for the given interface index and remote
     *         object.
     */
    public static native int getRemoteInterfaceAddress(Remote remoteObj, byte interfaceIndex);

    /**
     * copies interface name into a buffer in the format {u1 length, u1[]
     * bytes}.
     * 
     * @param ptr_to_interface
     *            pointer to the interface name to be copied.
     * @param buffer
     *            The buffer into which the interface name is to be copied.
     * @param offset
     *            The offset in the buffer for the point at which the interface
     *            name is to be copied.
     * @return the next offset.
     */

    public static native short copyInterfaceNameIntoBuffer(int ptr_to_interface, byte[] buffer, short offset);

    /**
     * all remaining native methods are used to invoke remote methods. The only
     * difference in them is the return type. Most of the code here is common,
     * but separate methods are needed so that the return type is handled
     * correctly by the VM.
     * 
     * @param the
     *            address of the remote method information
     * @param the
     *            apdu buffer with the parameter data to be used when invoking
     *            the remote method.
     * @param offset
     *            in the apdu buffer where the parameter data starts.
     */

    public static native void rmi_invoker_void(int remote_method_info, short objID, byte[] buffer, byte offset);

    public static native boolean rmi_invoker_boolean(int remote_method_info, short objID, byte[] buffer, byte offset);

    public static native byte rmi_invoker_byte(int remote_method_info, short objID, byte[] buffer, byte offset);

    public static native short rmi_invoker_short(int remote_method_info, short objID, byte[] buffer, byte offset);

    public static native int rmi_invoker_int(int remote_method_info, short objID, byte[] buffer, byte offset);

    public static native Object rmi_invoker_reference(int remote_method_info, short objID, byte[] buffer, byte offset);

    public static native Object rmi_invoker_array(int remote_method_info, short objID, byte[] buffer, byte offset);

    /**
     * Returns error code thrown by RMI applet.
     * 
     * @return RMI error code.
     */
    public static native short getRMIErrorCode();

    public static native short writeArray(Object data, byte[] buffer, short offset);

}
