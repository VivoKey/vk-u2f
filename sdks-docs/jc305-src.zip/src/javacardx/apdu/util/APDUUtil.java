/**
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package javacardx.apdu.util;

/**
 * The <code>APDUUtil</code> class contains utility methods to parse CLA byte from
 * a command APDU. All methods in <code>APDUUtil</code>, class are static methods.
 * <p>
 * @see javacard.framework.APDU APDU
 * @since 3.0.5
 */
public class APDUUtil {
    /**
     * Returns the logical channel number encoded in the <CODE>CLAbyte</CODE>
     * parameter which represents a CLA byte from a command APDU. A number in the range
     * 0-19 based on the CLA byte encoding is returned if the CLA contains logical
     * channel encoding. If the CLA byte does not contain logical channel
     * information, 0 is returned.
     * <p>
     * Note:
     * <ul>
     * <li><em>This method returns 0 if the CLA bits (b8,b7,b6) is
     * %b001 which is a CLA encoding reserved for future use(RFU),
     * or if CLA is 0xFF which is an invalid value as defined in
     * the ISO 7816-4:2013 specification.</em>
     * </ul>
     * <p>
     * See <em>Runtime Environment
     * Specification, Java Card Platform, Classic Edition</em>,
     * section 4.3 for encoding details.
     * </p>
     *
     * @param CLAbyte is CLA byte from a command APDU
     * @return logical channel number, if present, within the CLA byte, 0
     *         otherwise
     * @since 3.0.5
     * @see javacard.framework.APDU.#getCLAChannel()
     */
    public static byte getCLAChannel(byte CLAbyte){
        // TODO: Implementation
        if(isValidCLA(CLAbyte)){
            if(((short)CLAbyte & 0x0040) == 0x0040)
                return (byte)((short)((short)CLAbyte & 0x000F) + 0x0004);
            else
                return (byte)((short)CLAbyte & 0x0003);
        }
        return 0;
    }

    /**
     * Returns <CODE>true</CODE> if encoding of the <CODE>CLAbyte</CODE>
     * parameter, which represents a CLA byte from a command APDU, indicates secure
     * messaging. The secure messaging information is in bits (b4,b3) for
     * commands with origin channel numbers 0-3, and in bit b6 for origin
     * channel numbers 4-19.
     * <p>
     * Note:
     * <ul>
     * <li><em>This method returns <CODE>false</CODE> if the CLA bits (b8,b7,b6) is
     * %b001 which is a CLA encoding reserved for future use(RFU),
     * or if CLA is 0xFF which is an invalid value as defined in
     * the ISO 7816-4:2013 specification.</em>
     * </ul>
     * <p>
     * See <em>Runtime Environment Specification, Java Card
     * Platform, Classic Edition</em>, section 4.3 for encoding details.
     * </p>
     *
     * @param CLAbyte is CLA byte from a command APDU
     * @return <CODE>true</CODE> if the secure messaging bit(s) is(are)
     *         nonzero, <CODE>false</CODE> otherwise
     * @since 3.0.5
     * @see javacard.framework.APDU.#isSecureMessagingCLA()
     */
    public static boolean isSecureMessagingCLA(byte CLAbyte){
        // TODO: Implementation
        if(isValidCLA(CLAbyte)){
            if(((short)CLAbyte & 0x0040) == 0x0040)
                return ((short)CLAbyte & 0x0020) != 0;
            else
                return ((short)CLAbyte & 0x000C) != 0;
        }
        return false;
    }

    /**
     * Based on encoding of the <CODE>CLAByte</CODE> parameter which represents a
     * CLA byte from a command APDU, returns whether an <CODE>APDU</CODE> command
     * is the first or part of a command chain. Bit b5 of the CLA byte if set, indicates that
     * the <CODE>APDU</CODE> is the first or part of a chain of commands.
     * <p>
     * Note:
     * <ul>
     * <li><em>This method returns <CODE>false</CODE> if the CLA bits (b8,b7,b6) is
     * %b001 which is a CLA encoding reserved for future use(RFU),
     * or if CLA is 0xFF which is an invalid value as defined in
     * the ISO 7816-4:2013 specification.</em>
     * </ul>
     * <p>
     * See <em>Runtime Environment Specification, Java Card
     * Platform, Classic Edition</em>, section 4.3 for encoding details.
     * </p>
     *
     * @param CLAbyte is CLA byte from a command APDU
     * @return <CODE>true</CODE> if the CLA byte encoding indicates if an APDU
     * is not the last APDU of a command chain,
     * <CODE>false</CODE> otherwise.
     * @since 3.0.5
     * @see javacard.framework.APDU.#isCommandChainingCLA()
     */
    public static boolean isCommandChainingCLA(byte CLAbyte){
        // TODO: Implementation
        return isValidCLA(CLAbyte) && (((short)CLAbyte & 0x0010) != 0);
    }

    /**
     * Returns whether the <CODE>CLAByte</CODE> parameter which represents a
     * CLA bye from a command APDU, corresponds to an interindustry command as
     * defined in ISO 7816-4:2013 specification. Bit b8 of the CLA byte if
     * <code>0</code>, indicates that the <CODE>APDU</CODE> is an interindustry command.
     *
     * @param CLAbyte is CLA byte from a command APDU
     * @return <CODE>true</CODE> if this APDU CLA byte corresponds to an ISO
     *         interindustry command, <CODE>false</CODE> otherwise.
     * @since 3.0.5
     * @see javacard.framework.APDU.#isISOInterindustryCLA()
     */
    public static boolean isISOInterindustryCLA(byte CLAbyte){
        // TODO: Implementation
        return ((short)CLAbyte & 0x0080) == 0;
    }

    /**
     * Returns whether the current <CODE>CLAByte</CODE> parameter represents a
     * valid CLA byte. The CLA byte is invalid if the CLA bits (b8,b7,b6) is %b001, which
     * is a CLA encoding reserved for future use(RFU), or if CLA is 0xFF which
     * is an invalid value as defined in the ISO 7816-4:2013 specification.
     * <p>
     * See <em>Runtime Environment Specification, Java Card
     * Platform, Classic Edition</em>, section 4.3 for encoding details.
     * </p>
     *
     * @param CLAbyte is CLA byte from a command APDU
     * @return <CODE>true</CODE> if CLA byte is valid,
     *         <CODE>false</CODE> otherwise.
     * @since 3.0.5
     * @see javacard.framework.APDU.#isValidCLA()
     */
    public static boolean isValidCLA(byte CLAbyte){
        // TODO: Implementation
        return !((CLAbyte == (byte)0xFF) || (isISOInterindustryCLA(CLAbyte) && (((short)CLAbyte & 0x00E0) == 0x0020)));
    }

    /**
     * Prevents instantiation.
     */
    private APDUUtil() {}
}
