/*
 *  Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */
/**
 * Extension package that contains functionality, for implementing security
 * countermeasures to protect security relevant applet assets on the Java Card
 * platform. The platform must support this optional package only if all the
 * specified functionality is included in the implementation.
 */
package javacardx.security;
