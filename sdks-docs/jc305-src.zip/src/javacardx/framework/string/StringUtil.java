/**
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

package javacardx.framework.string;

import javacard.framework.Util;

/**
 * This class provides methods for handling UTF-8 encoded character sequences (strings).
 * This class also provides methods to convert UTF-8 encoded character strings to and from other character encodings,
 * such as UCS-2, the GSM 7-bit character set and UTF-16. Support for character encodings other than UTF-8 is optional.
 * Proprietary extensions to the supported character encodings must be identified starting from {@link #PROP_ENCODING_EXT}.
 * An implementation must throw a {@link StringException} with reason {@link StringException#UNSUPPORTED_ENCODING}
 * if a requested character encoding is not supported.
 * <p />
 * UTF-8 encodes each of the code points in the Unicode character set using one to four 8-bit bytes.
 * Unicode code points are the numerical values that make up the Unicode code space.
 * The Unicode Standard, version 4.0 is  available from the Unicode Consortium at <a href="http://www.unicode.org">http://www.unicode.org</a>.
 * The UTF-8 transformation format is specified by <a href="http://tools.ietf.org/rfc/rfc3629.txt">RFC 3629</a>.
 * <p />
 * The encoded character sequences handled by this class are stored in byte arrays.
 * Each string or character sequence is designated by a byte array, an offset in the byte array
 * indicating the start of the character sequence and a length indicating the length in bytes of the character sequence.
 * If a designated character sequence is outside the bounds of its containing array
 * an {@link ArrayIndexOutOfBoundsException} is thrown (note: for readablity reasons,
 * these exceptions are assumed and not systematically documented in the methods of this
 * class).
 * <br />
 * An index of a character or substring within a string is always relative to the begining of the string; that is relative
 * to the offset of the string within the containing byte array. If a provided
 * index of a character or substring within a designated  character sequence is outside the bounds
 * of the designated character sequence an {@link IndexOutOfBoundsException} is thrown.
 * <p />
 * This class provides two categories of methods:
 * <dl>
 * <dt>Methods for dealing with plain byte sequences</dt>
 * <dd>
 * These methods do not check the (UTF-8) well-formedness of the
 * byte sequences passed as parameters; in particular, they do not check whether the byte at a provided
 * offset is the first byte of a valid UTF-8 byte sequence or if a provided length
 * is equal or greater than the length of the UTF-8 byte sequence starting at the provided offset
 * (as can be determined by its first byte). They only treat UTF-8 byte sequences as plain byte sequences for
 * the purpose of comparison, copying, truncating... As an example of such methods,
 * see the {@link #indexOf(byte[], short, short, byte[], short, short) indexOf} method.
 * </dd>
 * <dt>Methods for dealing with Unicode code points (i.e., Unicode characters)</dt>
 * <dd>
 * These methods check the well-formedness of UTF-8 byte sequences. They either
 * throw a {@link StringException} with reason {@link StringException#INVALID_BYTE_SEQUENCE}
 * when encountering an ill-formed UTF-8 byte sequence; as an example of such methods,
 * see the {@link #convertTo(byte[], short, short, byte[], short, byte) convertTo} method.
 * <br />
 * Or they consider any byte sequence that is not well-formed (eg. incomplete)
 * within a designated text range as a code point for the purpose of counting, comparing or returning;
 * as an example of such methods,
 * see the {@link #codePointCount(byte[], short, short) codePointCount} method.
 * </dd>
 * </dl>
 * To ensure that a character or character sequence is a valid UTF-8 character or character sequence,
 * the {@link #check(byte[], short, short) check} method should be used.
 * <p>
 * Because Unicode case conversion may require locale-sensitive mappings,
 * context-sensitive mappings, and 1:M character mappings, and in order to limit footprint
 * case conversion supported by the methods {@link #toLowerCase(byte[], short, short, byte[], short) toLowerCase},
 * {@link #toUpperCase(byte[], short, short, byte[], short) toUpperCase} and
 * {@link #compare(boolean, byte[], short, short, byte[], short, short) compare} is
 * only available by default for the Basic Latin Unicode block (US-ASCII character set: U+0000 - U+007F). Other
 * character blocks may be supported.
 *
 * @since Java Card 3.0.4
 */
public final class StringUtil {

    /**
     * The UTF-8 character encoding. This character encoding is used for internal representation and handling of character strings.
     */
    public static final byte UTF_8 = (byte) 0x01;
    /**
     * The UTF-16 character encoding. This character encoding may be optionally supported for conversion to and from UTF-8 when doing input or output.
     */
    public static final byte UTF_16 = (byte) 0x02;
    /**
     * The UTF-16LE (Little Endian) character encoding. This character encoding may be optionally supported for conversion to and from UTF-8 when doing input or output.
     */
    public static final byte UTF_16_LE = (byte) 0x03;
    /**
     * The UTF-16BE (Big Endian) character encoding. This character encoding may be optionally supported for conversion to and from UTF-8 when doing input or output.
     */
    public static final byte UTF_16_BE = (byte) 0x04;
    /**
     * The UCS-2 character encoding. This character encoding may be optionally supported for conversion to and from UTF-8 when doing input or output.
     */
    public static final byte UCS_2 = (byte) 0x05;
    /**
     * The GSM Septet character encoding. This character encoding may be optionally supported for conversion to and from UTF-8 when doing input or output.
     */
    public static final byte GSM_7 = (byte) 0x06;
    /**
     * The ISO 8859-1 (Latin-1) character encoding. This character encoding may be optionally supported for conversion to and from UTF-8 when doing input or output.
     */
    public static final byte ISO_8859_1 = (byte) 0x07;
    /**
     * Start of proprietary character encoding numbering.
     */
    public static final byte PROP_ENCODING_EXT = (byte) 0x40;

    /**
     * Returns the number of characters (Unicode code points) in the UTF-8
     * encoded character sequence designated by <code>aString</code>, <code>offset</code> and <code>length</code>.
     * Ill-formed or incomplete byte sequences within the text range count as one code point each.
     *
     * @param aString the byte array containing the UTF-8 encoded character sequence.
     * @param offset the starting offset of the character sequence in the byte array.
     * @param length the length (in bytes) of the contained character sequence.
     * @return the number of characters (Unicode code points) in the designated UTF-8 encoded character sequence.
     * @throws NullPointerException
     *                if <code>aString</code> is <code>null</code>.
     */
    public static short codePointCount(byte[] aString, short offset, short length) {
        short count = 0;
        for (short i = offset; i < (short) (offset + length); i++) {
            if ((aString[i] & 0xE0) == 0xC0) { /* 2B character */
                count++;
                if ((short)(i + 1) < (short)(offset + length )
                        && (aString[(short) (i + 1)] & 0xC0) == 0x80) {
                    i++; /* Move forward if valid following bytes */
                }
            } else if ((aString[i] & 0xF0) == 0xE0) { /* 3B character */
                count++;
                for (short j = 0; j < 2; j++) {
                    if ((short)(i + 1) < (short)(offset + length )
                        && (aString[(short) (i + 1)] & 0xC0) == 0x80) {
                        i++; /* Move forward if valid following bytes */
                    } else {
                        break;
                    }
                }
            } else if ((aString[i] & 0xF8) == 0xF0) { /* 4B character */
                count++;
                for (short j = 0; j < 3; j++) {
                    if ((short)(i + 1) < (short)(offset + length )
                        && (aString[(short) (i + 1)] & 0xC0) == 0x80) {
                        i++; /* Move forward if valid following bytes */
                    } else {
                        break;
                    }
                }
            } else { /* 1B or invalid character */
                count++;
            }
        }
        return count;
    }

    /**
     * Copies to the destination buffer the character (Unicode code point) at the specified index in
     * the UTF-8 encoded character sequence designated by <code>aString</code>, <code>offset</code> and <code>length</code>.
     * <code>index</code> is an index in the byte array relative to the offset of the
     * designated character sequence within the byte array (that is relative to <code>offset</code>).
     * The resulting code point copied to the destination array is UTF-8 encoded
     * and is therefore from one to four byte long.
     * Ill-formed or incomplete byte sequences within the text range counting as
     * one code point each, they are returned as-is.
     *
     * @param aString the byte array containing the UTF-8 encoded reference character sequence.
     * @param offset the starting offset of the reference character sequence in <code>aString</code>.
     * @param length the length (in bytes) of the reference character sequence.
     * @param index the byte index (relative to <code>offset</code>) of the character to be returned.
     * @param dstBuffer the byte array for copying the resulting character.
     * @param dstOffset the starting offset in <code>dstBuffer</code> for copying the UTF-8 byte
     * sequence of the character (Unicode code point) at the specified index.
     * @return the number of bytes copied.
     * @throws IndexOutOfBoundsException if <code>index</code> is negative or not less than the length of <code>aString</code>.
     * @throws NullPointerException
     *                if <code>aString</code> or <code>dstBuffer</code> is <code>null</code>.
     */
    public static short codePointAt(byte[] aString, short offset, short length,
            short index, byte[] dstBuffer, short dstOffset) {
        short count = 1; /* Count number of bytes to copy */
        short totOff = (short)(offset + index);
        if (index < 0 || index >= length) { /* Check index out of bounds */
            aString[(short)-1] = 1; //Throw IndexOutOfBounds exception
        }
        if ((aString[totOff] & 0xE0) == 0xC0) { /* 2B character */
            if ((short)(totOff + 1) < (short)(offset + length)
                    && (aString[(short) (totOff + 1)] & 0xC0) == 0x80) {
                count++;
            }
            Util.arrayCopy(aString, totOff, dstBuffer, dstOffset, count);
        }
        else if ((aString[totOff] & 0xF0) == 0xE0) { /* 3B character */
            for (short j = 0; j < 2; j++){
                if ((short)(totOff + j + 1) < (short)(offset + length)
                        && (aString[(short) (totOff + j + 1)] & 0xC0) == 0x80) {
                    count++;
                }
                else {
                    break;
                }
            }
            Util.arrayCopy(aString, totOff, dstBuffer, dstOffset, count);
        }
        else if ((aString[totOff] & 0xF8) == 0xF0){ /* 4B character */
            for (short j = 0; j < 3; j++){
                if ((short)(totOff + j + 1) < (short)(offset + length)
                        && (aString[(short) (totOff + j + 1)] & 0xC0) == 0x80) {
                    count++;
                }
                else {
                    break;
                }
            }
            Util.arrayCopy(aString, totOff, dstBuffer, dstOffset, count);
        }
        else { /* 1B or invalid 1B character */
            dstBuffer[dstOffset] = aString[totOff];
        }
        return count;
    }

    /**
     * Copies to the destination buffer the character (Unicode code point) before the specified
     * index in the UTF-8 encoded character sequence designated by <code>aString</code>, <code>offset</code> and <code>length</code>.
     * <code>index</code> is an index in the byte array relative to the offset of the
     * designated character sequence within the byte array (that is relative to <code>offset</code>).
     * The resulting code point copied to the destination array is UTF-8 encoded
     * and is therefore from one to four byte long.
     * Ill-formed or incomplete byte sequences within the text range counting as
     * one code point each, they are returned as-is.
     *
     * @param aString the byte array containing the UTF-8 encoded character sequence.
     * @param offset the starting offset of the reference character sequence in <code>aString</code>.
     * @param length the length (in bytes) of the reference character sequence.
     * @param index the byte index (relative to <code>offset</code>) following the character to be returned.
     * @param dstBuffer the byte array for copying the resulting character.
     * @param dstOffset the starting offset in <code>dstBuffer</code> for copying the UTF-8 byte sequence of the character (Unicode code point) before the specified index.
     * @return the number of bytes copied.
     * @throws IndexOutOfBoundsException if <code>index</code> is less than 1 or greater than the length of <code>aString</code>.
     * @throws NullPointerException
     *                if <code>aString</code> or <code>dstBuffer</code> is <code>null</code>.
     */
    public static short codePointBefore(byte[] aString, short offset, short length,
            short index, byte[] dstBuffer, short dstOffset) {
        short count = 0; /* Count number of bytes to copy */
        short i = 1;
        short totOff = (short)(offset + index);
        if (index < 1 || index > length) { /* Index out of bounds */
            aString[(short)-1] = 1; //Throw IndexOutOfBounds exception
        }
        while (i < 5) {
            if ((short)(totOff - i - 1) >= offset
                    && (aString[(short)(totOff - i)] & 0xC0) == 0x80) { /* Check for continuing bytes */
                i++;
            }
            else { /* Found starting or invalid byte */
                break;
            }
        }
        if((aString[(short) (totOff - i)] & 0xF8) == 0xF0 && i < 5) { /* Check for starting of 4B char */
            count += i;
            Util.arrayCopy(aString, (short)(totOff - i), dstBuffer, dstOffset, count);
        }
        else if((aString[(short)(totOff - i)] & 0xF0) == 0xE0 && i < 4) { /* Check for starting  of 3B char */
            count += i;
            Util.arrayCopy(aString, (short)(totOff - i), dstBuffer, dstOffset, count);
        }
        else if((aString[(short)(totOff - i)] & 0xE0) == 0xC0 && i < 3){ /* Check for starting  of 2B char */
            count += i;
            Util.arrayCopy(aString, (short)(totOff - i), dstBuffer, dstOffset, count);
        }
        else { /* 1B char or invalid */
            count++;
            dstBuffer[dstOffset] = aString[(short)(totOff - 1)];
        }
        return count;
    }

    /**
     * Returns the byte index within the UTF-8 encoded character sequence designated
     * by <code>aString</code>, <code>offset</code> and <code>length</code>
     * that is offset from the
     * given <code>index</code> by <code>codePointOffset</code> code points.
     * Ill-formed or incomplete UTF-8 byte sequences within the text range given
     * by <code>index</code> and <code>codePointOffset</code> count as one code point each.
     * <p>
     * This method can be used to extract a substring from a string. For example, to copy to <code>buffer</code>
     * the substring of the string <code>aString</code> that begins at <code>codePointBeginIndex</code> and
     * extends to the character at index <code>codePointEndIndex - 1</code>, one can call:
     * <pre>
     * short beginOffset = StringUtil.offsetByCodePoints(aString, offset, length, (short) 0, codePointBeginIndex);
     * short endOffset = StringUtil.offsetByCodePoints(aString, offset, length, (short) 0, codePointEndIndex);
     * short l = Util.arrayCopy(aString, beginOffset, buffer, 0, (short) (endOffset - beginOffset));
     * </pre>
     * The copied substring thus has a length in codepoints (that is a codepoint count) equal to <code>codePointEndIndex - codePointbeginIndex</code>.
     *
     * @param aString the byte array containing the UTF-8 encoded character sequence.
     * @param offset the starting offset of the reference character sequence in <code>aString</code>.
     * @param length the length (in bytes) of the reference character sequence.
     * @param index the byte index to be offset (relative to <code>offset</code>).
     * @param codePointOffset the offset in code points.
     * @return the index within <code>aString</code> relative to the begining of the string contained in <code>aString</code>
     * that is, relative to <code>offset</code>.
     * @throws IndexOutOfBoundsException if <code>index</code> is negative or larger than the length of <code>aString</code>,
     * or if <code>codePointOffset</code> is positive and the substring starting with
     * <code>index</code> has fewer than <code>codePointOffset</code> code points,
     * or if <code>codePointOffset</code> is negative and the substring before
     * <code>index</code> has fewer than the absolute value of <code>codePointOffset</code> code points.
     * @throws NullPointerException
     *                if <code>aString</code> is <code>null</code>.
     */
    public static short offsetByCodePoints(byte[] aString, short offset, short length,
            short index, short codePointOffset) {
        short i = 0; //current offset from index
        if (index < 0 || index > length) {
            aString[(short)-1] = 1; //Throw IndexOutOfBounds exception
        }
        if (codePointOffset >= 0) {
            while (codePointOffset > 0) {
                if ((aString[(short) (i + index + offset)] & 0xE0) == 0xC0) { /* 2B long char */
                    if ((short) (i + index + 1) < length && (short) (i + index + 1) >= 0
                            && (aString[(short) (i + index + offset + 1)] & 0xC0) == 0x80) {
                        i++;
                    }
                } else if ((aString[(short) (i + index + offset)] & 0xF0) == 0xE0) { /* 3B long char */
                    for (short j = 1; j < 3; j++) {
                        if ((short) (i + index + 1) < length && (short) (i + index + 1) >= 0
                            && (aString[(short) (i + index + offset + 1)] & 0xC0) == 0x80) {
                            i++;
                        } else {
                            break;
                        }
                    }
                } else if ((aString[(short) (i + index + offset)] & 0xF8) == 0xF0) { /* 4B long char */
                    for (short j = 1; j < 4; j++) {
                        if ((short) (i + index + 1) < length && (short) (i + index + 1) >= 0
                            && (aString[(short) (i + index + offset + 1)] & 0xC0) == 0x80) {
                            i++;
                        } else {
                            break;
                        }
                    }
                } /* Else 1B or Invalid byte */
                codePointOffset--;
                i++;
                if ((short)(i + index) > length) {
                    aString[(short)-1] = 1; //Throw IndexOutOfBounds exception
                }
            }
        }
        else {
            while (codePointOffset < 0) {
                short count = 0;
                while (count < 4) {
                    if ((short)(index - count - 2 + i) >= 0
                            && (aString[(short)(index - count - 1 + i + offset)] & 0xC0) == 0x80) { /* Check for continuing bytes */
                        count++;
                    }
                    else { /* Found starting or invalid byte */
                        break;
                    }
                }
                if((aString[(short) (index - count - 1 + i + offset)] & 0xF8) == 0xF0 && count < 4) { /* Check for starting of 4B char */
                    i -= count;
                }
                else if((aString[(short)(index - count - 1 + i + offset)] & 0xF0) == 0xE0 && count < 3) { /* Check for starting  of 3B char */
                    i -= count;
                }
                else if((aString[(short)(index - count - 1 + i + offset)] & 0xE0) == 0xC0 && count < 2){ /* Check for starting  of 2B char */
                    i -= count;
                } /* Else  1B or invalid */
                i--;
                codePointOffset++;
                if ((short)(i + index) < 0) {
                    aString[(short)-1] = 1; //Throw IndexOutOfBounds exception
                }
            }
        }
        return (short) (i + index); 
    }

    /**
     * Compares two strings lexicographically, optionally ignoring case considerations. The comparison is based on the
     * UTF-8-encoded Unicode value of each character in the strings. The character sequence
     * designated by <code>aString</code>, <code>offset</code> and <code>length</code> is compared
     * lexicographically to the character sequence designated by <code>anotherString</code>, <code>ooffset</code> and <code>olength</code>.
     * The result is a negative number if the character sequence contained in <code>aString</code>
     * lexicographically precedes the character sequence contained in <code>anotherString</code>. The result is
     * a positive number if the character sequence contained in <code>aString</code> lexicographically
     * follows the character sequence contained in <code>anotherString</code>. The result is zero if the two character sequences are equal.
     * <p>
     * This is the definition of lexicographic ordering. If two strings are
     * different, then either they have different characters at some index that
     * is a valid index for both strings, or their lengths are different, or
     * both. If they have different characters at one or more index positions,
     * let <i>k</i> be the smallest such index; then the string whose character
     * at position <i>k</i> has the smaller value, as determined by using the &lt;
     * operator, lexicographically precedes the other string. In this case,
     * <code>compare</code> returns the difference of the first mismatching byte
     * of the UTF-8 encode representation of the two character at position <i>k</i>
     * in the two strings. If there is no index position at which they differ, then
     * the shorter string lexicographically precedes the longer string. In this
     * case, <code>compare</code> returns the difference of the lengths of
     * the strings.
     * <p>
     * When ignoring case considerations, this method behaves as if comparing
     * (using the same algorithm as described above)
     * normalized versions of the strings where case differences have been
     * eliminated by calling <code>toLowerCase(toUpperCase(string))</code> on both argument strings.
     *
     * @param ignoreCase whether case must be ignored.
     * @param aString the byte array containing the reference UTF-8 encoded character sequence.
     * @param offset the starting offset of the reference character sequence in <code>aString</code>.
     * @param length the length (in bytes) of the reference character sequence.
     * @param anotherString the byte array containing the UTF-8 encoded character sequence to be compared.
     * @param ooffset the starting offset in <code>anotherString</code> of the character sequence to be compared.
     * @param olength the length (in bytes) of the character sequence to be compared.
     * @return the value <code>0</code> if the character sequence contained in <code>anotherString</code> is equal to
     *         the character sequence contained in <code>aString</code>; a value less than <code>0</code> if the character sequence contained in <code>aString</code> is
     *         lexicographically less than the character sequence contained in <code>anotherString</code>; and a value
     *         greater than <code>0</code> if the character sequence contained in <code>aString</code> is lexicographically
     *         greater than the character sequence contained in <code>anotherString</code>, optionally ignoring case considerations..
     * @throws NullPointerException
     *                if <code>aString</code> or <code>anotherString</code> is <code>null</code>.
     */
    public static short compare(boolean ignoreCase, byte[] aString, short offset,
            short length, byte[] anotherString, short ooffset, short olength) {
        byte b1, b2;
        short min = length <= olength ? length : olength;
        for (short i=0; i < min; i++) {
            b1 = aString[(short)(offset + i)];
            b2 = anotherString[(short)(ooffset + i)];
            if (b1 != b2 && ignoreCase) {
                /* Convert bytes to lower case if applicable */
                if (((byte)(b1 & 0x80) == (byte)0)
                        &&( (b1 & 0xff) >= 0x41 && (b1 & 0xff) <= 0x5A
                        || (b1 & 0xff) >= 0xC0 && (b1 & 0xff) <= 0xD6
                        || (b1 & 0xff) >= 0xD8 && (b1 & 0xff) <= 0xDE)) {
                    b1 = (byte)(b1 + 0x20);
                }
                if (((byte)(b2 & 0x80) == (byte)0)
                        &&( (b2 & 0xff) >= 0x41 && (b2 & 0xff) <= 0x5A
                        || (b2 & 0xff) >= 0xC0 && (b2 & 0xff) <= 0xD6
                        || (b2 & 0xff) >= 0xD8 && (b2 & 0xff) <= 0xDE)) {
                    b2 = (byte)(b2 + 0x20);
                }
            }
            if (b1 != b2) {
                return (short)(b1 - b2);
            }
        }
        return (short)(length - olength);
    }

    /**
     * Returns the index within the provided UTF-8 encoded character string of the first occurrence of the
     * specified substring. The number returned is the smallest value <i>k</i>
     * for which: <blockquote>
     *
     * <pre>
     *  compare(false, aString, offset + <i>k</i>, slength, substring, soffset, slength) == 0
     * </pre>
     *
     * </blockquote> If no such value of <i>k</i> exists, then -1 is returned.
     *
     * @param aString the byte array containing the reference UTF-8 encoded character sequence.
     * @param offset the starting offset of the reference character sequence in <code>aString</code>.
     * @param length the length (in bytes) of the reference character sequence.
     * @param subString the byte array containing the UTF-8 encoded character sequence of the substring.
     * @param soffset the starting offset in <code>subString</code> of the substring's character sequence.
     * @param slength the length (in bytes) of the substring's character sequence.
     * @return if the substring designated by <code>subString</code>, <code>soffset</code> and <code>slength</code>
     * occurs as a substring within the string designated by <code>aString</code>, <code>offset</code> and <code>length</code>,
     *         then the index (relative to <code>offset</code>) of the first byte of the first such substring
     *         is returned; if it does not occur as a substring, <code>-1</code>
     *         is returned.
     * @throws java.lang.NullPointerException
     *                if <code>aString</code> or <code>subString</code> is <code>null</code>.
     *
     */
    public static short indexOf(byte[] aString, short offset, short length,
            byte[] subString, short soffset, short slength) {
        if (slength == 0) {
            return (short)0;
        }
        short max = (short) (offset + length - slength);

        for (short i = offset; i <= max; i++) {
            if (Util.arrayCompare(aString, i, subString, soffset, slength) == 0) {
                return (short)(i - offset);
            }
        }
        return (short) -1;
    }

    /**
     * Copies to the destination byte array the string resulting from replacing all occurrences of
     * the old substring in the provided source string with the new substring.
     * <p>
     * If the character sequence (substring) designated by <code>oldSubstring</code>,
     * <code>oOffset</code> and <code>oLength</code>
     * does not occur in the source character sequence
     * designated by <code>srcString</code>, <code>srcOffset</code> and <code>srcLength</code>, then the source character sequence is
     * copied as is to <code>dstString</code>, starting at <code>dstOffset</code>. Otherwise, a character
     * sequence identical to the character sequence designated by
     * <code>srcString</code>, <code>srcOffset</code> and <code>srcLength</code> is copied to <code>dstString</code>,
     * starting at <code>dstOffset</code>, except that every occurrence of
     * the substring designated by <code>oldSubstring</code>,
     * <code>oOffset</code> and <code>oLength</code> is replaced by an occurrence of
     * the substring designated by <code>newSubstring</code>,
     * <code>nOffset</code> and <code>nLength</code>.
     * The replacement proceeds from the beginning of the source string to the end.
     *
     * @param srcString the byte array containing the source UTF-8 encoded character sequence.
     * @param srcOffset the starting offset of the source character sequence in <code>srcString</code>.
     * @param srcLength the length (in bytes) of the source character sequence.
     * @param oldSubstring the byte array containing the UTF-8 encoded character sequence to be replaced.
     * @param oOffset the starting offset of the replaced character sequence in <code>oldSubstring</code>.
     * @param oLength the length (in bytes) of the replaced character sequence.
     * @param newSubstring the byte array containing the replacement UTF-8 encoded character sequence.
     * @param nOffset the starting offset of the replacement character sequence in <code>newSubstring</code>.
     * @param nLength the length (in bytes) of the replacement character sequence.
     * @param dstString the byte array for copying the resulting character sequence.
     * @param dstOffset the starting offset in <code>dstString</code> for copying the resulting character sequence.
     * @return the number of bytes copied.
     * @throws NullPointerException
     *                if <code>srcString</code>, <code>oldSubstring</code>, <code>newSubstring</code> or <code>dstString</code> is <code>null</code>.
     */
    public static short replace(byte[] srcString, short srcOffset, short srcLength,
                byte[] oldSubstring, short oOffset, short oLength,
                byte[] newSubstring, short nOffset, short nLength,
                byte[] dstString, short dstOffset) {
        if (oLength == nLength && Util.arrayCompare(oldSubstring, oOffset, newSubstring, nOffset, oLength) == 0) {
            Util.arrayCopy(srcString, srcOffset, dstString, dstOffset, srcLength);
            return srcLength;
        }
        else {
            short count;
            short i = -1;
            while (++i <= (short)(srcLength - oLength)) { /* Find first occurrance of oldSubstring */
                if (Util.arrayCompare(srcString, (short)(i + srcOffset), oldSubstring, oOffset, oLength) == 0) {
                    break;
                }
            }
            if (i <= (short)(srcLength - oLength)) { /* Found first occurance */
                Util.arrayCopy(srcString, srcOffset, dstString, dstOffset, i);
                count = i;
                while (i <= (short)(srcLength - oLength)) { /* Search for remaining occurances */
                    if (Util.arrayCompare(srcString, (short)(i + srcOffset), oldSubstring, oOffset, oLength) == 0) {
                        Util.arrayCopy(newSubstring, nOffset, dstString, (short)(dstOffset + count), nLength);
                        i += oLength;
                        count += nLength;
                    }
                    else { /* Copy each other byte */
                        dstString[(short)(dstOffset + count)] = srcString[(short)(i + srcOffset)];
                        i++;
                        count++;
                    }
                }
                /* Copy remaining end bytes when oLength > 1 */
                Util.arrayCopy(srcString, i, dstString, (short)(dstOffset + count), (short)(srcLength - i));
                count += srcLength - i;
                return count;
            }
            else { /* oldSubstring not found */
                Util.arrayCopy(srcString, srcOffset, dstString, dstOffset, srcLength);
                return srcLength;
            }
        }
    }

    /**
     * Converts to lower case and copies all of the characters from the provided
     * source UTF-8 encoded character string to the provided destination array, starting at the provided <code>dstOffset</code>.
     * This method skips/ignores any unrecognized (ill-formed or incomplete) byte sequence.
     *
     * @param srcString the byte array containing the source UTF-8 encoded character sequence.
     * @param srcOffset the starting offset of the source character sequence in <code>srcString</code>.
     * @param srcLength the length (in bytes) of the source character sequence.
     * @param dstString the byte array for copying the resulting character sequence.
     * @param dstOffset the starting offset in <code>dstString</code> for copying the resulting character sequence.
     * @return the number of bytes copied.
     * @throws NullPointerException
     *                if <code>srcString</code> or <code>dstString</code> is <code>null</code>.
     * @see StringUtil#toUpperCase
     */
    public static short toLowerCase(byte[] srcString, short srcOffset, short srcLength,
            byte[] dstString, short dstOffset) {
        byte c;
        for (short i = 0; i < srcLength; i++) {
            c = srcString[(short) (i + srcOffset)];
            if (((byte)(c & 0x80) == (byte)0)
                    && ((c & 0xff) >= 0x41 && (c & 0xff) <= 0x5A
                    || (c & 0xff) >= 0xC0 && (c & 0xff) <= 0xD6
                    || (c & 0xff) >= 0xD8 && (c & 0xff) <= 0xDE)) {
                c = (byte) (c + 0x20);
            }
            dstString[(short) (dstOffset + i)] = c;
        }
        return srcLength;
    }

    /**
     * Converts to upper case and copies all of the characters from the provided
     * source UTF-8 encoded character string to the provided destination array, starting at the provided <code>dstOffset</code>.
     * This method skips/ignores any unrecognized (ill-formed or incomplete) byte sequence.
     *
     * @param srcString the byte array containing the source UTF-8 encoded character sequence.
     * @param srcOffset the starting offset of the source character sequence in <code>srcString</code>.
     * @param srcLength the length (in bytes) of the source character sequence.
     * @param dstString the byte array for copying the resulting character sequence.
     * @param dstOffset the starting offset in <code>dstString</code> for copying the resulting character sequence.
     * @return the number of bytes copied.
     * @throws NullPointerException
     *                if <code>srcString</code> or <code>dstString</code> is <code>null</code>.
     * @see StringUtil#toLowerCase
     */
    public static short toUpperCase(byte[] srcString, short srcOffset, short srcLength,
            byte[] dstString, short dstOffset) {
        byte c;
        for (short i = 0; i < srcLength; i++) {
            c = srcString[(short) (i + srcOffset)];
            if (((byte)(c & 0x80) == (byte)0)
                    && ((c & 0xff) >= 0x61 && (c & 0xff) <= 0x7A
                    || (c & 0xff) >= 0xDF && (c & 0xff) <= 0xF6
                    || (c & 0xff) >= 0xF8 && (c & 0xff) <= 0xFF)) {
                c = (byte) (c - 0x20);
            }
            dstString[(short) (dstOffset + i)] = c;
        }
        return srcLength;
    }

    /**
     * Removes white space from both ends of the provided
     * UTF-8 encoded character string and copies the resulting character sequence to the provided destination array, starting at the provided <code>dstOffset</code>.
     * <p>
     * If the source string designated by <code>srcString</code>, <code>srcOffset</code> and <code>srcLength</code> represents an empty character
     * sequence, or the first and last characters of character sequence
     * of the source string both have codes greater
     * than <code>'&#92;u0020'</code> (the space character), then the source string
     * is copied as is to <code>dstString</code>, starting at <code>dstOffset</code>.
     * <p>
     * Otherwise, if there is no character with a code greater than
     * <code>'&#92;u0020'</code> in the source string, then no character
     * is copied and 0 is returned.
     * <p>
     * Otherwise, let <i>k</i> be the index of the first character in the
     * source string whose code is greater than <code>'&#92;u0020'</code>, and let
     * <i>m</i> be the index of the last character in the source string whose code is
     * greater than <code>'&#92;u0020'</code>. The substring of the source string that begins
     * with the character at index <i>k</i> and ends with the character at
     * index <i>m</i> is copied to <code>dstString</code>, starting at <code>dstOffset</code>.
     * <p>
     * This method may be used to trim whitespace from the beginning and end of
     * a string; in fact, it trims all ASCII control characters as well.
     * <p>
     * Illegal byte sequences are considered as non-white spaces.
     *
     * @param srcString the byte array containing the source UTF-8 encoded character sequence.
     * @param srcOffset the starting offset of the source character sequence in <code>srcString</code>.
     * @param srcLength the length (in bytes) of the source character sequence.
     * @param dstString the byte array for copying the resulting character sequence.
     * @param dstOffset the starting offset in <code>dstString</code> for copying the resulting character sequence.
     * @return the number of bytes copied.
     * @throws NullPointerException
     *                if <code>srcString</code> or <code>dstString</code> is <code>null</code>.
     */
    public static short trim(byte[] srcString, short srcOffset, short srcLength, byte[] dstString, short dstOffset) {
        short st = 0;
        short en = srcLength;
        while (st < en && srcString[(short) (srcOffset + st)] <= 0x20
                && srcString[(short) (srcOffset + st)] >= 0x00) {
            st++;
        }
        while (st < en && srcString[(short) (en + srcOffset - 1)] <= 0x20
                && srcString[(short) (srcOffset + st)] >= 0x00) {
            en--;
        }
        Util.arrayCopy(srcString, (short) (st + srcOffset), dstString, dstOffset, (short) (en - st));
        return (short) (en - st);
    }

    /**
     * Copies the UTF-8 encoded character string representation of the <code>boolean</code> argument into
     * the provided destination array, starting at the provided offset.
     * If the argument is <code>true</code>, a string equal to  <code>"true"</code> is copied; otherwise, a string equal to
     * <code>"false"</code> is copied.
     *
     * @param b a <code>boolean</code>.
     * @param dstString the destination UTF-8 encoded character string, as a byte array
     * @param dstOffset the starting offset in the destination array
     * @return the number of bytes copied.
     * @throws NullPointerException
     *                if <code>dstString</code> is <code>null</code>.
     */
    public static short valueOf(boolean b, byte[] dstString, short dstOffset) {
        if (b) { /* "true" */
            dstString[dstOffset] = 0x74;
            dstString[(short) (dstOffset + 1)] = 0x72;
            dstString[(short) (dstOffset + 2)] = 0x75;
            dstString[(short) (dstOffset + 3)] = 0x65;
            return (short) 4;
        } else { /* "false" */
            dstString[dstOffset] = 0x66;
            dstString[(short) (dstOffset + 1)] = 0x61;
            dstString[(short) (dstOffset + 2)] = 0x6C;
            dstString[(short) (dstOffset + 3)] = 0x73;
            dstString[(short) (dstOffset + 4)] = 0x65;
            return (short) 5;
        }
    }

    /**
     * Parses the string argument as a boolean.  The <code>boolean</code>
     * returned represents the value <code>true</code> if the string argument
     * is not <code>null</code> and is equal, ignoring case, to the string
     * {@code "true"}.
     *
     * @param aString the byte array containing the UTF-8 encoded character sequence to be parsed.
     * @param offset the starting offset of the character sequence in <code>aString</code>.
     * @param length the length (in bytes) of the character sequence to be parsed.
     * @return the boolean value represented by the designated character sequence.
     * @throws NullPointerException
     *                if <code>aString</code> is <code>null</code>.
     */
    public static boolean parseBoolean(byte[] aString, short offset, short length) {
        if ((aString[offset] == 0x74 || aString[offset] == 0x54) //throws NullPointerException if aString is null
                && length == 4
                && (aString[(short)(offset + 1)] == 0x72 || aString[(short)(offset + 1)] == 0x52)
                && (aString[(short)(offset + 2)] == 0x75 || aString[(short)(offset + 2)] == 0x55)
                && (aString[(short)(offset + 3)] == 0x65 || aString[(short)(offset + 3)] == 0x45)) {
            return true;
        }
        return false;
    }

    /**
     * Copies the UTF-8 encoded, signed decimal string representation of the
     * the (up-to) 16 bits long signed (<code>short</code>) argument into
     * the provided destination array, starting at the provided offset.
     *
     * @param i a <code>short</code>.
     * @param dstString the destination UTF-8 encoded character string, as a byte array
     * @param dstOffset the starting offset in the destination array
     * @return the number of bytes copied.
     * @throws NullPointerException
     *                if <code>dstString</code> is <code>null</code>.
     */
    public static short valueOf(short i, byte[] dstString, short dstOffset) {
        short radix = 10;
        short charPos = 5;
        boolean negative = i < 0;
        byte buf[] = new byte[6]; /* Max digits needed to display a short */
        short k;
        byte neg = 0x2D;
        byte digits[] = {0x30, 0x31, 0x32, 0x33, 0x34,
            0x35, 0x36, 0x37, 0x38, 0x39};

        if (!negative) {
            i = (short) -i;
        }
        while (i <= (short) (-radix)) {
            buf[(short) (charPos--)] = digits[(short) (-(i % radix))];
            i = (short) (i / radix);
        }
        buf[charPos] = digits[(short) (-i)];
        if (negative) {
            buf[(short) (--charPos)] = neg;
        }
        /* Find and remove empty space from the front of buf: */
        for (k = 0; k < 6; k++) {
            if (buf[k] != 0) {
                break;
            }
        }
        Util.arrayCopy(buf, k, dstString, dstOffset, (short) (6 - k));
        return (short) (6 - k);
    }

    /**
     * Parses the provided UTF-8 encoded character sequence into the (up-to) 16 bits long signed (<code>short</code>) integer.
     * Accepts decimal and hexadecimal numbers given by the following grammar:
     *
     * <blockquote>
     * <dl>
     * <dt><i>DecodableString:</i>
     * <dd><i>Sign<sub>opt</sub> DecimalNumeral</i>
     * <dd><i>Sign<sub>opt</sub></i> <code>0x</code> <i>HexDigits</i>
     * <dd><i>Sign<sub>opt</sub></i> <code>0X</code> <i>HexDigits</i>
     * <dd><i>Sign<sub>opt</sub></i> <code>#</code> <i>HexDigits</i>
     * <p>
     * <dt><i>Sign:</i>
     * <dd><code>-</code>
     * </dl>
     * </blockquote>
     *
     * <i>DecimalNumeral</i> and <i>HexDigits</i>
     * are defined in <a href="http://java.sun.com/docs/books/jls/second_edition/html/lexical.doc.html#48282">&sect;3.10.1</a>
     * of the <a href="http://java.sun.com/docs/books/jls/html/">Java
     * Language Specification</a>.
     * <p>
     * The sequence of characters following an (optional) negative
     * sign and/or radix specifier (&quot;<code>0x</code>&quot;,
     * &quot;<code>0X</code>&quot;, &quot;<code>#</code>&quot;, or
     * leading zero) is parsed as a (<code>short</code>) integer in the specified radix (10, or 16).
     * This sequence of characters must represent a positive value or a {@link
     * StringException} will be thrown with reason {@link StringException#ILLEGAL_NUMBER_FORMAT}.
     * The result is negated
     * if first character of the specified character string is the
     * minus sign.  No whitespace characters are permitted in the
     * character string.
     *
     * @param aString the byte array containing the UTF-8 encoded character sequence to be parsed.
     * @param offset the starting offset of the character sequence in <code>aString</code>.
     * @param length the length (in bytes) of the character sequence to be parsed.
     * @return the <code>short</code> integer value represented by the designated character sequence.
     * @throws StringException  if the designated character sequence does not contain a parsable (<code>short</code>) integer.
     * @throws NullPointerException
     *                if <code>aString</code> is <code>null</code>.
     */
    public static short parseShortInteger(byte[] aString, short offset, short length) {
        short s = 0;
        short radix = 0;
        boolean negative = false;
        short limit;
        short multmin;
        short digit = 0;
        byte b;

        /* Check negativity */
        if (aString[offset] == 0x2D) {
            negative = true;
            limit = -32768;
            offset++;
            length--;
        } else {
            limit = -32767;
        }

        /* Find radix */
        if (aString[offset] == 0x30 && length > 1) {
            if (aString[(short) (offset + 1)] == 0x78 || aString[(short) (offset + 1)] == 0x58) { /* Hex */
                offset += 2;
                length -= 2;
                radix = 16;
            } else { /* Octal */
                StringException.throwIt(StringException.ILLEGAL_NUMBER_FORMAT);
                /* offset += 1;
                length -= 1;
                radix = 8; */
            }
        } else if (aString[offset] == 0x23) { /* Hex */
            offset += 1;
            length -= 1;
            radix = 16;
        } else { /* Decimal */
            radix = 10;
        }

        /* Calculate value */
        multmin = (short) (limit / radix);
        if (length > 0) {
            b = aString[offset];
            if (b >= 0x30 && b <= 0x39) {
                digit = (short) (b - 0x30);
            } else if ((b >= 0x41 && b <= 0x46) || (b >= 0x61 && b <= 0x66)) {
                digit = (short) ((b & 0x1F) + 9);
            } else {
                StringException.throwIt(StringException.ILLEGAL_NUMBER_FORMAT);
            }
            if (digit >= radix) {
                StringException.throwIt(StringException.ILLEGAL_NUMBER_FORMAT);
            }
            s = (short) -digit;
            length--;
            offset++;
        } else {
            StringException.throwIt(StringException.ILLEGAL_NUMBER_FORMAT);
        }
        while (length > 0) {
            // Accumulating negatively avoids surprises near MAX_VALUE
            b = aString[offset];
            if (b >= 0x30 && b <= 0x39) {
                digit = (short) (b - 0x30);
            } else if ((b >= 0x41 && b <= 0x46) || (b >= 0x61 && b <= 0x66)) {
                digit = (short) ((b & 0x1F) + 9);
            } else {
                StringException.throwIt(StringException.ILLEGAL_NUMBER_FORMAT);
            }
            if (digit >= radix || s < multmin) {
                StringException.throwIt(StringException.ILLEGAL_NUMBER_FORMAT);
            }
            s *= radix;
            if (s < (short) (limit + digit)) {
                StringException.throwIt(StringException.ILLEGAL_NUMBER_FORMAT);
            }
            s -= digit;
            length--;
            offset++;
        }
        if (negative) {
            return s;
        }
        return (short) -s;
    }

    /**
     * Copies the UTF-8 encoded, signed decimal string representation of the (up-to) 64 bits long signed integer
     * argument provided as an array of <code>short</code> integers, into
     * the provided destination array, starting at the provided offset.
     *
     * @param l an array of <code>short</code> integers representing up to a 64bits signed long integer;
     * the most significant <code>short</code> integer is at index <code>0</code>.
     * @param dstString the destination UTF-8 encoded character string, as a byte array
     * @param dstOffset the starting offset in the destination array
     * @return the number of bytes copied.
     * @throws NullPointerException
     *                if <code>l</code> or <code>dstString</code> is <code>null</code>.
     */
    public static short valueOf(short[] l, byte[] dstString, short dstOffset) {
        boolean negative = l[(short)0] < 0; /* Check for negativity in MSB */
        short radix = 10;
        short len = (short)l.length;
        short lCopy[] = new short[(short)l.length];
        short i;
        for ( i = 0; i < len; i++) { //copy & reverse order for calculations with LSB at 0
            if (negative) {
                lCopy[(short)(len - 1 - i)] = (short)~l[i];
            }
            else {
                lCopy[(short)(len - 1 - i)] = l[i];
            }
        }
        /* Convert negative numbers to positives: */
        if (negative) {
            boolean carry = false;
            if (lCopy[0] == (short) 0xFFFF) {
                carry = true;
                i = 1;
            }
            lCopy[0] += 1;
            while (carry) {
                if (lCopy[i] == (short) 0xFFFF) {
                    carry = true;
                } else {
                    carry = false;
                }
                lCopy[i] += 1;
                i++;
            }
        }
        /* Calculate minimum length necessary */
        if (len > 1 && lCopy[(short)(len - 1)] == (short)0) {
            while (len > 1 && lCopy[(short)(len - 1)] == (short)0) {
                len--;
            }
        }
        short rlen = (short)(2*len);
        short remainder[] = new short[rlen];
        short divisor[] = new short[rlen];
        short quotient[] = new short[len];
        short charPos = 20;
        byte buf[] = new byte[21]; /* Max digits needed to display a short */
        short k;
        byte neg = 0x2D;
        byte digits[] = {0x30, 0x31, 0x32, 0x33, 0x34,
                         0x35, 0x36, 0x37, 0x38, 0x39};
        boolean gt = true;
        for (i = 0; i < len; i++) {
            remainder[i] = lCopy[i];
        }
        divisor[len] = radix;
        if (len == 1 && remainder[0] < radix && remainder[0] >= 0) {
            gt = false;
        }
        /**
         * Division algorithm:
         * Divisor, Remainder registers are 2 * length of Quotient register
         * Divisor initialized with Divisor in upper half of Divisor register
         * Remainder initialized to Dividend
         * Quotient initialized to 0
         *
         * Repeat (quotient register length + 1) times:
         *  Remainder = Remainder - Divisor;
         *  If (Remainder >= 0) {
         *      Quotient = Quotient << 1 | 0x1; // Shift left by 1, set rightmost bit to 1
         *  }
         *  Else {
         *      Remainder = Remainder + Divisor; // Restore Remainder value
         *      Quotient = Quotient << 1 & 0xFFFE; // Shift left by 1, set rightmost bit to 0
         *  }
         *  Divisor = Divisor >> 1;
         *
         */
        while (gt) { //quotient >= radix
            for (i = 0; i < (short)(len * 16 + 1); i++){
                short borrow = 0;
                short temp[] = new short[rlen];
                short j;
                for (j = 0; j < rlen; j++) {
                    temp[j] = (short)(remainder[j] - divisor[j] - borrow);
                    if ((remainder[j] >= 0 && temp[j] < 0)
                            || (remainder[j] >= 0 && temp[j] > remainder[j])) {
                        borrow = 1;
                    }
                    else {
                        borrow = 0;
                    }
                }
                /* Find first non-zero short in resultant remainder value */
                j = (short)(rlen - 1);
                while (temp[j] == 0 && j > 0) {
                    j--;
                }
                /* templen used to determine negativity based on if remainder contains a longer value than temp*/
                short templen = (short)(rlen - 1);
                while (remainder[templen] == 0 && templen > 0) {
                    templen--;
                }
                /* Check if temp contains a value >= 0 */
                if (temp[j] >= 0 || (temp[j] < 0 && remainder[j] < 0 && temp[j] <= remainder[j])
                        || (temp[j] < 0 && templen > j && remainder[templen] > 0)) {
                    for (j = 0; j < rlen; j++) { //update remainder
                        remainder[j] = temp[j];
                    }
                    for (j = (short)(len - 1); j > 0; j--) { //update quotient
                        quotient[j] = (short)((quotient[j] << 1) |
                                ((quotient[(short)(j-1)] >> 15)& 0x0001));
                    }
                    quotient[0] = (short)((quotient[0] << 1) | 0x1); //LSB = 1
                }
                else { //don't change remainder
                    for (j = (short)(len - 1); j > 0; j--) { //update quotient
                        quotient[j] = (short)((quotient[j] << 1) |
                                ((quotient[(short)(j-1)] >> 15)& 0x0001));
                    }
                    quotient[0] = (short)((quotient[0] << 1) & (short)0xFFFE); //LSB = 0
                }
                for (j = 0; j < (short)(rlen - 1); j++) {
                    divisor[j] = (short)(((divisor[j] >> 1) & 0x7FFF) | ((divisor[(short)(j+1)] << 15) & (short)0x8000));
                }
                divisor[(short)(rlen - 1)] = (short)(divisor[(short)(rlen - 1)] >> 1);
            }
            /* Update buffer with the resultant digit */
            buf[(short)(charPos--)] = digits[remainder[0]];
            /* re-initialize len, remainder, quotient, divisor to calculate the next digit */
            if(len > 1 && quotient[(short)(len - 1)] == (short)0) {
                while (len > 1 && quotient[(short)(len - 1)] == (short)0) {
                    len--;
                }
            }
            if (len == 1 && quotient[0] < radix && quotient[0] >= 0) {
                gt = false;
            }
            for (i = 0; i < len; i++) {
                remainder[(short)(i + len)] = 0;
                remainder[i] = quotient[i];
                quotient[i] = 0;
                divisor[i] = 0;
                divisor[(short)(i + len)] = 0;
            }
            divisor[len] = radix;
        }
        /* Update buffer with final digit */
        buf[charPos] = digits[remainder[0]];
        if (negative) {
            buf[(short)(--charPos)] = neg;
        }
        /* Find and remove empty space from the front of buf: */
        for (k = 0; k < 21; k++) {
            if (buf[k] != 0) {
                break;
            }
        }
        Util.arrayCopy(buf, k, dstString, dstOffset, (short)(21-k));
        return (short)(21-k);
    }

    /**
     * Parses the provided UTF-8 encoded character sequence into a (up-to) 64 bits long signed integer.
     * Accepts decimal and hexadecimal numbers given by the following grammar:
     *
     * <blockquote>
     * <dl>
     * <dt><i>DecodableString:</i>
     * <dd><i>Sign<sub>opt</sub> DecimalNumeral</i>
     * <dd><i>Sign<sub>opt</sub></i> <code>0x</code> <i>HexDigits</i>
     * <dd><i>Sign<sub>opt</sub></i> <code>0X</code> <i>HexDigits</i>
     * <dd><i>Sign<sub>opt</sub></i> <code>#</code> <i>HexDigits</i>
     * <p>
     * <dt><i>Sign:</i>
     * <dd><code>-</code>
     * </dl>
     * </blockquote>
     *
     * <i>DecimalNumeral</i> and <i>HexDigits</i>
     * are defined in <a href="http://java.sun.com/docs/books/jls/second_edition/html/lexical.doc.html#48282">&sect;3.10.1</a>
     * of the <a href="http://java.sun.com/docs/books/jls/html/">Java
     * Language Specification</a>.
     * <p>
     * The sequence of characters following an (optional) negative
     * sign and/or radix specifier (&quot;<code>0x</code>&quot;,
     * &quot;<code>0X</code>&quot;, &quot;<code>#</code>&quot;, or
     * leading zero) is parsed as a (long) integer in the specified radix (10 or 16).
     * This sequence of characters must represent a positive value or a {@link
     * StringException} will be thrown with reason {@link StringException#ILLEGAL_NUMBER_FORMAT}.
     * The result is negated
     * if first character of the specified character string is the
     * minus sign.  No whitespace characters are permitted in the
     * character string.
     *
     * @param aString the byte array containing the UTF-8 encoded character sequence to be parsed.
     * @param offset the starting offset of the character sequence in <code>aString</code>.
     * @param length the length (in bytes) of the character sequence to be parsed.
     * @param integer the array of <code>short</code> integers to contained the value represented
     * by the designated character sequence; the most significant <code>short</code> integer is at index <code>0</code>.
     * @param ioffset the starting offset in <code>integer</code> for copying the resulting short sequence.
     * @return the number of <code>short</code> integers written into the array, ignoring leading zeroshort values.
     * @throws StringException  the designated character sequence does not contain a parsable (long) integer.
     * @throws NullPointerException
     *                if <code>aString</code> or <code>integer</code> is <code>null</code>.
     */
    public static short parseLongInteger(byte[] aString, short offset, short length,
            short[] integer, short ioffset) {
        short radix = 0;
        boolean negative = false;
        short digit = 0;
        byte b;
        short buf[] = new short[5];
        short len = 1;
        /* Check negativity */
        if (aString[offset] == 0x2D) {
            negative = true;
            offset++;
            length--;
        }
        /* Find radix */
        if (aString[offset] == 0x30 && length > 1) {
            if (aString[(short) (offset + 1)] == 0x78 || aString[(short) (offset + 1)] == 0x58) { /* Hex */
                offset += 2;
                length -= 2;
                radix = 16;
            } else { /* Octal */
                StringException.throwIt(StringException.ILLEGAL_NUMBER_FORMAT);
                /* offset += 1;
                length -= 1;
                radix = 8; */
            }
        } else if (aString[offset] == 0x23) { /* Hex */
            offset += 1;
            length -= 1;
            radix = 16;
        } else { /* Decimal */
            radix = 10;
        }
        if (length <= 0) {
            StringException.throwIt(StringException.ILLEGAL_NUMBER_FORMAT);
        }
        /* Calculate value */
        if (radix == 16) { /* Hex Case */
            while (length > 1 && aString[offset] == 0x30) {
                offset++;
                length--;
            }
            /* Initialize needed shorts in integer: */
            len = (short) (length / 4 * 4) < length ? (short) (length / 4 + 1)
                    : (short) (length / 4);
            if (len > 4 || negative) {
                len = 4;
            }
            for (short i = 0; i < len; i++) {
                buf[(short) (ioffset + i)] = 0;
            }
            short i = 0;
            while (i < length) {
                /* Get and check each digit: */
                b = aString[(short) (offset + i)];
                if (b >= 0x30 && b <= 0x39) {
                    digit = (short) (b - 0x30);
                } else if ((b >= 0x41 && b <= 0x46) || (b >= 0x61 && b <= 0x66)) {
                    digit = (short) ((b & 0x1F) + 9);
                } else {
                    StringException.throwIt(StringException.ILLEGAL_NUMBER_FORMAT);
                }
                short off = (short) ((short) (length - i - 1) % 4);
                short shortCount = (short) ((short) (length - i - 1) / 4);
                buf[(short) (ioffset + shortCount)] =
                        (short) (buf[(short) (ioffset + shortCount)]
                        | digit << ((off) * 4));
                i++;
            }
        } 
        /* else if (radix == 8) { // Octal Case
            while (length > 1 && aString[offset] == 0x30) {
                offset++;
                length--;
            }
            // Initialize needed shorts in integer:
            len = (short) ((short) (length * 3) % 16) == 0 ? (short) ((short) (length * 3) / 16)
                    : (short) ((short) ((short) (length * 3) / 16) + 1);
            if (len > 4 || negative) {
                len = 4;
            }
            for (short i = 0; i < len; i++) {
                buf[(short) (ioffset + i)] = 0;
            }
            short i = 0;
            while (i < length) {
                // Get and check each digit:
                b = aString[(short) (offset + i)];
                if (b >= 0x30 && b <= 0x37) {
                    digit = (short) (b - 0x30);
                } else {
                    StringException.throwIt(StringException.ILLEGAL_NUMBER_FORMAT);
                }
                short shortCount = (short) ((short) ((short) (length - i - 1) * 3) / 16);
                short shortEnd = (short) ((short) ((short) ((short) ((short) (length - i - 1) * 3)) + 2) / 16);
                short off = (short) ((short) (length - 1 - i) * 3);
                buf[(short) (ioffset + shortCount)] =
                        (short) (buf[(short) (ioffset + shortCount)]
                        | (digit << (off % 16)));
                if (shortCount != shortEnd) {
                    if (off < 16) {
                        buf[(short) (ioffset + shortEnd)] =
                                (short) (buf[(short) (ioffset + shortEnd)]
                                | (digit >> (16 - off)));
                    } else {
                        buf[(short) (ioffset + shortEnd)] =
                                (short) (buf[(short) (ioffset + shortEnd)]
                                | (digit >> (16 * shortEnd - off)));
                    }
                }
                i++;
            }
        } */
        else { /* Decimal Case */
            b = aString[offset];
            if (b >= 0x30 && b <= 0x39) {
                digit = (short) (b - 0x30);
            } else {
                StringException.throwIt(StringException.ILLEGAL_NUMBER_FORMAT);
            }
            buf[ioffset] = digit;
            length--;
            offset++;
            len = 1; //#shorts used
            while (length > 0) {
                b = aString[offset];
                if (b >= 0x30 && b <= 0x39) {
                    digit = (short) (b - 0x30);
                } else {
                    StringException.throwIt(StringException.ILLEGAL_NUMBER_FORMAT);
                }
                short tmp = 0;
                short val = 0;
                short carry = 0;
                for (short j = 0; j < len; j++) { //add each short
                    tmp = carry;
                    carry = 0;
                    val = buf[(short) (ioffset + j)];
                    for (short i = 0; i < radix; i++) { //add several times to multiply
                        tmp = (short) (tmp + val);
                        if ((buf[(short) (ioffset + j)] < 0 && tmp > 0)
                                || (((buf[(short) (ioffset + j)] < 0 && tmp < 0)
                                || (buf[(short) (ioffset + j)] > 0 && tmp > 0))
                                && tmp < buf[(short) (ioffset + j)])) { //check for carry out
                            if (j == (short) (len - 1)) { //check if additional short is needed
                                len++;
                                buf[(short) (ioffset + j + 1)] = 0; //initialize additional short
                            }
                            carry++;
                        }
                        buf[(short) (ioffset + j)] = tmp;
                    }
                }
                tmp = (short) (buf[ioffset] + digit); //add current digit
                short j = 0;
                if ((buf[ioffset] < 0 && tmp >= 0) //check for carry out
                        || (buf[ioffset] < 0 && tmp < 0 && tmp < buf[ioffset])) {
                    carry = (short) 1;
                } else {
                    carry = 0;
                }
                buf[ioffset] = tmp;
                while (carry == (short) 1) {
                    if (j == (short) (len - 1)) {
                        len++;
                        buf[(short) (ioffset + j + 1)] = 0;
                        carry = (short) 1;
                    } else {
                        j++;
                        tmp = (short) (buf[(short) (ioffset + j)] + 1);
                        if ((buf[(short) (ioffset + j)] < 0 && tmp >= 0)
                                || (buf[(short) (ioffset + j)] < 0
                                && tmp < 0 && tmp < buf[(short) (ioffset + j)])) {
                            carry = (short) 1;
                        } else {
                            carry = 0;
                        }
                        buf[(short) (ioffset + j)] = tmp;
                    }
                }
                length--;
                offset++;
            }
            if (negative) {
                for (short i = len; i < 4; i++){
                    buf[(short)(ioffset + i)] = 0;
                }
                len = 4;
            }
        }
        if (len == 4 && (buf[3]&((short)0x8000)) == (short)0x8000) {
                if (negative && buf[3] == (short)0x8000 && buf[2] == 0 && buf[1] == 0 && buf[0] == 0);
                else {
                    StringException.throwIt(StringException.ILLEGAL_NUMBER_FORMAT);
                }
        }
        if (negative) { /* Two's complement representation: Flip bits & add 1 */
            short j;
            boolean carry = false;
            for (j = 0; j < len; j++) {
                buf[(short) (j + ioffset)] = (short) ~buf[(short) (j + ioffset)];
            }
            if (buf[ioffset] == (short) 0xFFFF) {
                carry = true;
                buf[ioffset] = 0;
                j = 1;
            } else {
                buf[ioffset] += 1;
            }
            while (carry) {
                if (buf[(short) (j + ioffset)] == (short) 0xFFFF) {
                    carry = true;
                } else {
                    carry = false;
                }
                buf[(short) (j + ioffset)] += 1;
                j++;
            }
        }
        for (short i = 0; i < len; i++){ //copy and reverse for MSB at 0
            integer[(short)(len - 1 - i)] = buf[i];
        }
        return len;
    }

    /**
     * Converts to the specified character encoding all of the characters from the provided
     * source UTF-8 encoded character string and copies them to the provided destination array,
     * starting at the provided <code>dstOffset</code>.
     *
     * @param srcString the byte array containing the source UTF-8 encoded character sequence.
     * @param srcOffset the starting offset of the source character sequence in <code>srcString</code>.
     * @param srcLength the length (in bytes) of the source character sequence.
     * @param dstString the byte array for copying the resulting character sequence.
     * @param dstOffset the starting offset in <code>dstString</code> for copying the resulting character sequence.
     * @param encoding the character encoding to be used.
     * @return the number of bytes copied.
     * @throws StringException with reason {@link StringException#UNSUPPORTED_ENCODING} if the requested character encoding is not supported.
     * @throws StringException with reason {@link StringException#INVALID_BYTE_SEQUENCE} if an invalid byte sequence is encountered.
     * @see StringUtil#convertFrom
     * @throws NullPointerException
     *                if <code>srcString</code> or <code>dstString</code> is <code>null</code>.
     */
    public static short convertTo(byte[] srcString, short srcOffset, short srcLength,
            byte[] dstString, short dstOffset, byte encoding) {
        if (encoding == UTF_8) {
            if (check(srcString, srcOffset, srcLength)) {
                Util.arrayCopy(srcString, srcOffset, dstString, dstOffset, srcLength);
            } else {
                StringException.throwIt(StringException.INVALID_BYTE_SEQUENCE);
            }
            return srcLength;
        } else if (encoding == UCS_2) {
            short count = 0;
            for (short i = srcOffset; i < (short) (srcOffset + srcLength); i++) {
                if ((srcString[i] & 0xF0) == 0xE0) { //3B
                    if ((srcString[(short) (i + 1)] & 0xC0) != 0x80
                            || (srcString[(short) (i + 2)] & 0xC0) != 0x80) {
                        StringException.throwIt(StringException.INVALID_BYTE_SEQUENCE);
                    }
                    dstString[(short) (2 * count + dstOffset)] =
                            (byte) (((srcString[i] << 4) & 0xF0)
                            | ((srcString[(short) (i + 1)] >> 2) & 0x0F));
                    dstString[(short) (2 * count + dstOffset + 1)] =
                            (byte) (((srcString[(short) (i + 1)] << 6) & 0xC0)
                            | (srcString[(short) (i + 2)] & 0x3F));
                    count++;
                    i += 2;
                } else if ((srcString[i] & 0xE0) == 0xC0) { //2B
                    if ((srcString[(short) (i + 1)] & 0xC0) != 0x80) {
                        StringException.throwIt(StringException.INVALID_BYTE_SEQUENCE);
                    }
                    dstString[(short) (2 * count + dstOffset)] =
                            (byte) ((srcString[i] >> 2) & 0x07);
                    dstString[(short) (2 * count + dstOffset + 1)] =
                            (byte) (((srcString[i] << 6) & 0xC0)
                            | (srcString[(short) (i + 1)] & 0x3F));
                    count++;
                    i++;
                } else if ((srcString[i] & 0x80) == 0) { //1B
                    dstString[(short) (2 * count + dstOffset)] = (byte) (0);
                    dstString[(short) (2 * count + dstOffset + 1)] = srcString[i];
                    count++;
                } else {
                    /* Too large to be represented by UCS-2 */
                    StringException.throwIt(StringException.INVALID_BYTE_SEQUENCE);
                }
            }
            return (short) (2 * count);
        } else {
            StringException.throwIt(StringException.UNSUPPORTED_ENCODING);
        }
        return (short) 0;
    }

    /**
     * Converts from the specified character encoding to the UTF-8 character encoding all of the characters from the provided
     * source character string and copies them to the provided destination array, starting at the provided <code>dstOffset</code>.
     *
     * @param srcString the byte array containing the source character sequence encoded in the character encoding designated by <code>encoding</code>.
     * @param srcOffset the starting offset of the source character sequence in <code>srcString</code>.
     * @param srcLength the length (in bytes) of the source character sequence.
     * @param dstString the byte array for copying the UTF-8 encoded resulting character sequence.
     * @param dstOffset the starting offset in <code>dstString</code> for copying the resulting character sequence.
     * @param encoding the character encoding of the source character string.
     * @return the number of bytes copied.
     * @throws StringException with reason {@link StringException#UNSUPPORTED_ENCODING} if the requested character encoding is not supported.
     * @throws StringException with reason {@link StringException#INVALID_BYTE_SEQUENCE} if an invalid byte sequence is encountered.
     * @throws NullPointerException
     *                if <code>srcString</code> or <code>dstString</code> is <code>null</code>.
     * @see StringUtil#convertTo
     */
    public static short convertFrom(byte[] srcString, short srcOffset, short srcLength,
            byte[] dstString, short dstOffset, byte encoding) {
        short codePoint;
        short count = dstOffset;
        if (encoding == UTF_8) {
            if (check(srcString, srcOffset, srcLength)) {
                Util.arrayCopy(srcString, srcOffset, dstString, dstOffset, srcLength);
            } else {
                StringException.throwIt(StringException.INVALID_BYTE_SEQUENCE);
            }
            return srcLength;
        } else if (encoding == UCS_2) {
            if (srcLength % 2 != 0) {
                StringException.throwIt(StringException.INVALID_BYTE_SEQUENCE);
            }
            for (short i = srcOffset; i < (short) (srcLength + srcOffset); i += 2) {
                codePoint = srcString[(short) (i + 1)];
                codePoint = (short) ((codePoint & 0x00FF) + (srcString[i] << 8));
                if (codePoint < 0x80 && codePoint >= 0) {
                    dstString[count] = (byte) codePoint;
                    count++;
                } else if (codePoint < 0x800 && codePoint >= 0) {
                    dstString[count] = (byte) ((codePoint >> 6) | 0xC0);
                    dstString[(short) (count + 1)] = (byte) (codePoint & 0x3F | 0x80);
                    count += 2;
                } else { //codePoint < 0x10000: Max for 16b encodings
                    dstString[count] = (byte) ((codePoint >> 12) & 0xEF | 0xE0);
                    dstString[(short) (count + 1)] = (byte) ((codePoint >> 6) & 0x3F | 0x80);
                    dstString[(short) (count + 2)] = (byte) (codePoint & 0x3F | 0x80);
                    count += 3;
                }
            }
            return (short) (count - dstOffset);
        } else {
            StringException.throwIt(StringException.UNSUPPORTED_ENCODING);
        }
        return (short) 0;
    }

    /**
     * Checks if the provided byte array contains a valid UTF-8 encoded character
     * or character sequence.
     * As per UTF-8, a byte with a leading '0' bit is a single-byte code;
     * a byte with leading '1' bits is the first byte of
     * a multi-byte sequence whose length is equals to number of leading '1' bits;
     * finally, a byte with a leading '10' bit sequence is a continuation byte of a multi-byte sequence.
     *
     * @param aString the byte array containing the UTF-8 encoded character sequence to be checked.
     * @param offset the starting offset of the character sequence in <code>srcString</code>.
     * @param length the length (in bytes) of the character sequence to be checked.
     * @return true, if the byte sequence corresponds to a valid UTF-8 encoded character
     * or character sequence, false otherwise.
     * @throws NullPointerException
     *                if <code>aString</code> is <code>null</code>.
     */
    public static boolean check(byte[] aString, short offset, short length) {
        for (short i = 0; i < length; i++) {
            if ((aString[(short) (i + offset)] & 0x80) == 0); /* 1B long char */ else if ((aString[(short) (i + offset)] & 0xE0) == 0xC0) { /* 2B long char */
                i++;
                if ((i >= length) || ((aString[(short) (i + offset)] & 0xC0) != 0x80)) {
                    return false;
                }
            } else if ((aString[(short) (i + offset)] & 0xF0) == 0xE0) { /* 3B long char */
                for (short j = 0; j < 2; j++) {
                    i++;
                    if ((i >= length) || ((aString[(short) (i + offset)] & 0xC0) != 0x80)) {
                        return false;
                    }
                }
            } else if ((aString[(short) (i + offset)] & 0xF8) == 0xF0) { /* 4B long char */
                for (short j = 0; j < 3; j++) {
                    i++;
                    if ((i >= length) || ((aString[(short) (i + offset)] & 0xC0) != 0x80)) {
                        return false;
                    }
                }
            } else {
                return false;
            }
        }
        return true;
    }

    /**
     * Tests if the UTF-8 encoded character sequence
     * designated by <code>aString</code>, <code>offset</code> and <code>length</code> starts
     * with the first <code>codePointCount</code> characters of the character sequence
     * designated by <code>prefix</code>, <code>poffset</code> and <code>plength</code>.
     * <p />
     * If <code>codePointCount</code> is negative, the whole prefix character sequence is
     * considered; in which case calling this method is equivalent to calling
     * {@link Util#arrayCompare(byte[], short, byte[], short, short) arrayCompare} as follows:
     * <pre>
     * return length >= plength && arrayCompare(aString, offset, prefix, poffset, plength) == 0;
     * </pre>
     * Otherwise if <code>codePointCount</code> is positive, calling this method
     * is equivalent to calling {@link Util#arrayCompare(byte[], short, byte[], short, short) arrayCompare} as follows:
     * <pre>
     * short endOffset = StringUtil.offsetByCodePoints(prefix, poffset, plength, 0, codePointCount);
     * return length >= endOffset && arrayCompare(aString, offset, prefix, poffset, endOffset) == 0;
     * </pre>
     *
     * @param aString the byte array containing the reference UTF-8 encoded character sequence.
     * @param offset the starting offset of the reference character sequence in <code>aString</code>.
     * @param length the length (in bytes) of the reference character sequence.
     * @param prefix the byte array containing the prefixing UTF-8 encoded character sequence.
     * @param poffset the starting offset in <code>prefix</code> of the prefixing character sequence.
     * @param plength the length (in bytes) of the prefixing character sequence.
     * @param codePointCount the number of code points to be used for testing.
     * @return <code>true</code> if the character sequence designated by <code>prefix</code>,
     * <code>poffset</code> and <code>plength</code> is a prefix of the character sequence designated by
     * <code>aString</code>, <code>offset</code> and <code>length</code>; <code>false</code> otherwise.
     *
     * @throws java.lang.NullPointerException
     *                if <code>aString</code> or <code>prefix</code> is <code>null</code>.
     *
     */
    public static boolean startsWith(byte[] aString, short offset, short length,
            byte[] prefix, short poffset, short plength, short codePointCount) {
        short endOffset;
        if (codePointCount >= 0) {
            endOffset = StringUtil.offsetByCodePoints(prefix, poffset, plength, (short)0, codePointCount);
        }
        else {
            endOffset = plength;
        }
        return length >= endOffset &&
                Util.arrayCompare(aString, offset, prefix, poffset, endOffset) == 0;
    }


    /**
     * Tests if the UTF-8 encoded character sequence
     * designated by <code>aString</code>, <code>offset</code> and <code>length</code> ends
     * with the first <code>codePointCount</code> characters of the character sequence
     * designated by <code>suffix</code>, <code>soffset</code> and <code>slength</code>.
     * <p />
     * If <code>codePointCount</code> is negative, the whole suffix character sequence is
     * considered; in which case calling this method is equivalent to calling
     * {@link Util#arrayCompare(byte[], short, byte[], short, short) arrayComapre } as follows:
     * <pre>
     * return length >= slength && arrayCompare(aString,
     *         (short) (offset + length - slength), suffix, soffset, slength) == 0;
     * </pre>
     * Otherwise if <code>codePointCount</code> is positive, calling this method
     * is equivalent to calling {@link Util#arrayCompare(byte[], short, byte[], short, short) arrayCompare } as follows:
     * <pre>
     * short endOffset = StringUtil.offsetByCodePoints(suffix, soffset, slength, 0, codePointCount);
     * return length >= endOffset && arrayCompare(aString,
     *         (short) (offset + length - endOffset), suffix, soffset, endOffset) == 0;
     * </pre>
     *
     * @param aString the byte array containing the reference UTF-8 encoded character sequence.
     * @param offset the starting offset of the reference character sequence in <code>aString</code>.
     * @param length the length (in bytes) of the reference character sequence.
     * @param suffix the byte array containing the suffixing UTF-8 encoded character sequence.
     * @param soffset the starting offset in <code>suffix</code> of the suffixing character sequence.
     * @param slength the length (in bytes) of the suffixing character sequence.
     * @param codePointCount the number of code points to be used for testing.
     * @return <code>true</code> if the character sequence designated by <code>suffix</code>,
     * <code>soffset</code> and <code>slength</code> is a suffix of the character sequence designated by
     * <code>aString</code>, <code>offset</code> and <code>length</code>; <code>false</code> otherwise.
     *
     * @throws java.lang.NullPointerException
     *                if <code>aString</code> or <code>suffix</code> is <code>null</code>.
     *
     */
    public static boolean endsWith(byte[] aString, short offset, short length,
            byte[] suffix, short soffset, short slength, short codePointCount) {
        short endOffset;
        if (codePointCount >= 0) {
            endOffset = StringUtil.offsetByCodePoints(suffix, soffset, slength, (short)0, codePointCount);
        }
        else {
            endOffset = slength;
        }
        return length >= endOffset &&
                Util.arrayCompare(aString, (short) (offset + length - endOffset), suffix, soffset, endOffset) == 0;
    }

    /**
     * Copies to the destination byte array the specified substring of the designated source string.
     * The substring begins at the specified <code>codePointbeginIndex</code> and
     * extends to the character at index <code>codePointEndIndex - 1</code>.
     * Thus the length of the substring in codepoints (that is its codepoint count) is <code>codePointEndIndex - codePointbeginIndex</code>.
     * <p>
     * Ill-formed or incomplete byte sequences within the text range count as one code point each.
     * <br>
     * If <code>codePointEndIndex</code> is negative, then the whole remaining character
     * sequence from the source string is considered.
     *
     * @param srcString the byte array containing the source UTF-8 encoded character sequence.
     * @param srcOffset the starting offset of the source character sequence in <code>srcString</code>.
     * @param srcLength the length (in bytes) of the source character sequence.
     * @param codePointBeginIndex the beginning index (relative to <code>srcOffset</code>), inclusive.
     * @param codePointEndIndex the ending index (relative to <code>srcOffset</code>), exclusive.
     * @param dstString the byte array for copying the resulting character sequence.
     * @param dstOffset the starting offset in <code>dstString</code> for copying the resulting character sequence.
     * @return the number of bytes copied.
     * @throws NullPointerException
     *                if <code>srcString</code> or <code>dstString</code> is <code>null</code>.
     */
    public static short substring(byte[] srcString, short srcOffset, short srcLength,
            short codePointBeginIndex, short codePointEndIndex,
            byte[] dstString, short dstOffset) {
        short endOffset;
        short beginOffset = (short)(srcOffset + StringUtil.offsetByCodePoints(srcString, srcOffset, srcLength, (short) 0, codePointBeginIndex));
        if (codePointEndIndex >= 0) {
            endOffset = (short)(srcOffset + StringUtil.offsetByCodePoints(srcString, srcOffset, srcLength, (short) 0, codePointEndIndex));
        }
        else {
            endOffset = (short)(srcOffset + srcLength);
        }
        short l = Util.arrayCopy(srcString, beginOffset, dstString, dstOffset, (short) (endOffset - beginOffset));
        return l;
    }

    private StringUtil() {}
 }
