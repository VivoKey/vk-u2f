/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package javacardx.framework.math;

import com.sun.javacard.impl.NativeMethods;

/**
 * The <code>BigNumber</code> class encapsulates an unsigned number whose
 * value is represented in internal hexadecimal format using an implementation
 * specific maximum number of bytes. This class supports the BCD (binary coded
 * decimal) format for I/O.
 * 
 * @since 2.2.2
 */

public final class BigNumber {

    /**
     * Constant to indicate a BCD (binary coded decimal) data format. When this
     * format is used a binary coded decimal digit is stored in 1 nibble (4
     * bits). A byte is packed with 2 BCD digits.
     */
    public static final byte FORMAT_BCD = (byte) 1;

    /**
     * Constant to indicate a hexadecimal (simple binary) data format.
     */
    public static final byte FORMAT_HEX = (byte) 2;

    // internally we store all numbers as hex. If there is a need to convert
    // from hex to some other number, we do it on the fly. All input arrays
    // which are passed in FORMAT_BCD are also converted to hex before
    // the desired operation is performed.
    byte[] number;

    // default max is the maximum hex value that can be stored in the number
    // array
    byte[] maxValue;

    static final byte MAX_BYTES_SUPPORTED = (byte) 8;

    /**
     * Creates a BigNumber instance with initial value 0. All implementations
     * must support at least 8 byte length internal representation capacity.
     * 
     * @param maxBytes
     *            maximum number of bytes needed in the hexadecimal format for
     *            the largest unsigned big number. For example, maxBytes = 2
     *            allows a big number representation range 0-65535.
     * @exception java.lang.ArithmeticException
     *                if maxBytes is 0, negative or larger than the supported
     *                maximum
     */
    public BigNumber(short maxBytes) {
        // we need to go native on this method because we cannot throw
        // ArithmeticException from java level.
        NativeMethods.checkForValidBNSize(getMaxBytesSupported(), maxBytes);
        // once we know the size is valid, initialize internal arrays
        number = new byte[maxBytes]; // this is automatically initialized to
        // 0
        maxValue = new byte[maxBytes]; // this is initialized to maximum value
        // that
        // can fit in the array of maxBytes
        javacard.framework.Util.arrayFillNonAtomic(maxValue, (byte) 0, maxBytes, (byte) 0xFF);
    }

    /**
     * Sets the maximum value that the BigNumber may contain. Attempts to
     * increase beyond the maximum results in an exception. If this method is
     * not called, the maximum value is the maximum hex value that fits within
     * the configured maximum number of bytes.
     * <p>
     * Note:
     * <ul>
     * <li><em>This method may allocate internal storage to store the specified
     * maximum value.</em>
     * </ul>
     * 
     * @param maxValue
     *            input byte array
     * @param bOff
     *            offset within input byte array containing first byte (the high
     *            order byte)
     * @param bLen
     *            byte length of input data
     * @param arrayFormat
     *            indicates the format of the input data. Valid codes listed in
     *            <code>FORMAT_*</code> constants, for example
     *            {@link #FORMAT_BCD FORMAT_BCD}.
     * @exception java.lang.NullPointerException
     *                if <code>maxValue</code> is <code>null</code>
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access of data
     *                outside array bounds or if <code>bLen</code> is negative
     * @exception java.lang.ArithmeticException
     *                for the following conditions:
     *                <ul>
     *                <li>if the specified maximum value is smaller than the
     *                encapsulated big number
     *                <li>if the specified maximum value is larger than will
     *                fit within the supported maximum number of bytes
     *                <li>if the input byte array format is not conformant with
     *                the specified <code>arrayFormat</code> parameter
     *                <li>if <code>bLen</code> is 0
     *                <li>if <code>arrayFormat</code> is not one of the
     *                FORMAT_ constants.
     *                </ul>
     */
    public void setMaximum(byte[] maxValue, short bOff, short bLen, byte arrayFormat) {
        NativeMethods.setMaxBNValue(maxValue, bOff, bLen, arrayFormat, this.maxValue, this.number);
    }

    /**
     * This method returns the byte length of the hex array that can store the
     * biggest BigNumber supported. This number is the maximum number in hex
     * byte representation. All implementations must support at least 8 bytes.
     * 
     * @return the byte length of the biggest number supported
     */
    public static short getMaxBytesSupported() {
        return MAX_BYTES_SUPPORTED;
    }

    /**
     * Initializes the big number using the input data
     * 
     * @param bArray
     *            input byte array
     * @param bOff
     *            offset within byte array containing first byte (the high order
     *            byte)
     * @param bLen
     *            byte length of input data
     * @param arrayFormat
     *            indicates the format of the input data. Valid codes listed in
     *            <code>FORMAT_*</code> constants, for example
     *            {@link #FORMAT_BCD FORMAT_BCD}.
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access outside
     *                array bounds or if <code>bLen</code> is negative
     * @exception java.lang.NullPointerException
     *                if <code>bArray</code> is <code>null</code>
     * @exception java.lang.ArithmeticException
     *                for the following conditions:
     *                <ul>
     *                <li>if the input byte array format is not conformant with
     *                the specified <code>arrayFormat</code> parameter
     *                <li>if the specified input data represents a number which
     *                is larger than the maximum value configured or larger than
     *                will fit within the supported maximum number of bytes
     *                <li>if <code>bLen</code> is 0
     *                <li>if <code>arrayFormat</code> is not one of the
     *                FORMAT_ constants.
     *                </ul>
     */
    public void init(byte[] bArray, short bOff, short bLen, byte arrayFormat) throws NullPointerException,
            ArrayIndexOutOfBoundsException, ArithmeticException {
        NativeMethods.initBigNumber(bArray, bOff, bLen, arrayFormat, this.number, this.maxValue);
    }

    /**
     * Increments the internal big number by the specified operand value
     * 
     * @param bArray
     *            input byte array
     * @param bOff
     *            offset within input byte array containing first byte (the high
     *            order byte)
     * @param bLen
     *            byte length of input data
     * @param arrayFormat
     *            indicates the format of the input data. Valid codes listed in
     *            <code>FORMAT_*</code> constants, for example
     *            {@link #FORMAT_BCD FORMAT_BCD}.
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access of data
     *                outside array bounds or if <code>bLen</code> is negative
     * @exception java.lang.NullPointerException
     *                if <code>bArray</code> is <code>null</code>
     * @exception java.lang.ArithmeticException
     *                for the following conditions:
     *                <ul>
     *                <li>if the input byte array format is not conformant with
     *                the specified <code>arrayFormat</code> parameter
     *                <li>if the result of the addition results in a big number
     *                which cannot be represented within the maximum supported
     *                bytes or is greater than the configured max value. The
     *                internal big number is left unchanged.
     *                <li>if <code>bLen</code> is 0
     *                <li>if <code>arrayFormat</code> is not one of the
     *                FORMAT_ constants
     *                </ul>
     */
    public void add(byte[] bArray, short bOff, short bLen, byte arrayFormat) throws NullPointerException,
            ArrayIndexOutOfBoundsException, ArithmeticException {
        NativeMethods.addBigNumbers(bArray, bOff, bLen, arrayFormat, number, maxValue);
    }

    /**
     * Decrements the internal big number by the specified operand value
     * 
     * @param bArray
     *            input byte array
     * @param bOff
     *            offset within input byte array containing first byte (the high
     *            order byte)
     * @param bLen
     *            byte length of input data
     * @param arrayFormat
     *            indicates the format of the input data. Valid codes listed in
     *            <code>FORMAT_*</code> constants, for example
     *            {@link #FORMAT_BCD FORMAT_BCD}.
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access of data
     *                outside array bounds or if <code>bLen</code> is negative
     * @exception java.lang.NullPointerException
     *                if <code>bArray</code> is <code>null</code>
     * @exception java.lang.ArithmeticException
     *                for the following conditions:
     *                <ul>
     *                <li>if the input byte array format is not conformant with
     *                the specified <code>arrayFormat</code> parameter
     *                <li>if the result of the subtraction results in a
     *                negative number. The internal big number is left
     *                unchanged.
     *                <li>if <code>bLen</code> is 0
     *                <li>if <code>arrayFormat</code> is not one of the
     *                FORMAT_ constants.
     *                </ul>
     */
    public void subtract(byte[] bArray, short bOff, short bLen, byte arrayFormat) throws ArithmeticException {
        NativeMethods.subtractBigNumbers(bArray, bOff, bLen, arrayFormat, number, maxValue);
    }

    /**
     * Multiplies the internal big number by the specified operand value
     * 
     * @param bArray
     *            input byte array
     * @param bOff
     *            offset within input byte array containing first byte (the high
     *            order byte)
     * @param bLen
     *            byte length of input data
     * @param arrayFormat
     *            indicates the format of the input data. Valid codes listed in
     *            <code>FORMAT_*</code> constants, for example
     *            {@link #FORMAT_BCD FORMAT_BCD}.
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access of data
     *                outside array bounds or if <code>bLen</code> is negative
     * @exception java.lang.NullPointerException
     *                if <code>bArray</code> is <code>null</code>
     * @exception java.lang.ArithmeticException
     *                for the following conditions:
     *                <ul>
     *                <li>if the input byte array format is not conformant with
     *                the specified <code>arrayFormat</code> parameter
     *                <li>if the result of the multiplication results in a big
     *                number which cannot be represented within the maximum
     *                supported bytes or is greater than the configured max
     *                value. The internal big number is left unchanged.
     *                <li>if <code>bLen</code> is 0
     *                <li>if <code>arrayFormat</code> is not one of the
     *                FORMAT_ constants.
     *                </ul>
     */
    public void multiply(byte[] bArray, short bOff, short bLen, byte arrayFormat) throws ArithmeticException {
        NativeMethods.multiplyBigNumbers(bArray, bOff, bLen, arrayFormat, number, maxValue);
    }

    /**
     * Compares the internal big number against the specified operand.
     * <p />
     * In addition to returning a {@code byte} result, this method sets the
     * result in an internal state which can be rechecked using assertion methods
     * of the {@link javacardx.security.SensitiveResult SensitiveResult} class,
     * if supported by the platform.
     * 
     * @param operand
     *            contains the BigNumber operand
     * @return the result of the comparison as follows:
     *         <ul>
     *         <li> <code>0</code> if equal</li>
     *         <li> <code>-1</code> if the internal big number is less than
     *         the specified operand</li>
     *         <li> <code>1</code> if the internal big number is greater than
     *         the specified operand</li>
     *         </ul>
     * @exception java.lang.NullPointerException
     *                if <code>operand</code> is <code>null</code>
     */
    public byte compareTo(BigNumber operand) {
        NativeMethods.sensitiveResultSetTagValUnassigned();
        byte result = NativeMethods.compareBigNumbers(operand.number, (short) 0, (short) operand.number.length, FORMAT_HEX,
                this.number);
        NativeMethods.sensitiveResultSet(result);
        return result;
    }

    /**
     * Compares the internal big number against the specified operand. The
     * operand is specified in an input byte array.
     * <p />
     * In addition to returning a {@code byte} result, this method sets the
     * result in an internal state which can be rechecked using assertion methods
     * of the {@link javacardx.security.SensitiveResult SensitiveResult} class,
     * if supported by the platform.
     * 
     * @param bArray
     *            input byte array
     * @param bOff
     *            offset within input byte array containing first byte (the high
     *            order byte)
     * @param bLen
     *            byte length of input data
     * @param arrayFormat
     *            indicates the format of the input data. Valid codes listed in
     *            <code>FORMAT_*</code> constants, for example
     *            {@link #FORMAT_BCD FORMAT_BCD}.
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access of data
     *                outside array bounds or if <code>bLen</code> is negative
     * @exception java.lang.NullPointerException
     *                if <code>bArray</code> is <code>null</code>
     * @exception java.lang.ArithmeticException
     *                for the following conditions:
     *                <ul>
     *                <li>if the input byte array format is not conformant with
     *                the specified <code>arrayFormat</code> parameter
     *                <li>if <code>bLen</code> is 0
     *                <li>if <code>arrayFormat</code> is not one of the
     *                FORMAT_ constants.
     *                </ul>
     * @return the result of the comparison as follows:
     *         <ul>
     *         <li> <code>0</code> if equal</li>
     *         <li> <code>-1</code> if the internal big number is less than
     *         the specified operand</li>
     *         <li> <code>1</code> if the internal big number is greater than
     *         the specified operand</li>
     *         </ul>
     */
    public byte compareTo(byte[] bArray, short bOff, short bLen, byte arrayFormat) {
        NativeMethods.sensitiveResultSetTagValUnassigned();
        byte result = NativeMethods.compareBigNumbers(bArray, bOff, bLen, arrayFormat, this.number);
        NativeMethods.sensitiveResultSet(result);
        return result;        
    }

    /**
     * Writes the internal big number out in the desired format. Note that the
     * value output into the specified byte array is right justified for the
     * number of requested bytes. BCD 0 nibbles are prepended to the output BCD
     * data written out.
     * 
     * @param outBuf
     *            output byte array
     * @param bOff
     *            offset within byte array containing first byte (the high order
     *            byte)
     * @param numBytes
     *            number of output bytes required
     * @param arrayFormat
     *            indicates the format of the input data. Valid codes listed in
     *            <code>FORMAT_*</code> constants, for example
     *            {@link #FORMAT_BCD FORMAT_BCD}.
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the output array would cause access of data
     *                outside array bounds or if <code>numBytes</code> is
     *                negative
     * @exception java.lang.NullPointerException
     *                if <code>outBuf</code> is <code>null</code>
     * @exception java.lang.ArithmeticException
     *                for the following conditions:
     *                <ul>
     *                <li>if <code>numBytes</code> is not sufficient to
     *                represent the big number in the desired format
     *                <li>if <code>numBytes</code> is 0
     *                <li>if <code>arrayFormat</code> is not one of the
     *                FORMAT_ constants.
     *                </ul>
     */
    public void toBytes(byte[] outBuf, short bOff, short numBytes, byte arrayFormat)
            throws ArrayIndexOutOfBoundsException, NullPointerException {
        NativeMethods.bigNumberToBytes(outBuf, bOff, numBytes, arrayFormat, number);
    }

    /**
     * Returns the number of bytes required to represent the big number using
     * the desired format
     * 
     * @param arrayFormat
     *            indicates the format of the output data. Valid codes listed in
     *            <code>FORMAT_*</code> constants, for example
     *            {@link #FORMAT_BCD FORMAT_BCD}.
     * @return the byte length of big number
     * @exception ArithmeticException
     *                if <code>arrayFormat</code> is not one of the FORMAT_
     *                constants.
     */
    public short getByteLength(byte arrayFormat) {
        return NativeMethods.getBNByteLength(number, arrayFormat);
    }

    /**
     * Resets the big number to 0
     */
    public void reset() {
        javacard.framework.Util.arrayFillNonAtomic(number, (byte) 0, (short) number.length, (byte) 0);
    }

}
