/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package javacardx.framework.tlv;

import javacard.framework.JCSystem;
import javacard.framework.Util;

import com.sun.javacard.impl.NativeMethods;

/**
 * The <code>PrimitiveBERTLV</code> class encapsulates a primitive BER TLV
 * structure. It extends the generic <CODE>BERTLV</CODE> class. The rules on
 * the allowed encoding of the Tag, length and value fields is based on the
 * ASN.1 BER encoding rules ISO/IEC 8825-1:2002.
 * <p>
 * The <CODE>PrimitiveBERTLV</CODE> class only supports encoding of the
 * length(L) octets in definite form. The value(V) field which encodes the
 * contents octets are merely viewed as a series of bytes.
 * <p>
 * Every <CODE>PrimitiveBERTLV</CODE> has a capacity which represents the
 * allocated internal buffer to represent the Value of <code>this</code> TLV
 * object. As long as the number of bytes required to represent the Value of the
 * TLV object does not exceed the capacity, it is not necessary to allocate
 * additional internal buffer space. If the internal buffer overflows, and the
 * implementation supports automatic expansion which might require new data
 * allocation and possibly old data/object deletion, it is automatically made
 * larger. Otherwise a <CODE>TLVException</CODE> is thrown.
 * <p>
 * The <CODE>BERTLV</CODE> class and the subclasses
 * <CODE>ConstructedBERTLV</CODE> and <CODE>PrimitiveBERTLV</CODE>, also
 * provide static methods to parse or edit a TLV structure representation in a
 * byte array.
 * 
 * @since 2.2.2
 */

public class PrimitiveBERTLV extends BERTLV {

    /**
     * Constructor creates an empty <CODE>PrimitiveBERTLV</CODE> object
     * capable of encapsulating a Primitive BER TLV structure.
     * <p>
     * The initial capacity is specified by the numValueBytes argument.
     * 
     * @param numValueBytes
     *            is the number of Value bytes to allocate
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.INVALID_PARAM</code> if
     *                numValueBytes parameter is negative or larger than the
     *                maximum capacity supported by the implementation.
     *                </ul>
     */
    public PrimitiveBERTLV(short numValueBytes) {

        try {
            theValue = new byte[numValueBytes];
        } catch (Exception e) {
            TLVException.throwIt(TLVException.INVALID_PARAM);
        }

        theValue = new byte[numValueBytes];
        valueLength = 0;
        emptyTLV = true;

    }

    /**
     * (Re-)Initializes <code>this</code> <CODE>PrimitiveBERTLV</CODE> using
     * the input byte data.
     * <p>
     * The capacity of <code>this</code> <CODE>PrimitiveBERTLV</CODE> is increased, 
     * if required and supported, to 
     * the byte length of the Value represented in the primitive TLV structure
     * of the input byte array.
     * <p>
     * Note:
     * <ul>
     * <li><em>If </em><code>bOff+bLen</code><em> is greater than </em><code>bArray.length</code><em>, the length
     * of the </em><code>bArray</code><em> array, an </em><code>ArrayIndexOutOfBoundsException</code><em> exception is thrown.</em>
     * </ul>
     * 
     * @param bArray
     *            input byte array
     * @param bOff
     *            offset within byte array containing the TLV data
     * @param bLen
     *            byte length of input data
     * @return the resulting size of <code>this</code> TLV if represented in
     *         bytes
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access of data
     *                outside array bounds, or if the array offset or array
     *                length parameter is negative
     * @exception java.lang.NullPointerException
     *                if <code>bArray</code> is <code>null</code>
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.INSUFFICIENT_STORAGE</code> if
     *                the required capacity is not available and the
     *                implementation does not support automatic expansion.
     *                <li><code>TLVException.MALFORMED_TLV</code> if the
     *                input data is not a well-formed primitive BER TLV
     *                structure.
     *                </ul>
     */
    public short init(byte[] bArray, short bOff, short bLen) throws TLVException {

        NativeMethods.checkArrayArgs(bArray, bOff, bLen);
        if (!BERTLV.verifyFormat(bArray, bOff, bLen)) {
            TLVException.throwIt(TLVException.MALFORMED_TLV);
        }

        if (theBERTag != null) {
            JCSystem.requestObjectDeletion();
        }

        short bLength = getLength(bArray, bOff);
        short bOffSet = getValueOffsetInternal(bArray, bOff);

        // verify that the length found in the tlv does not cause access beyond
        // bLen
        // If it does, it is a malformed tlv.
        if ((short) (bOffSet + bLength) > (short) (bOff + bLen)) {
            TLVException.throwIt(TLVException.MALFORMED_TLV);
        }

        theBERTag = BERTag.getInstance(bArray, bOff);
        sharedValueInit(bArray, bOffSet, bLength);

        return this.size();
    }

    /**
     * (Re-)Initializes <code>this</code> <CODE>PrimitiveBERTLV</CODE>
     * object with the input tag, length and data. Note that a reference to the
     * BER Tag object is retained by <code>this</code> object. A change in the
     * BER Tag object contents affects <code>this</code> TLV instance.
     * <p>
     * If <code>this</code> primitive TLV object is empty, the initial
     * capacity of <code>this</code>
     * <CODE>PrimitiveBERTLV</CODE> is set to
     * the value of the vLen argument.
     * <p>
     * Note:
     * <ul>
     * <li><em>If </em><code>vOff+vLen</code><em> is greater than </em><code>vArray.length</code><em>, the length
     * of the </em><code>vArray</code><em> array, an </em><code>ArrayIndexOutOfBoundsException</code><em> exception is thrown.</em>
     * </ul>
     * 
     * @param tag
     *            a <CODE>BERTag</CODE> object
     * @param vArray
     *            the byte array containing length bytes of TLV value
     * @param vOff
     *            offset within the <CODE>vArray</CODE> byte array where data
     *            begins
     * @param vLen
     *            byte length of the value data in <CODE>vArray</CODE>
     * @return the resulting size of <code>this</code> TLV if represented in
     *         bytes
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access of data
     *                outside array bounds, or if the array offset or array
     *                length parameter is negative
     * @exception java.lang.NullPointerException
     *                if either <code>tag</code> or <code>vArray</code>
     *                parameter is <code>null</code>
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.INSUFFICIENT_STORAGE</code> if
     *                the required capacity is not available and the
     *                implementation does not support automatic expansion.
     *                </ul>
     */
    public short init(PrimitiveBERTag tag, byte[] vArray, short vOff, short vLen) throws TLVException {

        NativeMethods.checkArrayArgs(vArray, vOff, vLen);

        if (theBERTag != null) {
            JCSystem.requestObjectDeletion();
        }

        theBERTag = tag;

        sharedValueInit(vArray, vOff, vLen);

        return this.size();
    }

    /**
     * Code shared by both init routines.
     * 
     * @param vArray
     *            the byte array containing length bytes of TLV value
     * @param vOff
     *            offset within the <CODE>vArray</CODE> byte array where data
     *            begins
     * @param vLen
     *            byte length of the value data in <CODE>vArray</CODE>
     */
    private void sharedValueInit(byte[] vArray, short vOff, short vLen) {

        if (theBERTag.isConstructed()) {
            TLVException.throwIt(TLVException.MALFORMED_TLV);
        }

        if (theValue.length < vLen) {
            theValue = new byte[(short) (vLen + VALUE_INCREMENT)];
            JCSystem.requestObjectDeletion();
        }

        Util.arrayCopy(vArray, vOff, theValue, (short) 0, vLen);

        valueLength = vLen;
        emptyTLV = false;
    }

    /**
     * Appends the specified data to the end of <code>this</code> Primitive
     * BER TLV object.
     * <p>
     * Note:
     * <ul>
     * <li><em>If </em><code>vOff+vLen</code><em> is greater than </em><code>vArray.length</code><em>, the length
     * of the </em><code>vArray</code><em> array, an </em><code>ArrayIndexOutOfBoundsException</code><em> exception is thrown.</em>
     * </ul>
     * 
     * @param vArray
     *            the byte array containing length bytes of TLV value
     * @param vOff
     *            offset within the <CODE>vArray</CODE> byte array where data
     *            begins
     * @param vLen
     *            the byte length of the value in the input <CODE>vArray</CODE>
     * @return the resulting size of <code>this</code> if represented in bytes
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access of data
     *                outside array bounds, or if the array offset or length
     *                parameter is negative
     * @exception java.lang.NullPointerException
     *                if <code>vArray</code> is <code>null</code>
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.INSUFFICIENT_STORAGE</code> if
     *                the required capacity is not available and the
     *                implementation does not support automatic expansion
     *                <li><code>TLVException.EMPTY_TLV</code> if
     *                <code>this</code> <CODE>PrimitiveBERTLV</CODE> object
     *                is empty.
     *                </ul>
     */
    public short appendValue(byte[] vArray, short vOff, short vLen) throws TLVException {

        return setValue(vArray, vOff, vLen, APPEND);
    }

    /**
     * Replaces the specified data in place of the current value of
     * <code>this</code> Primitive BER TLV object.
     * <p>
     * Note:
     * <ul>
     * <li><em>If </em><code>vOff+vLen</code><em> is greater than </em><code>vArray.length</code><em>, the length
     * of the </em><code>vArray</code><em> array, an </em><code>ArrayIndexOutOfBoundsException</code><em> exception is thrown.</em>
     * </ul>
     * 
     * @param vArray
     *            the byte array containing length bytes of TLV value
     * @param vOff
     *            offset within the <CODE>vArray</CODE> byte array where data
     *            begins
     * @param vLen
     *            the byte length of the value in the input <CODE>vArray</CODE>
     * @return the resulting size of <code>this</code> if represented in bytes
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access of data
     *                outside array bounds, or if the array offset or length
     *                parameter is negative
     * @exception java.lang.NullPointerException
     *                if <code>vArray</code> is <code>null</code>
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.INSUFFICIENT_STORAGE</code> if
     *                the required capacity is not available and the
     *                implementation does not support automatic expansion
     *                <li><code>TLVException.EMPTY_TLV</code> if
     *                <code>this</code> <CODE>PrimitiveBERTLV</CODE> object
     *                is empty.
     *                </ul>
     */
    public short replaceValue(byte[] vArray, short vOff, short vLen) throws TLVException {

        return setValue(vArray, vOff, vLen, REPLACE);
    }

    /*
     * code shared between appendValue and replaceValue. This has been done
     * because other than the treatment of the length of the value and the offset,
     * the logic is identical.
     * @param vArray the byte array containing length bytes of TLV value
     * @param vOff offset within the <CODE>vArray</CODE> byte array where data begins
     * @param vLen the byte length of the value in the input <CODE>vArray</CODE>
     * @param replaceOrAppend If equal APPEND, the value will be appended, otherwise
     * it will be replaced.
     * @return the resulting size of <code>this</code> if represented in bytes
     * @exception TLVException with the following reason code:<ul>
     * <li><code>TLVException.EMPTY_TLV</code> if <code>this</code> <CODE>PrimitiveBERTLV</CODE> object
     * is empty.
     */
    private short setValue(byte[] vArray, short vOff, short vLen, byte replaceOrAppend) throws TLVException {

        short valueLen;
        short offset = 0;
        byte[] tempArray = null;

        NativeMethods.checkArrayArgs(vArray, vOff, vLen);

        if (emptyTLV) {
            TLVException.throwIt(TLVException.EMPTY_TLV);
        }

        if (replaceOrAppend == APPEND) {
            valueLen = (short) (vLen + valueLength);
            offset = valueLength;
        } else {
            valueLen = vLen;
        }

        if (theValue.length < valueLen) {
            if (replaceOrAppend == APPEND) {
                tempArray = new byte[theValue.length];
                Util.arrayCopy(theValue, (short) 0, tempArray, (short) 0, valueLength);
            }
            theValue = new byte[(short) (valueLen + VALUE_INCREMENT)];
            if (replaceOrAppend == APPEND) {
                Util.arrayCopy(tempArray, (short) 0, theValue, (short) 0, valueLength);
            }
            JCSystem.requestObjectDeletion();
        }

        Util.arrayCopy(vArray, vOff, theValue, offset, vLen);

        valueLength = valueLen;

        return (short) (valueLength + theBERTag.size() + getValueLengthSize(valueLength));
    }

    /**
     * Writes the value (V) part of <code>this</code> Primitive BER TLV object
     * into the output buffer. Returns the length of data written to tlvValue
     * output array
     * 
     * @param tlvValue
     *            the output byte array
     * @param tOff
     *            offset within the <CODE>tlvValue</CODE> byte array where
     *            output data begins
     * @return the byte length of data written to tlvValue output array
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the output array would cause access of data
     *                outside array bounds, or if the array offset parameter is
     *                negative
     * @exception java.lang.NullPointerException
     *                if <code>tlvValue</code> is <code>null</code>
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.TLV_SIZE_GREATER_THAN_32767</code>
     *                if the size of the Primitive BER TLV is > 32767
     *                <li><code>TLVException.EMPTY_TLV</code> if
     *                <code>this</code> <CODE>PrimitiveBERTLV</CODE> object
     *                is empty.
     *                </ul>
     */
    public short getValue(byte[] tlvValue, short tOff) throws TLVException {

        NativeMethods.checkArrayArgs(tlvValue, tOff, valueLength);

        if (emptyTLV) {
            TLVException.throwIt(TLVException.EMPTY_TLV);
        }

        Util.arrayCopy(theValue, (short) 0, tlvValue, tOff, valueLength);

        return valueLength;
    }

    /**
     * Returns the offset into the specified input byte array of the value (V)
     * part of the BER TLV structure representation in the input array.
     * 
     * @param berTLVArray
     *            input byte array
     * @param bTLVOff
     *            offset within byte array containing the TLV data
     * @return the offset into the specified input byte array of the value (V)
     *         part
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access of data
     *                outside array bounds, or if the array offset parameter is
     *                negative
     * @exception java.lang.NullPointerException
     *                if <code>tlvValue</code> or <code>berTLVArray</code>
     *                is <code>null</code>
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.TLV_SIZE_GREATER_THAN_32767</code>
     *                if the size of the Primitive BER TLV is > 32767.
     *                <li><code>TLVException.MALFORMED_TLV</code> if the TLV
     *                representation in the input byte array is not a
     *                well-formed primitive BER TLV structure.
     *                </ul>
     */
    public static short getValueOffset(byte[] berTLVArray, short bTLVOff) throws TLVException {

        if ((BERTag.CONSTRUCTED_TAG & berTLVArray[bTLVOff]) != 0) {
            TLVException.throwIt(TLVException.MALFORMED_TLV);
        }

        NativeMethods.checkArrayArgs(berTLVArray, bTLVOff, (short) (berTLVArray.length - bTLVOff));
        // Verify tag and length format
        short offSet = verifyTagAndLength(berTLVArray, bTLVOff);

        // If MALFORMED_TAG_VALUE returned, the tag is malformed,
        // if ILLEGAL_SIZE_VALUE is returned, length is too long,
        // MALFORMED_LENGTH
        // is returned, the length is malformed.
        if (offSet == BERTag.MALFORMED_TAG_VALUE) {
            TLVException.throwIt(TLVException.MALFORMED_TLV);
        } else if (offSet == BERTag.ILLEGAL_SIZE_VALUE) {
            TLVException.throwIt(TLVException.TLV_LENGTH_GREATER_THAN_32767);
        } else if (offSet == MALFORMED_LENGTH) {
            TLVException.throwIt(TLVException.MALFORMED_TLV);
        } else if (offSet == LENGTH_NOT_IN_LIMITS) {
            // force java.lang.ArrayIndexOutOfBoundsException. since value
            // length is more than
            // can be contained in the given array.
            NativeMethods.checkArrayArgs(berTLVArray, bTLVOff, (short) (berTLVArray.length + 1));
        }

        return BERTLV.getValueOffsetInternal(berTLVArray, bTLVOff);
    }

    /**
     * Writes a primitive TLV representation to the specified byte array using
     * as input a Primitive BER tag representation in a byte array and a value
     * representation in another byte array.
     * <p>
     * Note:
     * <ul>
     * <li><em>If </em><code>vOff+vLen</code><em> is greater than </em><code>valueArray.length</code><em>, the length
     * of the </em><code>valueArray</code><em> array, an </em><code>ArrayIndexOutOfBoundsException</code><em> exception is thrown.</em>
     * </ul>
     * 
     * @param berTagArray
     *            input byte array
     * @param berTagOff
     *            offset within byte array containing first byte of tag
     * @param valueArray
     *            input byte array containing primitive value
     * @param vOff
     *            offset within byte array containing the first byte of value
     * @param vLen
     *            length in bytes of the value component of the TLV
     * @param outBuf
     *            output byte array
     * @param bOff
     *            offset within byte array output data begins
     * @return the byte length written to the output array
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input or output arrays would cause access
     *                of data outside array bounds, or if any of the array
     *                offset or array length parameters is negative
     * @exception java.lang.NullPointerException
     *                if <code>berTagArray</code> or <code>valueArray</code>
     *                or <code>outBuf</code> is <code>null</code>
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.TLV_SIZE_GREATER_THAN_32767</code>
     *                if the size of the resulting Primitive BER TLV is > 32767.
     *                <li><code>TLVException.MALFORMED_TAG</code> if the tag
     *                representation in the byte array is not a well-formed
     *                constructed array tag.
     *                </ul>
     */
    public static short toBytes(byte[] berTagArray, short berTagOff, byte[] valueArray, short vOff, short vLen,
            byte[] outBuf, short bOff) {

        NativeMethods.checkArrayArgs(berTagArray, berTagOff, (short) (berTagArray.length - berTagOff));
        NativeMethods.checkArrayArgs(valueArray, vOff, vLen);

        short tagSizeInBytes = 0;
        short len = BERTLV.getValueLengthSize(vLen);
        short totalLen = 0;

        if (BERTag.isConstructed(berTagArray, berTagOff)) {
            TLVException.throwIt(TLVException.MALFORMED_TAG);
        }

        short tempNumber = BERTag.verifyFormatInternal(berTagArray, berTagOff);

        if (tempNumber >= 0) {
            // Check resulting length of TLV and TAG size
            tagSizeInBytes = BERTag.getTagSize(tempNumber);

            totalLen = (short) (vLen + tagSizeInBytes + len);
            NativeMethods.checkArrayArgs(outBuf, bOff, totalLen);
            /*if (totalLen > MAX_TLV_SIZE) {
                TLVException.throwIt(TLVException.TLV_SIZE_GREATER_THAN_32767);
            }*/
            // copy in the tag number
            Util.arrayCopy(berTagArray, berTagOff, outBuf, bOff, tagSizeInBytes);
            // Set the Length
            short offset = (short) (bOff + tagSizeInBytes);
            if (vLen < (short) 0x80) {
                outBuf[offset] = (byte) vLen;
                offset++;
            } else {
                outBuf[offset] = FIRST_BYTE_LONG_LENGTH;
                offset++;
                Util.setShort(outBuf, offset, vLen);
                offset += 2;
            }
            // Copy in the value
            Util.arrayCopy(valueArray, vOff, outBuf, offset, vLen);
        } else {
            TLVException.throwIt(TLVException.MALFORMED_TAG);
        }

        return totalLen;
    }

    /**
     * Appends the specified data to the end of the Primitive TLV representation
     * in the specified byte array. Note that this method is only applicable to
     * a primitive TLV representation, otherwise an exception is thrown.
     * <p>
     * Note:
     * <ul>
     * <li><em>If </em><code>vOff+vLen</code><em> is greater than </em><code>vArray.length</code><em>, the length
     * of the </em><code>vArray</code><em> array, an </em><code>ArrayIndexOutOfBoundsException</code><em> exception is thrown.</em>
     * </ul>
     * 
     * @param berTLVArray
     *            input byte array
     * @param bTLVOff
     *            offset within byte array containing the TLV data
     * @param vArray
     *            the byte array containing value to be appended
     * @param vOff
     *            offset within the <CODE>vArray</CODE> byte array where the
     *            data begins
     * @param vLen
     *            the byte length of the value in the input <CODE>vArray</CODE>
     * @return the resulting size of <code>this</code> if represented in bytes
     * @return the byte length written to the output array
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input arrays would cause access of data
     *                outside array bounds, or if any of the array offset or
     *                array length parameters is negative
     * @exception java.lang.NullPointerException
     *                if <code>berTLVArray</code> or <code>vArray</code> is
     *                <code>null</code>
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.TLV_SIZE_GREATER_THAN_32767</code>
     *                if the size of the resulting Primitive BER TLV is > 32767.
     *                <li><code>TLVException.MALFORMED_TLV</code> if the TLV
     *                representation in the input byte array is not a
     *                well-formed primitive BER TLV structure
     *                </ul>
     */
    public static short appendValue(byte[] berTLVArray, short bTLVOff, byte[] vArray, short vOff, short vLen)
            throws TLVException {

        short sizeOfLength = 0;
        short tagSizeInBytes = 0;
        short valueOffset = 0;
        short valueLength = 0;
        short lengthSizeChange = 0;

        if (BERTag.verifyFormatInternal(berTLVArray, bTLVOff) < 0) {
            TLVException.throwIt(TLVException.MALFORMED_TLV);
        }

        if (BERTag.isConstructed(berTLVArray, bTLVOff)) {
            TLVException.throwIt(TLVException.MALFORMED_TLV);
        }

        try {
            // must determine the end of this tlv to pass to verifyFormat
            valueOffset = getValueOffset(berTLVArray, bTLVOff);
            // Get Length value
            valueLength = getLength(berTLVArray, bTLVOff);
        } catch (Exception e) {
            TLVException.throwIt(TLVException.MALFORMED_TLV);
        }
        short tempNumber = BERTag.verifyFormatInternal(berTLVArray, bTLVOff);
        if (tempNumber >= 0) {
            // Check resulting length of TLV and TAG size
            tagSizeInBytes = BERTag.getTagSize(tempNumber);
        } else {
            TLVException.throwIt(TLVException.MALFORMED_TLV);
        }

        if ((short) (vLen + valueLength) > (short) 32767) {
            TLVException.throwIt(TLVException.TLV_SIZE_GREATER_THAN_32767);
        }

        // verifyFormatInternal will check the TLV parameters and if needed
        // throw
        // java.lang.ArrayIndexOutOfBoundsException or
        // java.lang.NullPointerException
        if (BERTLV.verifyFormatInternal(berTLVArray, bTLVOff, (short) (valueOffset + valueLength - bTLVOff)) >= 0) {
            NativeMethods.checkArrayArgs(vArray, vOff, vLen);
            // ok, now update the length of this TLV
            short offSet = getLengthOffset(berTLVArray, bTLVOff);
            if ((short) (valueLength + vLen) > (short) 0x7f) {
                if ((berTLVArray[(offSet)] & EXTENDED_FORMAT) != EXTENDED_FORMAT) {
                    lengthSizeChange = 2;
                } else {
                    lengthSizeChange = 1;
                }
                // The length will become extended to a 3 byte length to
                // accomodate the
                // larger value. This means moving the current value over 1 or 2
                // bytes
                // to accomodate the longer length componenent
                // A three byte length can contain the max value length
                // supported by this reference
                NativeMethods.checkArrayArgs(berTLVArray, valueOffset, (short) (valueLength + lengthSizeChange + vLen));
                Util.arrayCopy(vArray, vOff, berTLVArray, (short) (valueOffset + valueLength + lengthSizeChange), vLen);
                Util.arrayCopy(berTLVArray, valueOffset, berTLVArray, (short) (valueOffset + lengthSizeChange),
                        valueLength);
                berTLVArray[(offSet)] = (byte) 0x82;
                valueLength += vLen;
                Util.setShort(berTLVArray, (short) (offSet + 1), valueLength);
                sizeOfLength = 3;
            } else {
                Util.arrayCopy(vArray, vOff, berTLVArray, (short) (valueOffset + valueLength), vLen);
                // now get and return the length, already verified that the
                // length value is ok
                valueLength += vLen;
                if ((berTLVArray[(offSet)] & EXTENDED_FORMAT) == EXTENDED_FORMAT) {
                    sizeOfLength = (short) ((byte) 1 + (berTLVArray[offSet] & LENGTH_VALUE_MASK));
                    if (sizeOfLength == 2) {
                        berTLVArray[(short) (offSet + 1)] = (byte) valueLength;
                    } else {
                        for (short i = 1; i < (short) (sizeOfLength - 2); i++) {
                            if (berTLVArray[(short) (offSet + i)] != (byte) 0) {
                                Util.setShort(berTLVArray, (short) (offSet + i), valueLength);
                            }
                        }
                    }
                } else {
                    berTLVArray[(offSet)] = (byte) valueLength;
                    sizeOfLength = 1;
                }
            }
        } else {
            TLVException.throwIt(TLVException.MALFORMED_TLV);
        }

        return (short) (sizeOfLength + valueLength + tagSizeInBytes);
    }

}
