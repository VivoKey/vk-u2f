/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package javacardx.framework.tlv;

import com.sun.javacard.impl.NativeMethods;

/**
 * The abstract <code>BERTag</code> class encapsulates a BER TLV tag. The
 * rules on the allowed encoding of the Tag field are based on the ASN.1 BER
 * encoding rules of ISO/IEC 8825-1:2002.
 * <p>
 * The <CODE>BERTag</CODE> class and the subclasses
 * <CODE>ConstructedBERTag</CODE> and <CODE>PrimitiveBERTag</CODE>, also
 * provide static methods to parse or edit a BER Tag structure representation in
 * a byte array.
 * 
 * @since 2.2.2
 */
public abstract class BERTag {

    /**
     * Constant for BER Tag Class Universal
     */
    public static final byte BER_TAG_CLASS_MASK_UNIVERSAL = (byte) 0;

    /**
     * Constant for BER Tag Class Application
     */
    public static final byte BER_TAG_CLASS_MASK_APPLICATION = (byte) 1;

    /**
     * Constant for BER Tag Class Context-Specific
     */
    public static final byte BER_TAG_CLASS_MASK_CONTEXT_SPECIFIC = (byte) 2;

    /**
     * Constant for BER Tag Class Private
     */
    public static final byte BER_TAG_CLASS_MASK_PRIVATE = (byte) 3;

    /**
     * Constant for constructed BER Tag type
     */
    public static final boolean BER_TAG_TYPE_CONSTRUCTED = true;

    /**
     * Constant for primitive BER Tag type
     */
    public static final boolean BER_TAG_TYPE_PRIMITIVE = false;

    /**
     * Internal constants
     */

    /**
     * Internal Constant to indicate the maximum size in bytes of the BER Tag
     * supported. All implementations must support at least a 3 byte tag.
     */
    private static final short MAX_TAG_SIZE_SUPPORTED = (short) 3;

    // Constant used to test for a primitive tag
    private static final byte PRIMITIVE_TAG = (byte) 0x00;

    // Constant used to test for a contructed tag
    static final byte CONSTRUCTED_TAG = (byte) 0x20;

    // Error return values
    static final byte MALFORMED_TAG_VALUE = (byte) -1;
    static final byte ILLEGAL_SIZE_VALUE = (byte) -2;

    // package visible constants

    // Constant used to check if there are more bytes in a tag
    static final byte MORE_BYTES_CHECK = (byte) 0x80;

    // Constant used to see if this is more than a 1 byte tag
    static final byte MORE_THAN_ONE_BYTE_TAG_MASK = (byte) 0x1f;

    // Used to mask off value of tag number in each byte of tag
    static final byte TAG_MASK = (byte) 0x7f;

    // used to mask off the tag class value
    static final byte TAG_CLASS_MASK = (byte) 0x03;

    static final byte TAG_CLASS_SHIFT = (byte) 0x06;

    static final short ONE_BYTE_TAG_MAX = (short) 0x1e;

    static final short TWO_BYTE_TAG_MAX = (short) 0x7f;

    static final short THREE_BYTE_TAG_MAX = (short) 0x3fff;

    static final byte TAG_BYTE_ONE = (byte) 1;

    static final byte TAG_BYTE_TWO = (byte) 2;

    static final byte TAG_BYTE_THREE = (byte) 3;

    /**
     * Tag Storage
     */
    private short tagNumber;
    private byte tagClass;
    private byte tagSizeInBytes;
    boolean tagPC;
    private boolean emptyTag = true;

    /**
     * Constructor creates an empty <CODE>BERTLV</CODE> Tag object capable of
     * encapsulating a BER TLV Tag. All implementations must support at least 3
     * byte Tags which can encode tag numbers up to 0x3FFF.
     */
    protected BERTag() {
    }

    /**
     * Abstract init method. (Re-)Initialize
     * <code>this</code> <CODE>BERTag</CODE> object from the binary
     * representation in the byte array. All implementations must support tag
     * numbers up to 0x3FFF.
     * 
     * @param bArray
     *            the byte array containing the binary representation
     * @param bOff
     *            the offset within bArray where the tag binary begins
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access of data
     *                outside array bounds, or if the array offset parameter is
     *                negative
     * @exception java.lang.NullPointerException
     *                if <code>bArray</code> is <code>null</code>
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.ILLEGAL_SIZE</code> if the tag
     *                number requested is larger than the supported maximum size
     *                <li><code>TLVException.MALFORMED_TAG</code> if tag
     *                representation in the byte array is malformed
     *                </ul>
     */
    public abstract void init(byte[] bArray, short bOff) throws TLVException;

    /**
     * Create a <CODE>BERTLV</CODE> Tag object from the binary representation
     * in the byte array. All implementations must support tag numbers up to
     * 0x3FFF. Note that the returned <CODE>BERTag</CODE> must be cast to the
     * correct subclass: <code>PrimitiveBERTag</code> or
     * <code>ConstructedBERTag</code> to access their specialized API.
     * 
     * @param bArray
     *            the byte array containing the binary representation
     * @param bOff
     *            the offset within bArray where the tag binary begins
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access of data
     *                outside array bounds, or if the array offset parameter is
     *                negative
     * @exception java.lang.NullPointerException
     *                if <code>bArray</code> is <code>null</code>
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.ILLEGAL_SIZE</code> if the tag
     *                number requested is larger than the supported maximum size
     *                <li><code>TLVException.MALFORMED_TAG</code> if tag
     *                representation in the byte array is malformed.
     *                </ul>
     */
    public static BERTag getInstance(byte[] bArray, short bOff) throws TLVException {

        BERTag instance = null;

        // Check if malformed tag and check array parameters,
        // the following init() will check for ILLEGAL_SIZE.
        if (verifyFormatInternal(bArray, bOff) == MALFORMED_TAG_VALUE) {
            TLVException.throwIt(TLVException.MALFORMED_TAG);
        }

        if ((CONSTRUCTED_TAG & bArray[bOff]) != 0) {
            instance = new ConstructedBERTag();
            instance.init(bArray, bOff);
        } else {
            instance = new PrimitiveBERTag();
            instance.init(bArray, bOff);
        }

        return instance;
    }

    /**
     * Returns the byte size required to represent <code>this</code> tag
     * structure
     * 
     * @return size of BER Tag in bytes
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.TAG_SIZE_GREATER_THAN_127</code>
     *                if the size of the BER Tag is > 127.
     *                <li><code>TLVException.EMPTY_TAG</code> if the BER Tag
     *                is empty.
     *                </ul>
     */
    public byte size() throws TLVException {

        // Check if Empty tag, but size over 127 will not be checked here, since
        // This implementation only supports 3 bytes and the tag size is
        // verified
        // when initialized.
        if (emptyTag) {
            TLVException.throwIt(TLVException.EMPTY_TAG);
        }

        return tagSizeInBytes;
    }

    /**
     * Writes the representation of <code>this</code> BER tag structure to the
     * byte array
     * 
     * @param outBuf
     *            the byteArray where the BER tag is written
     * @param bOffset
     *            offset within outBuf where BER tag value starts
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the output array would cause access of data
     *                outside array bounds, or if the array offset parameter is
     *                negative
     * @exception java.lang.NullPointerException
     *                if <code>outBuf</code> is <code>null</code>
     * @return size of BER Tag in bytes
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.EMPTY_TAG</code> if the BER Tag
     *                is empty.
     *                </ul>
     */
    public short toBytes(byte[] outBuf, short bOffset) throws TLVException {

        if (emptyTag) {
            TLVException.throwIt(TLVException.EMPTY_TAG);
        }

        NativeMethods.checkArrayArgs(outBuf, bOffset, tagSizeInBytes);

        // set Tag Class
        outBuf[bOffset] = (byte) (tagClass << TAG_CLASS_SHIFT);

        // set P/C value
        if (tagPC == true) {
            outBuf[bOffset] |= CONSTRUCTED_TAG;
        }

        switch (tagSizeInBytes) {
            case (byte) 1:
                outBuf[bOffset] |= (byte) (tagNumber);
                break;
            case (byte) 2:
                outBuf[bOffset] |= MORE_THAN_ONE_BYTE_TAG_MASK;
                outBuf[(short) (bOffset + 1)] = (byte) (tagNumber);
                break;
            case (byte) 3:
                outBuf[bOffset] |= MORE_THAN_ONE_BYTE_TAG_MASK;
                outBuf[(short) (bOffset + 1)] = (byte) (((tagNumber >> 7) & TAG_MASK) | MORE_BYTES_CHECK);
                outBuf[(short) (bOffset + 2)] = (byte) (tagNumber & TAG_MASK);
                break;
            default:
                TLVException.throwIt(TLVException.ILLEGAL_SIZE);
        }

        return tagSizeInBytes;
    }

    /**
     * Returns the tag number part of <code>this</code> BER Tag structure
     * 
     * @return the BER Tag tag number
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.TAG_NUMBER_GREATER_THAN_32767</code>
     *                if the tag number is > 32767.
     *                <li><code>TLVException.EMPTY_TAG</code> if the BER Tag
     *                is empty.
     *                </ul>
     */
    public short tagNumber() throws TLVException {

        // Check if empty tag, but tag number is checked at initialization, so
        // will
        // never be > 32767.
        if (emptyTag) {
            TLVException.throwIt(TLVException.EMPTY_TAG);
        }

        return tagNumber;
    }

    /**
     * Used to query if <code>this</code> BER tag structure is constructed
     * 
     * @return <CODE>true</CODE> if constructed, <CODE>false</CODE> if
     *         primitive
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.EMPTY_TAG</code> if the BER Tag
     *                is empty.
     *                </ul>
     */
    public boolean isConstructed() {

        if (emptyTag) {
            TLVException.throwIt(TLVException.EMPTY_TAG);
        }

        // The tag will never be malformed if it has been created, since it
        // checks the format during init.

        return tagPC;
    }

    /**
     * Returns the tag class part of <code>this</code> BER Tag structure
     * 
     * @return the BER Tag class. One of the <CODE>BER_TAG_CLASS_MASK_*</CODE>..
     *         constants defined above, for example
     *         {@link #BER_TAG_CLASS_MASK_APPLICATION BER_TAG_CLASS_MASK_APPLICATION}.
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.EMPTY_TAG</code> if the BER Tag
     *                is empty.
     *                </ul>
     */
    public byte tagClass() {

        if (emptyTag) {
            TLVException.throwIt(TLVException.EMPTY_TAG);
        }

        return tagClass;
    }

    /**
     * Compares <code>this</code> BER Tag with another. Note that this method
     * does not throw exceptions. If the parameter <CODE>otherTag</CODE> is
     * <CODE>null</CODE>, the method returns <CODE>false</CODE>
     * 
     * @return <CODE>true</CODE> if the tag data encapsulated are equal,
     *         <CODE>false</CODE> otherwise
     */

    public boolean equals(BERTag otherTag) {

        if (otherTag == null) {
            return false;
        }

        return ((otherTag.tagClass() == tagClass) && (otherTag.isConstructed() == tagPC) && (otherTag.tagNumber() == tagNumber));

    }
    
    public boolean equals(Object otherTag) {

        if(!(otherTag instanceof BERTag)){
            return false;
        }

        return equals((BERTag)otherTag);
    }

    /**
     * Writes the BER Tag bytes representing the specified tag class,
     * constructed flag and the tag number as a BER Tag representation in the
     * specified byte array
     * 
     * @param tagClass
     *            encodes the tag class. Valid codes are the
     *            <CODE>BER_TAG_CLASS_MASK_*</CODE> constants defined above, for example
     *            {@link #BER_TAG_CLASS_MASK_APPLICATION BER_TAG_CLASS_MASK_APPLICATION}.
     * @param isConstructed
     *            true if the tag is constructed, false if primitive
     * @param tagNumber
     *            is the tag number.
     * @param outArray
     *            output byte array
     * @param bOff
     *            offset within byte array containing first byte
     * @return size of BER Tag output bytes
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the output array would cause access of data
     *                outside array bounds, or if the array offset parameter is
     *                negative
     * @exception java.lang.NullPointerException
     *                if <code>outArray</code> is <code>null</code>
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.ILLEGAL_SIZE</code> if the tag
     *                size is larger than the supported maximum size or 32767
     *                <li><code>TLVException.INVALID_PARAM</code> if
     *                <code>tagClass</code> parameter is invalid or if the
     *                <code>tagNumber</code> parameter is negative
     *                </ul>
     */
    public static short toBytes(short tagClass, boolean isConstructed, short tagNumber, byte[] outArray, short bOff) {

        short thisTagSizeInBytes = 0;

        if ((tagClass < 0) || (tagClass > 3) || (tagNumber < 0)) {
            TLVException.throwIt(TLVException.INVALID_PARAM);
        }

        if (tagNumber <= ONE_BYTE_TAG_MAX) {
            NativeMethods.checkArrayArgs(outArray, bOff, (short) 1);
            thisTagSizeInBytes = 1;
            outArray[bOff] = (byte) (tagNumber);
        } else if (tagNumber <= TWO_BYTE_TAG_MAX) {
            NativeMethods.checkArrayArgs(outArray, bOff, (short) 2);
            thisTagSizeInBytes = 2;
            outArray[bOff] = MORE_THAN_ONE_BYTE_TAG_MASK;
            outArray[(short) (bOff + 1)] = (byte) (tagNumber);
        } else if (tagNumber <= THREE_BYTE_TAG_MAX) {
            NativeMethods.checkArrayArgs(outArray, bOff, (short) 3);
            thisTagSizeInBytes = 3;
            outArray[bOff] = MORE_THAN_ONE_BYTE_TAG_MASK;
            outArray[(short) (bOff + 1)] = (byte) (((tagNumber >> 7) & TAG_MASK) | MORE_BYTES_CHECK);
            outArray[(short) (bOff + 2)] = (byte) (tagNumber & TAG_MASK);
        } else {
            TLVException.throwIt(TLVException.ILLEGAL_SIZE);
        }

        // set Tag Class
        outArray[bOff] |= (byte) ((byte) tagClass << TAG_CLASS_SHIFT);

        // set P/C value
        if (isConstructed == true) {
            outArray[bOff] |= CONSTRUCTED_TAG;
        }

        return thisTagSizeInBytes;
    }

    /**
     * Returns the byte size required to represent the BER Tag from its
     * representation in the specified byte array
     * 
     * @param berTagArray
     *            input byte array containing the BER Tag representation
     * @param bOff
     *            offset within byte array containing first byte
     * @return size of BER Tag in bytes
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access of data
     *                outside array bounds, or if the array offset parameter is
     *                negative
     * @exception java.lang.NullPointerException
     *                if <code>berTagArray</code> is <code>null</code>
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.ILLEGAL_SIZE</code> if the size
     *                of the BER Tag is greater than the maximum Tag size
     *                supported
     *                <li><code>TLVException.TAG_SIZE_GREATER_THAN_127</code>
     *                if the size of the BER Tag is > 127.
     *                <li><code>TLVException.MALFORMED_TAG</code> if tag
     *                representation in the byte array is malformed
     *                </ul>
     */
    public static byte size(byte[] berTagArray, short bOff) throws TLVException {

        short tempNumber = verifyFormatInternal(berTagArray, bOff);

        if (tempNumber == MALFORMED_TAG_VALUE) {
            TLVException.throwIt(TLVException.MALFORMED_TAG);
        } else if (tempNumber == ILLEGAL_SIZE_VALUE) {
            TLVException.throwIt(TLVException.ILLEGAL_SIZE);
        }

        return (byte) getTagSize(tempNumber);
    }

    /**
     * Returns the tag number part of the BER Tag from its representation in the
     * specified byte array
     * 
     * @param berTagArray
     *            input byte array
     * @param bOff
     *            offset within byte array containing first byte
     * @return the BER Tag tag number
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access of data
     *                outside array bounds, or if the array offset parameter is
     *                negative
     * @exception java.lang.NullPointerException
     *                if <code>berTagArray</code> is <code>null</code>
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.ILLEGAL_SIZE</code> if the size
     *                of the BER Tag is greater than the maximum Tag size
     *                supported
     *                <li><code>TLVException.TAG_NUMBER_GREATER_THAN_32767</code>
     *                if the tag number is > 32767.
     *                <li><code>TLVException.MALFORMED_TAG</code> if tag
     *                representation in the byte array is malformed.
     *                </ul>
     */
    public static short tagNumber(byte[] berTagArray, short bOff) throws TLVException {

        short tempNumber;

        tempNumber = verifyFormatInternal(berTagArray, bOff);

        if (tempNumber == MALFORMED_TAG_VALUE) {
            TLVException.throwIt(TLVException.MALFORMED_TAG);
        } else if (tempNumber == ILLEGAL_SIZE_VALUE) {
            TLVException.throwIt(TLVException.ILLEGAL_SIZE);
        }

        return tempNumber;

    }

    /**
     * Returns the constructed flag part of the BER Tag from its representation
     * in the specified byte array
     * 
     * @param berTagArray
     *            input byte array
     * @param bOff
     *            offset within byte array containing first byte
     * @return <CODE>true</CODE> if constructed, <CODE>false</CODE> if
     *         primitive
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access of data
     *                outside array bounds, or if the array offset parameter is
     *                negative
     * @exception java.lang.NullPointerException
     *                if <code>berTagArray</code> is <code>null</code>
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.MALFORMED_TAG</code> if tag
     *                representation in the byte array is malformed.
     *                </ul>
     */
    public static boolean isConstructed(byte[] berTagArray, short bOff) {

        short tempNumber = verifyFormatInternal(berTagArray, bOff);

        if (tempNumber == MALFORMED_TAG_VALUE) {
            TLVException.throwIt(TLVException.MALFORMED_TAG);
        }

        return ((CONSTRUCTED_TAG & berTagArray[bOff]) != 0);

    }

    /**
     * Returns the tag class part of the BER Tag from its representation in the
     * specified byte array
     * 
     * @param berTagArray
     *            input byte array
     * @param bOff
     *            offset within byte array containing first byte
     * @return the BER Tag class. One of the <CODE>BER_TAG_CLASS_MASK_*</CODE>..
     *         constants defined above, for example
     *         {@link #BER_TAG_CLASS_MASK_APPLICATION BER_TAG_CLASS_MASK_APPLICATION}.
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access of data
     *                outside array bounds, or if the array offset parameter is
     *                negative
     * @exception java.lang.NullPointerException
     *                if <code>berTagArray</code> is <code>null</code>
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.MALFORMED_TAG</code> if tag
     *                representation in the byte array is malformed.
     *                </ul>
     */
    public static byte tagClass(byte[] berTagArray, short bOff) {

        short tempNumber = verifyFormatInternal(berTagArray, bOff);

        if (tempNumber == MALFORMED_TAG_VALUE) {
            TLVException.throwIt(TLVException.MALFORMED_TAG);
        } else if (tempNumber == ILLEGAL_SIZE_VALUE) {
            TLVException.throwIt(TLVException.ILLEGAL_SIZE);
        }

        return (byte) ((berTagArray[bOff] >> TAG_CLASS_SHIFT) & TAG_CLASS_MASK);

    }

    /**
     * Checks if the input data is a well-formed BER Tag representation
     * 
     * @param berTagArray
     *            input byte array
     * @param bOff
     *            offset within byte array containing first byte
     * @return <CODE>true</CODE> if input data is a well formed BER Tag
     *         structure of tag size equal to or less than the supported maximum
     *         size, <CODE>false</CODE> otherwise
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access of data
     *                outside array bounds, or if the array offset parameter is
     *                negative
     * @exception java.lang.NullPointerException
     *                if <code>berTagArray</code> is <code>null</code>
     */
    public static boolean verifyFormat(byte[] berTagArray, short bOff) {

        if (verifyFormatInternal(berTagArray, bOff) < 0) {
            return false;
        } else {
            return true;
        }

    }

    /* Internal version of verifyFormat. Rather than returning a boolean,
     * it will return a negative error code if not a well formed tag. 
     * returns the tag number if it is a well formed tag.
     * @param bArray input byte array
     * @param bOff offset
     */
    static short verifyFormatInternal(byte[] bArray, short bOff) throws TLVException {

        short tNumber;

        /*
         * To determine the number of bytes in <code>this</code> tag, we must:
         * In the first byte, check to see if bits 1 through 5 are set, if yes,
         * this is at least a 2 byte tag, if no, this is a 1 byte tag. If, we
         * determining that this tag is larger thay 1 byte, bit 8 is checked in byte 2.
         * If bit 8  is set, this is at least a 3 byte tag. If, in byte 3, bit 8
         * set as well, this tag is more than 3 bytes long and is too large for this 
         * implementation,  since this impementation only supports up tp 3 byte tags.
         */
        NativeMethods.checkArrayArgs(bArray, bOff, (short) 1);

        if ((bArray[bOff] & MORE_THAN_ONE_BYTE_TAG_MASK) == MORE_THAN_ONE_BYTE_TAG_MASK) {
            NativeMethods.checkArrayArgs(bArray, bOff, (short) 2);
            if ((bArray[(short) (bOff + 1)] & MORE_BYTES_CHECK) != 0) {
                NativeMethods.checkArrayArgs(bArray, bOff, (short) 3);
                if ((bArray[(short) (bOff + 2)] & MORE_BYTES_CHECK) != 0) {
                    return ILLEGAL_SIZE_VALUE;
                }
                tNumber = ((short) ((bArray[(short) (bOff + 1)] & TAG_MASK) << 7));
                tNumber |= ((short) (bArray[(short) (bOff + 2)] & TAG_MASK));
                // check to make sure that the tag is less than 127, if not, tag
                // is malformed.

                if (tNumber <= TWO_BYTE_TAG_MAX) {
                    return MALFORMED_TAG_VALUE;
                }
            } else {
                tNumber = (short) (bArray[(short) (bOff + 1)] & TAG_MASK);
                // check to make sure that the tag is <= to 30, if not, tag is
                // malformed.
                if (tNumber <= ONE_BYTE_TAG_MAX) {
                    return MALFORMED_TAG_VALUE;
                }

            }
        } else {
            tNumber = (short) (bArray[bOff] & MORE_THAN_ONE_BYTE_TAG_MASK);
        }

        return tNumber;
    }

    static short getTagSize(short tagNum) throws TLVException {
        short tagSize = 0;

        if (tagNum <= ONE_BYTE_TAG_MAX) {
            tagSize = 1;
        } else if (tagNum <= TWO_BYTE_TAG_MAX) {
            tagSize = 2;
        } else if (tagNum <= THREE_BYTE_TAG_MAX) {
            tagSize = 3;
        } else {
            TLVException.throwIt(TLVException.ILLEGAL_SIZE);
        }

        return tagSize;
    }

    void sharedInit(byte tagClassIn, short tagNumberIn) throws TLVException {

        if (tagClassIn < 0 || tagClassIn > 3) {
            TLVException.throwIt(TLVException.INVALID_PARAM);
        }

        tagSizeInBytes = (byte) getTagSize(tagNumberIn);

        tagClass = tagClassIn;
        tagNumber = tagNumberIn;
        emptyTag = false;
    }
}
