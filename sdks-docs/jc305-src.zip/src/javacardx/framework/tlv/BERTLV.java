/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package javacardx.framework.tlv;

import javacard.framework.Util;

import com.sun.javacard.impl.NativeMethods;

/**
 * The abstract <code>BERTLV</code> class encapsulates a BER TLV structure.
 * The rules on the allowed encoding of the Tag, length and value fields are
 * based on the ASN.1 BER encoding rules ISO/IEC 8825-1:2002.
 * <p>
 * The <CODE>BERTLV</CODE> class and the subclasses -
 * <CODE>ConstructedBERTLV</CODE> and <CODE>PrimitiveBERTLV</CODE> only
 * support encoding of the length(L) octets in definite form. These classes do
 * not provide support for the encoding rules of the contents octets of the
 * value(V) field as described in ISO/IEC 8825-1:2002.
 * <p>
 * The <CODE>BERTLV</CODE> class and the subclasses -
 * <CODE>ConstructedBERTLV</CODE> and <CODE>PrimitiveBERTLV</CODE> also
 * provide static methods to parse/edit a TLV structure representation in a byte
 * array.
 * 
 * @since 2.2.2
 */

public abstract class BERTLV {

    // Constants used within the TLV package
    static final byte PRIMITIVE_TLV = (byte) 0x00;
    static final byte CONSTRUCTED_TLV = (byte) 0x20;
    static final byte MORE_BYTES_CHECK = (byte) 0x80;
    static final byte LENGTH_VALUE_MASK = (byte) 0x7f;
    static final byte TAG_MASK = 0x1f;
    static final byte EXTENDED_FORMAT = (byte) 0x80;
    static final byte INDEFINITE_FORMAT = (byte) 0x80;
    static final byte MAX_TAG_SIZE = 3;
    static final byte MAX_ONE_BYTE_LENGTH = 127;
    //static final short MAX_TLV_SIZE = 32767;
    static final byte FIRST_BYTE_LONG_LENGTH = (byte) 0x82;
    static final byte TLV_ARRAY_EXPANSION_INCREMENT = (byte) 0x08;
    static final byte VALUE_INCREMENT = (byte) 0x04;
    static final byte APPEND = 1;
    static final byte REPLACE = 2;

    // error if length is malformed
    static final byte MALFORMED_LENGTH = -3;

    // error if length would cause access beyond array length
    static final byte LENGTH_NOT_IN_LIMITS = -4;
    // The tag for <code>this</code> TLV
    BERTag theBERTag = null;

    // berTLV is used if <code>this</code> is instantiated as a contructed TLV.
    BERTLV[] berTLV = null;

    // The number of TLVs in <code>this</code> constructed TLV.
    short numTLVs;

    // The number of TLVs that have been deleted from <code>this</code> TLV.
    short numDeletedTLVs;

    // theValue is used if <code>this</code> is a primitive TLV.
    byte[] theValue = null;

    // The value length of <code>this</code> constructed TLV.
    short valueLength;

    // Flag to indicate if <code>this</code> TLV has been initialized.
    boolean emptyTLV;

    /**
     * Constructor creates an empty <CODE>BERTLV</CODE> object capable of
     * encapsulating a BER TLV structure.
     */
    protected BERTLV() {
    }

    /**
     * Abstract init method. (Re-)Initializes
     * <code>this</code> <CODE>BERTLV</CODE> using the input byte data.
     * <p>
     * The capacity of <code>this</code> <CODE>BERTLV</CODE> is increased, 
     * if required and supported, based on the size of the 
     * input TLV data structure.
     * <p>
     * Note:
     * <ul>
     * <li><em>If </em><code>bOff+bLen</code><em> is greater than </em><code>bArray.length</code><em>, the length
     * of the </em><code>bArray</code><em> array, an </em><code>ArrayIndexOutOfBoundsException</code><em> exception is thrown.</em>
     * </ul>
     * 
     * @param bArray
     *            input byte array
     * @param bOff
     *            offset within byte array containing the TLV data
     * @param bLen
     *            byte length of input data
     * @return the resulting size of <code>this</code> TLV if represented in
     *         bytes
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access of data
     *                outside array bounds, or if the array offset or array
     *                length parameter is negative
     * @exception java.lang.NullPointerException
     *                if <code>bArray</code> is <code>null</code>
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.INSUFFICIENT_STORAGE</code> if
     *                the required capacity is not available and the
     *                implementation does not support automatic expansion.
     *                <li><code>TLVException.MALFORMED_TLV</code> if the
     *                input data is not a well-formed BER TLV or the input data
     *                represents a primitive BER TLV structure and
     *                <code>this</code> is a <code>ConstructedBERTLV</code>
     *                object or the input data represents a constructed BER TLV
     *                structure and <code>this</code> is a
     *                <code>PrimiitveBERTLV</code> object.
     *                </ul>
     */
    public abstract short init(byte[] bArray, short bOff, short bLen) throws TLVException;

    /**
     * Creates the <CODE>BERTLV</CODE> using the input binary data. The
     * resulting BER TLV object may be a primitive or a constructed TLV object.
     * The object must be cast to the correct sub-class:
     * <code>ConstructedBERTLV</code> or <code>PrimitiveBERTLV</code> to
     * access the specialized API. The
     * <code>init( byte[] bArray, short bOff, short bLen )</code> methods of
     * the appropriate <CODE>BERTLV</CODE> classes will be used to initialize
     * the created TLV object.
     * <p>
     * Note:
     * <ul>
     * <li><em>If </em><code>bOff+bLen</code><em> is greater than </em><code>bArray.length</code><em>, the length
     * of the </em><code>bArray</code><em> array, an </em><code>ArrayIndexOutOfBoundsException</code><em> exception is thrown.</em>
     * </ul>
     * 
     * @param bArray
     *            input byte array
     * @param bOff
     *            offset within byte array containing the tlv data
     * @param bLen
     *            byte length of input data
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access of data
     *                outside array bounds, or if the array offset or array
     *                length parameter is negative
     * @exception java.lang.NullPointerException
     *                if <code>bArray</code> is <code>null</code>
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.ILLEGAL_SIZE</code> if the TLV
     *                structure requested is larger than the supported maximum
     *                size
     *                <li><code>TLVException.MALFORMED_TLV</code> if the
     *                input data is not a well-formed BER TLV.
     *                </ul>
     */
    public static BERTLV getInstance(byte[] bArray, short bOff, short bLen) throws TLVException {

        BERTLV instance = null;

        NativeMethods.checkArrayArgs(bArray, bOff, bLen);

        /*if (bLen > MAX_TLV_SIZE) {
            TLVException.throwIt(TLVException.ILLEGAL_SIZE);
        }*/

        if (!verifyFormat(bArray, bOff, bLen)) {
            TLVException.throwIt(TLVException.MALFORMED_TLV);
        }

        if ((bArray[bOff] & CONSTRUCTED_TLV) != 0) {
            instance = new ConstructedBERTLV(TLV_ARRAY_EXPANSION_INCREMENT);
            instance.init(bArray, bOff, bLen);
        } else {
            instance = new PrimitiveBERTLV(bLen);
            instance.init(bArray, bOff, bLen);
        }

        return instance;

    }

    /**
     * Writes <code>this</code> TLV structure to the specified byte array.
     * 
     * @param outBuf
     *            output byte array
     * @param bOff
     *            offset within byte array output data begins
     * @return the byte length written to the output array
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the output array would cause access of data
     *                outside array bounds, or if the array offset parameter is
     *                negative
     * @exception java.lang.NullPointerException
     *                if <code>outBuf</code> is <code>null</code>
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.TLV_SIZE_GREATER_THAN_32767</code>
     *                if the size of the BER TLV is > 32767.
     *                <li><code>TLVException.EMPTY_TLV</code> if the
     *                <CODE>BERTLV</CODE> object is empty.
     *                </ul>
     */
    public short toBytes(byte[] outBuf, short bOff) {

        if (emptyTLV) {
            TLVException.throwIt(TLVException.EMPTY_TLV);
        }

        short valueLen = this.getLength();
        short totalLength = (short) (theBERTag.size() + valueLen + BERTLV.getValueLengthSize(valueLen));
        NativeMethods.checkArrayArgs(outBuf, bOff, valueLen);

        if (totalLength < (short)0) {
            TLVException.throwIt(TLVException.TLV_SIZE_GREATER_THAN_32767);
        }

        // put tag in output buffer
        short valueOffset = (short) (bOff + theBERTag.toBytes(outBuf, bOff));

        // put length in output buffer
        if (valueLen > MAX_ONE_BYTE_LENGTH) {
            outBuf[valueOffset] = FIRST_BYTE_LONG_LENGTH;
            valueOffset += (short) 3;
            Util.setShort(outBuf, valueOffset, valueLen);
        } else {
            outBuf[valueOffset] = (byte) valueLen;
            valueOffset++;
        }

        // put the value in the output buffer
        if (theBERTag.isConstructed()) {
            for (short i = 0; i < numTLVs; i++) {
                if (berTLV[i] != null) {
                    valueOffset += berTLV[i].toBytes(outBuf, valueOffset);
                }
            }
            return (short) (valueOffset - bOff);
        } else {
            Util.arrayCopy(theValue, (short) 0, outBuf, valueOffset, valueLen);
            return (short) (valueOffset + valueLen - bOff);
        }

    }

    /**
     * Returns <code>this</code> value of the TLV object's Tag component
     * 
     * @return the Tag for <code>this</code> <CODE>BERTLV</CODE> object
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.EMPTY_TLV</code> if the
     *                <CODE>BERTLV</CODE> object is empty.
     *                </ul>
     */
    public BERTag getTag() throws TLVException {

        if (emptyTLV) {
            TLVException.throwIt(TLVException.EMPTY_TLV);
        }

        return theBERTag;
    }

    /**
     * Returns the value of <code>this</code> TLV object's Length component
     * 
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.TLV_LENGTH_GREATER_THAN_32767</code>
     *                if the value of the Length component is > 32767.
     *                <li><code>TLVException.EMPTY_TLV</code> if the
     *                <CODE>BERTLV</CODE> object is empty.
     *                </ul>
     */
    public short getLength() throws TLVException {

        short valueLen = 0;
        if (emptyTLV) {
            TLVException.throwIt(TLVException.EMPTY_TLV);
        }

        if (theBERTag.isConstructed()) {
            // false parameter here indicates this is not a contained
            // constructed tlv
            valueLen = getLengthInternal(false);
        } else {
            valueLen = valueLength;
        }

        if ((short) (theBERTag.size() + valueLen + BERTLV.getValueLengthSize(valueLen)) < (short)0) {
            TLVException.throwIt(TLVException.TLV_SIZE_GREATER_THAN_32767);
        }

        return valueLen;
    }

    /**
     * Returns the number of bytes required to represent <code>this</code> TLV
     * structure
     * 
     * @return the byte length of the TLV
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.TLV_SIZE_GREATER_THAN_32767</code>
     *                if the size of TLV structure is > 32767.
     *                <li><code>TLVException.EMPTY_TLV</code> if the
     *                <CODE>BERTLV</CODE> object is empty.
     *                </ul>
     */
    public short size() {

        short valueLen = 0;

        if (emptyTLV) {
            TLVException.throwIt(TLVException.EMPTY_TLV);
        }

        if (theBERTag.isConstructed()) {
            valueLen = this.getLength();
        } else {
            valueLen = valueLength;
        }

        valueLen = (short) (theBERTag.size() + valueLen + BERTLV.getValueLengthSize(valueLen));

        if (valueLen < (short)0) {
            TLVException.throwIt(TLVException.TLV_SIZE_GREATER_THAN_32767);
        }

        return valueLen;
    }

    /**
     * Checks if the input data is a well-formed BER TLV representation.
     * <p>
     * Note:
     * <ul>
     * <li><em>If </em><code>bOff+bLen</code><em> is greater than </em><code>berTlvArray.length</code><em>, the length
     * of the </em><code>berTlvArray</code><em> array, an </em><code>ArrayIndexOutOfBoundsException</code><em> exception is thrown.</em>
     * </ul>
     * 
     * @param berTlvArray
     *            input byte array
     * @param bOff
     *            offset within byte array containing first byte
     * @param bLen
     *            byte length of input BER TLV data
     * @return <CODE>true</CODE> if input data is a well formed BER TLV
     *         structure, <CODE>false</CODE> otherwise
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access of data
     *                outside array bounds, or if the array offset or array
     *                length parameter is negative
     * @exception java.lang.NullPointerException
     *                if <code>berTlvArray</code> is <code>null</code>
     */
    public static boolean verifyFormat(byte[] berTlvArray, short bOff, short bLen) {

        try {
            if (verifyFormatInternal(berTlvArray, bOff, bLen) < 0) {
                return false;
            } else {
                return true;
            }
        } catch (TLVException e) {
            return false;
        }

    }

    /*
     * An internal verifyFormat that will return the number of contained TLVs if <code>this</code> is
     * a constructed TLV, or will return 1 less than the number of TLVs contained in an
     * array of TLVs to be used to initialize a constructed TLV.
     * This is wrapped by the public version, since the public version returns a boolean
     * true or false depending on if the TLV is well formed or not. Internally, it is usefull
     * to return the number of TLVs contained at the highest level of a constructed TLV.
     * Will return MALFORMED_TAG_VALUE if malformed tag, ILLEGAL_SIZE_VALUE 
     * if illegal length, MALFORMED_LENGTH malformed length.
     */
    static short verifyFormatInternal(byte[] berTlvArray, short bOff, short bLen) {

        short nextTagLengthOffSet;
        short numTlv = 0;

        NativeMethods.checkArrayArgs(berTlvArray, bOff, bLen);

        nextTagLengthOffSet = bOff;

        // A tlv can never be less than 2 bytes, so it is malformed if it is
        if (bLen < 2) {
            return MALFORMED_LENGTH;
        }
        short firstValueLen = BERTLV.getLength(berTlvArray, nextTagLengthOffSet);
        getValueOffsetInternal(berTlvArray, nextTagLengthOffSet);

        if (firstValueLen == 1 && BERTag.isConstructed(berTlvArray, bOff)) {
            // Can't have a valid constructed tlv with a value of 1
            return MALFORMED_LENGTH;
        }

        if ((bLen == 2) && (firstValueLen > 0)) {
            return MALFORMED_LENGTH;
        }

        while (nextTagLengthOffSet < (short) (bLen + bOff)) {
            // while (nextTagLengthOffSet < (short)(firstValueLen +
            // firstValueOffset)) {
            if (BERTag.isConstructed(berTlvArray, nextTagLengthOffSet)) {
                // get first Tag and Length and verify
                short intValueLen = BERTLV.getLength(berTlvArray, nextTagLengthOffSet);
                if (intValueLen == 1) {
                    // Can't have a valid constructed tlv with a value of 1
                    return MALFORMED_LENGTH;
                }
                nextTagLengthOffSet = verifyTagAndLength(berTlvArray, nextTagLengthOffSet);
                if (nextTagLengthOffSet < 0) {
                    return nextTagLengthOffSet;
                } else if ((short) (bLen + bOff) < nextTagLengthOffSet) {
                    return MALFORMED_LENGTH;
                }
                short intOffSet = nextTagLengthOffSet;
                // Will verify, but not count all tags and lengths within
                // contained constructed TLVs
                if ((short) (bLen + bOff) != (short) (nextTagLengthOffSet + firstValueLen)) {
                    while (nextTagLengthOffSet < (short) (intValueLen + intOffSet)) {
                        nextTagLengthOffSet = verifyTagAndLength(berTlvArray, nextTagLengthOffSet);
                        if (nextTagLengthOffSet < 0) {
                            return nextTagLengthOffSet;
                        } else if ((short) (bLen + bOff) < nextTagLengthOffSet) {
                            return MALFORMED_LENGTH;
                        }
                    }
                }
            } else {
                nextTagLengthOffSet = verifyTagAndLength(berTlvArray, nextTagLengthOffSet);
                if (nextTagLengthOffSet < 0) {
                    return nextTagLengthOffSet;
                } else if ((short) (bLen + bOff) < nextTagLengthOffSet) {
                    return MALFORMED_LENGTH;
                }
            }
            numTlv++;
        }
        return (short) (numTlv - (short) 1);
    }

    /**
     * Copies the tag component in the TLV representation in the specified input
     * byte array to the specified output byte array
     * 
     * @param berTLVArray
     *            input byte array
     * @param bTLVOff
     *            offset within byte array containing the tlv data
     * @param berTagArray
     *            output Tag byte array
     * @param bTagOff
     *            offset within byte array where output begins
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input or output array would cause access
     *                of data outside array bounds, or if either array offset
     *                parameter is negative
     * @exception java.lang.NullPointerException
     *                if either <code>berTLVArray</code> or
     *                <code>berTagArray</code> is <code>null</code>
     * @return the size of the output BER Tag
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.ILLEGAL_SIZE</code> if the size
     *                of the Tag component is > 32767.
     *                <li><code>TLVException.MALFORMED_TLV</code> if the
     *                input data is not a well-formed BER TLV.
     *                </ul>
     */
    public static short getTag(byte[] berTLVArray, short bTLVOff, byte[] berTagArray, short bTagOff)
            throws TLVException {

        NativeMethods.checkArrayArgs(berTLVArray, bTLVOff, (short) (berTLVArray.length - bTLVOff));
        NativeMethods.checkArrayArgs(berTagArray, bTagOff, (short) (berTagArray.length - bTagOff));
        // Check for malformed tag or tag that is too long
        short retStatus = verifyTagAndLength(berTLVArray, bTLVOff);

        if (retStatus == BERTag.MALFORMED_TAG_VALUE) {
            TLVException.throwIt(TLVException.MALFORMED_TLV);
        } else if (retStatus == BERTag.ILLEGAL_SIZE_VALUE) {
            TLVException.throwIt(TLVException.ILLEGAL_SIZE);
        } else if (retStatus == MALFORMED_LENGTH) {
            TLVException.throwIt(TLVException.MALFORMED_TLV);
        } else if (retStatus == LENGTH_NOT_IN_LIMITS) {
            TLVException.throwIt(TLVException.MALFORMED_TLV);
        }

        // Now that the tlv has been verified, get the tag value
        berTagArray[bTagOff] = berTLVArray[bTLVOff];
        short tagSizeInBytes = 1;

        if ((berTLVArray[bTLVOff] & TAG_MASK) == TAG_MASK) {
            berTagArray[(short) (bTagOff + tagSizeInBytes)] = berTLVArray[(short) (bTLVOff + tagSizeInBytes)];
            tagSizeInBytes++;
            if ((berTLVArray[(short) (bTLVOff + tagSizeInBytes - 1)] & MORE_BYTES_CHECK) == MORE_BYTES_CHECK) {
                berTagArray[(short) (bTagOff + tagSizeInBytes)] = berTLVArray[(short) (bTLVOff + tagSizeInBytes)];
                tagSizeInBytes++;
            }
        }

        return tagSizeInBytes;
    }

    /**
     * Returns the value of the TLV Structure's Length component in the
     * specified input byte array
     * 
     * @param berTLVArray
     *            input byte array
     * @param bOff
     *            offset within byte array containing the tlv data
     * @return the length value in the TLV representation in the specified byte
     *         array
     * @exception java.lang.ArrayIndexOutOfBoundsException
     *                if accessing the input array would cause access of data
     *                outside array bounds, or if the array offset parameter is
     *                negative
     * @exception java.lang.NullPointerException
     *                if <code>berTLVArray</code>
     * @exception TLVException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>TLVException.TLV_LENGTH_GREATER_THAN_32767</code>
     *                if the length element(L) > 32767.
     *                <li><code>TLVException.MALFORMED_TLV</code> if the
     *                input data is not a well-formed BER TLV.
     *                </ul>
     */
    public static short getLength(byte[] berTLVArray, short bOff) throws TLVException {

        short offSet;
        short i;
        short valueLen;

        NativeMethods.checkArrayArgs(berTLVArray, bOff, (short) (berTLVArray.length - bOff));

        // Verify tag and length format
        offSet = verifyTagAndLength(berTLVArray, bOff);

        // If MALFORMED_TAG_VALUE returned, the tag is malformed,
        // if ILLEGAL_SIZE_VALUE is returned, length is too long,
        // MALFORMED_LENGTH
        // is returned, the length is malformed.
        if (offSet == BERTag.MALFORMED_TAG_VALUE) {
            TLVException.throwIt(TLVException.MALFORMED_TLV);
        } else if (offSet == BERTag.ILLEGAL_SIZE_VALUE) {
            TLVException.throwIt(TLVException.TLV_LENGTH_GREATER_THAN_32767);
        } else if (offSet == MALFORMED_LENGTH) {
            TLVException.throwIt(TLVException.MALFORMED_TLV);
        } else if (offSet == LENGTH_NOT_IN_LIMITS) {
            // force java.lang.ArrayIndexOutOfBoundsException since length of
            // value more than
            // can be contained in this array.
            NativeMethods.checkArrayArgs(berTLVArray, bOff, (short) (berTLVArray.length + 1));
        }

        // Get offset to the Length value
        offSet = getLengthOffset(berTLVArray, bOff);

        // now get and return the length, already verified that the length value
        // is ok
        if ((berTLVArray[(offSet)] & EXTENDED_FORMAT) == EXTENDED_FORMAT) {
            short sizeOfLength = (short) ((berTLVArray[offSet] & LENGTH_VALUE_MASK) + (byte) 1);
            if (sizeOfLength > 2) {
                valueLen = Util.getShort(berTLVArray, (short) (offSet + sizeOfLength - 2));
            } else {
                // In 2 byte sizeOfLength, the second byte is always length
                // value
                valueLen = (short) (berTLVArray[(short) (offSet + 1)] & (short) 0x00ff);
            }
        } else {
            valueLen = (berTLVArray[(offSet)]);
        }

        return valueLen;

    }

    /* method to get the size in bytes of the value length for an instance of 
     * BERTLV when the tlv is represented in a byte array. Since there is no rule
     * that the value length must be represented in the shortest form possible,
     * this implementation will return a size of 1 if the value length is < 127.
     * It will return a size of 3, for all value lengths between 128 and 32,767.
     * @param valueLength This is the length of the value, which is to be checked
     * for it's size.
     */
    static short getValueLengthSize(short valueLength) {
        return (valueLength < 127 ? (short) 1 : (short) 3);
    }

    /* method to get offset to the value or length portion of a TLV, given the offset to the start 
     * of a TLV. This assumes the format and size have been verified as supported.
     * @param berTLVArray - The array containing the tlv.
     * @param bOff - the offset in the array where the tag & length to be verified starts.
     * return offset to the Length in <code>this</code> TLV.
     */
    static short getLengthOffset(byte[] berTlvArray, short bOff) {

        short offSet;

        // Get offset to the Length value
        if ((berTlvArray[bOff] & TAG_MASK) == TAG_MASK) {
            if ((berTlvArray[(short) (bOff + BERTag.TAG_BYTE_ONE)] & MORE_BYTES_CHECK) == MORE_BYTES_CHECK) {
                offSet = (short) (BERTag.TAG_BYTE_THREE + bOff);
            } else {
                offSet = (short) (BERTag.TAG_BYTE_TWO + bOff);
            }
        } else {
            offSet = (short) (BERTag.TAG_BYTE_ONE + bOff);
        }

        return offSet;

    }

    /* This internal version of getValueOffset does not check parameters. It assumes
     * parameters have already been checked. This is done to avoid rechecking paramters
     * internally with checkArrayArgs.
     * @param berTlvArray The array containing the TLV.
     * @param bOff the offset where the tlv starts.
     * return the offset of the value.
     */
    static short getValueOffsetInternal(byte[] berTlvArray, short bOff) {

        short offSet = getLengthOffset(berTlvArray, bOff);

        if ((berTlvArray[(offSet)] & EXTENDED_FORMAT) == EXTENDED_FORMAT) {
            return (short) ((short) ((berTlvArray[offSet] & LENGTH_VALUE_MASK) & 0x00ff) + offSet + 1);
        } else {
            return (short) (offSet + 1);
        }

    }

    /* Used to get the size of the length component of a TLV in the supplied array.
     * @param berTLVArray -  the array containing the tlv.
     * @param bOff -  the offset where the tlv starts.
     * return - the size of the length component of the supplied tlv.
     */
    static short getSizeOfLength(byte[] berTLVArray, short bOff) {
        short returnSize = 0;
        // Get offset to the Length value
        short offSet = getLengthOffset(berTLVArray, bOff);

        // now get and return the size of length, already verified that the
        // length value is ok
        if ((berTLVArray[(offSet)] & EXTENDED_FORMAT) == EXTENDED_FORMAT) {
            // If this is extended format, the size of the remaining length is
            // found in the
            // last 5 bits of the first byte. Add one to this value for total
            // size.
            returnSize = (short) ((berTLVArray[offSet] & LENGTH_VALUE_MASK) + (byte) 1);
        } else {
            returnSize = (short) 1;
        }

        return returnSize;
    }

    /* This method will verify the format of a tag and length, If the format
     * is ok, it will return  the offset to the next tag and length in a constructed
     * TLV or the offset to the end of the data value, if <code>this</code> is a primitive tlv
     * If it is a contained constructed TLV, returnEndValueOff will indicate that
     * the end of <code>this</code> contained TLV is to be returned.
     * This allows for verifying of all tag and length values within a constructed
     * or primitive TLV. If the tag format is found to be malformed, it will return MALFORMED_TAG_VALUE. 
     * If the tag value is too large, will return ILLEGAL_SIZE_VALUE. If the length is malformed, return
     * MALFORMED_LENGTH. This method assumes that the array parameters have already been verified.
     * @param berTLVArray - The array containing the tlv.
     * @param bOff - the offset in the array where the tag & length to be verified starts.
     * @param bLen - the Length of the remaining portion of the TLV if this tag and length
     * value is within a constructed tlv. It is the total length of the tlv if it
     * is the first tag and length within a constructed TLV or it is a primitive TLV.
     * @return the offset to the next tag and length in a constructed tlv or the offset
     * to the end of the data value if <code>this</code> is a primitive tlv. A negative return value
     * as noted above, if a value is malformed or length value is too large.
     */

    static short verifyTagAndLength(byte[] berTlvArray, short bOff) {

        short sizeOfLength;
        short tagNumber;
        short tlvLength;
        short offSet = 0;
        short i;

        // Verify the Tag is well formed and less than 3 bytes in length.

        tagNumber = BERTag.verifyFormatInternal(berTlvArray, bOff);

        // if not a good tag, return will be negative, otherwise, return the tag
        // number
        if (tagNumber < 0) {
            return tagNumber;
        }

        offSet = BERTag.getTagSize(tagNumber);

        if (berTlvArray.length < (short) (bOff + offSet)) {
            return LENGTH_NOT_IN_LIMITS;
        }

        // Verify the Length format
        if (berTlvArray[(short) (bOff + offSet)] == (byte) 0xff
                || berTlvArray[(short) (bOff + offSet)] == INDEFINITE_FORMAT) {
            return MALFORMED_LENGTH;
        }

        if ((berTlvArray[(short) (bOff + offSet)] & EXTENDED_FORMAT) == EXTENDED_FORMAT) {
            sizeOfLength = (short) (((berTlvArray[(short) (bOff + offSet)] & LENGTH_VALUE_MASK) & 0x00ff) + (byte) 1);
            if (berTlvArray.length < (short) (bOff + offSet + sizeOfLength)) {
                return LENGTH_NOT_IN_LIMITS;
            }
            /* Since length above 32767 is not supported, if length is greater than 2,
             * All but the last 2 bytes of length should be 0, otherwise this TLV
             * is longer than what is supported.
             */
            if (sizeOfLength > 3) {
                for (i = 1; i < (short) (sizeOfLength - 2); i++) {
                    if (berTlvArray[(short) (bOff + offSet + i)] != (byte) 0) {
                        return BERTag.ILLEGAL_SIZE_VALUE;
                    }
                }
            }

            if (sizeOfLength > 2) {
                i = Util.getShort(berTlvArray, (short) (bOff + offSet + sizeOfLength - 2));
            } else {
                i = (short) (berTlvArray[(short) (bOff + offSet + 1)] & (short) 0x00ff);
            }

            // See if length value is negative
            if (i < 0) {
                return BERTag.ILLEGAL_SIZE_VALUE;
            }

            if ((berTlvArray[bOff] & CONSTRUCTED_TLV) != 0) {
                offSet += sizeOfLength;
            } else {
                offSet += (short) (sizeOfLength + i);
            }

        } else {
            // Not Extended Format
            if ((berTlvArray[bOff] & CONSTRUCTED_TLV) != 0) {
                offSet += 1;
            } else {
                offSet += (short) (1 + ((berTlvArray[(short) (bOff + offSet)])));
            }

        }

        return (short) (bOff + offSet);

    }

    /**
     * Internal non public function to determine the value size of this
     * Constructed TLV
     * 
     */
    short getLengthInternal(boolean isInnerTLV) {

        short lastTLV = (short) (numTLVs + numDeletedTLVs);
        short valueLen = 0;

        for (short i = 0; i < lastTLV; i++) {
            if (berTLV[i] != null) {
                if (berTLV[i] instanceof ConstructedBERTLV) {
                    valueLen += berTLV[i].getLengthInternal(true);
                } else {
                    valueLen += berTLV[i].size();
                }
            }
        }

        if (isInnerTLV) {
            valueLen += (short) (theBERTag.size() + BERTLV.getValueLengthSize(valueLen));
        }

        return valueLen;
    }

    /**
     * Internal non public function used to determine if the tlv being appended
     * or used during init is this tlv object. If the passed tlv is this,
     * infinite recursion would occur when calculating the length or size of
     * this tlv object.
     * 
     * @param aTLV:
     *            the tlv being checked to see if it is contained in this tlv
     *            object.
     * @return returns true if aTLV is contained in this, otherwise false.
     */
    boolean contains(BERTLV aTLV) {

        short lastTLV = (short) (numTLVs + numDeletedTLVs);

        if (this.equals(aTLV)) {
            return true;
        }

        for (short i = 0; i < lastTLV; i++) {
            if (berTLV[i] != null) {
                if (berTLV[i] instanceof ConstructedBERTLV) {
                    if (berTLV[i].contains(aTLV)) {
                        return true;
                    }
                } else {
                    if (berTLV[i].equals(aTLV)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }
}
