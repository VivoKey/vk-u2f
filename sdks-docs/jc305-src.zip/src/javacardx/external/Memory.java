/** 
 * Copyright (c) 1998, 2015, Oracle and/or its affiliates. All rights reserved.
 * 
 */

/*
 */
package javacardx.external;

/**
 * This class provides access to memory subsystems that are not directly
 * addressable, typically that of other contactless state machine handlers such
 * as Mifare<sup>TM</sup>. This class could also be used to access specialized
 * memory spaces such as that of a mass storage device.
 * 
 * @since 2.2.2
 */
public final class Memory {

    /**
     * MIFARE<sup>TM</sup> memory type constant. When a
     * <CODE>MemoryAccess</CODE> instance of this type is requested, the
     * <CODE>memorySize</CODE> and <CODE>memorySizeOffset</CODE> parameters
     * are ignored.
     * <p>
     * To use the <CODE>MemoryAccess</CODE> instance the following parameters
     * are applicable :
     * <ul>
     * <li><em>auth_key is an 8 byte password, other_len <=16</em>
     * <li><em>other_sector = 0, 0<= other_block <= 63 for MIFARE 1K chip and
     * 0<= other_block <= 255 for MIFARE 4K chip</em>
     * <li><em>security related errors return 0 on readData</em>
     * <li><em>security related errors return false on writeData</em>
     * </ul>
     * <p>
     * Note:
     * <ul>
     * <li><em>The actual external memory device servicing this memory type
     * maybe a MIFARE 1K chip or a MIFARE 4K chip.</em>
     * </ul>
     */
    public static final byte MEMORY_TYPE_MIFARE = (byte) 1;

    /**
     * Extended Memory Store type constant. When a <CODE>MemoryAccess</CODE>
     * instance of this type is requested, the <CODE>memorySize</CODE>
     * parameter contains the 32 bit number representing the size in bytes of
     * the memory access required and must be a positive number less than or
     * equal to <CODE>2,147,483,647 (2^31 - 1)</CODE>.
     * <p>
     * <p>
     * To use the <CODE>MemoryAccess</CODE> instance the following parameters
     * are applicable.
     * <ul>
     * <li><em>auth_key parameter is not required; it is ignored</em>
     * <li><em>other_len <= 32767</em>
     * <li><em>(other_sector, other_block) concatenated is a 32 bit address</em>
     * </ul>
     * <p>
     * Note.
     * <ul>
     * <li><em> To ensure optimal performance on all mass storage memory types
     * when accessing different areas of memory, use monotonically increasing
     * addresses.</em>
     * <li><em>Each time the </em><code>getMemoryAccessInstance</code><em> method is called
     * with this memory type parameter, a new memory access object to access a distinct memory chunk
     * is returned. A previously obtained memory access object cannot be used to access the
     * memory chunk obtained via this new memory access object. The new memory access object
     * cannot be used to access the memory chuck accessible via any previously allocated
     * memory access object.</em>
     * </ul>
     */
    public static final byte MEMORY_TYPE_EXTENDED_STORE = (byte) 2;

    /**
     * Only the Java Card runtime environment can use constructor.
     */
    Memory() {
    }

    /**
     * Creates a <code>MemoryAccess</code> object instance for the selected
     * memory subsystem.
     * 
     * @param memoryType
     *            the desired external memory subsystem. Valid codes listed in
     *            <CODE>MEMORY_TYPE_*</CODE> constants above, for example
     *            {@link #MEMORY_TYPE_MIFARE MEMORY_TYPE_MIFARE}.
     * @param memorySize
     *            the array containing the desired size in bytes, if applicable,
     *            in the external memory subsystem. Check the descriptions of
     *            the MEMORY_TYPE_* constants above for more details. The 32 bit
     *            number representing the memory size in bytes is formed by
     *            concatenating the two short values at offset
     *            <CODE>memorySizeOffset</CODE> (most significant 16 bits) and
     *            <CODE>memorySizeOffset+1</CODE> (least significant 16 bits)
     *            in this array
     * @param memorySizeOffset
     *            the offset within the <CODE>memorySize</CODE> array where
     *            the 32 bit memory size number in bytes is specified
     * @return the <code>MemoryAccess</code> object instance of the requested
     *         memory subsystem
     * @exception ExternalException
     *                with the following reason codes:
     *                <ul>
     *                <li><code>ExternalException.NO_SUCH_SUBSYSTEM</code> if
     *                the requested memory subsystem is not available.
     *                <li><code>ExternalException.INVALID_PARAM</code> if the
     *                <CODE>memorySize</CODE> parameter is invalid.
     *                </ul>
     */
    public static final MemoryAccess getMemoryAccessInstance(byte memoryType, short[] memorySize, short memorySizeOffset)
            throws ExternalException {
        return null;
    }
}
